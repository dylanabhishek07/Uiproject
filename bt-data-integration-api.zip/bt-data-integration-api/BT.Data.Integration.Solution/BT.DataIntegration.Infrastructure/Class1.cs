﻿namespace BT.DataIntegration.Infrastructure
{
    public class Class1
    {

    }
}