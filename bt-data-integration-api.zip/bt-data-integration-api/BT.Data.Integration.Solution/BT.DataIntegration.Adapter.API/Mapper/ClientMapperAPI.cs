﻿using AutoMapper;
using BT.DataIntegration.Adapter.API.Models;
using BT.DataIntegration.Domain.Model;

namespace BT.DataIntegration.Adapter.API.Mapper
{
    public class ClientMapperAPI : Profile
    {
        public ClientMapperAPI()
        {
            this.MapFromDomaintoApiModel();
        }

        private void MapFromDomaintoApiModel()
        {
            CreateMap<ClientDomain, ClientDetails>();
        }
    }
}
