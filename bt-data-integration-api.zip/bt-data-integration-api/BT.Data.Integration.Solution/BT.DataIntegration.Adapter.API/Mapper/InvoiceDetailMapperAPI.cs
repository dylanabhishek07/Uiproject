﻿using AutoMapper;
using BT.DataIntegration.Adapter.API.Models;
using BT.DataIntegration.Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Mapper
{
    public class InvoiceDetailMapperAPI : Profile
    {
        public InvoiceDetailMapperAPI()
        {
            this.MapFromApitoDomainModel();
            this.MapFromDomaintoApiModel();
        }

        private void MapFromDomaintoApiModel()
        {
        }

        private void MapFromApitoDomainModel()
        {
            CreateMap<InvoiceDetail, InvoiceDetailsDomain>();
        }
    }
}
