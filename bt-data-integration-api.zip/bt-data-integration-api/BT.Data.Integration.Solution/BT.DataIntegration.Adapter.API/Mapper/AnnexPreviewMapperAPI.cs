﻿using AutoMapper;
using BT.Data.Integration.Adapter.API.Models;
using BT.DataIntegration.Adapter.API.Models;
using BT.DataIntegration.Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Mapper
{
    public class AnnexPreviewMapperAPI:Profile
    {
        public AnnexPreviewMapperAPI()
        {
            MapFromDomaintoApiModel();
            MapFromApitoDomainModel();
        }

        private void MapFromApitoDomainModel()
        {
            CreateMap<ModifiedWorkSpaceDetails, ModifiedWorkSpaceDetailsDomain>();
            CreateMap<WorkSpaceAdjustedDetails, WorkSpaceAdjustedDataDomain>();
            CreateMap<AnnexPreviewFeeDetail, AnnexPreviewFeeDetailDomain>();
        }

        private void MapFromDomaintoApiModel()
        {
            CreateMap<BillingEntityWiseAnnexPreviewSummaryDomain, BillingEntityWiseAnnexPreviewSummary>();
            CreateMap<BillingEntityWiseAnnexPreviewDistributionDomain, BillingEntityWiseAnnexPreviewDistribution>();
            CreateMap<BillingEntityWiseAnnexPreviewDistributionDomainItems, BillingEntityWiseAnnexPreviewDistributionItems>();
        }
    }
}
