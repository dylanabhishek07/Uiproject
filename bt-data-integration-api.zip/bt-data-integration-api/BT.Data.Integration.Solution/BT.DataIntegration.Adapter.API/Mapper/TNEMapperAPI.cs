﻿using AutoMapper;
using BT.DataIntegration.Adapter.API.Models;
using BT.DataIntegration.Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Mapper
{
    public class TNEMapperAPI : Profile
    {
        public TNEMapperAPI()
        {
            this.MapFromDomaintoApiModel();
        }

        private void MapFromDomaintoApiModel()
        {
            CreateMap<TNEDetailDomain, TNEDetails>();
        }
    }
}
