﻿//using AutoMapper;

//using BT.DataIntegration.Adapter.API.Models;
//using BT.DataIntegration.Adapter.API.Models.Enums;
//using BT.DataIntegration.Domain.Model;
//using BT.DataIntegration.Domain.Model.Enums;

//namespace BT.DataIntegration.Adapter.API.Mapper
//{
//    public class WorkSpaceViewMapperAPI : Profile
//    {
//        public WorkSpaceViewMapperAPI()
//        {
//            this.MapFromApitoDomainModel();
//        }

//        private void MapFromApitoDomainModel()
//        {
         
          
//        }
//    }
//}
