﻿using AutoMapper;
using BT.DataIntegration.Adapter.API.Models;
using BT.DataIntegration.Adapter.API.Models.Enums;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Model.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Mapper
{
    public class TNEDataTransferMapperAPI : Profile
    {
        public TNEDataTransferMapperAPI()
        {
            this.MapFromApitoDomainModel();
            this.MapFromDomaintoApiModel();
        }

        private void MapFromDomaintoApiModel()
        {
            CreateMap<TNEDataTransferDomain,TNEDataTransferModel >();
            CreateMap<DataTypeDomainEnum,DataTypeEnum>();
        }

        private void MapFromApitoDomainModel()
        {
            CreateMap<TNEDataTransferModel, TNEDataTransferDomain>();
            CreateMap<DataTypeEnum, DataTypeDomainEnum>(); 
        }
    }
}
