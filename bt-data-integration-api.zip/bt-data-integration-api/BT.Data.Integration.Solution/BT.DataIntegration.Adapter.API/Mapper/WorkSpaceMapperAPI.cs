﻿using AutoMapper;
using BT.DataIntegration.Adapter.API.Models;
using BT.DataIntegration.Adapter.API.Models.Enums;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Model.Enums;

namespace BT.DataIntegration.Adapter.API.Mapper
{
    public class WorkSpaceMapperAPI:Profile
    {
        public WorkSpaceMapperAPI()
        {
            this.MapFromApitoDomainModel();
            this.MapFromDomaintoApiModel();
            MapFromSessionToApiModel();
        }

        private void MapFromApitoDomainModel()
        {
            CreateMap<WorkSpaceDetail, WorkSpaceDetailDomain>();
            CreateMap<WorkspaceItemTimeExpenseDetails, WorkspaceItemTimeDetailsDomain>();
        }

        private void MapFromDomaintoApiModel()
        {
            CreateMap<WorkSpaceDetailDomain,WorkSpaceDetail>();
            CreateMap<WorkspaceBillingItemDomain,WorkspaceBillingItemDetails>();
            CreateMap<WorkspaceItemTimeDetailsDomain, WorkspaceItemTimeExpenseDetails>();
            CreateMap<ModifiedWorkSpaceDetails, ModifiedWorkSpaceDetailsDomain>();
            CreateMap<WorkSpaceAdjustedDetails, WorkSpaceAdjustedDataDomain>();
            CreateMap<DataTypeEnum, DataTypeDomainEnum>();
            CreateMap<BillingActionEnum, BillingActionDomainEnum>();
        }

        private void MapFromSessionToApiModel()
        {
            CreateMap<WorkSpaceAdjustedDetails, WorkspaceBillingItemDetails>();
        }
    }
}
