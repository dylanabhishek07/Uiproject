﻿using AutoMapper;
using BT.DataIntegration.Adapter.API.Models;
using BT.DataIntegration.Adapter.API.Models.Enums;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Model.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Mapper
{
    internal class BillSummeryMapperAPI : Profile
    {
        public BillSummeryMapperAPI()
        {
            MapFromDomaintoApiModel();
            MapFromApitoDomainModel();
        }

        private void MapFromApitoDomainModel()
        {
            CreateMap<ModifiedWorkSpaceDetails, ModifiedWorkSpaceDetailsDomain>();
            CreateMap<WorkSpaceAdjustedDetails, WorkSpaceAdjustedDataDomain>();
            CreateMap<BillsummeryEngagmentEAFDeatils,BillSummeryEAFDetailsDomain > ();
            CreateMap<BillSummeryEAFDetails, BillSummeryEAFDetailsDomain>()
                .ForMember(dest => dest.WorkSpaceDetailMasterGId, opt => opt.MapFrom(src => src.WorkspaceMasterGid));
        }

        private void MapFromDomaintoApiModel()
        {
            CreateMap<EngagementSummeryConsolidatedDomain, EngagementSummeryConsolidated>();
            CreateMap<EngagementRevenueDomain, EngagementRevenue>();
            CreateMap<EngagementRevenueItemsDomian, EngagementRevenueItems>();
            CreateMap<BillingActionDomainEnum, BillingActionEnum>();
            CreateMap<BillingEntityWiseInvoiceFeeDistributionDomain, BillingEntityWiseInvoiceFeeDistribution>();
            CreateMap<EntityInvoiceDetailDomain, EntityInvoiceDetail>();
            CreateMap<BillSummeryEAFDetailsDomain,BillsummeryEngagmentEAFDeatils > ();
        }
    }
}
