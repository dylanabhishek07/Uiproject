﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Helper
{
    public  static class Constant
    {
        public static readonly string WORKSPACE_SESSION_KEY = "WorkspaceUIData";
    }
}
