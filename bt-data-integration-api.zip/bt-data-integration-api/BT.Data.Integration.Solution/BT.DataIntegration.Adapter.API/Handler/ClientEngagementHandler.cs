﻿using AutoMapper;
using BT.DataIntegration.Adapter.API.Contracts;
using BT.DataIntegration.Adapter.API.Models;
using BT.DataIntegration.Domain.Ports.In;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Handler
{
    public class ClientEngagementHandler: IClientEngagementHandler
    {
        private IClientService _clientService;
        private IMapper _mapper;

        public ClientEngagementHandler(IClientService clientService, IMapper mapper)
        {
            _clientService = clientService;
            _mapper = mapper;
        }

        public async Task<List<ClientDetails>> GetClientByIndex(int index, int count)
        {
            var clients = new List<ClientDetails>();
            var result = await _clientService.GetClientByIndex(index, count);
            if (result.Any())
            {
                clients = _mapper.Map<List<ClientDetails>>(result.ToList());
            }
            return clients;
        }

        public async Task<List<EngagementDetails>> GetClientSpecificEngagementsByIndex(string clientid, int index, int count)
        {
            var engagements = new List<EngagementDetails>();
            var result = await _clientService.GetClientSpecificEngagementsByIndex(clientid,index,count);
            if (result.Any())
            {
                engagements = _mapper.Map<List<EngagementDetails>>(result.ToList());
            }
            return engagements;
        }
    }
}
