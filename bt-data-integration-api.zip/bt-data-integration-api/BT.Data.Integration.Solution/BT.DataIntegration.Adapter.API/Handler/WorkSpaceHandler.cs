﻿using AutoMapper;
using BT.DataIntegration.Adapter.API.Contracts;
using BT.DataIntegration.Adapter.API.Models;
using BT.DataIntegration.Adapter.API.Models.Enums;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Ports.In;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Handler
{
    public class WorkSpaceHandler : IWorkSpaceHandler
    {
        private IWorkSpaceService _workSpaceService;
        private IMapper _mapper;

        public WorkSpaceHandler(IWorkSpaceService workSpaceService, IMapper mapper)
        {
            _workSpaceService = workSpaceService;
            _mapper = mapper;
        }

        public async Task<Guid> AddWorkSpace(WorkSpaceDetail wrkSpcDetail)
        {

            Guid result = Guid.Empty;
            if (wrkSpcDetail != null)
            {
                var workSpaceDetailDomain = _mapper.Map<WorkSpaceDetailDomain>(wrkSpcDetail);
                result = await _workSpaceService.AddWorkSpace(workSpaceDetailDomain);
            }
            return result;
        }

        public async Task<Guid> CreateAdhocGuid(Guid wrkSpaceGuid, string createdBy)
        {
            Guid result = Guid.Empty;
            if (wrkSpaceGuid != Guid.Empty)
            {
                result = await _workSpaceService.CreateAdhocGuid(wrkSpaceGuid, createdBy);
            }
            return result;
        }

        public async Task<List<WorkSpaceDetail>> CheckForExistingWorkSpace(string ClientEngagementMapGIds)
        {

            var workSpaceDetail = new List<WorkSpaceDetail>();
            if (!string.IsNullOrWhiteSpace(ClientEngagementMapGIds))
            {
                var result = await _workSpaceService.CheckForExistingWorkSpace(ClientEngagementMapGIds);
                if (result != null && result.Any())
                {
                    workSpaceDetail = _mapper.Map<List<WorkSpaceDetail>>(result.ToList());
                }
            }
            return workSpaceDetail;
        }

        public async Task<IEnumerable<TNEDetails>> GetTimeDetails(string workSpaceGuid)
        {
            var tneDetail = new List<TNEDetails>();
            if (!string.IsNullOrWhiteSpace(workSpaceGuid))
            {
                var result = await _workSpaceService.GetTimeDetails(workSpaceGuid);
                if (result != null && result.Any())
                {
                    tneDetail = _mapper.Map<List<TNEDetails>>(result.ToList());
                }
            }
            return tneDetail;
        }

        public async Task<bool> IsBillingDataReady(string workspaceId)
        {
            return await _workSpaceService.IsBillingDataReady(workspaceId);
        }

        public async Task<bool> UpdateWorkSpace(List<ModifiedWorkSpaceDetails> wrkSpaceAllRecords)
        {

            if (wrkSpaceAllRecords.Any())
            {
                return await _workSpaceService.UpdateWorkSpace(_mapper.Map<List<ModifiedWorkSpaceDetailsDomain>>(wrkSpaceAllRecords));
            }
            else { return false; }

        }

        public async Task<List<TNEDataTransferModel>> UpdateTNEMapping(List<TNEDataTransferModel> tneDataTransferModel)
        {
            var modifiedTNEMappings = new List<TNEDataTransferModel>();
            if (tneDataTransferModel != null && tneDataTransferModel.Any())
            {
                var tneDataTransferDomain = _mapper.Map<List<TNEDataTransferDomain>>(tneDataTransferModel);
                var result = await _workSpaceService.UpdateTNEMapping(tneDataTransferDomain);
                if (result.Any())
                {
                    modifiedTNEMappings = _mapper.Map<List<TNEDataTransferModel>>(result.ToList());
                }
            }
            return modifiedTNEMappings;
        }

        public async Task<List<WorkspaceBillingItemDetails>> HandleWorkspaceBillingDetails(string workspaceGid, WorkSpaceUIDetails workspaceSession)
        {
            List<WorkspaceBillingItemDetails> mappedBillingItems = new List<WorkspaceBillingItemDetails>();
            if (!string.IsNullOrEmpty(workspaceGid))
            {
                var workspaceBillingItem = await _workSpaceService.GetWorkSpaceBillingDetails(workspaceGid);
                mappedBillingItems = _mapper.Map<List<WorkspaceBillingItemDetails>>(workspaceBillingItem);
                if (workspaceSession != null && workspaceSession.ModifiedWorkSpaceDetails != null && workspaceSession.ModifiedWorkSpaceDetails.Any() &&
                    !string.IsNullOrEmpty(workspaceSession.WorkspaceMasterGid) && workspaceSession.WorkspaceMasterGid.Equals(workspaceGid, StringComparison.OrdinalIgnoreCase))
                {
                    workspaceSession.ModifiedWorkSpaceDetails.ForEach(sessionAdjustedDet =>
                    {
                        var matchedBillingItem = mappedBillingItems.FirstOrDefault(item => item.GId.Equals(sessionAdjustedDet.GId));
                        if (matchedBillingItem != null)
                            matchedBillingItem = _mapper.Map<WorkSpaceAdjustedDetails, WorkspaceBillingItemDetails>(sessionAdjustedDet, matchedBillingItem);
                    });

                }
                mappedBillingItems.Select(item => 
                {
                    if (item.DataType == DataTypeEnum.NonBillable)
                    {
                        item.BillingAction = BillingActionEnum.AlreadyBilled;
                    }
                    else
                    {
                        item.BillingAction = BillingActionEnum.InvoiceNow;
                    }
                    return item; 
                }).ToList();
            }
            return mappedBillingItems;
        }

        public async Task<List<WorkspaceItemTimeExpenseDetails>> HandelConsolidatedTimeDetailsForItems(List<WorkspaceItemTimeExpenseDetails> workspaceItemDetails)
        {
            var consolidatedTimeDetails = await _workSpaceService.GetProcessedTimeDetailsForItems(_mapper.Map<List<WorkspaceItemTimeDetailsDomain>>(workspaceItemDetails));

            return _mapper.Map<List<WorkspaceItemTimeExpenseDetails>>(consolidatedTimeDetails);
        }


    }
}
