﻿using Microsoft.AspNetCore.Http;
using System.Text.Json;

namespace BT.DataIntegration.Adapter.API.Handler
{
    public static class SessionHandler
    {

        public static async Task SetObjectInSession<T>( this ISession session, T value, string key) where T : class
        {
            session.Set(key, JsonSerializer.SerializeToUtf8Bytes(value));
            await session.CommitAsync();
        }

        public static async Task<T> GetObjectFromSession<T>(this ISession session, string key) where T : class
        {
            T? value = null;
            byte[] resultByte;
            await session.LoadAsync();
            session.TryGetValue(key, out resultByte);
            if (resultByte != null && resultByte.Length > 0)
                value = JsonSerializer.Deserialize<T>(resultByte);

            return value;
        }
    }
}
