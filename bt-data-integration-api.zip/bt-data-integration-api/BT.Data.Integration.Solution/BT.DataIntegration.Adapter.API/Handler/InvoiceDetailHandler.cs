﻿using AutoMapper;
using BT.DataIntegration.Adapter.API.Contracts;
using BT.DataIntegration.Adapter.API.Models;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Ports.In;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Handler
{
    public class InvoiceDetailHandler : IInvoiceDetailHandler
    {
        IInvoiceDetailsService _invoiceDetailsService;
        IMapper _mapper;
        public InvoiceDetailHandler(IInvoiceDetailsService invoiceDetailsService, IMapper mapper)
        {
            _invoiceDetailsService = invoiceDetailsService;
            _mapper = mapper;
        }

        public async Task<int> SaveInvoiceDetails(List<InvoiceDetail> invoiceDetails)
        {
            int result = 0;
            if (invoiceDetails != null && invoiceDetails.Any())
            {
                result = await _invoiceDetailsService.SaveInvoiceDetails(_mapper.Map<List<InvoiceDetailsDomain>>(invoiceDetails));
            }
            return result;
        }
    }
}
