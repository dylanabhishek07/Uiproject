﻿using AutoMapper;
using BT.Data.Integration.Adapter.API.Models;
using BT.DataIntegration.Adapter.API.Contracts;
using BT.DataIntegration.Adapter.API.Models;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Ports.In;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Handler
{
    public class AnnexPreviewHandler : IAnnexPreviewHandler
    {
        IAnnexPreviewService _annexPreviewService;
        IMapper _mapper;

        public AnnexPreviewHandler(IAnnexPreviewService annexPreviewService, IMapper mapper)
        {
            _annexPreviewService = annexPreviewService;
            _mapper = mapper;
        }
        public async Task<BillingEntityWiseAnnexPreviewSummary> GetBillingEntityWiseAnnexPreviewData(string workspaceMasterGId, WorkSpaceUIDetails workspaceSession)
        {
            BillingEntityWiseAnnexPreviewSummary annexPreviewSummary = new BillingEntityWiseAnnexPreviewSummary();
            if (workspaceSession != null && workspaceSession.ModifiedWorkSpaceDetails.Any())
            {
                var result = await _annexPreviewService.GetBillingEntityWiseAnnexPreviewData(workspaceMasterGId, _mapper.Map<List<ModifiedWorkSpaceDetailsDomain>>(workspaceSession.ModifiedWorkSpaceDetails));
                annexPreviewSummary = _mapper.Map<BillingEntityWiseAnnexPreviewSummary>(result);
            }
            return annexPreviewSummary;
        }

        public async Task<int> SaveAnnexPreviewFeeDetails(List<AnnexPreviewFeeDetail> feeDetails)
        {
            int result = 0;
            if (feeDetails != null && feeDetails.Any())
            {
                result = await _annexPreviewService.SaveFeeDetails(_mapper.Map<List<AnnexPreviewFeeDetailDomain>>(feeDetails));
            }
            return result;
        }
    }
}
