﻿using AutoMapper;
using BT.DataIntegration.Adapter.API.Contracts;
using BT.DataIntegration.Adapter.API.Helper;
using BT.DataIntegration.Adapter.API.Models;
using BT.DataIntegration.Adapter.API.Models.Enums;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Ports.In;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Handler
{
    public class BillSummeryHandler : IBillSummeryHandler
    {
        IBillSummeryService _billSummeryService;
        IMapper _mapper;

        public BillSummeryHandler(IBillSummeryService billSummeryService, IMapper mapper)
        {
            _billSummeryService = billSummeryService;
            _mapper = mapper;
        }

        public async Task<BillingEntityWiseInvoiceFeeDistribution> GetBillingEntitySummery(string workspaceMasterGId, WorkSpaceUIDetails workspaceSession)
        {
            BillingEntityWiseInvoiceFeeDistribution invoiceDistribution = new BillingEntityWiseInvoiceFeeDistribution();
            if (workspaceSession != null && workspaceSession.ModifiedWorkSpaceDetails.Any())
            {
                var result = await _billSummeryService.GetBillingEntitySummeryDetails(workspaceMasterGId, _mapper.Map<List<ModifiedWorkSpaceDetailsDomain>>(workspaceSession.ModifiedWorkSpaceDetails));
                invoiceDistribution = _mapper.Map<BillingEntityWiseInvoiceFeeDistribution>(result);
            }
            return invoiceDistribution;

        }

        public async Task<EngagementSummeryConsolidated> GetEngagementSummery(string workspaceMasterGId)
        {
            EngagementSummeryConsolidated summeryConsolidated = new EngagementSummeryConsolidated();
            var result = await _billSummeryService.GetEngagementSummeryDetails(workspaceMasterGId);

            summeryConsolidated = _mapper.Map<EngagementSummeryConsolidatedDomain, EngagementSummeryConsolidated>(result, summeryConsolidated);

            return summeryConsolidated;
        }



        public async Task<BillSummeryEAFDetails> GetEAFCalculationDetails(string workspaceMasterGId)
        {
            BillSummeryEAFDetails _detais = new BillSummeryEAFDetails();

            var result = await _billSummeryService.GetEAFCalculationDetails(workspaceMasterGId);
            if (result != null && result.Count > 0)
            {
                _detais.WorkspaceMasterGid = workspaceMasterGId;
                _detais.BillsummeryEngagmentEAFDeatils = _mapper.Map<List<BillsummeryEngagmentEAFDeatils>>(result);
            }

            return _detais;
        }

        public async Task SaveEAFCalculationDetails(BillSummeryEAFDetails billSummeryEafDetails)
        {
            if (billSummeryEafDetails != null && billSummeryEafDetails.BillsummeryEngagmentEAFDeatils != null && billSummeryEafDetails.BillsummeryEngagmentEAFDeatils.Count > 0)
            {
                var billSummeryEngagementEafDetails = billSummeryEafDetails.BillsummeryEngagmentEAFDeatils;
                var billSummeryEngagementEafDetailsDomain = _mapper.Map<List<BillSummeryEAFDetailsDomain>>(billSummeryEngagementEafDetails);
                billSummeryEngagementEafDetailsDomain = _mapper.Map<BillSummeryEAFDetails, List<BillSummeryEAFDetailsDomain>>(billSummeryEafDetails, billSummeryEngagementEafDetailsDomain);
                await _billSummeryService.SaveEAFCalculationDetails(billSummeryEngagementEafDetailsDomain);
            }

        }

        public async Task<FeeSharingResponse> GetFeeSharingDetails(FeeSharingRequest feeSharingRequest)
        {
            FeeSharingResponse feeSharingResponse = new FeeSharingResponse();
            if (feeSharingRequest != null && feeSharingRequest.EngageMentConsolidatedRevenues.Any() && feeSharingRequest.EntityInvoiceDetails.Any())
            {
                float effectiveEngagementCoefficient = 0;
                if (feeSharingRequest.FeeSharingType == FeeSharingTypeEnum.EqualEAF)
                    effectiveEngagementCoefficient = CalculateEqualEAFCoefficent(feeSharingRequest.NetTotalNSR, feeSharingRequest.NetTotalExpense, feeSharingRequest.TotalInvoiveFee);
                else if (feeSharingRequest.FeeSharingType == FeeSharingTypeEnum.Prorata)
                    effectiveEngagementCoefficient = CalculateProrataCoefficient(feeSharingRequest.NetTotalANSR, feeSharingRequest.NetTotalExpense, feeSharingRequest.TotalInvoiveFee);

                feeSharingResponse = CalculateEngagementFeeSharingDetails(effectiveEngagementCoefficient, feeSharingRequest);
                feeSharingResponse.WorkspaceGid = feeSharingRequest.WorkspaceMasterGid;
            }

            return feeSharingResponse;
        }
        private FeeSharingResponse CalculateEngagementFeeSharingDetails(float engagementCoefficient, FeeSharingRequest feeSharingRequest)
        {
            FeeSharingResponse feeSharingResponse = new FeeSharingResponse();
            if (feeSharingRequest.EngageMentConsolidatedRevenues != null && feeSharingRequest.EngageMentConsolidatedRevenues.Any())
            {
                feeSharingRequest.EngageMentConsolidatedRevenues.ForEach(engagement =>
                {
                    EngagementWiseFeeSharingDetails feeSharingDetails = new EngagementWiseFeeSharingDetails();
                    if (feeSharingRequest.FeeSharingType == FeeSharingTypeEnum.EqualEAF)
                        feeSharingDetails.TotalInvoiceAllocation = engagementCoefficient * (engagement.TotalNSR + engagement.Expense);
                    else if (feeSharingRequest.FeeSharingType == FeeSharingTypeEnum.Prorata)
                        feeSharingDetails.TotalInvoiceAllocation = engagementCoefficient * (engagement.TotalANSR + engagement.Expense);
                    feeSharingDetails.EngagementId = engagement.EngagementId;
                    feeSharingDetails.EntityInvoiceDetails = CalculateBillingEntityFeeSharingDetails(feeSharingRequest.EntityInvoiceDetails, feeSharingDetails.TotalInvoiceAllocation, feeSharingRequest.TotalInvoiveFee);
                    feeSharingResponse.EngagementWiseFeeSharingDetails.Add(feeSharingDetails);
                });
            }
            return feeSharingResponse;
        }

        private List<EntityInvoiceDetail> CalculateBillingEntityFeeSharingDetails(List<EntityInvoiceDetail> requestEntityInvoiceDetails, float invoiceAllocationForEngagement, float totalInvoice)
        {
            List<EntityInvoiceDetail> responseEntityInvoiceDetails = new List<EntityInvoiceDetail>();
            if (requestEntityInvoiceDetails != null && requestEntityInvoiceDetails.Any())
            {
                requestEntityInvoiceDetails.ForEach(entity =>
                {
                    EntityInvoiceDetail entityInvoiceDetail = new EntityInvoiceDetail();
                    if (totalInvoice > 0)
                        entityInvoiceDetail.InvoiceFee = invoiceAllocationForEngagement * (entity.InvoiceFee / totalInvoice);
                    entityInvoiceDetail.BillingEntityId = entity.BillingEntityId;
                    entityInvoiceDetail.BillingEntityName = entity.BillingEntityName;
                    responseEntityInvoiceDetails.Add(entityInvoiceDetail);
                });

            }
            return responseEntityInvoiceDetails;
        }

        private float CalculateEqualEAFCoefficent(float nsr, float expense, float totalInvoice)
        {
            float result = 0;
            if (nsr > 0 || expense > 0)
                result = totalInvoice / (nsr + expense);
            return result;
        }


        private float CalculateProrataCoefficient(float ansr, float expense, float totalInvoice)
        {
            float result = 0;
            if (ansr > 0 || expense > 0)
                result = totalInvoice / (ansr + expense);
            return result;
        }
    }
}
