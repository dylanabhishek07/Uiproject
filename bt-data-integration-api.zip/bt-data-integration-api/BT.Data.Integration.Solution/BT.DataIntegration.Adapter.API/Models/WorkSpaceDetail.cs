﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Models
{
    public class WorkSpaceDetail
    {
        public Guid? WorkSpaceGuid { get; set; }
        public string? WorkspaceName { get; set; }
        public string? EngagementIds { get; set; }
        public List<string>? ClientEngagementMapGIds { get; set; }
        public string? BeOneWorkFlowId { get; set; }
        public string? CreatedBy { get; set; }
        
    }
}
