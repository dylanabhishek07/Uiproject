﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Models.Enums
{
    public enum BillingStatusEnum
    {
        None=0,
        ToBeBilled=1,
        NotBillable=2,
        AlreadyBilled=3
    }
}
