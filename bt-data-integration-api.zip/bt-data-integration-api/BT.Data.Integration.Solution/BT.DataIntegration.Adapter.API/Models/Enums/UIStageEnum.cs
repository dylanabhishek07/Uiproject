﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Models.Enums
{
    public enum UIStageEnum
    {
        None=0,
        Home=1,
        Workspace=2,
        Summery=3,
        Invoice=4,
        Complete=5

    }
}
