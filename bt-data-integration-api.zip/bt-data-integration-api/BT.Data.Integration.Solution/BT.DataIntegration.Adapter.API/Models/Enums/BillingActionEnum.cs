﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Models.Enums
{
    public enum BillingActionEnum
    {
        None=0,
        InvoiceNow=1,
        CarryForward=2,
        NotBillable=3,
        AlreadyBilled=4,
        Miscoded=5
    }
}
