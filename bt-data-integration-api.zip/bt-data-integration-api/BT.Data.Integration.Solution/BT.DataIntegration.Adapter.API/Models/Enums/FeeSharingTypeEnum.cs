﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Models.Enums
{
    public enum FeeSharingTypeEnum
    {
        None=0,
        Prorata=1,
        EqualEAF=2,
        Custom=3
    }
}
