﻿using BT.DataIntegration.Adapter.API.Models.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Models
{
    public class WorkspaceBillingItemDetails: WorkSpaceAdjustedDetails
    {
        public string? BillingItemId { get; set; }
        public BillingActionEnum BillingAction { get; set; } = BillingActionEnum.InvoiceNow;
        public DataTypeEnum DataType { get; set; }
        //public string ProcessedTnEIds { get; set; }
        public string? ProductId { get; set; }
        public string? Product { get; set; }
        public string? ProductType { get; set; }
        public int ActivityId { get; set; }
        public string? ActivityDescription { get; set; }
        public string ExpenseReferenceId { get; set; }
        public string? ClientName { get; set; }
        public string? ClientId { get; set; }
       // public BillingStatusEnum BillingStatus { get; set; }
        public string BillingStatus { get; set; }  
        public string? Employee { get; set; }
        public string? EmployeeId { get; set; }
        public string? ProductStatus { get; set; }   
        public string? BillingType { get; set; }
        public string? FeeType { get; set; }
        public float Hours { get; set; }
        public float NSR { get; set; }
        public float ANSR { get; set; }
        public float ExpenseAmount { get; set; }
        public float? InvoiceFee { get; set; }
        public string? Currency { get; set; }
        public string? ServiceDescription { get; set; }
        public string? BillingEntity { get; set; } 
        public string? CostCenter { get; set; }
        public string? OosNr { get; set; }
        public string? GbtRef { get; set; }
        public string? GbtStatus { get; set; }
        public string? InvoiceVendor { get; set; }
        public string? InvoiceReference { get; set; }


    }
}
