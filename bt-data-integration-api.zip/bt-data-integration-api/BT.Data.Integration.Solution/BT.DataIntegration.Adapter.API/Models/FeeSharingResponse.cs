﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Models
{
    public class FeeSharingResponse
    {
        public FeeSharingResponse()
        {
            this.EngagementWiseFeeSharingDetails = new List<EngagementWiseFeeSharingDetails>();
        }
        public string WorkspaceGid { get; set; }

        public List<EngagementWiseFeeSharingDetails>  EngagementWiseFeeSharingDetails { get; set; }
    }

    public class EngagementWiseFeeSharingDetails
    {
        public EngagementWiseFeeSharingDetails()
        {
            this.EntityInvoiceDetails = new List<EntityInvoiceDetail>();
        }
        public string EngagementId { get; set; }
        public float TotalInvoiceAllocation { get; set; }

        public List<EntityInvoiceDetail> EntityInvoiceDetails { get; set; }
    }
}
