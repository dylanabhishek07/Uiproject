﻿using BT.DataIntegration.Adapter.API.Models.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Models
{
    public  class TNEDataTransferModel
    {
        public Guid? TransferToWorkspaceGId { get; set; }
        public bool? IsSourceCategory { get; set; }
        public DataTypeEnum? TransferToDataCategory { get; set; }
        public List<string>? FinalProcessedTnEList { get; set; }
    }
}
