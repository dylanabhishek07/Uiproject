﻿using BT.DataIntegration.Adapter.API.Models.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Models
{
    public class EngagementSummeryConsolidated
    {
        public EngagementSummeryConsolidated()
        {
            this.EngagementRevenueList = new List<EngagementRevenue>();
        }
        public string WorkSpaceMasterGid { get; set; }
        public float TotalNSR { get; set; }
        public float TotalANSR { get; set; }
        public float TotalEAF { get; set; }
        public float NetTotalNSR { get; set; }
        public float NetTotalANSR { get; set; }
        public float TotalExpense { get; set; }
        public List<EngagementRevenue> EngagementRevenueList { get; set; }
    }

    public class EngagementRevenue
    {
        public EngagementRevenue()
        {
            this.EngagementItems = new List<EngagementRevenueItems>();
            this.EngagementItems.Add(new EngagementRevenueItems() { BillingAction = BillingActionEnum.InvoiceNow });
            this.EngagementItems.Add(new EngagementRevenueItems() { BillingAction = BillingActionEnum.CarryForward });
            this.EngagementItems.Add(new EngagementRevenueItems() { BillingAction = BillingActionEnum.NotBillable });
            this.EngagementItems.Add(new EngagementRevenueItems() { BillingAction = BillingActionEnum.AlreadyBilled });
            this.EngagementItems.Add(new EngagementRevenueItems() { BillingAction = BillingActionEnum.Miscoded });
        }

        public string EngagementId { get; set; }
        public float TotalNSR { get; set; }
        public float TotalANSR { get; set; }
        public float EAF { get; set; }
        public float TotalExpense { get; set; }

        public float NetTotalNSR { get; set; } /// Excluding Miscoded and carryforward
        public float NetTotalANSR { get; set; } /// Excluding Miscoded and carryforward
        public List<EngagementRevenueItems> EngagementItems { get; set; }
    }

    public class EngagementRevenueItems
    {
        public BillingActionEnum BillingAction { get; set; }
        public float NSR { get; set; } = 0;
        public float ANSR { get; set; } = 0;
        public float Expense { get; set; } = 0;
    }
}
