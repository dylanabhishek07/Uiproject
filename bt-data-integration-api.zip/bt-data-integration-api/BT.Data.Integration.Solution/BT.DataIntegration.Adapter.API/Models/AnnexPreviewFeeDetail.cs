﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Models
{
    public class AnnexPreviewFeeDetail
    {
        public Guid WorkSpaceRowGId { get; set; }
        public string? FeeText { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; } = DateTime.Now;
        public string? ModifiedBy { get; set; }
        public DateTime? ModifiedDateTime { get; set; } = DateTime.Now;
    }
}
