﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Models
{
    public class BillingEntityWiseInvoiceFeeDistribution
    {
        public string WorkSpaceMasterGid { get; set; }
        public float? TotalInvoiceFee { get; set; }
        public List<EntityInvoiceDetail> EntityInvoiceDetails { get; set; }
    }

    public class EntityInvoiceDetail
    {
        public string? BillingEntityId { get; set; }
        public string? BillingEntityName { get; set; }
        public float InvoiceFee { get; set; }
    }
}
