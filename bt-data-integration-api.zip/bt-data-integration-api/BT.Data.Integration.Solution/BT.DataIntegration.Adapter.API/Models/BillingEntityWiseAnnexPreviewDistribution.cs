﻿namespace BT.Data.Integration.Adapter.API.Models
{
    public class BillingEntityWiseAnnexPreviewSummary
    {
        public string WorkSpaceMasterGid { get; set; }
        public List<BillingEntityWiseAnnexPreviewDistribution> AnnexPreviewDistribution { get; set; }
    }

    public class BillingEntityWiseAnnexPreviewDistribution
    {
        public string BillingEntityId { get; set; }
        public string BillingEntityName { get; set;}
        public float  TotalFee{ get; set;}
        public List<BillingEntityWiseAnnexPreviewDistributionItems> AnnexPreviewDistributionItems { get; set; }
    }

    public class BillingEntityWiseAnnexPreviewDistributionItems
    {
        public string ProductID { get; set; }
        public string ServiceDescription { get; set;}
        public float InvoiceFee { get; set; }
        public string OOSNR { get; set; }
        public string CostCenter { get; set; }
        public string GBTRef { get; set; }
        public string FeeText { get; set; }

    }
}