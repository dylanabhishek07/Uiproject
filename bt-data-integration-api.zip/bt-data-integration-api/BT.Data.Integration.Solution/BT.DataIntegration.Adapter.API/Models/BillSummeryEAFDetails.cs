﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Models
{
    public class BillSummeryEAFDetails
    {
        public string WorkspaceMasterGid { get; set; }
        public List<BillsummeryEngagmentEAFDeatils> BillsummeryEngagmentEAFDeatils { get; set; }
    }

    public class BillsummeryEngagmentEAFDeatils
    {
        public string EngagementId { get; set; }
        public float ETDNSR { get; set; }
        public float ETDEXP { get; set; }
        public float ETDInvoices { get; set; }
        public float NUI { get; set; }
        public float ETCNSR { get; set; }
        public float ETCExpenses { get; set; }
        public float ETCSales { get; set; }
        public bool ETCToBeProcessed { get; set; }
        public bool IsDeleted { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
    }
}
