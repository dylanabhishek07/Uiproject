﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Models
{
    public class EngagementDetails
    {
        public Guid GId { get; set; }
        public string EngagementId { get; set; }
    }
}
