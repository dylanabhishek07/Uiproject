﻿using BT.DataIntegration.Adapter.API.Models.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Models
{
    public class WorkSpaceUIDetails
    {
        public UIStageEnum Stage { get; set; }
        public string WorkspaceMasterGid { get; set; }
        public string WorkspaceName { get; set; }
        public string ClientName { get; set; }
        public string ClientGId { get; set; }
        public List<string> Engagements { get; set; }
        public List<ModifiedWorkSpaceDetails> ModifiedWorkSpaceDetails { get; set; }

    }
}
