﻿using BT.DataIntegration.Adapter.API.Models.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Models
{
    public class WorkSpaceAdjustedDetails
    {
        public Guid? GId { get; set; }
        public DataTypeEnum WorkSpaceDataType { get; set; }
        public BillingActionEnum AdjustedBillingAction { get; set; }
        public float? AdjustedInvoiceFee { get; set; }
        public string? AdjustedCurrency { get; set; }
        public string? AdjustedDescription { get; set; }
        public string? AdjustedBillingEntity { get; set; }
        public string? AdjustedBillingEntityId { get; set; }
        public string? AdjustedCostCenter { get; set; }
        public string? AdjustedOOSNR { get; set; }
        public string? AdjustedGBTStatus { get; set; }
        public string? AdjustedGBTRef { get; set; }
        public string? ModifiedBy { get; set; }
        public DateTime? ModifiedDateTime { get; set; } = DateTime.Now;
    }
}
