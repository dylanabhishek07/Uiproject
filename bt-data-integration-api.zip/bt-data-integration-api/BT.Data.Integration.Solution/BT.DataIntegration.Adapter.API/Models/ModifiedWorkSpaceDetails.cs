﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Models
{
    public class ModifiedWorkSpaceDetails: WorkSpaceAdjustedDetails
    {
        public float InvoiceFee { get; set; }
        public string? BillingEntityName { get; set; }
        public string? BillingEntityId { get; set; }
        public int BillingActionId { get; set; }
        public string ProductID { get; set; }
        public string ServiceDescription { get; set; }
        public string OOSNR { get; set; }
        public string CostCenter { get; set; }
        public string GBTRef { get; set; }
    }
}
