﻿using BT.DataIntegration.Adapter.API.Models.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Models
{
    public class FeeSharingRequest
    {
        public FeeSharingRequest()
        {
            this.EngageMentConsolidatedRevenues = new List<EngageMentConsolidatedRevenue>();
        }
        public string WorkspaceMasterGid { get; set; }
        public FeeSharingTypeEnum FeeSharingType { get; set; }
        public float NetTotalNSR { get; set; }

        public float NetTotalANSR { get; set; }

        public float NetTotalExpense { get; set; }

        public float TotalInvoiveFee { get; set; }

        public List<EngageMentConsolidatedRevenue> EngageMentConsolidatedRevenues { get; set; }

        public List<EntityInvoiceDetail> EntityInvoiceDetails { get; set; }

    }


    public class EngageMentConsolidatedRevenue
    {
        public string EngagementId { get; set; }
        public float TotalNSR { get; set; }

        public float TotalANSR { get; set; }

        public float Expense { get; set; }  


    }

}
