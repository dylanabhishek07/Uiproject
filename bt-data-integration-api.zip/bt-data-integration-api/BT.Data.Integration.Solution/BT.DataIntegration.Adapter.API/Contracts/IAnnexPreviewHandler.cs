﻿using BT.Data.Integration.Adapter.API.Models;
using BT.DataIntegration.Adapter.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Contracts
{
    public interface IAnnexPreviewHandler
    {
        Task<BillingEntityWiseAnnexPreviewSummary> GetBillingEntityWiseAnnexPreviewData(string workspaceMasterGId, WorkSpaceUIDetails workspaceSession);
        Task<int> SaveAnnexPreviewFeeDetails(List<AnnexPreviewFeeDetail> feeDetails);
    }
}
