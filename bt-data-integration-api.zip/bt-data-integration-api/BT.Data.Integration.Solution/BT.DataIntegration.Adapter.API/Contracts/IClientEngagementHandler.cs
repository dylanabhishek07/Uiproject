﻿using BT.DataIntegration.Adapter.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Contracts
{
    public interface IClientEngagementHandler
    {
        Task<List<ClientDetails>> GetClientByIndex(int index, int count);
        Task<List<EngagementDetails>> GetClientSpecificEngagementsByIndex(string clientid, int index, int count);
    }
}
