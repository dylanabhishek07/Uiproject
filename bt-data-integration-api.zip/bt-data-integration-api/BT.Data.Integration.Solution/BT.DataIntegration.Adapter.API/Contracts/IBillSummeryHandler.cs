﻿using BT.DataIntegration.Adapter.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Contracts
{
    public interface IBillSummeryHandler
    {
        public Task<EngagementSummeryConsolidated> GetEngagementSummery(string workspaceMasterGId);
        Task<BillingEntityWiseInvoiceFeeDistribution> GetBillingEntitySummery(string workspaceMasterGId, WorkSpaceUIDetails workspaceSession);
        Task<FeeSharingResponse> GetFeeSharingDetails(FeeSharingRequest feeSharingRequest);
        Task<BillSummeryEAFDetails> GetEAFCalculationDetails(string workspaceMasterGId);
        Task SaveEAFCalculationDetails(BillSummeryEAFDetails billSummeryEafDetails);
    }
}
