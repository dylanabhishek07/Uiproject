﻿using BT.DataIntegration.Adapter.API.Models;
using BT.DataIntegration.Adapter.API.Models.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Contracts
{
    public interface IWorkSpaceHandler
    {
        Task<Guid> AddWorkSpace(WorkSpaceDetail wrkSpcDetail);
        Task<bool> UpdateWorkSpace(List<ModifiedWorkSpaceDetails> wrkSpaceAllRecords);
        Task<List<WorkSpaceDetail>> CheckForExistingWorkSpace(string ClientEngagementMapGIds);
        Task<bool> IsBillingDataReady(string workspaceId);
        Task<IEnumerable<TNEDetails>> GetTimeDetails(string workSpaceGuid);
        Task<List<WorkspaceBillingItemDetails>> HandleWorkspaceBillingDetails(string workspaceGid, WorkSpaceUIDetails workspaceSession);
        Task<List<TNEDataTransferModel>> UpdateTNEMapping(List<TNEDataTransferModel> tneDataTransferModel);
        Task<List<WorkspaceItemTimeExpenseDetails>> HandelConsolidatedTimeDetailsForItems(List<WorkspaceItemTimeExpenseDetails> workspaceItemDetails);
        Task<Guid> CreateAdhocGuid(Guid wrkSpaceGuid, string createdBy);
    }
}
