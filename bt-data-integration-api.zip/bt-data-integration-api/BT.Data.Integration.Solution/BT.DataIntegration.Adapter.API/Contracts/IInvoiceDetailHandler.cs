﻿using BT.DataIntegration.Adapter.API.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.API.Contracts
{
    public interface IInvoiceDetailHandler
    {
        Task<int> SaveInvoiceDetails(List<InvoiceDetail> invoiceDetails);
    }
}
