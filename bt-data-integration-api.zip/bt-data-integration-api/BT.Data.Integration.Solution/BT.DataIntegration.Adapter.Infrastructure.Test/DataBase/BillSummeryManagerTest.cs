﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using BT.DataIntegration.Adapter.Infrastructure.DataBase;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Mappers;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Ports.Out;
using Moq;
using Xunit;

namespace BT.DataIntegration.Adapter.Infrastructure.Test.DataBase
{
    public class BillSummeryManagerTest
    {
        Mock<IBillSummeryRepository> billSummeryRepoMock = new Mock<IBillSummeryRepository>();
        private readonly IBillSummeryManager billSummeryManager;
        public BillSummeryManagerTest()
        {
            var mapperProfiles = new List<Profile>() {
                new BillSummeryMapper(),
            };
            var configuration = new MapperConfiguration(cfg => cfg.AddProfiles(mapperProfiles));
            IMapper mapper = new Mapper(configuration);
            billSummeryManager = new BillSummeryManager(billSummeryRepoMock.Object, mapper);
        }
        [Fact]
        public async void GetEngagementSummeryDetails_Should_Return_List_Of_EngagementSummeryDomain()
        {

            billSummeryRepoMock.Setup(p => p.GetEngagementSummeryDetails(It.IsAny<string>())).ReturnsAsync(new List<EngagementSummeryDetails>());
            var result = await billSummeryManager.GetEngagementSummeryDetails("GID_1");
            Assert.True(result.GetType() == typeof(List<EngagementSummeryDomain>));
            Assert.True(result.Count == 0);
        }

        [Fact]
        public async void GetEngagementSummeryDetails_Should_Return_Non_Zero_List_Of_Valid_EngagementSummeryDomain_If_Found_In_DB()
        {

            var existingengagementSummeryDetails = new List<EngagementSummeryDetails>()
            {
                new EngagementSummeryDetails()
                {
                    AdjustedBillingActionId = 1,
                    ANSR = 50,
                    BillingActionId = 2,
                    EAF = 75,
                    EngagementId = "ENG_1",
                    ExpenseAmount = 0,
                    GId = Guid.NewGuid(),
                    NSR = 100,
                    ProcessedTnEId = "TNE_1,TNE_2",
                },
            };
            billSummeryRepoMock.Setup(p => p.GetEngagementSummeryDetails(It.IsAny<string>())).ReturnsAsync(existingengagementSummeryDetails);
            var result = await billSummeryManager.GetEngagementSummeryDetails("GID_1");
            Assert.True(result.GetType() == typeof(List<EngagementSummeryDomain>));
            Assert.True(result.Count > 0);
            foreach (var workSpaceDetailDomain in result)
            {
                Assert.True(workSpaceDetailDomain.GId != Guid.Empty);
                Assert.True(workSpaceDetailDomain.AdjustedBillingActionId != Domain.Model.Enums.BillingActionDomainEnum.None);
                Assert.True(workSpaceDetailDomain.EngagementId != string.Empty);
                Assert.True(workSpaceDetailDomain.BillingActionId != Domain.Model.Enums.BillingActionDomainEnum.None);
            }
        }
    }
}
