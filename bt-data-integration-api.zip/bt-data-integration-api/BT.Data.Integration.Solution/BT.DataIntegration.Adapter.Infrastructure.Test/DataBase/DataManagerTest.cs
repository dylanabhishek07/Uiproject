﻿using AutoMapper;
using BT.DataIntegration.Adapter.Infrastructure.DataBase;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Mappers;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Ports.Out;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace BT.DataIntegration.Adapter.Infrastructure.Test.DataBase
{
    public class DataManagerTest
    {
        Mock<IClientRepository> clientRepoMock = new Mock<IClientRepository>();
        Mock<IEngagementRepository> engagementRepoMock = new Mock<IEngagementRepository>();
        Mock<IWorkSpaceRepository> workSpaceRepoMock = new Mock<IWorkSpaceRepository>();
        private readonly IDataManager dataManager;



        public DataManagerTest()
        {
            var mapperProfiles = new List<Profile>() {
                new WorkSpaceMapper(),
                new ClientMapper(),
                new EngagementMapper(),
                new TNEMapper(),
                new TNEDataTransferMapper()
            };

            var configuration = new MapperConfiguration(cfg => cfg.AddProfiles(mapperProfiles));
            IMapper mapper = new Mapper(configuration);
            dataManager = new DataManager(clientRepoMock.Object,mapper, engagementRepoMock.Object,workSpaceRepoMock.Object);
        }

        [Fact]
        public async void AddWorkSpace_Should_Return_New_Guid()
        {

            workSpaceRepoMock.Setup(p => p.AddWorkSpaceByGuids(It.IsAny<WorkSpace>())).ReturnsAsync(Guid.Parse("524d0962-6258-ec11-9977-a864f19bbed1"));
            var result = await dataManager.AddWorkSpace(new WorkSpaceDetailDomain());
            Assert.True(result.GetType() == typeof(Guid));
            Assert.True(result == Guid.Parse("524d0962-6258-ec11-9977-a864f19bbed1"));
        }

        [Fact]
        public async void CheckForExistingWorkSpace_Should_Return_List_Of_WorkSpaceDetailDomain()
        {

            workSpaceRepoMock.Setup(p => p.CheckForExistingWorkSpaceByGuids(It.IsAny<string>())).ReturnsAsync(new List<WorkSpace>());
            var result = await dataManager.CheckForExistingWorkSpace("GID_1,GID_2");
            Assert.True(result.GetType() == typeof(List<WorkSpaceDetailDomain>));
            Assert.True(result.Count == 0);
        }

        [Fact]
        public async void CheckForExistingWorkSpace_Should_Return_Non_Zero_List_Of_Valid_WorkSpaceDetailDomain_If_Found_In_DB()
        {

            var existingWorkSpace = new List<WorkSpace>()
            {
                new WorkSpace()
                {
                    WorkSpaceGuid = Guid.NewGuid(),
                    WorkspaceName = "Workspace_1",
                    EngagementIds = "Eng_1,Eng_2",
                    BeOneWorkFlowId = "BeOne_1",
                    CreatedBy = "Unit_Test_1"
                },
                new WorkSpace()
                {
                    WorkSpaceGuid = Guid.NewGuid(),
                    WorkspaceName = "Workspace_2",
                    EngagementIds = "Eng_2",
                    BeOneWorkFlowId = "BeOne_2",
                    CreatedBy = "Unit_Test_2"
                }
            };
            workSpaceRepoMock.Setup(p => p.CheckForExistingWorkSpaceByGuids(It.IsAny<string>())).ReturnsAsync(existingWorkSpace);
            var result = await dataManager.CheckForExistingWorkSpace("GID_1,GID_2");
            Assert.True(result.GetType() == typeof(List<WorkSpaceDetailDomain>));
            Assert.True(result.Count> 0);
            foreach(var workSpaceDetailDomain in result)
            {
                Assert.True(workSpaceDetailDomain.WorkSpaceGuid != Guid.Empty);
                Assert.True(workSpaceDetailDomain.WorkspaceName != string.Empty);
                Assert.True(workSpaceDetailDomain.EngagementIds != string.Empty);
                Assert.True(workSpaceDetailDomain.BeOneWorkFlowId != string.Empty);
                Assert.True(workSpaceDetailDomain.CreatedBy != string.Empty);
            }
        }

        [Fact]
        public async void GetClientByIndex_Should_Return_List_Of_ClientDomain()
        {

            clientRepoMock.Setup(p => p.GetByIndex(It.IsAny<int>(), It.IsAny<int>())).ReturnsAsync(new List<Client>());
            var result = await dataManager.GetClientByIndex(0,5);
            Assert.True(result.GetType() == typeof(List<ClientDomain>));
            Assert.True(result.Count == 0);
        }

        [Fact]
        public async void GetClientByIndex_Should_Return_Non_Zero_List_Of_Valid_ClientDomain_If_Found_In_DB()
        {

            var existingClient = new List<Client>()
            {
                new Client()
                {
                    ClientId = "22991100",
                    ClientName = "Beta Corp.",
                },
                new Client()
                {
                    ClientId = "25794210",
                    ClientName = "Alpha Inc.",
                }
            };
            clientRepoMock.Setup(p => p.GetByIndex(It.IsAny<int>(), It.IsAny<int>())).ReturnsAsync(existingClient);
            var result = await dataManager.GetClientByIndex(0,5);
            Assert.True(result.GetType() == typeof(List<ClientDomain>));
            Assert.True(result.Count > 0);
            foreach (var workSpaceDetailDomain in result)
            {
                Assert.True(workSpaceDetailDomain.ClientId != string.Empty);
                Assert.True(workSpaceDetailDomain.ClientName != string.Empty);
            }
        }

        [Fact]
        public async void GetClientSpecificEngagementsByIndex_Should_Return_List_Of_EngagementDomain()
        {

            engagementRepoMock.Setup(p => p.GetClientSpecificEngagementsByIndex(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).ReturnsAsync(new List<Engagement>());
            var result = await dataManager.GetClientSpecificEngagementsByIndex("22991100",0, 5);
            Assert.True(result.GetType() == typeof(List<EngagementDomain>));
            Assert.True(result.Count == 0);
        }

        [Fact]
        public async void GetClientSpecificEngagementsByIndex_Should_Return_Non_Zero_List_Of_Valid_EngagementDomain_If_Found_In_DB()
        {

            var existingEngagement = new List<Engagement>()
            {
                new Engagement()
                {
                    EngagementId = "12341234",
                    GId = Guid.Parse("91FE9320-987F-EC11-8179-415645000030"),
                },
                new Engagement()
                {
                    EngagementId = "12345678",
                    GId = Guid.Parse("ADFE9320-987F-EC11-8179-415645000030"),
                },
            };
            engagementRepoMock.Setup(p => p.GetClientSpecificEngagementsByIndex(It.IsAny<string>(), It.IsAny<int>(), It.IsAny<int>())).ReturnsAsync(existingEngagement);
            var result = await dataManager.GetClientSpecificEngagementsByIndex("22991100", 0, 5);
            Assert.True(result.GetType() == typeof(List<EngagementDomain>));
            Assert.True(result.Count> 0);
            foreach (var workSpaceDetailDomain in result)
            {
                Assert.True(workSpaceDetailDomain.GId != Guid.Empty);
                Assert.True(workSpaceDetailDomain.EngagementId != string.Empty);
            }
        }

        [Fact]
        public async void GetTimeDetails_Should_Return_IEnumerable_Of_TNEDetailDomain()
        {
            workSpaceRepoMock.Setup(p => p.GetTimeDetails(It.IsAny<string>())).ReturnsAsync(new List<TNEData>());
            var result = await dataManager.GetTimeDetails("524d0962-6258-ec11-9977-a864f19bbed1");
            Assert.True(result.ToList().GetType() == typeof(List<TNEDetailDomain>));
            Assert.True(result.ToList().Count == 0);
        }

        [Fact]
        public async void GetTimeDetails_Should_Return_Non_Zero_List_Of_Valid_TNEDetailDomain_If_Found_In_DB()
        {

            var existingTimeDetails = new List<TNEData>()
            {
                new TNEData()
                {
                     ActivityName = "11133355-0000",
                     AccountingDate = DateTime.Now,
                     ANSR=200,
                     ChargedHours=5,
                     ChargedHoursDescription="Submitting Tax Return",
                     Country = "US",
                     EAF = 95,
                     EmployeeName= "Emp_1",
                     EngagementName= "Eng_1",
                     ExpenseAmount= 0,
                     ExpensesDescription= String.Empty,
                     Guid= Guid.NewGuid(),
                     NSR=100,
                     NSRRate=50,
                     Rank=  String.Empty,
                     TransactionDate= DateTime.Now,
                     VendorName= String.Empty,

                },
                 new TNEData()
                {
                     ActivityName = "11223344-0000                 ",
                     AccountingDate = DateTime.Now,
                     ANSR=200,
                     ChargedHours= -2,
                     ChargedHoursDescription="Submitting Tax Return",
                     Country = "US",
                     EAF = 95,
                     EmployeeName= "Emp_2",
                     EngagementName= "Eng_2",
                     ExpenseAmount= 0,
                     ExpensesDescription= String.Empty,
                     Guid= Guid.NewGuid(),
                     NSR=100,
                     NSRRate=50,
                     Rank=  String.Empty,
                     TransactionDate= DateTime.Now,
                     VendorName= String.Empty,
                }
            };

            workSpaceRepoMock.Setup(p => p.GetTimeDetails(It.IsAny<string>())).ReturnsAsync(existingTimeDetails);
            var result = await dataManager.GetTimeDetails("524d0962-6258-ec11-9977-a864f19bbed1");
            Assert.True(result.ToList().GetType() == typeof(List<TNEDetailDomain>));
            Assert.True(result.ToList().Count > 0);
            foreach (var tneDetailDomain in result)
            {
                Assert.True(tneDetailDomain.Guid != Guid.Empty);
                Assert.True(tneDetailDomain.ChargedHours != 0);
            }
        }

        [Fact]
        public async void IsBillingDataReady_Should_Return_bool()
        {
            workSpaceRepoMock.Setup(p => p.IsBillingDataReady(It.IsAny<string>())).ReturnsAsync(true);
            var result = await dataManager.IsBillingDataReady("524d0962-6258-ec11-9977-a864f19bbed1");
            Assert.True(result.GetType() == typeof(bool));
            Assert.True(result);
        }
        [Fact]
        public async void UpdateTNEMapping_Should_Return_List_Of_TNEDataTransferDomain()
        {
            workSpaceRepoMock.Setup(p => p.UpdateTNEMappingTables(It.IsAny<List<TNEDataTransfer>>())).ReturnsAsync(new List<TNEDataTransfer>());
            var result = await dataManager.UpdateTNEMapping(new List<TNEDataTransferDomain>());
            Assert.True(result.GetType() == typeof(List<TNEDataTransferDomain>));
        }

    }
}
