﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using BT.DataIntegration.Adapter.Infrastructure.DataBase;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Mappers;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Ports.Out;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace BT.DataIntegration.Adapter.Infrastructure.Test.DataBase
{
    public class WorkspaceManagerTest
    {
        Mock<IWorkSpaceRepository> workSpaceRepoMock = new Mock<IWorkSpaceRepository>();
        Mock<IProcessedDataRepository> processedDataRepoMock = new Mock<IProcessedDataRepository>();
        Mock<ILogger<WorkspaceManager>> loggerMock = new Mock<ILogger<WorkspaceManager>>();
        private readonly IWorkSpaceManager workSpaceManager;
        public WorkspaceManagerTest()
        {
            var mapperProfiles = new List<Profile>() {
                new WorkSpaceMapper(),
            };

            var configuration = new MapperConfiguration(cfg => cfg.AddProfiles(mapperProfiles));
            IMapper mapper = new Mapper(configuration);
            workSpaceManager = new WorkspaceManager(mapper, workSpaceRepoMock.Object, processedDataRepoMock.Object, loggerMock.Object);
        }

        [Fact]
        public async void GetWorkspaceBillingDetails_Should_Return_List_Of_WorkspaceBillingItemDomain()
        {

            workSpaceRepoMock.Setup(p => p.GetWorkSpaceBillableData(It.IsAny<string>())).ReturnsAsync(new List<WorkspaceCommonData>());
            workSpaceRepoMock.Setup(p => p.GetWorkSpaceNonBillableData(It.IsAny<string>())).ReturnsAsync(new List<WorkspaceCommonData>());
            workSpaceRepoMock.Setup(p => p.GetWorkSpaceBillingOpportunityData(It.IsAny<string>())).ReturnsAsync(new List<WorkspaceCommonData>());
            workSpaceRepoMock.Setup(p => p.GetWorkSpaceUncodedData(It.IsAny<string>())).ReturnsAsync(new List<WorkspaceCommonData>());
            workSpaceRepoMock.Setup(p => p.GetWorkSpaceExpenseData(It.IsAny<string>())).ReturnsAsync(new List<WorkspaceCommonData>());
            workSpaceRepoMock.Setup(p => p.GetWorkSpaceAdhocData(It.IsAny<string>())).ReturnsAsync(new List<WorkspaceCommonData>());
            var result = await workSpaceManager.GetWorkspaceBillingDetails("GID_1");
            Assert.True(result.GetType() == typeof(List<WorkspaceBillingItemDomain>));
            Assert.True(result.Count == 0);
        }

        [Fact]
        public async void GetListOfProcessedDataTimeForWorkspace_Should_Return_List_Of_WorkspaceBillingItemDomain()
        {
            //workSpaceRepoMock.Setup(p => p.GetAllAsync<WorkspaceItemProcessedGIds>(It.IsAny<string>(), It.IsAny<object>())).ReturnsAsync(new Mock<IEnumerable<T>>().Object);          
            //var result = await workSpaceManager.GetWorkspaceBillingDetails("GID_1");
            //Assert.True(result.GetType() == typeof(List<WorkspaceBillingItemDomain>));
            //Assert.True(result.Count == 0);
        }

        [Fact]
        public async void UpdateWorkSpace_Should_Return_False_When_Input_WorkSpaceAdjustedDataDomain_List_Is_Empty()
        {
            var result = await workSpaceManager.UpdateWorkSpace(new List<ModifiedWorkSpaceDetailsDomain>());
            Assert.True(result.GetType() == typeof(bool));
            Assert.False(result);
        }

        [Fact]
        public async void UpdateWorkSpace_Should_Return_True_Input_WorkSpaceAdjustedDataDomain_List_Is_Valid()
        {
            var worspaceAdjustedDataDomain = new List<ModifiedWorkSpaceDetailsDomain>()
            {
                new ModifiedWorkSpaceDetailsDomain()
                {
                    WorkSpaceDataType = Domain.Model.Enums.DataTypeDomainEnum.Billable,
                    AdjustedBillingAction = Domain.Model.Enums.BillingActionDomainEnum.CarryForward,
                    AdjustedBillingEntity = "BillingEntity_1",
                    AdjustedBillingEntityId = "TestID_1",
                    AdjustedCostCenter = null,
                    AdjustedCurrency = null,
                    AdjustedDescription = null,
                    AdjustedGBTRef = null,
                    AdjustedGBTStatus = null,
                    AdjustedInvoiceFee = 200,
                    AdjustedOOSNR = null,
                    Gid = Guid.NewGuid(),
                    ModifiedBy =    String.Empty,
                    ModifiedDateTime = DateTime.Now,
                }
            };
            workSpaceRepoMock.Setup(p => p.UpdateWorkSpace(It.IsAny<List<WorkSpaceAdjustedData>>())).ReturnsAsync(true);
            var result = await workSpaceManager.UpdateWorkSpace(worspaceAdjustedDataDomain);
            Assert.True(result.GetType() == typeof(bool));
            Assert.True(result);
        }
    }
}
