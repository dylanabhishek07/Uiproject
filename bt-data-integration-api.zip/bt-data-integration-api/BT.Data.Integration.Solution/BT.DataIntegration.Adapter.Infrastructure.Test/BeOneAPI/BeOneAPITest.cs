﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;
using BT.DataIntegration.Adapter.Infrastructure.AuthAPI;
using BT.DataIntegration.Adapter.Infrastructure.BeOneAPI;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Mappers;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Ports.Out;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Moq;
using Xunit;

namespace BT.DataIntegration.Adapter.Infrastructure.Test.BeOneAPI
{
    public class BeOneAPITest
    {
        Mock<IHttpClientFactory> httpClientFactoryMock = new Mock<IHttpClientFactory>();
        Mock<IConfiguration> configurationMock = new Mock<IConfiguration>();
        Mock<IAuthenticationAPI> authAPIMock = new Mock<IAuthenticationAPI>();
        Mock<IVaultManager> vaultManagerMock = new Mock<IVaultManager>();
        Mock<ILogger<BeeOneAPI>> loggerMock = new Mock<ILogger<BeeOneAPI>>();
        private readonly IBeOneAPI beOneAPIManager;
        public BeOneAPITest()
        {
            var mapperProfiles = new List<Profile>() {
                new BillSummeryMapper(),
            };
            var configuration = new MapperConfiguration(cfg => cfg.AddProfiles(mapperProfiles));
            IMapper mapper = new Mapper(configuration);
            //This is throwing error.
            //beOneAPIManager = new BeeOneAPI(mapper, httpClientFactoryMock.Object, configurationMock.Object, authAPIMock.Object, loggerMock.Object,vaultManagerMock.Object);
        }

        //[Fact]
        //public async void GetProductDetails_Should_Return_Task()
        //{
        //    await beOneAPIManager.GetProductDetails(new List<Domain.Model.WorkspaceBillingItemDomain>());
        //    Assert.True(true);
        //}
    }
}
