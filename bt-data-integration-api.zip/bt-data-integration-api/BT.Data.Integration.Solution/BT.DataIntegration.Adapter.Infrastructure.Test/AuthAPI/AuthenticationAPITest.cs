﻿using BT.DataIntegration.Adapter.Infrastructure.AuthAPI;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Logging;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace BT.DataIntegration.Adapter.Infrastructure.Test.AuthAPI
{
    public class AuthenticationAPITest
    {
        Mock<IDistributedCache> cacheMock = new Mock<IDistributedCache>();
        Mock<ILogger<AuthenticationAPI>> loggerMock = new Mock<ILogger<AuthenticationAPI>>();
        private readonly IAuthenticationAPI authAPIManager;
        public AuthenticationAPITest()
        {
            authAPIManager = new AuthenticationAPI(cacheMock.Object,loggerMock.Object);
        }

        [Fact]
        public async void GetTokenForAdClient_Should_Return_String()
        {
        }
    }
}
