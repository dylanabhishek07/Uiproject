﻿using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Ports.In;
using BT.DataIntegration.Domain.Ports.Out;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Domain.Invoice
{
    public class InvoiceDetailsService : IInvoiceDetailsService
    {
        IInvoiceDetailsManager _invoiceDetailsManager;

        public InvoiceDetailsService(IInvoiceDetailsManager invoiceDetailsManager)
        {
            _invoiceDetailsManager = invoiceDetailsManager;
        }

        public async Task<int> SaveInvoiceDetails(List<InvoiceDetailsDomain> invoiceDetails)
        {
            return await _invoiceDetailsManager.SaveInvoiceDetails(invoiceDetails);
        }
    }
}
