﻿using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Model.Enums;
using BT.DataIntegration.Domain.Ports.In;
using BT.DataIntegration.Domain.Ports.Out;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Domain.BillSummery
{
    public class BillSummeryService : IBillSummeryService
    {
        IBillSummeryManager _billSummeryManager;

        public BillSummeryService(IBillSummeryManager billSummeryManager)
        {
            _billSummeryManager = billSummeryManager;
        }


        public async Task<EngagementSummeryConsolidatedDomain> GetEngagementSummeryDetails(string workspaceMasterGId)
        {
            var summeryResult = await _billSummeryManager.GetEngagementSummeryDetails(workspaceMasterGId);
            var consolidatedEngagementSummery = GetEngagementCosolidatedSummery(summeryResult);
            CalculateTotalForConsolidatedEngagementSummery(consolidatedEngagementSummery);
            consolidatedEngagementSummery.WorkSpaceMasterGid = workspaceMasterGId;
            return consolidatedEngagementSummery;
        }

        public async Task<BillingEntityWiseInvoiceFeeDistributionDomain> GetBillingEntitySummeryDetails(string workspaceMasterGId, List<ModifiedWorkSpaceDetailsDomain> workspaceModifiedData)
        {
            BillingEntityWiseInvoiceFeeDistributionDomain billingEntityWiseInvoiceFeeDistributionDomain = new BillingEntityWiseInvoiceFeeDistributionDomain();
            billingEntityWiseInvoiceFeeDistributionDomain.WorkSpaceMasterGid = workspaceMasterGId;
            billingEntityWiseInvoiceFeeDistributionDomain.TotalInvoiceFee = workspaceModifiedData.Sum(item => (item.AdjustedInvoiceFee != null && item.AdjustedInvoiceFee != 0 && item.AdjustedInvoiceFee > 0) ? item.AdjustedInvoiceFee : item.InvoiceFee);
            billingEntityWiseInvoiceFeeDistributionDomain.EntityInvoiceDetails = CalculateEntityWiseInvoiceFee(workspaceModifiedData);
            return billingEntityWiseInvoiceFeeDistributionDomain;

        }
        public async Task<List<BillSummeryEAFDetailsDomain>> GetEAFCalculationDetails(string workspaceMasterGId)
        {
            return await _billSummeryManager.GetEAFCalculationDetails(workspaceMasterGId);
        }

        public async Task SaveEAFCalculationDetails(List<BillSummeryEAFDetailsDomain> billSummeryEngamentEafDomain)
        {
            await _billSummeryManager.SaveEAFCalculationDetails(billSummeryEngamentEafDomain);
        }

        private List<EntityInvoiceDetailDomain> CalculateEntityWiseInvoiceFee(List<ModifiedWorkSpaceDetailsDomain> workspaceModifiedData)
        {
            var entityInvoiceMappingList = new List<EntityInvoiceDetailDomain>();
            var finalConsolidatedInvoiceMappingList = new List<EntityInvoiceDetailDomain>();
            if (workspaceModifiedData.Any())
            {
                foreach (var workspaceModifiedDataDomain in workspaceModifiedData)
                {
                    var entityInvoiceMapping = new EntityInvoiceDetailDomain();
                    entityInvoiceMapping.InvoiceFee = (workspaceModifiedDataDomain.AdjustedInvoiceFee != null && workspaceModifiedDataDomain.AdjustedInvoiceFee != 0 && workspaceModifiedDataDomain.AdjustedInvoiceFee > 0) ? workspaceModifiedDataDomain.AdjustedInvoiceFee : workspaceModifiedDataDomain.InvoiceFee;
                    entityInvoiceMapping.BillingEntityName = string.IsNullOrWhiteSpace(workspaceModifiedDataDomain.AdjustedBillingEntity) ? workspaceModifiedDataDomain.BillingEntityName : workspaceModifiedDataDomain.AdjustedBillingEntity;
                    entityInvoiceMapping.BillingEntityId = string.IsNullOrWhiteSpace(workspaceModifiedDataDomain.AdjustedBillingEntityId) ? workspaceModifiedDataDomain.BillingEntityId : workspaceModifiedDataDomain.AdjustedBillingEntityId;
                    //Check and add the mapping for BillingActionID if required.
                    entityInvoiceMappingList.Add(entityInvoiceMapping);
                }
                /// This is added for worked with billing entity name.. but in real it should be with billing entity ID.
                finalConsolidatedInvoiceMappingList = entityInvoiceMappingList.GroupBy(t => t.BillingEntityName)
                           .Select(t => new EntityInvoiceDetailDomain
                           {
                               BillingEntityName = t.First().BillingEntityName,
                               InvoiceFee = t.Sum(c => c.InvoiceFee),
                               BillingEntityId = t.First().BillingEntityId,
                           }).ToList();

            }
            return finalConsolidatedInvoiceMappingList;
        }

        private EngagementSummeryConsolidatedDomain GetEngagementCosolidatedSummery(List<EngagementSummeryDomain> summeryResult)
        {
            EngagementSummeryConsolidatedDomain summeryConsolidated = new EngagementSummeryConsolidatedDomain();
            if (summeryResult != null && summeryResult.Count > 0)
            {
                var distinctEngagements = summeryResult.Select(item => item.EngagementId).Distinct().ToList();
                if (distinctEngagements != null && distinctEngagements.Any())
                {
                    distinctEngagements.ForEach(enagementId =>
                    {
                        var linkedRecords = summeryResult.FindAll(item => item.EngagementId.Equals(enagementId, StringComparison.OrdinalIgnoreCase));
                        summeryConsolidated.EngagementRevenueList.Add(CalculateEngagementRevenue(linkedRecords, enagementId));
                    });
                }
            }

            return summeryConsolidated;
        }

        private EngagementRevenueDomain CalculateEngagementRevenue(List<EngagementSummeryDomain> engagementLinkedRecods, string engagementId)
        {
            EngagementRevenueDomain engagementRevenue = new EngagementRevenueDomain();
            engagementRevenue.EngagementId = engagementId;
            if (engagementLinkedRecods != null && engagementLinkedRecods.Count > 0)
            {
                engagementLinkedRecods.ForEach(engmentRecord =>
                {
                    ///Adjusted billing action would get higher priority
                    var billingAction = engmentRecord.AdjustedBillingActionId != BillingActionDomainEnum.None ? engmentRecord.AdjustedBillingActionId : engmentRecord.BillingActionId;
                    switch (billingAction)
                    {
                        case BillingActionDomainEnum.InvoiceNow:
                            UpdateDetailsForEngagementItems(BillingActionDomainEnum.InvoiceNow, engagementRevenue.EngagementItems, engmentRecord);
                            break;

                        case BillingActionDomainEnum.CarryForward:
                            UpdateDetailsForEngagementItems(BillingActionDomainEnum.CarryForward, engagementRevenue.EngagementItems, engmentRecord);
                            break;

                        case BillingActionDomainEnum.NotBillable:
                            UpdateDetailsForEngagementItems(BillingActionDomainEnum.NotBillable, engagementRevenue.EngagementItems, engmentRecord);
                            break;

                        case BillingActionDomainEnum.AlreadyBilled:
                            UpdateDetailsForEngagementItems(BillingActionDomainEnum.AlreadyBilled, engagementRevenue.EngagementItems, engmentRecord);
                            break;
                        case BillingActionDomainEnum.Miscoded:
                            UpdateDetailsForEngagementItems(BillingActionDomainEnum.Miscoded, engagementRevenue.EngagementItems, engmentRecord);
                            break;
                    }
                });

                CalculateTotalsForEngagementRevenue(engagementRevenue);
            }
            return engagementRevenue;
        }
        private void UpdateDetailsForEngagementItems(BillingActionDomainEnum billingAction, List<EngagementRevenueItemsDomian> engagementItems, EngagementSummeryDomain engagementSummery)
        {
            if (engagementItems != null && engagementItems.Count > 0)
            {
                var selectedItem = engagementItems.FirstOrDefault(item => item.BillingAction == billingAction);
                if (selectedItem != null && engagementSummery != null)
                {
                    if (engagementSummery.ExpenseAmount == 0)
                        selectedItem.NSR += engagementSummery.NSR;
                    else if (engagementSummery.ExpenseAmount > 0)
                        selectedItem.Expense += engagementSummery.ExpenseAmount;
                    selectedItem.ANSR += engagementSummery.ANSR;
                }
            }
        }

        private void CalculateTotalForConsolidatedEngagementSummery(EngagementSummeryConsolidatedDomain consolidatedSummery)
        {
            if (consolidatedSummery != null && consolidatedSummery.EngagementRevenueList != null && consolidatedSummery.EngagementRevenueList.Count > 0)
            {
                consolidatedSummery.EngagementRevenueList.ForEach(item =>
                {
                    consolidatedSummery.TotalNSR += item.TotalNSR;
                    consolidatedSummery.TotalANSR += item.TotalANSR;
                    consolidatedSummery.TotalExpense += item.TotalExpense;
                    consolidatedSummery.NetTotalNSR += item.NetTotalNSR;
                    consolidatedSummery.NetTotalANSR += item.NetTotalANSR;
                });

                consolidatedSummery.TotalEAF = CalculateEAF(consolidatedSummery.TotalNSR, consolidatedSummery.TotalANSR);
            }
        }

        private void CalculateTotalsForEngagementRevenue(EngagementRevenueDomain engagementRevenue)
        {
            if (engagementRevenue != null && engagementRevenue.EngagementItems != null && engagementRevenue.EngagementItems.Count > 0)
            {
                engagementRevenue.EngagementItems.ForEach(item =>
                {
                    engagementRevenue.TotalNSR += item.NSR;
                    engagementRevenue.TotalANSR += item.ANSR;
                    engagementRevenue.TotalExpense += item.Expense;
                    if (item.BillingAction != BillingActionDomainEnum.Miscoded && item.BillingAction != BillingActionDomainEnum.AlreadyBilled)
                    {
                        engagementRevenue.NetTotalNSR += item.NSR;
                        engagementRevenue.NetTotalANSR += item.ANSR;
                    }

                });
                engagementRevenue.EAF = CalculateEAF(engagementRevenue.TotalNSR, engagementRevenue.TotalANSR);
            }
        }

        private float CalculateEAF(float nsr, float ansr)
        {
            float eaf = 0;
            if (nsr > 0)
                eaf = ((ansr / nsr - 1) * 100);
            return eaf;
        }


    }
}
