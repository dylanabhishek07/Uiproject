﻿using BT.DataIntegration.Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Domain.Ports.In
{
    public interface IWorkSpaceService
    {
        Task<Guid> AddWorkSpace(WorkSpaceDetailDomain wrkSpcDetail);
        Task<bool> UpdateWorkSpace(List<ModifiedWorkSpaceDetailsDomain> wrkSpcAdjustedRecords);
        Task<List<WorkSpaceDetailDomain>> CheckForExistingWorkSpace(string ClientEngagementMapGIds);
        Task<bool> IsBillingDataReady(string workspaceId);
        Task<IEnumerable<TNEDetailDomain>> GetTimeDetails(string workSpaceGuid);
        Task<List<WorkspaceBillingItemDomain>> GetWorkSpaceBillingDetails(string workspaceGId);
        Task<List<TNEDataTransferDomain>> UpdateTNEMapping(List<TNEDataTransferDomain> tneDataTransferDomain);
        Task<List<WorkspaceItemTimeDetailsDomain>> GetProcessedTimeDetailsForItems(List<WorkspaceItemTimeDetailsDomain> workspaceItemTimeDetails);
        Task<Guid> CreateAdhocGuid(Guid wrkSpaceGuid, string createdBy);
    }
}
