﻿using BT.DataIntegration.Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Domain.Ports.In
{
    public interface IInvoiceDetailsService
    {
        Task<int> SaveInvoiceDetails(List<InvoiceDetailsDomain> invoiceDetails);
    }
}
