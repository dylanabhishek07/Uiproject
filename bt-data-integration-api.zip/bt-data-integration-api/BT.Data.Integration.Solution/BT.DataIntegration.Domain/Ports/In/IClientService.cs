﻿using BT.DataIntegration.Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Domain.Ports.In
{
    public interface IClientService
    {
        Task<List<ClientDomain>> GetClientByIndex(int index, int count);

        Task<List<EngagementDomain>> GetClientSpecificEngagementsByIndex(string clientid, int index, int count);
    }
}
