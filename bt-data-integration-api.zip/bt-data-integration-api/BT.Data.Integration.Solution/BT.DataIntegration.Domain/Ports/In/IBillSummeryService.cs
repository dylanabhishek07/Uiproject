﻿using BT.DataIntegration.Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Domain.Ports.In
{
    public interface IBillSummeryService
    {
        public Task<EngagementSummeryConsolidatedDomain> GetEngagementSummeryDetails(string workspaceMasterGId);
        Task<BillingEntityWiseInvoiceFeeDistributionDomain> GetBillingEntitySummeryDetails(string workspaceMasterGId, List<ModifiedWorkSpaceDetailsDomain> workspaceModifiedData);
        Task<List<BillSummeryEAFDetailsDomain>> GetEAFCalculationDetails(string workspaceMasterGId);
        Task SaveEAFCalculationDetails(List<BillSummeryEAFDetailsDomain> billSummeryEngamentEafDomain);
    }
}
