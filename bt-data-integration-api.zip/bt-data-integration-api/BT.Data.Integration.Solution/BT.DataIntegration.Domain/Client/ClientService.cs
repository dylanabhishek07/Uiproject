﻿using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Ports.In;
using BT.DataIntegration.Domain.Ports.Out;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Domain.Client
{
    public class ClientService: IClientService
    {
        IDataManager _dataManger;

        public ClientService(IDataManager dataManger)
        {
            _dataManger = dataManger;
        }

        public async Task<List<ClientDomain>> GetClientByIndex(int index, int count)
        {
            return await _dataManger.GetClientByIndex(index, count);
        }

        public async Task<List<EngagementDomain>> GetClientSpecificEngagementsByIndex(string clientid, int index, int count)
        {
            return await _dataManger.GetClientSpecificEngagementsByIndex(clientid,  index,  count);
        }
    }
}
