﻿using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Model.Enums;
using BT.DataIntegration.Domain.Ports.In;
using BT.DataIntegration.Domain.Ports.Out;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Domain.AnnexPreview
{
    public class AnnexPreviewService : IAnnexPreviewService
    {
        IAnnexePreviewManager _annexPreviewManager;

        public AnnexPreviewService(IAnnexePreviewManager annexPreviewManager)
        {
            _annexPreviewManager = annexPreviewManager;
        }
        public async Task<BillingEntityWiseAnnexPreviewSummaryDomain> GetBillingEntityWiseAnnexPreviewData(string workspaceMasterGId, List<ModifiedWorkSpaceDetailsDomain> workspaceModifiedData)
        {
            BillingEntityWiseAnnexPreviewSummaryDomain billingEntityWiseAnnexPreviewSummaryDomain = new BillingEntityWiseAnnexPreviewSummaryDomain();
            billingEntityWiseAnnexPreviewSummaryDomain.WorkSpaceMasterGid = workspaceMasterGId;
            var workSpaceGIDs = workspaceModifiedData.Select(item => item.Gid.ToString()).ToList();
            List<WorkSpaceFeeTextMappingDomain> workSpaceFeeTextMapping = await _annexPreviewManager.GetFeeTextByWorkSpaceGIds(workSpaceGIDs);
            var annexPreviewWorkSpaceDataList = GetAnnexPreviewDataSet(workspaceModifiedData, workSpaceFeeTextMapping);
            billingEntityWiseAnnexPreviewSummaryDomain.AnnexPreviewDistribution = GroupAnnexPreviewDataSet(annexPreviewWorkSpaceDataList);
            return billingEntityWiseAnnexPreviewSummaryDomain;
        }
        public async Task<int> SaveFeeDetails(List<AnnexPreviewFeeDetailDomain> feeDetails)
        {
            return await _annexPreviewManager.SaveFeeDetails(feeDetails);
        }

        private List<BillingEntityWiseAnnexPreviewDistributionDomain> GroupAnnexPreviewDataSet(List<AnnexPreviewWorkSpaceDomain> annexPreviewWorkSpaceDataList)
        {
            var finalAnnexPreviewDistributionList = new List<BillingEntityWiseAnnexPreviewDistributionDomain>();
            if (annexPreviewWorkSpaceDataList.Any())
            {
                finalAnnexPreviewDistributionList = annexPreviewWorkSpaceDataList.GroupBy(t => t.BillingEntityId)
                       .Select(t => new BillingEntityWiseAnnexPreviewDistributionDomain
                       {
                           BillingEntityName = t.First().BillingEntityName,
                           BillingEntityId = t.First().BillingEntityId,
                           TotalFee = t.Sum(c => c.InvoiceFee),
                           AnnexPreviewDistributionItems = t.Select(item => new BillingEntityWiseAnnexPreviewDistributionDomainItems()
                           {
                               InvoiceFee = item.InvoiceFee,
                               OOSNR = item.OOSNR,
                               CostCenter = item.CostCenter,
                               GBTRef = item.GBTRef,
                               ProductID = item.ProductID,
                               ServiceDescription = item.ServiceDescription,
                               FeeText = item.FeeText,
                           }).ToList(),
                       }).ToList();
            }
            return finalAnnexPreviewDistributionList;
        }

        private List<AnnexPreviewWorkSpaceDomain> GetAnnexPreviewDataSet(List<ModifiedWorkSpaceDetailsDomain> workspaceModifiedData, List<WorkSpaceFeeTextMappingDomain> workSpaceFeeTextMapping)
        {
            var annexPreviewWorkSpaceDataList = new List<AnnexPreviewWorkSpaceDomain>();
            if (workspaceModifiedData != null && workspaceModifiedData.Count > 0)
            {
                foreach (var workspaceModifiedDataDomain in workspaceModifiedData)
                {
                    if (workspaceModifiedDataDomain != null)
                    {
                        var annexPreviewWorkSpaceData = new AnnexPreviewWorkSpaceDomain();
                        annexPreviewWorkSpaceData.ProductID  = workspaceModifiedDataDomain.ProductID;
                        annexPreviewWorkSpaceData.InvoiceFee = (workspaceModifiedDataDomain.AdjustedInvoiceFee != null && workspaceModifiedDataDomain.AdjustedInvoiceFee != 0 && workspaceModifiedDataDomain.AdjustedInvoiceFee > 0) ? workspaceModifiedDataDomain.AdjustedInvoiceFee : workspaceModifiedDataDomain.InvoiceFee;
                        annexPreviewWorkSpaceData.BillingEntityName = string.IsNullOrWhiteSpace(workspaceModifiedDataDomain.AdjustedBillingEntity) ? workspaceModifiedDataDomain.BillingEntityName : workspaceModifiedDataDomain.AdjustedBillingEntity;
                        annexPreviewWorkSpaceData.BillingEntityId = string.IsNullOrWhiteSpace(workspaceModifiedDataDomain.AdjustedBillingEntityId) ? workspaceModifiedDataDomain.BillingEntityId : workspaceModifiedDataDomain.AdjustedBillingEntityId;
                        annexPreviewWorkSpaceData.ServiceDescription = string.IsNullOrWhiteSpace(workspaceModifiedDataDomain.AdjustedDescription) ? workspaceModifiedDataDomain.ServiceDescription : workspaceModifiedDataDomain.AdjustedDescription;
                        var feeTextFound = workSpaceFeeTextMapping.Where(item => item.WorkSpaceRowGId.Equals(workspaceModifiedDataDomain.Gid)).FirstOrDefault();
                        annexPreviewWorkSpaceData.FeeText = feeTextFound != null ? feeTextFound.FeeText:null;
                        if (workspaceModifiedDataDomain.WorkSpaceDataType == DataTypeDomainEnum.Billable || workspaceModifiedDataDomain.WorkSpaceDataType == DataTypeDomainEnum.AdditionalBillingOppertunity || workspaceModifiedDataDomain.WorkSpaceDataType == DataTypeDomainEnum.NonBillable)
                        {
                            annexPreviewWorkSpaceData.OOSNR = workspaceModifiedDataDomain.OOSNR;
                            annexPreviewWorkSpaceData.CostCenter = workspaceModifiedDataDomain.CostCenter;
                            annexPreviewWorkSpaceData.GBTRef = workspaceModifiedDataDomain.GBTRef;
                        }
                        else
                        {
                            annexPreviewWorkSpaceData.OOSNR = workspaceModifiedDataDomain.AdjustedOOSNR;
                            annexPreviewWorkSpaceData.CostCenter = workspaceModifiedDataDomain.AdjustedCostCenter;
                            annexPreviewWorkSpaceData.GBTRef = workspaceModifiedDataDomain.AdjustedGBTRef;
                        }                        
                        annexPreviewWorkSpaceDataList.Add(annexPreviewWorkSpaceData);
                    }
                }
            }
            return annexPreviewWorkSpaceDataList;
        }

        
    }
}
