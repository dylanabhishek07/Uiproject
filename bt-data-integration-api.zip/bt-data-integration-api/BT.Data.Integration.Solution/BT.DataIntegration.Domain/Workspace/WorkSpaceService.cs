﻿using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Ports.In;
using BT.DataIntegration.Domain.Ports.Out;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Domain.Workspace
{
    public class WorkSpaceService : IWorkSpaceService
    {
        private IDataManager _dataManger;
        private IQueueManager _queueManager;
        private IWorkSpaceManager _workSpaceManager;
        private IBeOneAPI _beOneApi;

        public WorkSpaceService(IBeOneAPI beOneApi, IDataManager dataManger, IQueueManager queueManager, IWorkSpaceManager workSpaceManager)
        {
            _beOneApi = beOneApi;
            _dataManger = dataManger;
            _workSpaceManager = workSpaceManager;
            _queueManager = queueManager;
        }
        public async Task<Guid> AddWorkSpace(WorkSpaceDetailDomain wrkSpcDetail)
        {
            Guid result = Guid.Empty;
            if (wrkSpcDetail != null && !string.IsNullOrWhiteSpace(wrkSpcDetail.WorkspaceName) && wrkSpcDetail.ClientEngagementMapGIds != null && wrkSpcDetail.ClientEngagementMapGIds.Count() > 0)
            {
                result = await _dataManger.AddWorkSpace(wrkSpcDetail);
                if (!string.IsNullOrWhiteSpace(result.ToString()))
                {
                    await _queueManager.SendMessage(result.ToString());
                }
            }
            return result;
        }

        public async Task<Guid> CreateAdhocGuid(Guid wrkSpaceGuid, string createdBy)
        {
            Guid result = Guid.Empty;
            if (wrkSpaceGuid != Guid.Empty)
            {
                result = await _workSpaceManager.CreateAdhocGuid(wrkSpaceGuid, createdBy);
            }
            return result;
        }

        public async Task<List<WorkSpaceDetailDomain>> CheckForExistingWorkSpace(string ClientEngagementMapGIds)
        {
            return await _dataManger.CheckForExistingWorkSpace(ClientEngagementMapGIds);
        }

        public async Task<IEnumerable<TNEDetailDomain>> GetTimeDetails(string workSpaceGuid)
        {
            return await _dataManger.GetTimeDetails(workSpaceGuid);
        }

        public async Task<bool> IsBillingDataReady(string workspaceId)
        {
            return await _dataManger.IsBillingDataReady(workspaceId);
        }

        public async Task<bool> UpdateWorkSpace(List<ModifiedWorkSpaceDetailsDomain> wrkSpcAdjustedRecords)
        {
            if (wrkSpcAdjustedRecords.Any())
            {
                return await _workSpaceManager.UpdateWorkSpace(wrkSpcAdjustedRecords);
            }
            else
            {
                return false;
            }
        }

        public async Task<List<WorkspaceItemTimeDetailsDomain>> GetProcessedTimeDetailsForItems(List<WorkspaceItemTimeDetailsDomain> workspaceItemTimeDetails)
        {
            if (workspaceItemTimeDetails.Any())
            {
                var workspaceItemGid = new List<string>();
                workspaceItemTimeDetails.ForEach(item =>
                {
                    workspaceItemGid.Add(item.GId.ToString());
                });
                workspaceItemGid = workspaceItemGid.Distinct().ToList();
                var listOfProcessedItemDetails = await _workSpaceManager.GetListOfProcessedDataTimeForWorkspace(workspaceItemGid);
                if (listOfProcessedItemDetails.Any())
                {
                    workspaceItemTimeDetails.ForEach((item) =>
                    {
                        var sortedProcessedItemDet = listOfProcessedItemDetails.Where(lItem => !string.IsNullOrEmpty(lItem.LinkedWorkspaceItemGid) && item.GId.Equals(lItem.LinkedWorkspaceItemGid, StringComparison.InvariantCultureIgnoreCase))?.ToList();
                        if (sortedProcessedItemDet != null && sortedProcessedItemDet.Any())
                        {
                            sortedProcessedItemDet.ForEach(slpItem =>
                            {
                                item.TotalHours += slpItem.ChargedHours;
                                item.TotalANSR += slpItem.ANSR;
                                item.TotalExpenseAmount += slpItem.ExpenseAmount;
                            });
                        }
                    });
                }
            }
            return workspaceItemTimeDetails;
        }

        public async Task<List<WorkspaceBillingItemDomain>> GetWorkSpaceBillingDetails(string workspaceGId)
        {
            var workspaceBillingItems = await _workSpaceManager.GetWorkspaceBillingDetails(workspaceGId);
            CalculateConsolidatedTimeAndExpense(workspaceBillingItems);
            await _beOneApi.GetProductDetails(workspaceBillingItems);
            DetermineInvoiceFee(workspaceBillingItems);
            return workspaceBillingItems;
        }
        public async Task<List<TNEDataTransferDomain>> UpdateTNEMapping(List<TNEDataTransferDomain> tneDataTransferDomain)
        {
            var tneModifiedMapping = new List<TNEDataTransferDomain>();
            if (tneDataTransferDomain != null && tneDataTransferDomain.Any())
                tneModifiedMapping = await _dataManger.UpdateTNEMapping(tneDataTransferDomain);
            return tneModifiedMapping;

        }

        private void DetermineInvoiceFee(List<WorkspaceBillingItemDomain> workspaceBillingItems)
        {
            if (workspaceBillingItems.Any())
            {
                workspaceBillingItems.ForEach(item =>
                {
                    if (item != null && (item.FeeType != null && !item.FeeType.Equals("Fixed Fee", StringComparison.OrdinalIgnoreCase)) || item.FeeType == null)
                    {
                        item.InvoiceFee = item.NSR;
                    }
                });
            }
        }

        private void CalculateConsolidatedTimeAndExpense(List<WorkspaceBillingItemDomain> workspaceBillingItems)
        {
            if (workspaceBillingItems.Any())
            {
                workspaceBillingItems.ForEach(item =>
                {
                    item.LinkedProcessedDataList.ForEach(lpitem =>
                    {
                        item.Hours += lpitem.ChargedHours;
                        item.ANSR += lpitem.ANSR;
                        item.NSR += lpitem.NSR;
                        item.ExpenseAmount += lpitem.ExpenseAmount;
                    });
                });
            }
        }
    }
}
