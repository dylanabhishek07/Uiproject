﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Domain.Model
{
    public class ProductDetailsDomain
    {
        public string ProductId { get; set; }
        public string ClientName { get; set; }
        public string ProductType { get; set; }
        public string Product { get; set; }
        public string Employee { get; set; }
        public object InvoiceFee { get; set; }
        public object Currency { get; set; }
        public string ServiceDescription { get; set; }
        public object BillingEntity { get; set; }
        public object CostCenter { get; set; }
        public object OosNr { get; set; }
        public object GbtRef { get; set; }
        public string BillingType { get; set; }
        public string FeeType { get; set; }
        public string BillingStatus { get; set; }
        public string ProductStatus { get; set; }
        public string GbtStatus { get; set; }
    }
}
