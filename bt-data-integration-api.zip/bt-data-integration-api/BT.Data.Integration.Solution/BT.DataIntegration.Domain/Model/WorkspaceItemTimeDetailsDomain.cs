﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Domain.Model
{
    public class WorkspaceItemTimeDetailsDomain
    {
        public string GId { get; set; }
        //public List<string> ProcessedTnEGIds { get; set; }
        public float TotalHours { get; set; }
        public float TotalANSR { get; set; }
        public float TotalExpenseAmount { get; set; }
    }
}
