﻿using BT.DataIntegration.Domain.Model.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Domain.Model
{
    public class EngagementSummeryConsolidatedDomain
    {
        public EngagementSummeryConsolidatedDomain()
        {
            this.EngagementRevenueList = new List<EngagementRevenueDomain>();
        }

        public string WorkSpaceMasterGid { get; set; }
        public float TotalNSR { get; set; }
        public float TotalANSR { get; set; }
        public float NetTotalNSR { get; set; }
        public float NetTotalANSR { get; set; }
        public float TotalEAF { get; set; }
        public float TotalExpense { get; set; }
        public List<EngagementRevenueDomain> EngagementRevenueList { get; set; }
    }

    public class EngagementRevenueDomain
    {
        public EngagementRevenueDomain()
        {
            this.EngagementItems = new List<EngagementRevenueItemsDomian>();
            this.EngagementItems.Add(new EngagementRevenueItemsDomian() { BillingAction=BillingActionDomainEnum.InvoiceNow});
            this.EngagementItems.Add(new EngagementRevenueItemsDomian() { BillingAction = BillingActionDomainEnum.CarryForward });
            this.EngagementItems.Add(new EngagementRevenueItemsDomian() { BillingAction = BillingActionDomainEnum.NotBillable });
            this.EngagementItems.Add(new EngagementRevenueItemsDomian() { BillingAction = BillingActionDomainEnum.AlreadyBilled });
            this.EngagementItems.Add(new EngagementRevenueItemsDomian() { BillingAction = BillingActionDomainEnum.Miscoded });
        }

        public string EngagementId { get; set; }
        public float TotalNSR { get; set; }
        public float TotalANSR { get; set; }
        public float EAF { get; set; }
        public float TotalExpense { get; set; }
        public float NetTotalNSR { get; set; } /// Excluding Miscoded and carryforward
        public float NetTotalANSR { get; set; } /// Excluding Miscoded and carryforward
        public List<EngagementRevenueItemsDomian> EngagementItems { get; set; }
    }

    public class EngagementRevenueItemsDomian
    {
        public BillingActionDomainEnum BillingAction { get; set; }
        public float NSR { get; set; } = 0;
        public float ANSR { get; set; } = 0;
        public float Expense { get; set; } = 0;
    }
}
