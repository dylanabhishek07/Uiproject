﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Domain.Model
{
    public class BillingEntityWiseInvoiceFeeDistributionDomain
    {
        public string WorkSpaceMasterGid { get; set; }
        public float? TotalInvoiceFee { get; set; }
        public List<EntityInvoiceDetailDomain> EntityInvoiceDetails { get; set; }
    }

    public class EntityInvoiceDetailDomain
    {
        public string? BillingEntityId { get; set; }
        public string? BillingEntityName { get; set; }
        public float? InvoiceFee { get; set; }
    }
}
