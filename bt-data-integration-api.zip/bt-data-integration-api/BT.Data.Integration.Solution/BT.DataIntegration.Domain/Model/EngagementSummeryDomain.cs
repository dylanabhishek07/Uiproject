﻿using BT.DataIntegration.Domain.Model.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Domain.Model
{
    public class EngagementSummeryDomain
    {
        public Guid GId { get; set; }
        public BillingActionDomainEnum BillingActionId { get; set; }

        public BillingActionDomainEnum AdjustedBillingActionId { get; set; }

        public string ProcessedTnEId { get; set; }

        public float NSR { get; set; }

        public float ANSR { get; set; }

        public float EAF { get; set; }

        public float ExpenseAmount { get; set; }

        public string EngagementId { get; set; }
    }
}
