﻿using BT.DataIntegration.Domain.Model.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Domain.Model
{
    public class TNEDataTransferDomain
    {
        public Guid? TransferToWorkspaceGId { get; set; }
        public bool? IsSourceCategory { get; set; }
        public DataTypeDomainEnum? TransferToDataCategory { get; set; }
        public List<string>? FinalProcessedTnEList { get; set; }
    }
}
