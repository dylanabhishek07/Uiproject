﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Domain.Model
{
    public class TNEDetailDomain
    {
        public Guid Guid { get; set; }
        public string? EngagementName { get; set; }
        public DateTime? TransactionDate { get; set; }
        public string? EmployeeName { get; set; }
        public string? Rank { get; set; }
        public string? Country { get; set; }
        public double? ChargedHours { get; set; }
        public string? ChargedHoursDescription { get; set; }
        public double? NSR { get; set; }
        public double? NSRRate { get; set; }
        public double? ANSR { get; set; }
        public double? EAF { get; set; }
        public string? ActivityName { get; set; }
        public DateTime? AccountingDate { get; set; }
        public double? ExpenseAmount { get; set; }
        public string? ExpensesDescription { get; set; }
        public string? VendorName { get; set; }
    }
}
