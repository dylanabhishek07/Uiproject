﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Domain.Model
{
    public class WorkSpaceFeeTextMappingDomain
    {
        public Guid WorkSpaceRowGId { get; set; }
        public string FeeText { get; set; }

    }
}
