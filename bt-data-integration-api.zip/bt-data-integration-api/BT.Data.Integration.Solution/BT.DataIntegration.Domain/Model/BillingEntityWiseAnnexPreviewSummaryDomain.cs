﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Domain.Model
{
    public class BillingEntityWiseAnnexPreviewSummaryDomain
    {
        public string WorkSpaceMasterGid { get; set; } = string.Empty;
        public List<BillingEntityWiseAnnexPreviewDistributionDomain> AnnexPreviewDistribution { get; set; }

    }

    public class BillingEntityWiseAnnexPreviewDistributionDomain
    {
        public string BillingEntityId { get; set; } = string.Empty;
        public string BillingEntityName { get; set; } = string.Empty;
        public float? TotalFee { get; set; } = 0;
        public List<BillingEntityWiseAnnexPreviewDistributionDomainItems> AnnexPreviewDistributionItems { get; set; }       
    }

    public class BillingEntityWiseAnnexPreviewDistributionDomainItems
    {
        public string ProductID { get; set; }
        public string ServiceDescription { get; set; }
        public float? InvoiceFee { get; set; } = 0;
        public string OOSNR { get; set; }
        public string CostCenter { get; set; }
        public string GBTRef { get; set; }
        public string FeeText { get; set; }

    }

}
