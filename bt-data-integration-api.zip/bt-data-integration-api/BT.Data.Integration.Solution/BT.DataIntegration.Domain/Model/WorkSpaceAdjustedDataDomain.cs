﻿using BT.DataIntegration.Domain.Model.Enums;

namespace BT.DataIntegration.Domain.Model
{
    public class WorkSpaceAdjustedDataDomain
    {
        public Guid Gid { get; set; }
        public Enums.DataTypeDomainEnum WorkSpaceDataType { get; set; }
        public BillingActionDomainEnum AdjustedBillingAction { get; set; }
        public float? AdjustedInvoiceFee { get; set; }
        public string? AdjustedCurrency { get; set; }
        public string? AdjustedDescription { get; set; }
        public string? AdjustedBillingEntity { get; set; }
        public string? AdjustedBillingEntityId { get; set; }
        public string? AdjustedCostCenter { get; set; }
        public string? AdjustedOOSNR { get; set; }
        public string? AdjustedGBTStatus { get; set; }
        public string? AdjustedGBTRef { get; set; }
        public string? ModifiedBy { get; set; }
        public DateTime? ModifiedDateTime { get; set; }
    }
}
