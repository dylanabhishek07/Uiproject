﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Domain.Model.Enums
{
    public enum DataTypeDomainEnum
    {
        //None = 0,
        //Billable = 1,
        //NonBillable = 2,
        //Uncoded = 3,
        //Adhoc = 4,
        //AdditionalBillingOppertunity = 5,
        //Expense = 6

        None = 0,
        Billable = 1,
        AdditionalBillingOppertunity = 2,
        NonBillable = 3,
        Adhoc = 4,
        Uncoded = 5,
        Expense = 6
    }
}
