﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Domain.Model
{
    public class ClientDomain
    {
        public string? ClientId { get; set; }
        public string? ClientName { get; set; }
    }
}
