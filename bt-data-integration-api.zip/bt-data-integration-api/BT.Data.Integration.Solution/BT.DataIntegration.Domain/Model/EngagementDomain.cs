﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Domain.Model
{
    public class EngagementDomain
    {
        public Guid GId { get; set; }
        public string EngagementId { get; set; }
    }
}
