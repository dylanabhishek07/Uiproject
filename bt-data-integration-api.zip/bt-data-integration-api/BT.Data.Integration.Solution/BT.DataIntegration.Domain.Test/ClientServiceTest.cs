﻿using BT.DataIntegration.Domain.Client;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Ports.In;
using BT.DataIntegration.Domain.Ports.Out;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace BT.DataIntegration.Domain.Test
{
    public class ClientServiceTest
    {

        Mock<IDataManager> dataMangerMock = new Mock<IDataManager>();
        private readonly IClientService clientService;

        public ClientServiceTest()
        {
            clientService = new ClientService(dataMangerMock.Object);
        }

        [Fact]
        public async void GetClientByIndex_Should_Return_List_Of_ClientDomain()
        {

            dataMangerMock.Setup(p => p.GetClientByIndex(It.IsAny<int>(), It.IsAny<int>())).ReturnsAsync(new List<ClientDomain>());
            var result = await clientService.GetClientByIndex(0,5);
            Assert.True(result.GetType() == typeof(List<ClientDomain>));
        }

        [Fact]
        public async void GetClientSpecificEngagementsByIndex_Should_Return_List_Of_EngagementDomain()
        {

            dataMangerMock.Setup(p => p.GetClientSpecificEngagementsByIndex(It.IsAny<string>(),It.IsAny<int>(), It.IsAny<int>())).ReturnsAsync(new List<EngagementDomain>());
            var result = await clientService.GetClientSpecificEngagementsByIndex("Test",0, 5);
            Assert.True(result.GetType() == typeof(List<EngagementDomain>));
        }
    }
}
