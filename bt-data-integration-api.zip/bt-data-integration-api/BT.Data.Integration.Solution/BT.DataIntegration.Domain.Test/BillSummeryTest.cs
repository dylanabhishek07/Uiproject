﻿using BT.DataIntegration.Domain.BillSummery;
using BT.DataIntegration.Domain.Client;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Model.Enums;
using BT.DataIntegration.Domain.Ports.In;
using BT.DataIntegration.Domain.Ports.Out;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;


namespace BT.DataIntegration.Domain.Test
{
    public class BillSummeryTest
    {
        Mock<IBillSummeryManager> billSummeryManagerMock = new Mock<IBillSummeryManager>();
        private readonly BillSummeryService billSummeryService;
        public BillSummeryTest()
        {
            billSummeryService = new BillSummeryService(billSummeryManagerMock.Object);
        }
        [Fact]
        public async void GetEngagementSummeryDetails_Should_Return_EngagementSummeryConsolidatedDomain()
        {

            billSummeryManagerMock.Setup(p => p.GetEngagementSummeryDetails(It.IsAny<string>())).ReturnsAsync(new List<EngagementSummeryDomain>());
            var result = await billSummeryService.GetEngagementSummeryDetails("123");
            Assert.True(result.GetType() == typeof(EngagementSummeryConsolidatedDomain));
        }
        [Fact]
        public async void GetBillingEntitySummeryDetails_Should_Return_BillingEntityWiseInvoiceFeeDistributionDomain()
        {
            var result = await billSummeryService.GetBillingEntitySummeryDetails("123",new List<ModifiedWorkSpaceDetailsDomain>());
            Assert.True(result.GetType() == typeof(BillingEntityWiseInvoiceFeeDistributionDomain));
        }
        [Fact]
        public async void GetBillingEntitySummeryDetails_Result_Should_Sum_InvoiceFee_If_AdjustedInvoiceFee_Is_null()
        {
            var modifiedWorkSpaceList = new List<ModifiedWorkSpaceDetailsDomain>()
            {
                new ModifiedWorkSpaceDetailsDomain()
                {
                    Gid = Guid.Parse("524d0962-6258-ec11-9977-a864f19bbed1"),
                    WorkSpaceDataType = DataTypeDomainEnum.Billable,
                    AdjustedBillingAction= BillingActionDomainEnum.CarryForward ,
                    AdjustedInvoiceFee= null,
                    AdjustedCurrency= "test",
                    AdjustedDescription= "Desc_1",
                    AdjustedBillingEntity= "EY US",
                    AdjustedBillingEntityId= "EU123",
                    AdjustedCostCenter= null,
                    AdjustedOOSNR= null,
                    AdjustedGBTStatus= null,
                    AdjustedGBTRef= null,
                    ModifiedBy= null,
                    ModifiedDateTime = DateTime.Now,
                    InvoiceFee= 50,
                    BillingEntityName= null,
                    BillingEntityId= null,
                    BillingActionId= 0
                },
                new ModifiedWorkSpaceDetailsDomain()
                {
                    Gid = Guid.Parse("2C5C3BB1-345F-EC11-9977-A864F19BBED1"),
                    WorkSpaceDataType = DataTypeDomainEnum.AdditionalBillingOppertunity,
                    AdjustedBillingAction= BillingActionDomainEnum.CarryForward,
                    AdjustedInvoiceFee= null,
                    AdjustedCurrency= "test",
                    AdjustedDescription= "Desc_2",
                    AdjustedBillingEntity= "EY US",
                    AdjustedBillingEntityId= "EU123",
                    AdjustedCostCenter= null,
                    AdjustedOOSNR= null,
                    AdjustedGBTStatus= null,
                    AdjustedGBTRef= null,
                    ModifiedBy= null,
                    ModifiedDateTime = DateTime.Now,
                    InvoiceFee= 50,
                    BillingEntityName= null,
                    BillingEntityId= null,
                    BillingActionId= 0
                },
                new ModifiedWorkSpaceDetailsDomain()
                {
                    Gid = Guid.Parse("A78BF929-DF7D-EC11-997B-A864F19BBED1"),
                    WorkSpaceDataType = DataTypeDomainEnum.Expense,
                    AdjustedBillingAction= BillingActionDomainEnum.CarryForward,
                    AdjustedInvoiceFee= null,
                    AdjustedCurrency= "test",
                    AdjustedDescription= "Desc_3",
                    AdjustedBillingEntity= "EY India",
                    AdjustedBillingEntityId= "EI123",
                    AdjustedCostCenter= null,
                    AdjustedOOSNR= null,
                    AdjustedGBTStatus= null,
                    AdjustedGBTRef= null,
                    ModifiedBy= null,
                    ModifiedDateTime = DateTime.Now,
                    InvoiceFee= 50,
                    BillingEntityName= null,
                    BillingEntityId= null,
                    BillingActionId= 0
                }
            };
            var result = await billSummeryService.GetBillingEntitySummeryDetails("123", modifiedWorkSpaceList);
            Assert.True(result.TotalInvoiceFee == 150);
        }

        [Fact]
        public async void GetBillingEntitySummeryDetails_Result_Should_Group_AdjustedInvoiceFee_Per_Billing_Entity()
        {
            var modifiedWorkSpaceList = new List<ModifiedWorkSpaceDetailsDomain>()
            {
                new ModifiedWorkSpaceDetailsDomain()
                {
                    Gid = Guid.Parse("524d0962-6258-ec11-9977-a864f19bbed1"),
                    WorkSpaceDataType = DataTypeDomainEnum.Billable,
                    AdjustedBillingAction= BillingActionDomainEnum.CarryForward ,
                    AdjustedInvoiceFee= 100,
                    AdjustedCurrency= "test",
                    AdjustedDescription= "Desc_1",
                    AdjustedBillingEntity= "EY US",
                    AdjustedBillingEntityId= "EU123",
                    AdjustedCostCenter= null,
                    AdjustedOOSNR= null,
                    AdjustedGBTStatus= null,
                    AdjustedGBTRef= null,
                    ModifiedBy= null,
                    ModifiedDateTime = DateTime.Now,
                    InvoiceFee= 50,
                    BillingEntityName= null,
                    BillingEntityId= null,
                    BillingActionId= 0
                },
                new ModifiedWorkSpaceDetailsDomain()
                {
                    Gid = Guid.Parse("2C5C3BB1-345F-EC11-9977-A864F19BBED1"),
                    WorkSpaceDataType = DataTypeDomainEnum.AdditionalBillingOppertunity,
                    AdjustedBillingAction= BillingActionDomainEnum.CarryForward,
                    AdjustedInvoiceFee= 100,
                    AdjustedCurrency= "test",
                    AdjustedDescription= "Desc_2",
                    AdjustedBillingEntity= "EY US",
                    AdjustedBillingEntityId= "EU123",
                    AdjustedCostCenter= null,
                    AdjustedOOSNR= null,
                    AdjustedGBTStatus= null,
                    AdjustedGBTRef= null,
                    ModifiedBy= null,
                    ModifiedDateTime = DateTime.Now,
                    InvoiceFee= 50,
                    BillingEntityName= null,
                    BillingEntityId= null,
                    BillingActionId= 0
                },
                new ModifiedWorkSpaceDetailsDomain()
                {
                    Gid = Guid.Parse("A78BF929-DF7D-EC11-997B-A864F19BBED1"),
                    WorkSpaceDataType = DataTypeDomainEnum.Expense,
                    AdjustedBillingAction= BillingActionDomainEnum.CarryForward,
                    AdjustedInvoiceFee= 500,
                    AdjustedCurrency= "test",
                    AdjustedDescription= "Desc_3",
                    AdjustedBillingEntity= "EY India",
                    AdjustedBillingEntityId= "EI123",
                    AdjustedCostCenter= null,
                    AdjustedOOSNR= null,
                    AdjustedGBTStatus= null,
                    AdjustedGBTRef= null,
                    ModifiedBy= null,
                    ModifiedDateTime = DateTime.Now,
                    InvoiceFee= 50,
                    BillingEntityName= null,
                    BillingEntityId= null,
                    BillingActionId= 0
                }
            };
            var result = await billSummeryService.GetBillingEntitySummeryDetails("123", modifiedWorkSpaceList);
            Assert.True(result.EntityInvoiceDetails.Count == 2);
            foreach(var entity in result.EntityInvoiceDetails)
            {
                Assert.True(entity.BillingEntityId == "EU123" ? entity.InvoiceFee == 200 : entity.InvoiceFee == 500);
            }
            
        }


    }
}
