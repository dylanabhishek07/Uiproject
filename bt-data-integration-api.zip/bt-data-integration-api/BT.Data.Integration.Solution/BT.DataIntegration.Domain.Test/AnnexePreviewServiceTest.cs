﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using Moq;
using BT.DataIntegration.Domain.AnnexPreview;
using BT.DataIntegration.Domain.Ports.Out;
using BT.DataIntegration.Domain.Model;

namespace BT.DataIntegration.Domain.Test
{
    
    public class AnnexePreviewServiceTest
    {
        Mock<IAnnexePreviewManager> annexePreviewManagerMock = new Mock<IAnnexePreviewManager>();
        private readonly AnnexPreviewService annexPreviewService;

        public AnnexePreviewServiceTest()
        {
            annexPreviewService = new AnnexPreviewService(annexePreviewManagerMock.Object);
        }        

        [Fact]
        public async void GetBillingEntityWiseAnnexPreviewData_Should_Return_BillingEntityWiseAnnexPreviewSummaryDomain()
        {
            var result = await annexPreviewService.GetBillingEntityWiseAnnexPreviewData("123", new List<ModifiedWorkSpaceDetailsDomain>());
            Assert.True(result.GetType() == typeof(BillingEntityWiseAnnexPreviewSummaryDomain));
        }
        //[Fact]
        //public async void GetBillingEntitySummeryDetails_Result_Should_Sum_InvoiceFee_If_AdjustedInvoiceFee_Is_null()
        //{
        //    var modifiedWorkSpaceList = new List<ModifiedWorkSpaceDetailsDomain>()
        //    {
        //        new ModifiedWorkSpaceDetailsDomain()
        //        {
        //            Gid = Guid.Parse("524d0962-6258-ec11-9977-a864f19bbed1"),
        //            WorkSpaceDataType = DataTypeDomainEnum.Billable,
        //            AdjustedBillingAction= BillingActionDomainEnum.CarryForward ,
        //            AdjustedInvoiceFee= null,
        //            AdjustedCurrency= "test",
        //            AdjustedDescription= "Desc_1",
        //            AdjustedBillingEntity= "EY US",
        //            AdjustedBillingEntityId= "EU123",
        //            AdjustedCostCenter= null,
        //            AdjustedOOSNR= null,
        //            AdjustedGBTStatus= null,
        //            AdjustedGBTRef= null,
        //            ModifiedBy= null,
        //            ModifiedDateTime = DateTime.Now,
        //            InvoiceFee= 50,
        //            BillingEntityName= null,
        //            BillingEntityId= null,
        //            BillingActionId= 0
        //        },
        //        new ModifiedWorkSpaceDetailsDomain()
        //        {
        //            Gid = Guid.Parse("2C5C3BB1-345F-EC11-9977-A864F19BBED1"),
        //            WorkSpaceDataType = DataTypeDomainEnum.AdditionalBillingOppertunity,
        //            AdjustedBillingAction= BillingActionDomainEnum.CarryForward,
        //            AdjustedInvoiceFee= null,
        //            AdjustedCurrency= "test",
        //            AdjustedDescription= "Desc_2",
        //            AdjustedBillingEntity= "EY US",
        //            AdjustedBillingEntityId= "EU123",
        //            AdjustedCostCenter= null,
        //            AdjustedOOSNR= null,
        //            AdjustedGBTStatus= null,
        //            AdjustedGBTRef= null,
        //            ModifiedBy= null,
        //            ModifiedDateTime = DateTime.Now,
        //            InvoiceFee= 50,
        //            BillingEntityName= null,
        //            BillingEntityId= null,
        //            BillingActionId= 0
        //        },
        //        new ModifiedWorkSpaceDetailsDomain()
        //        {
        //            Gid = Guid.Parse("A78BF929-DF7D-EC11-997B-A864F19BBED1"),
        //            WorkSpaceDataType = DataTypeDomainEnum.Expense,
        //            AdjustedBillingAction= BillingActionDomainEnum.CarryForward,
        //            AdjustedInvoiceFee= null,
        //            AdjustedCurrency= "test",
        //            AdjustedDescription= "Desc_3",
        //            AdjustedBillingEntity= "EY India",
        //            AdjustedBillingEntityId= "EI123",
        //            AdjustedCostCenter= null,
        //            AdjustedOOSNR= null,
        //            AdjustedGBTStatus= null,
        //            AdjustedGBTRef= null,
        //            ModifiedBy= null,
        //            ModifiedDateTime = DateTime.Now,
        //            InvoiceFee= 50,
        //            BillingEntityName= null,
        //            BillingEntityId= null,
        //            BillingActionId= 0
        //        }
        //    };
        //    var result = await billSummeryService.GetBillingEntitySummeryDetails("123", modifiedWorkSpaceList);
        //    Assert.True(result.TotalInvoiceFee == 150);
        //}
    }
}
