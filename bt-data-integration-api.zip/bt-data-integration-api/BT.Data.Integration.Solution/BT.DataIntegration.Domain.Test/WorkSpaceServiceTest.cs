using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Ports.In;
using BT.DataIntegration.Domain.Ports.Out;
using BT.DataIntegration.Domain.Workspace;
using Moq;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace BT.DataIntegration.Domain.Test
{
    public class WorkSpaceServiceTest
    {
        Mock<IDataManager> dataMangerMock = new Mock<IDataManager>();
        Mock<IQueueManager> queueManagerMock = new Mock<IQueueManager>();
        Mock<IWorkSpaceManager> workSpaceManagerMock = new Mock<IWorkSpaceManager>();
        Mock<IBeOneAPI> _beOneApiServiceMock = new Mock<IBeOneAPI>();
        private readonly IWorkSpaceService workSpaceService;

        public WorkSpaceServiceTest()
        { 
            workSpaceService = new WorkSpaceService(_beOneApiServiceMock.Object, dataMangerMock.Object, queueManagerMock.Object, workSpaceManagerMock.Object);
        }

        [Fact]
        public async void AddWorkSpace_Should_Return_Empty_Guid_When_WorkSpaceDetail_Is_Null()
        {
            var result = await workSpaceService.AddWorkSpace(null);
            Assert.Equal(result, Guid.Empty);
        }

        [Fact]
        public async void AddWorkSpace_Should_Return_Empty_Guid_When_WorKSpaceName_Is_Empty()
        {

            var workSpaceDetail = new WorkSpaceDetailDomain()
            {
                WorkSpaceGuid = Guid.NewGuid(),
                WorkspaceName = String.Empty,
                EngagementIds = "ENG_1,ENG_2",
                ClientEngagementMapGIds = new System.Collections.Generic.List<string> { "GID_1", "GID_2" },
                BeOneWorkFlowId = "Test_Workflow",
                CreatedBy = "Unit_Test"
            };
            var result = await workSpaceService.AddWorkSpace(workSpaceDetail);
            Assert.Equal(result, Guid.Empty);
        }

        [Fact]
        public async void AddWorkSpace_Should_Return_Empty_Guid_When_WorKSpaceClientEngagementMapGIds_Is_Null()
        {

            var workSpaceDetail = new WorkSpaceDetailDomain()
            {
                WorkSpaceGuid = Guid.NewGuid(),
                WorkspaceName = "Test_WorkSpace",
                EngagementIds = "ENG_1,ENG_2",
                ClientEngagementMapGIds = null,
                BeOneWorkFlowId = "Test_Workflow",
                CreatedBy = "Unit_Test"
            };
            var result = await workSpaceService.AddWorkSpace(workSpaceDetail);
            Assert.Equal(result, Guid.Empty);
        }

        [Fact]
        public async void AddWorkSpace_Should_Return_Empty_Guid_When_WorKSpaceClientEngagementMapGIds_Count_Is_Zero()
        {

            var workSpaceDetail = new WorkSpaceDetailDomain()
            {
                WorkSpaceGuid = Guid.NewGuid(),
                WorkspaceName = "Test_WorkSpace",
                EngagementIds = "ENG_1,ENG_2",
                ClientEngagementMapGIds = new System.Collections.Generic.List<string> {  },
                BeOneWorkFlowId = "Test_Workflow",
                CreatedBy = "Unit_Test"
            };
            var result = await workSpaceService.AddWorkSpace(workSpaceDetail);
            Assert.Equal(result, Guid.Empty);
        }

        [Fact]
        public async void AddWorkSpace_Should_Return_Non_Empty_Guid_When_WorKSpaceDetail_Is_Properly_Framed()
        {

            var workSpaceDetail = new WorkSpaceDetailDomain()
            {
                WorkSpaceGuid = Guid.Empty,
                WorkspaceName = "Test_WorkSpace",
                EngagementIds = "ENG_1,ENG_2",
                ClientEngagementMapGIds = new System.Collections.Generic.List<string> { "GID_1", "GID_2" },
                BeOneWorkFlowId = "Test_Workflow",
                CreatedBy = "Unit_Test"
            };
            dataMangerMock.Setup(p => p.AddWorkSpace(It.IsAny<WorkSpaceDetailDomain>())).ReturnsAsync(Guid.NewGuid);
            var result = await workSpaceService.AddWorkSpace(workSpaceDetail);
            Assert.NotEqual(result, Guid.Empty);
        }

        [Fact]
        public async void CreateAdhocGuid_Should_Return_Empty_Guid_When_wrkSpaceGuid_Is_Empty()
        {
            var result = await workSpaceService.CreateAdhocGuid(Guid.Empty,"Unit_Test");
            Assert.Equal(result, Guid.Empty);
        }
        
        [Fact]
        public async void CreateAdhocGuid_Should_Return_Non_Empty_Guid_When_wrkSpaceGuid_Is_Not_Empty()
        {

            workSpaceManagerMock.Setup(p => p.CreateAdhocGuid(It.IsAny<Guid>(),It.IsAny<string>())).ReturnsAsync(Guid.NewGuid);
            var result = await workSpaceService.CreateAdhocGuid(Guid.NewGuid(), "Unit_Test");
            Assert.NotEqual(result, Guid.Empty);
        }

        [Fact]
        public async void CheckForExistingWorkSpace_Should_Return_List_Of_WorkDetailDomain_When_ClientEngagementMapGIds_Is_Not_Empty()
        {

            dataMangerMock.Setup(p => p.CheckForExistingWorkSpace(It.IsAny<string>())).ReturnsAsync(new List<WorkSpaceDetailDomain>());
            var result = await workSpaceService.CheckForExistingWorkSpace("123,456");
            Assert.True(result.GetType() == typeof(List<WorkSpaceDetailDomain>));
        }

        [Fact]
        public async void GetTimeDetails_Should_Return_List_Of_TNEDetailDomain_When_WorkspaceGuid_Is_Not_Empty()
        {

            dataMangerMock.Setup(p => p.GetTimeDetails(It.IsAny<string>())).ReturnsAsync(new List<TNEDetailDomain>());
            var result = await workSpaceService.GetTimeDetails("123");
            Assert.True(result.GetType() == typeof(List<TNEDetailDomain>));
        }

        [Fact]
        public async void IsBillingDataReady_Should_Return_bool__When_workspaceId_Is_Not_Empty()
        {

            dataMangerMock.Setup(p => p.IsBillingDataReady(It.IsAny<string>())).ReturnsAsync(false);
            var result = await workSpaceService.IsBillingDataReady("123");
            Assert.True(result.GetType() == typeof(bool));
        }

        [Fact]
        public async void IsBillingDataReady_Should_Return_true__When_workspaceId_Is_Not_Empty_And_Data_Is_Ready()
        {

            dataMangerMock.Setup(p => p.IsBillingDataReady(It.IsAny<string>())).ReturnsAsync(true);
            var result = await workSpaceService.IsBillingDataReady("123");
            Assert.True(result);
        }

        [Fact]
        public async void UpdateWorkSpace_Should_Return_false__When_wrkSpcAdjustedRecordsList_Is_Empty()
        {
            var result = await workSpaceService.UpdateWorkSpace(new List<ModifiedWorkSpaceDetailsDomain>());
            Assert.False(result);
        }

        [Fact]
        public async void UpdateWorkSpace_Should_Return_boolean_When_wrkSpcAdjustedRecordsList_Is_Not_Empty()
        {

            workSpaceManagerMock.Setup(p => p.UpdateWorkSpace(It.IsAny<List<ModifiedWorkSpaceDetailsDomain>>())).ReturnsAsync(false);
            var result = await workSpaceService.UpdateWorkSpace(new List<ModifiedWorkSpaceDetailsDomain>()
            {
                new ModifiedWorkSpaceDetailsDomain
                {
                    Gid = Guid.NewGuid(),
                    WorkSpaceDataType = Model.Enums.DataTypeDomainEnum.Billable,
                    AdjustedBillingAction = Model.Enums.BillingActionDomainEnum.InvoiceNow,
                    AdjustedInvoiceFee = 0,
                    AdjustedCurrency=  String.Empty,
                    AdjustedDescription = String.Empty,
                    AdjustedBillingEntity = String.Empty,
                    AdjustedBillingEntityId = "Test",
                    AdjustedCostCenter = String.Empty,
                    AdjustedOOSNR = String.Empty,
                    AdjustedGBTStatus= String.Empty,
                    AdjustedGBTRef = String.Empty,
                    ModifiedBy = "Unit_Test",
                    ModifiedDateTime = DateTime.Now,
                } 
            });
            Assert.True(result.GetType() == typeof(bool));
        }

        [Fact]
        public async void GetProcessedTimeDetailsForItems_Should_Always_Return_List_Of_WorkspaceItemTimeDetailsDomain()
        {
            var result = await workSpaceService.GetProcessedTimeDetailsForItems(new List<WorkspaceItemTimeDetailsDomain>());
            Assert.True(result.GetType() == typeof(List<WorkspaceItemTimeDetailsDomain>));
        }
        
        [Fact]
        public async void GetWorkSpaceBillingDetails_Should_Always_Return_List_Of_WorkspaceBillingItemDomain()
        {
            workSpaceManagerMock.Setup(p => p.GetWorkspaceBillingDetails(It.IsAny<string>())).ReturnsAsync(new List<WorkspaceBillingItemDomain>());
            var result = await workSpaceService.GetWorkSpaceBillingDetails("WorkSpaceGId_1");
            Assert.True(result.GetType() == typeof(List<WorkspaceBillingItemDomain>));
        }

        [Fact]
        public async void UpdateTNEMapping_Should_Always_Return_Empty_List_Of_TNEDataTransferDomain_When_Input_List_Of_TNEDataTransferDomain_Is_Empty()
        {
            var result = await workSpaceService.UpdateTNEMapping(new List<TNEDataTransferDomain>());
            Assert.True(result.Count ==0);
        }
    }
}