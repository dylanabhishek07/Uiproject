﻿using BT.DataIntegration.Adapter.API.Contracts;
using BT.DataIntegration.Adapter.API.Handler;
using BT.DataIntegration.Adapter.Infrastructure.AuthAPI;
using BT.DataIntegration.Adapter.Infrastructure.BeOneAPI;
using BT.DataIntegration.Adapter.Infrastructure.DataBase;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Repositories;
using BT.DataIntegration.Adapter.Infrastructure.KeyVault;
using BT.DataIntegration.Adapter.Infrastructure.Queue;
using BT.DataIntegration.Domain.AnnexPreview;
using BT.DataIntegration.Domain.BillSummery;
using BT.DataIntegration.Domain.Client;
using BT.DataIntegration.Domain.Invoice;
using BT.DataIntegration.Domain.Ports.In;
using BT.DataIntegration.Domain.Ports.Out;
using BT.DataIntegration.Domain.Workspace;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Azure;
using Microsoft.Identity.Web;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;

namespace BT.Data.Integration.API
{
    internal static class IServiceCollectionExtension
    {
        internal static IServiceCollection RegisterDB(this IServiceCollection services)
        {
            return services;

        }

        internal static IServiceCollection RegisterRepositories(this IServiceCollection services)
        {
            return services
                            .AddScoped(typeof(IBillingRepository<>), typeof(BillingRepository<>))
                            .AddScoped<IClientRepository, ClientRepository>()
                            .AddScoped<IEngagementRepository, EngagementRepository>()
                            .AddScoped<IProcessedDataRepository, ProcessedDataRepository>()
                            .AddScoped<IWorkSpaceRepository, WorkSpaceRepository>()
                            .AddScoped<IInvoiceDetailsRepository, InvoiceDetailsRepository>()
                            .AddScoped<IBillSummeryRepository, BillSummeryRepository>()                            
                            .AddScoped<IAnnexePreviewRepository,AnnexePreviewRepository>();

        }

        internal static IServiceCollection RegisterServices(this IServiceCollection services)
        {
            return services
                            .AddScoped<IDataManager, DataManager>()
                            .AddScoped<IWorkSpaceManager, WorkspaceManager>()
                            .AddScoped<IBillSummeryManager, BillSummeryManager>()
                            .AddScoped<IBillSummeryService, BillSummeryService>()
                            .AddScoped<IBillSummeryHandler, BillSummeryHandler>()
                            .AddScoped<IClientService, ClientService>()
                            .AddScoped<IAnnexPreviewService, AnnexPreviewService>()
                            .AddScoped<IAnnexPreviewHandler, AnnexPreviewHandler>()
                            .AddScoped<IAnnexePreviewManager, AnnexePreviewManager>()
                            .AddScoped<IClientEngagementHandler, ClientEngagementHandler>()
                            .AddScoped<IWorkSpaceHandler, WorkSpaceHandler>()
                            .AddScoped<IWorkSpaceService, WorkSpaceService>()
                            .AddScoped<IQueueManager, AZStorageQManager>()
                            .AddScoped<IVaultManager, AzureVaultManager>()
                            .AddScoped<IInvoiceDetailsManager, InvoiceDetailsManager>()
                            .AddScoped<IInvoiceDetailsService, InvoiceDetailsService>()
                            .AddScoped<IInvoiceDetailHandler, InvoiceDetailHandler>()
                            .AddSingleton<IAuthenticationAPI, AuthenticationAPI>()
                            .AddScoped<IBeOneAPI, BeeOneAPI>()
                            .AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
        }

        internal static IServiceCollection RegisterVersions(this IServiceCollection services)
        {
            return services.AddApiVersioning(config =>
             {
                 config.DefaultApiVersion = new ApiVersion(1, 0);
                 config.AssumeDefaultVersionWhenUnspecified = true;
                 config.ReportApiVersions = true;
             });
        }

        internal static IServiceCollection AddSecretServices(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddAzureClients(config =>
            {
                config.AddSecretClient(configuration.GetSection("KeyVault"));
            });

            return services;
        }

        /// <summary>
        /// Registers Redis Cache. Redis have Dependency on KeyVault. So, on start-up register redis post the keyvault service registrations 
        /// </summary>
        /// <param name="services"></param>
        /// <param name="configuration"></param>
        /// <returns></returns>
        internal static IServiceCollection AddRedisCache(this IServiceCollection services, IConfiguration configuration)
        {
            var _vaultManager = services.BuildServiceProvider().GetService<IVaultManager>();
            if (_vaultManager == null)
                throw new Exception(message: "Keyvault not initialized. Keyvault must be initialized before registering cache provider");
            services.AddStackExchangeRedisCache(async options =>
            {
                options.Configuration = await _vaultManager.GetClientsSecrets( configuration.GetValue<string>("KeyVault:RedisConnectionKey"));
                options.InstanceName = "BillingAutomation_";
            });

            return services;
        }

        //internal static IServiceCollection RegisterAuthentication(this IServiceCollection services, IConfiguration configuration)
        //{
        //  return services.AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
        //           .AddMicrosoftIdentityWebApi(configuration.GetSection("AzureAd"));
        //}

        internal static IServiceCollection RegisterSwagger(this IServiceCollection services)
        {
            // Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
            return services.AddSwaggerGen(config =>
             {
                 config.SwaggerDoc("v1", new OpenApiInfo { Title = "BT.DataIntegration.Api", Version = "v1" });
                 config.AddSecurityDefinition("Bearer",
                    new OpenApiSecurityScheme
                    {
                        Description = "Please enter into field the word 'Bearer' following by space and JWT",
                        Name = "Authorization",
                        Type = SecuritySchemeType.ApiKey,
                        BearerFormat = "JWT",
                        In = ParameterLocation.Header

                    });
                 config.AddSecurityRequirement(new OpenApiSecurityRequirement
                  {
                    {
                        new OpenApiSecurityScheme {
                            Reference = new OpenApiReference {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer" }
                        },
                        new string[] { }
                    }
                 });
             });
        }
    }
}
