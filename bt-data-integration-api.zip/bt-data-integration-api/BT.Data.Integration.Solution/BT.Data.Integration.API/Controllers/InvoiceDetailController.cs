﻿using BT.DataIntegration.Adapter.API.Contracts;
using BT.DataIntegration.Adapter.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BT.Data.Integration.API.Controllers
{
    [Authorize]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [Produces("application/json")]
    [ApiController]
    public class InvoiceDetailController : ControllerBase
    {
        private readonly IInvoiceDetailHandler _invoiceHandler;
        private readonly ILogger<InvoiceDetailController> _logger;

        public InvoiceDetailController(IInvoiceDetailHandler invoiceHandler, ILogger<InvoiceDetailController> logger)
        {
            _invoiceHandler = invoiceHandler;
            _logger = logger;
        }

        [HttpPost("SaveInvoiceDetails")]
        public async Task<int> SaveInvoiceDetails(List<InvoiceDetail> invoiceDetails)
        {
            _logger.LogInformation("Saving Invoice Details");
            return await _invoiceHandler.SaveInvoiceDetails(invoiceDetails);
        }
    }
}
