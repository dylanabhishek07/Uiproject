﻿using BT.DataIntegration.Adapter.API.Contracts;
using BT.DataIntegration.Adapter.API.Handler;
using BT.DataIntegration.Adapter.API.Helper;
using BT.DataIntegration.Adapter.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Caching.Distributed;

namespace BT.Data.Integration.API.Controllers
{
    [Authorize]
    [EnableCors()]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [Produces("application/json")]
    [ApiController]
    public class SessionManagementController : ControllerBase
    {
        public SessionManagementController()
        {

        }

        [HttpPost("SaveWorkSpaceUIDetails")]
        public async Task SetWorkSpaceData([FromBody] WorkSpaceUIDetails value)
        {
            await HttpContext.Session.SetObjectInSession<WorkSpaceUIDetails>(value, Constant.WORKSPACE_SESSION_KEY);
        }

        [HttpGet("GetWorkSpaceUIDetails")]
        public async Task<WorkSpaceUIDetails> GetWorkSpaceData()
        {
            var result = await HttpContext.Session.GetObjectFromSession<WorkSpaceUIDetails>(Constant.WORKSPACE_SESSION_KEY);
            return result;
        }

        [HttpGet("Clear")]
        public async Task Clear()
        {
             HttpContext.Session.Remove(Constant.WORKSPACE_SESSION_KEY);
            HttpContext.Session.Clear();
        }

        //private string _testText = "Text to go in cache";
        //[HttpGet("GetTestTextFromCache")]
        //public async Task<string> GetTestText()
        //{
        //    var cacheToken = "testtext01";
        //    string result = await _cache.GetStringAsync(cacheToken);
        //    if (string.IsNullOrEmpty(result))
        //    {
        //        result = _testText;
        //        await _cache.SetStringAsync(cacheToken, _testText);
        //    }

        //    return result;
        //}
    }
}
