﻿using BT.Data.Integration.Adapter.API.Models;
using BT.DataIntegration.Adapter.API.Contracts;
using BT.DataIntegration.Adapter.API.Handler;
using BT.DataIntegration.Adapter.API.Helper;
using BT.DataIntegration.Adapter.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BT.Data.Integration.API.Controllers
{
    [Authorize]
    [EnableCors()]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [Produces("application/json")]
    public class AnnexePreviewController : ControllerBase
    {
        private readonly ILogger<AnnexePreviewController> _logger;
        private readonly IConfiguration _config;
        private readonly IAnnexPreviewHandler _annexPreviewHandler;

        public AnnexePreviewController(ILogger<AnnexePreviewController> logger, IAnnexPreviewHandler annexPreviewHandler, IConfiguration config)
        {
            _logger = logger;
            _annexPreviewHandler = annexPreviewHandler;
            _config = config;
        }

        [HttpGet("GetBillingEntityWiseAnnexPreviewData")]
        public async Task<BillingEntityWiseAnnexPreviewSummary> GetBillingEntityWiseAnnexPreviewData([FromQuery] string workspaceMasterGId)
        {
            var workspaceSession = await HttpContext.Session.GetObjectFromSession<WorkSpaceUIDetails>(Constant.WORKSPACE_SESSION_KEY);
            return await _annexPreviewHandler.GetBillingEntityWiseAnnexPreviewData(workspaceMasterGId, workspaceSession);
        }

        [HttpPost("SaveAnnexPreviewFeeData")]
        public async Task<int> SaveAnnexPreviewFeeDetails([FromBody] List<AnnexPreviewFeeDetail> feeDetails)
        {
            return await _annexPreviewHandler.SaveAnnexPreviewFeeDetails(feeDetails);
        }

    }
}
