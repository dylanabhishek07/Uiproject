﻿using BT.DataIntegration.Adapter.API.Contracts;
using BT.DataIntegration.Adapter.API.Handler;
using BT.DataIntegration.Adapter.API.Helper;
using BT.DataIntegration.Adapter.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BT.Data.Integration.API.Controllers
{
    [Authorize]
    [EnableCors()]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [Produces("application/json")]
    public class BillSummeryController : ControllerBase
    {
        private readonly ILogger<BillSummeryController> _logger;
        private readonly IConfiguration _config;
        private readonly IBillSummeryHandler _billSummeryHandler;

        public BillSummeryController(ILogger<BillSummeryController> logger, IBillSummeryHandler billSummeryHandler, IConfiguration config)
        {
            _logger = logger;
            _billSummeryHandler = billSummeryHandler;
            _config = config;
        }

        [HttpGet("GetEngagementSummery")]
        public async Task<EngagementSummeryConsolidated> GetEngagementSummery([FromQuery] string workspaceMasterGId)
        {
            return await _billSummeryHandler.GetEngagementSummery(workspaceMasterGId);
        }

        [HttpGet("GetBillingEntitySummery")]
        public async Task<BillingEntityWiseInvoiceFeeDistribution> GetBillingEntitySummery([FromQuery] string workspaceMasterGId)
        {
            var workspaceSession = await HttpContext.Session.GetObjectFromSession<WorkSpaceUIDetails>(Constant.WORKSPACE_SESSION_KEY);
            return await _billSummeryHandler.GetBillingEntitySummery(workspaceMasterGId, workspaceSession);
        }

        [HttpPost("GetFeeSharingDetails")]
        public async Task<FeeSharingResponse> GetFeeSharingDetails([FromBody] FeeSharingRequest feeSharingRequest)
        {
            return await _billSummeryHandler.GetFeeSharingDetails(feeSharingRequest);
        }
        [HttpPost("GetEAFDetails")]
        public async Task<BillSummeryEAFDetails> GetEAFDetails([FromQuery] string workspaceMasterGId)
        {
            return await _billSummeryHandler.GetEAFCalculationDetails(workspaceMasterGId);
        }

        [HttpPost("SaveEAFDetails")]
        public async Task SaveEAFDetails([FromBody] BillSummeryEAFDetails billSummeryEAFDetails)
        {
             await _billSummeryHandler.SaveEAFCalculationDetails(billSummeryEAFDetails);
        }
    }
}
