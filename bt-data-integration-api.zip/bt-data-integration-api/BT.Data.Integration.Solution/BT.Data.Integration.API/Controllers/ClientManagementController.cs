﻿using BT.DataIntegration.Adapter.API.Contracts;
using BT.DataIntegration.Adapter.API.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BT.Data.Integration.API.Controllers
{
    [Authorize]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [Produces("application/json")]
    [ApiController]

    public class ClientManagementController : ControllerBase
    {

        private readonly ILogger<ClientManagementController> _logger;
        private IClientEngagementHandler _engagementHandler;

        public ClientManagementController(ILogger<ClientManagementController> logger, IClientEngagementHandler clientEngagementHandler)
        {
            _logger = logger;
            _engagementHandler = clientEngagementHandler;
        }

        [HttpGet("GetClientsByIndex")]
        public async Task<List<ClientDetails>> GetClientsByIndex([FromQuery]int startIndex, int count=0)
        {
            try
            {
                return await _engagementHandler.GetClientByIndex(startIndex, count);
            }
            catch (Exception ex)
            {
                _logger.LogError($"There is some error processing the  data: error={ex.Message}");
                throw;
            }
        }

        [HttpGet("GetClientSpecificEngagementsByIndex")]
        public async Task<List<EngagementDetails>> GetClientSpecificEngagementsByIndex( [FromQuery] string clientId, int startIndex, int count)
        {
            try
            {
                return await _engagementHandler.GetClientSpecificEngagementsByIndex(clientId, startIndex, count);
            }
            catch (Exception ex)
            {
                _logger.LogError($"There is some error processing the  data: error={ex.Message}");
                throw;
            }
        }
    }
}
