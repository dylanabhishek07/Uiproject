﻿using BT.DataIntegration.Adapter.API.Contracts;
using BT.DataIntegration.Adapter.API.Handler;
using BT.DataIntegration.Adapter.API.Helper;
using BT.DataIntegration.Adapter.API.Models;
using BT.DataIntegration.Adapter.API.Models.Enums;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace BT.Data.Integration.API.Controllers
{
    [Authorize]
    [EnableCors()]
    [ApiVersion("1.0")]
    [Route("api/v{version:apiVersion}/[controller]")]
    [Produces("application/json")]
    [ApiController]
    public class WorkSpaceManagementController : ControllerBase
    {
        private readonly ILogger<WorkSpaceManagementController> _logger;
        private IWorkSpaceHandler _workspaceHandler;
        private readonly IConfiguration _config;

        public WorkSpaceManagementController(ILogger<WorkSpaceManagementController> logger, IWorkSpaceHandler workspaceHandler, IConfiguration config)
        {
            _logger = logger;
            _workspaceHandler = workspaceHandler;
            _config = config;
        }

        [HttpPost("CreateWorkSpace")]
        public async Task<Guid> AddWorkSpace([FromBody] WorkSpaceDetail wrkSpcDetail)
        {
            try
            {
                return await _workspaceHandler.AddWorkSpace(wrkSpcDetail);
            }
            catch (Exception ex)
            {
                _logger.LogError($"There is some error processing the  data: error={ex.Message}");
                throw;
            }
        }

        [HttpGet("CreateAdhocGuid")]
        public async Task<Guid> CreateAdhocGuid([FromQuery] Guid wrkSpaceGuid, string createdBy)
        {
            try
            {
                return await _workspaceHandler.CreateAdhocGuid(wrkSpaceGuid, createdBy);
            }
            catch (Exception ex)
            {
                _logger.LogError($"There is some error processing the  data: error={ex.Message}");
                throw;
            }
        }

        [HttpGet("IsWorkSpaceAlreadyExisting")]
        public async Task<List<WorkSpaceDetail>> IsWorkSpaceAlreadyExisting( [FromQuery] string ClientEngagementMapGIds)
        {
            try
            {
                return await _workspaceHandler.CheckForExistingWorkSpace(ClientEngagementMapGIds);
            }
            catch (Exception ex)
            {
                _logger.LogError($"There is some error processing the  data: error={ex.Message}");
                throw;
            }
        }

        [HttpGet("GetBillingDetails")]
        public async Task<List<WorkspaceBillingItemDetails>> GetBillingDetails([FromQuery] string workspaceMasterGId)
        {
            List<WorkspaceBillingItemDetails> billingDetails = new List<WorkspaceBillingItemDetails>();
            try
            {
                var workspaceSession = await HttpContext.Session.GetObjectFromSession<WorkSpaceUIDetails>(Constant.WORKSPACE_SESSION_KEY);
                return await _workspaceHandler.HandleWorkspaceBillingDetails(workspaceMasterGId, workspaceSession);
            }
            catch (Exception ex)
            {
                _logger.LogError($"There is some error processing the  data: error={ex.Message}");
                throw;
            }

            return billingDetails;
        }

        [HttpPost("GetConsolidatedTimeDetailsForItems")]
        public async Task<List<WorkspaceItemTimeExpenseDetails>> GetConsolidatedTimeDetailsForItems([FromBody] List<WorkspaceItemTimeExpenseDetails> workspaceItemDetails)
        {
            var result = await _workspaceHandler.HandelConsolidatedTimeDetailsForItems(workspaceItemDetails);
            return result;
        }

        [HttpGet("GetTimeDetails")]
        public async Task<IEnumerable<TNEDetails>> GetTimeDetails([FromQuery] string workSpaceGuid)
        {
            try
            {
                return await _workspaceHandler.GetTimeDetails(workSpaceGuid);
            }
            catch (Exception ex)
            {
                _logger.LogError($"There is some error processing the  data: error={ex.Message}");
                throw;
            }
        }

        [HttpGet("IsBillingDataReady")]
        public async Task<bool> IsBillingDataReady([FromQuery] string workspaceId)
        {
            bool isBillingDataReady = false;
            try
            {
                isBillingDataReady = await _workspaceHandler.IsBillingDataReady(workspaceId);
            }
            catch (Exception ex)
            {
                _logger.LogError($"There is some error processing the  data: error={ex.Message}");
                throw;
            }

            return isBillingDataReady;
        }



        [HttpPost("SaveWorkSpace")]
        public async Task<bool> UpdateWorkSpace([FromBody] WorkSpaceUIDetails wrkSpaceAllRecords)
        {
            bool result = false;
            try
            {
                if (wrkSpaceAllRecords != null)
                {
                    await HttpContext.Session.SetObjectInSession<WorkSpaceUIDetails>(wrkSpaceAllRecords, Constant.WORKSPACE_SESSION_KEY);

                    if (wrkSpaceAllRecords.ModifiedWorkSpaceDetails != null && wrkSpaceAllRecords.ModifiedWorkSpaceDetails.Count > Convert.ToInt32(_config.GetValue<string>("AppConfig:BatchProcessingUpperLimit")))
                    {
                        throw new Exception($"Max rowcount exceeded. Total rows present:{wrkSpaceAllRecords.ModifiedWorkSpaceDetails.Count}");
                    }

                    result = await _workspaceHandler.UpdateWorkSpace(wrkSpaceAllRecords.ModifiedWorkSpaceDetails);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"There is some error processing the  data: error={ex.Message}");
                throw;
            }
            return result;
        }

        [HttpPost("TransferTNEDataToOtherCategory")]
        public async Task<List<TNEDataTransferModel>> UpdateTNEMapping([FromBody] List<TNEDataTransferModel> tneDataTransferModel)
        {
            try
            {
                //if (wrkSpaceViewModel.WrkSpaceAllRecords.Count > Convert.ToInt32(_config.GetValue<string>("AppConfig:BatchProcessingUpperLimit")))
                //{
                //    throw new Exception("Max rowcount exceeded. Total rows present:" + wrkSpaceViewModel.WrkSpaceAllRecords.Count);
                //}
                return await _workspaceHandler.UpdateTNEMapping(tneDataTransferModel);
            }
            catch (Exception ex)
            {
                _logger.LogError($"There is some error processing the  data: error={ex.Message}");
                throw;
            }
        }
    }
}
