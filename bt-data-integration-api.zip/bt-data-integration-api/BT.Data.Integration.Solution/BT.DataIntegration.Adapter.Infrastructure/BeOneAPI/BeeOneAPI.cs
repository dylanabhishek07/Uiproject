﻿
using AutoMapper;
using BT.DataIntegration.Adapter.Infrastructure.AuthAPI;
using BT.DataIntegration.Adapter.Infrastructure.BeOneAPI.Models;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Ports.Out;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Identity.Client;
using Microsoft.Identity.Web;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.BeOneAPI
{
    public class BeeOneAPI : BeOneAPIBase<BeeOneAPI>
    {
        private IMapper _mapper;

        public BeeOneAPI(IMapper mapper, IHttpClientFactory httpClientFactory, IConfiguration config, IAuthenticationAPI authenticationService, ILogger<BeeOneAPI> logger,IVaultManager vaultManager) : base(httpClientFactory, config, authenticationService, logger, vaultManager)
        {
            _mapper = mapper;
        }

        public override async Task GetProductDetails(List<WorkspaceBillingItemDomain> workspaceBillingItems)
        {
            List<string> productIds = GetConsolidatedProductIds(workspaceBillingItems);
            List<ProductDetails> productDetails = new List<ProductDetails>();
            await SetHttpClientWithToken();
            if (productIds.Any())
            {
                await Parallel.ForEachAsync(productIds, async (productId, cancellationToken) =>
                 {
                     productDetails.Add(await InvokeProductDetails(productId));
                 });

                MapWorkspacebillingItemFromProductDetails(productDetails, workspaceBillingItems);
            }
        }

        private void MapWorkspacebillingItemFromProductDetails(List<ProductDetails> productDetails, List<WorkspaceBillingItemDomain> workspaceBillingItems)
        {
            if (productDetails.Any() && workspaceBillingItems.Any())
            {
                workspaceBillingItems.ForEach(wsBillingItem =>
                {
                    var matchedProductDet = productDetails.FirstOrDefault(pDet => !string.IsNullOrEmpty(pDet.OccurrenceBillingItemId) && pDet.OccurrenceBillingItemId.Equals(wsBillingItem.ProductId, StringComparison.InvariantCultureIgnoreCase));
                    if (matchedProductDet != null)
                    {
                        _mapper.Map<ProductDetails, WorkspaceBillingItemDomain>(matchedProductDet,wsBillingItem);
                    }
                });
            }
        }

        private async Task<ProductDetails> InvokeProductDetails(string productId)
        {
            ProductDetails _productDetails = new ProductDetails();
            var result = await _httpClient.GetAsync(string.Format(await GetFormatedBeoneApiUrl("BeOneProductDetailsAPIKey"), productId));

            if (result != null && result.IsSuccessStatusCode)
            {
                var productRes = JsonSerializer.Deserialize<ProductDetails>(result.Content.ReadAsStringAsync().Result, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
                if (productRes != null)
                {
                    productRes.OccurrenceBillingItemId = productId;
                    _productDetails = productRes;
                }
                    //_productDetailsDomain = _mapper.Map<ProductDetailsDomain>(productRes);
            }
            return _productDetails;
        }

        private List<string> GetConsolidatedProductIds(List<WorkspaceBillingItemDomain> workspaceBillingItems)
        {
            List<string> _consolidatedProductIds = new List<string>();
            if (workspaceBillingItems.Any())
            {
                workspaceBillingItems.ForEach(wsBillingItem =>
                {
                    if (!string.IsNullOrEmpty(wsBillingItem.ProductId))
                        _consolidatedProductIds.Add(wsBillingItem.ProductId);
                });
                if (_consolidatedProductIds.Any())
                    _consolidatedProductIds = _consolidatedProductIds.Distinct().ToList();
            }
            return _consolidatedProductIds;
        }

        private async Task SetHttpClientWithToken()
        {
            _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue(TokenHeaderType, await GetBeOneToken());
        }
        private async Task<string> GetFormatedBeoneApiUrl(string apiUrlConfigKey)
        {
            if (string.IsNullOrEmpty(apiUrlConfigKey))
            {
                throw new Exception("BeoneAPIUrlConfigKey not provided");

            }
            StringBuilder stringBuilder = new StringBuilder();
            //stringBuilder.Append(_config.GetValue<string>("BeOne:BaseAddress"));
            //stringBuilder.Append(_config.GetValue<string>($"BeOne:{apiUrlConfigKey}"));
            stringBuilder.Append(await _vaultManager.GetClientsSecrets(_config.GetValue<string>("KeyVault:BeOneBaseAddressKey")));
            stringBuilder.Append(await _vaultManager.GetClientsSecrets(_config.GetValue<string>($"KeyVault:{apiUrlConfigKey}")));
            return stringBuilder.ToString();
        }
    }
}
