﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.BeOneAPI.Models
{
    public class ProductDetails
    {
        public string OccurrenceBillingItemId { get; set; }
        public string ClientName { get; set; }
        public string ProductType { get; set; }
        public string Product { get; set; }
        public string Employee { get; set; }
        public float? InvoiceFee { get; set; }
        public string Currency { get; set; }
        public string ServiceDescription { get; set; }
        public string BillingEntity { get; set; }
        public string CostCenter { get; set; }
        public string OosNr { get; set; }
        public string GbtRef { get; set; }
        public string BillingType { get; set; }
        public string FeeType { get; set; }
        public string BillingStatus { get; set; }
        public string ProductStatus { get; set; }
        public string GbtStatus { get; set; }
    }
}
