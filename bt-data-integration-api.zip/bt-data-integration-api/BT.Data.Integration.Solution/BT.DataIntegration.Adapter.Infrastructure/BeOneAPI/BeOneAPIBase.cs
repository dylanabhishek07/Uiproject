﻿using BT.DataIntegration.Adapter.Infrastructure.AuthAPI;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Ports.Out;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.BeOneAPI
{
    public abstract class BeOneAPIBase<T> : IBeOneAPI where T : class
    {

        private static string UserAgent;
        protected static HttpClient _httpClient;
        protected static string TokenHeaderType = "Bearer";
        protected IConfiguration _config;
        protected ILogger<T> _logger;
        private IAuthenticationAPI _authenticationService;
        protected IVaultManager _vaultManager;

        protected BeOneAPIBase(IHttpClientFactory httpClientFactory, IConfiguration config, IAuthenticationAPI authenticationService, ILogger<T> logger,IVaultManager vaultManager)
        {
            _config = config;
            UserAgent = _config.GetValue<string>("AppConfig:UserAgent");
            _authenticationService = authenticationService; ;
            _logger = logger;           
            _httpClient = InitiateHttpClient(httpClientFactory);
            _vaultManager = vaultManager;
        }

        public abstract Task GetProductDetails(List<WorkspaceBillingItemDomain> workspaceBillingItems);

        protected async Task<string> GetBeOneToken()
        {
            string beOneClientIDKey = _config.GetValue<string>("KeyVault:BeOneClientIdKey");
            string beOneClientSecretKey = _config.GetValue<string>("KeyVault:BeOneClientSecretKey");
            string beOneScopeKey = _config.GetValue<string>("KeyVault:BeOneScopeKey");
            string beOneTenentIdKey = _config.GetValue<string>("KeyVault:BeOneTenentIdKey");
            //return await _authenticationService.GetTokenForAdClient(_config.GetValue<string>("BeOne:ClientId"),
            //       _config.GetValue<string>("BeOne:ClientSecret"), _config.GetValue<string>("BeOne:Scope"),
            //       _config.GetValue<string>("BeOne:TenentId"));
            return await _authenticationService.GetTokenForAdClient(await _vaultManager.GetClientsSecrets(beOneClientIDKey),
                   await _vaultManager.GetClientsSecrets(beOneClientSecretKey), await _vaultManager.GetClientsSecrets(beOneScopeKey),
                   await _vaultManager.GetClientsSecrets(beOneTenentIdKey));
        }

        private HttpClient InitiateHttpClient(IHttpClientFactory httpClientFactory)
        {
            var httpClient = httpClientFactory.CreateClient();

            httpClient.Timeout = new TimeSpan(0, 0, int.Parse(_config.GetValue<string>("AppConfig:APITimeOut") ?? "30"));
            httpClient.DefaultRequestHeaders.Clear();
            httpClient.DefaultRequestHeaders.Add(HeaderNames.Accept, System.Net.Mime.MediaTypeNames.Application.Json);
            httpClient.DefaultRequestHeaders.Add(HeaderNames.UserAgent, UserAgent);
            return httpClient;
        }
    }
}
