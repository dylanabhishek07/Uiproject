﻿using AutoMapper;
using BT.DataIntegration.Adapter.Infrastructure.BeOneAPI.Models;
using BT.DataIntegration.Domain.Model;

namespace BT.DataIntegration.Adapter.Infrastructure.BeOneAPI.Mapper
{
    public class ProductMapper : Profile
    {
        public ProductMapper()
        {
            this.MapDbtoDomainModel();
            this.MapFromDomaintoDbModel();
        }

        private void MapFromDomaintoDbModel()
        {
        }

        private void MapDbtoDomainModel()
        {
            CreateMap<ProductDetails, WorkspaceBillingItemDomain>()
                .ForMember(dest => dest.ProductId, opt => opt.MapFrom(source => source.OccurrenceBillingItemId));
        }
    }
}
