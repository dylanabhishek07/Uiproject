﻿using Azure.Storage.Queues;
using BT.DataIntegration.Domain.Ports.Out;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.Queue
{
    
    public sealed class AZStorageQManager : QueueManagerBase
    {
        private QueueClient _queueClient;

        public AZStorageQManager(IConfiguration config, IVaultManager vaultManager) : base(config, vaultManager)
        {
            //this._queueClient = new QueueClient(ConncetionString, WorkspaceQueueName, new QueueClientOptions
            //{
            //    MessageEncoding = QueueMessageEncoding.Base64
            //});
        }

        public async override Task SendMessage(string message)
        {
            if (_queueClient == null)
            {
                await GetQueueClient();
            }
            await _queueClient.SendMessageAsync(message);
        }

        protected override async Task GetQueueClient()
        {
            string conncetionstringkey = _configuration.GetValue<string>("KeyVault:StorageAccountKey");
            string workspaceQueueKey = _configuration.GetValue<string>("KeyVault:WorkSpaceQueueNameKey");
            string ConncetionString = await _vaultManager.GetClientsSecrets(conncetionstringkey);
            string workspaceQueue = await _vaultManager.GetClientsSecrets(workspaceQueueKey);
            _queueClient = new QueueClient(ConncetionString, workspaceQueue, new QueueClientOptions
            {
                MessageEncoding = QueueMessageEncoding.Base64
            });
        }
    }
}
