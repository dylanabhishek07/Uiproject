﻿using Azure.Storage.Queues;
using BT.DataIntegration.Domain.Ports.Out;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.Queue
{
    public abstract class QueueManagerBase : IQueueManager
    {
        //protected readonly string ConncetionString;
        //protected readonly string WorkspaceQueueName;
        protected readonly IVaultManager _vaultManager;
        protected readonly IConfiguration _configuration;
        protected QueueManagerBase(IConfiguration config, IVaultManager vaultManager)
        {
            _vaultManager = vaultManager;
            _configuration = config;
        }
        public abstract Task SendMessage(string message);

        protected abstract Task GetQueueClient();
        
        
    }
}
