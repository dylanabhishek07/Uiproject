﻿using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;
using Microsoft.Identity.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.AuthAPI
{
    public sealed class AuthenticationAPI : IAuthenticationAPI
    {
        private readonly IDistributedCache _cache;
        ILogger<AuthenticationAPI> _logger;
        const string TOKENCACHENAME = "TokenCache_";
        const string MSAUTHORITYURL = "https://login.microsoftonline.com/";

        public AuthenticationAPI(IDistributedCache cache, ILogger<AuthenticationAPI> logger)
        {
            _cache = cache;
            _logger = logger;
        }

        public async Task<string> GetTokenForAdClient(string clientId, string clinetSecret, string scope, string tenentId)
        {
            string accessToken = string.Empty;
            try
            {

                ///Try to get the token form cache. If not exists a fresh token would be requested for 3ed party app
                accessToken = await _cache.GetStringAsync(TOKENCACHENAME + clientId);
                if (string.IsNullOrEmpty(accessToken))
                {
                    var app = ConfidentialClientApplicationBuilder.Create(clientId)
                    .WithClientSecret(clinetSecret)
                    .WithAuthority($"{MSAUTHORITYURL}{tenentId}/oauth2/v2.0/token")
                    .Build();
                    ///Get the fresh token form the 3ed party app
                    var result = await app.AcquireTokenForClient(new string[] { scope }).ExecuteAsync();
                    if (result != null && !string.IsNullOrEmpty(result.AccessToken))
                    {
                        long bufferTimeSeconds = 9;
                        DateTimeOffset cacheExpiry = result.ExpiresOn.LocalDateTime.Subtract(TimeSpan.FromSeconds(bufferTimeSeconds));
                        ///Set cache exipry to the token expiry time. so that once the token is invalid
                        ///the same token is cleared form the cache.Next time execution context hits
                        ///it would fresh token that would minted from the 3ed party
                        //////Added some buffer time so that by the time client call reaches the 3ed party api
                        ///Token should not get  expired.
                        var options = new DistributedCacheEntryOptions().SetAbsoluteExpiration(cacheExpiry);
                        ///Set the fresh token to the cache, so that it could re used in subsequent calls
                        await _cache.SetStringAsync(TOKENCACHENAME + clientId, result.AccessToken, options);
                        accessToken = result.AccessToken;
                    }
                }
                if (string.IsNullOrEmpty(accessToken))
                    throw new MsalException("E001", "Error Generating the token");
            }
            catch (Exception ex)
            {
                _logger.LogError($"There is some problem generating the token. error is {ex.Message}");
            }
            return accessToken;
        }
    }
}
