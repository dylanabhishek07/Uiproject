﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.AuthAPI
{
    public interface IAuthenticationAPI
    {
        internal Task<string> GetTokenForAdClient(string clientId, string clinetSecret, string scope, string tenentId);
    }
}
