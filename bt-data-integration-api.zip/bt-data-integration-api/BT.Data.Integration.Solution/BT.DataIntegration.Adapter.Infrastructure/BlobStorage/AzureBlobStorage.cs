﻿using Azure.Storage.Blobs;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.BlobStorage
{
    public class AzureBlobStorage: BlobStorageBase<AzureBlobStorage>
    {
        //private readonly IVaultManager vaultManager;

        //public AzureBlobStorage(StorageAccountConfiguration config, KeyVaultConfiguration kvConfig, IVaultManager vaultManager, ILogger<AzureBlobServices> logger) : base(config, kvConfig, logger)
        //{
        //    this.vaultManager = vaultManager;
        //}
        //public override async Task<Stream> GetListTemplate(string listType)
        //{
        //    try
        //    {
        //        _Logger.LogInformation($"GetListTemplate Method started executing for Form : {listType}");
        //        Console.WriteLine("Getting template for tax form...");

        //        Stream listTemplate = null;
        //        string templateName = string.Concat(listType, ".xlsx");

        //        //getting blobclient from storage
        //        var blobServiceClient = await GetBlobClient();
        //        if (blobServiceClient != null)
        //        {
        //            BlobContainerClient blobContainerClient = blobServiceClient.GetBlobContainerClient(Config.TemplateContainerName);
        //            blobContainerClient.CreateIfNotExists();

        //            //getting file from the blob container
        //            BlobClient blobClient = blobContainerClient.GetBlobClient(templateName);
        //            if (blobClient.Exists())
        //            {
        //                listTemplate = new MemoryStream();
        //                await blobClient.DownloadToAsync(listTemplate);
        //            }
        //        }

        //        //_logger.LogInformation("Form template response returned");
        //        _Logger.LogInformation($"GetListTemplate Method completed execution for Form : {listType}");
        //        return listTemplate;
        //    }
        //    catch (Exception ex)
        //    {
        //        _Logger.LogError($"Failure -  Class: Adapters.Infra/Azure/AzureServices.cs \t Method: GetListTemplate failed with Exception {ex.Message}");
        //        return null;
        //    }
        //}

        //private async Task<BlobServiceClient> GetBlobClient()
        //{
        //    try
        //    {
        //        return new BlobServiceClient(await vaultManager.GetSecrets(KVConfig.SAConnectionString));
        //    }
        //    catch (Exception ex)
        //    {
        //        _Logger.LogError($"Failure -  Class: Adapters.Infra/Azure/BaseAzureService.cs \t Method: SetTableClients failed with Exception {ex.Message}");
        //        return null;
        //    }
        //}
        
    }
}
