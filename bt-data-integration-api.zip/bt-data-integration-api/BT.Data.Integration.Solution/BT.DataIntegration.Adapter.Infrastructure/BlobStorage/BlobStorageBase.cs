﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.BlobStorage
{
    public abstract class BlobStorageBase<T> : IBlobStorage where T : class
    {
        //protected readonly StorageAccountConfiguration Config;
        //protected readonly KeyVaultConfiguration KVConfig;
        //protected readonly ILogger<T> _Logger;
        


        //public BlobStorageBase(StorageAccountConfiguration config, KeyVaultConfiguration kvConfig, ILogger<T> logger)
        //{
        //    Config = config;
        //    KVConfig = kvConfig;
        //    _Logger = logger;
        //}

        public virtual Task<Stream> GetListTemplate(string listType) { return null; }
    }
}
