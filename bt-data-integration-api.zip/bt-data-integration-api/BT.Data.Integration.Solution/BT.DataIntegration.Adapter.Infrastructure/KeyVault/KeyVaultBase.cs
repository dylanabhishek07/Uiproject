﻿using BT.DataIntegration.Domain.Ports.Out;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.KeyVault
{
    public abstract class KeyVaultBase:IVaultManager
    {
        public abstract Task<string> GetClientsSecrets(string secretCode);
    }
}
