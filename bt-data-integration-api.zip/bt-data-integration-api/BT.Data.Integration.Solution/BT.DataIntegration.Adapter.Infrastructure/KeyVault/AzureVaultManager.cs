﻿using Azure.Security.KeyVault.Secrets;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.KeyVault
{
    public class AzureVaultManager : KeyVaultBase
    {
        private readonly SecretClient _secretClient;
        private readonly IConfiguration _configuration;
        private readonly IDistributedCache _cache;
        const string SECRETCACHENAME = "SecretCache_";
        ILogger<AzureVaultManager> _logger;

        /// <summary>
        /// IDistributedCache marked as optional, as redis cache get initialized after key vault. 
        /// </summary>
        /// <param name="secretClient"></param>
        /// <param name="configuration"></param>
        /// <param name="cache"></param>
        public AzureVaultManager(SecretClient secretClient, IConfiguration configuration, ILogger<AzureVaultManager> logger, IDistributedCache cache = null )
        {
            _secretClient = secretClient;
            _configuration = configuration;
            _cache = cache;
            _logger = logger;
        }

        public override async Task<string> GetClientsSecrets(string secretCode)
        {
            string secretValue = string.Empty;
#if DEBUG
            //secretValue = _configuration[secretCode];
            secretValue = Environment.GetEnvironmentVariable(secretCode);

#else

            try
            {

                ///Try to get the secret form cache. If not exists a fresh secret would be requested for 3ed party app
                 if(_cache!=null)
                secretValue = await _cache.GetStringAsync(SECRETCACHENAME + secretCode);
                if (string.IsNullOrEmpty(secretValue))
                {
                    
                    ///Get the fresh secret form the Azure Key Vault
                    KeyVaultSecret secret = await _secretClient.GetSecretAsync(secretCode);
                    if (secret != null && !string.IsNullOrEmpty(secret.Value))
                    {
                        long bufferTimeDays = 1;
                        DateTimeOffset cacheExpiry = new DateTimeOffset(DateTime.Now.AddDays(bufferTimeDays));
                        var options = new DistributedCacheEntryOptions().SetAbsoluteExpiration(cacheExpiry);
                        ///Set the fresh token to the cache, so that it could re used in subsequent calls
                         if(_cache!=null)
                        await _cache.SetStringAsync(SECRETCACHENAME + secretCode, secret.Value, options);
                        secretValue = secret.Value;
                    }
                }
                if (string.IsNullOrEmpty(secretValue))
                    throw new Exception("Error Fetching the Secret");
            }
            catch (Exception ex)
            {
                _logger.LogError($"There is some problem fetching the secret. error is {ex.Message}");
            }
#endif
            return secretValue;
        }
    }
}
