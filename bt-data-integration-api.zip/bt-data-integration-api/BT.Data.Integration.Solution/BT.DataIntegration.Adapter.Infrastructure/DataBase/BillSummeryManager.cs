﻿using AutoMapper;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Ports.Out;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase
{
    public class BillSummeryManager : IBillSummeryManager
    {
        IBillSummeryRepository _billSummeryRepository;
        IMapper _mapper;

        public BillSummeryManager(IBillSummeryRepository billSummeryRepository, IMapper mapper)
        {
            _billSummeryRepository = billSummeryRepository;
            _mapper = mapper;
        }

        public async Task<List<EngagementSummeryDomain>> GetEngagementSummeryDetails(string workspaceMasterGid)
        {
            List<EngagementSummeryDomain> engagementSummeries = new List<EngagementSummeryDomain>();
            var result = await _billSummeryRepository.GetEngagementSummeryDetails(workspaceMasterGid);
            if (result != null && result.Count() > 0)
            {
                engagementSummeries.AddRange(_mapper.Map<List<EngagementSummeryDomain>>(result));
            }

            return engagementSummeries;
        }

        public async Task<List<BillSummeryEAFDetailsDomain>> GetEAFCalculationDetails(string workspaceMasterGid)
        {
            var result = await _billSummeryRepository.GetEAFCalculationDetails(workspaceMasterGid);

            return _mapper.Map<List<BillSummeryEAFDetailsDomain>>(result);
        }

        public async Task SaveEAFCalculationDetails(List<BillSummeryEAFDetailsDomain> billSummeryEngamentEafDomain)
        {
            await _billSummeryRepository.SaveEAFCalculationDetails(_mapper.Map<List<BillSummeryEngamentEafData>>(billSummeryEngamentEafDomain));
        }
    }
}
