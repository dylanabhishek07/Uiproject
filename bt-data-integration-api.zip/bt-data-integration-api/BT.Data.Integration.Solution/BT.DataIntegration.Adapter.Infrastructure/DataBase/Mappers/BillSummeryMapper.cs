﻿using AutoMapper;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Mappers.Converter;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using BT.DataIntegration.Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Mappers
{
    public class BillSummeryMapper : Profile
    {
        public BillSummeryMapper()
        {
            this.MapDomaintoDbModel();
            this.MapDbtoDomainModel();
        }

        private void MapDomaintoDbModel()
        {
            CreateMap<BillSummeryEAFDetailsDomain,BillSummeryEngamentEafData >();
        }

        private void MapDbtoDomainModel()
        {
            CreateMap<EngagementSummeryDetails, EngagementSummeryDomain>()
                 .ForMember(dest => dest.AdjustedBillingActionId, opt => opt.ConvertUsing(new BillingActionEnumTypeConverter(), src => src.AdjustedBillingActionId))
                 .ForMember(dest => dest.BillingActionId, opt => opt.ConvertUsing(new BillingActionEnumTypeConverter(), src => src.BillingActionId));

            CreateMap<BillSummeryEngamentEafData, BillSummeryEAFDetailsDomain>();
        }

    }
}
