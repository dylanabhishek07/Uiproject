﻿using AutoMapper;
using BT.DataIntegration.Domain.Model.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Mappers.Converter
{
    internal class BillingActionEnumTypeConverter : IValueConverter<int, BillingActionDomainEnum>
    {
        public BillingActionDomainEnum Convert(int source, ResolutionContext context)
        {
            return (BillingActionDomainEnum)source;
        }
    }
}
