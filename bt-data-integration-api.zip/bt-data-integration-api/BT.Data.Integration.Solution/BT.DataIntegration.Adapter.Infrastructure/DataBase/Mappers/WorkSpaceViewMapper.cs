﻿//using AutoMapper;
//using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
//using BT.DataIntegration.Domain.Model;

//namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Mappers
//{
//    public class WorkSpaceViewMapper : Profile
//    {
//        public WorkSpaceViewMapper()
//        {
//            this.MapDomaintoDbModel();
//        }

//        private void MapDomaintoDbModel()
//        {
//            CreateMap<WorkSpaceAdjustedDataDomain, WorkSpaceAdjustedData>()
//                .ForMember(dest => dest.AdjustedBillingActionId, opt => opt.MapFrom(src => (int)src.AdjustedBillingAction));
//        }
//    }
//}
