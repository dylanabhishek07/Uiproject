﻿using AutoMapper;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using BT.DataIntegration.Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Mappers
{
    public class InvoiceDetailMapper : Profile
    {
        public InvoiceDetailMapper()
        {
            this.MapDomaintoDbModel();
            this.MapDbtoDomainModel();
        }

        private void MapDomaintoDbModel()
        {
            CreateMap<InvoiceDetailsDomain, Invoice>();
        }

        private void MapDbtoDomainModel()
        {
        }
    }
}
