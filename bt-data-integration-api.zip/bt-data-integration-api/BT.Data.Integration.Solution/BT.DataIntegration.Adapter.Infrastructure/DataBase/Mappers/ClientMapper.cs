﻿using AutoMapper;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using BT.DataIntegration.Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Mappers
{
    public class ClientMapper :Profile
    {
        public ClientMapper()
        {
            this.MapDbtoDomainModel();
            this.MapFromDomaintoDbModel();
        }

        private void MapFromDomaintoDbModel()
        {

        }

        private void MapDbtoDomainModel()
        {
            CreateMap<Client, ClientDomain>();
        }
    }
}
