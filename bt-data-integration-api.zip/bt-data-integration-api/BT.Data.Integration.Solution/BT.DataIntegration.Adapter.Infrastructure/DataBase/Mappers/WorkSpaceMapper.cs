﻿using AutoMapper;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Mappers.Converter;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Model.Enums;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Mappers
{
    public class WorkSpaceMapper : Profile
    {
        public WorkSpaceMapper()
        {
            this.MapDomaintoDbModel();
            this.MapDbtoDomainModel();
        }

        private void MapDomaintoDbModel()
        {
            CreateMap<WorkSpaceDetailDomain, WorkSpace>();
            CreateMap<ModifiedWorkSpaceDetailsDomain, WorkSpaceAdjustedData>()
                .ForMember(dest => dest.AdjustedBillingActionId, opt => opt.MapFrom(src => (int)src.AdjustedBillingAction));
            CreateMap<WorkSpaceAdjustedDataDomain, WorkSpaceAdjustedData>()
              .ForMember(dest => dest.AdjustedBillingActionId, opt => opt.MapFrom(src => (int)src.AdjustedBillingAction));
        }

        private void MapDbtoDomainModel()
        {
            CreateMap<WorkSpace, WorkSpaceDetailDomain>();
            CreateMap<ProcessedData, ProcessedDataDomain>();
            CreateMap<WorkspaceCommonData, WorkspaceBillingItemDomain>()
                 .ForMember(dest => dest.AdjustedBillingAction, opt => opt.ConvertUsing(new BillingActionEnumTypeConverter(), src => src.AdjustedBillingActionId));
        }

    }

}
