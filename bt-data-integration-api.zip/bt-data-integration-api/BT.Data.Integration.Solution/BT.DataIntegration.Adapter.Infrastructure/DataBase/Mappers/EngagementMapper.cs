﻿using AutoMapper;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using BT.DataIntegration.Domain.Model;


namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Mappers
{
    public class EngagementMapper : Profile
    {
        public EngagementMapper()
        {
            this.MapDbtoDomainModel();
            
        }
        private void MapDbtoDomainModel()
        {
            CreateMap<Engagement, EngagementDomain>();
        }
    }
}
