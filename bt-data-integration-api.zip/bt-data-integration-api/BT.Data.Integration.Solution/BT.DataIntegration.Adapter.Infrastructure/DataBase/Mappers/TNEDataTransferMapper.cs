﻿using AutoMapper;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Model.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Mappers
{
    public class TNEDataTransferMapper: Profile
    {
        public TNEDataTransferMapper()
        {
            this.MapDomaintoDbModel();
            this.MapDbtoDomainModel();
        }

        private void MapDomaintoDbModel()
        {
            CreateMap<TNEDataTransferDomain, TNEDataTransfer>()
                .ForMember(dest => dest.TransferToDataCategory, opt => opt.MapFrom(src => (int)src.TransferToDataCategory))
                .ForMember(dest => dest.FinalProcessedTnEList, opt => opt.MapFrom(src => string.Join(",", src.FinalProcessedTnEList)));
        }
        private void MapDbtoDomainModel()
        {
            CreateMap<TNEDataTransfer,TNEDataTransferDomain>()
                .ForMember(dest => dest.TransferToDataCategory, opt => opt.MapFrom(src => (DataTypeDomainEnum)src.TransferToDataCategory))
                .ForMember(dest => dest.FinalProcessedTnEList, opt => opt.MapFrom(src => (src.FinalProcessedTnEList != "" && src.FinalProcessedTnEList != null) ? src.FinalProcessedTnEList.Split(",",StringSplitOptions.None): null));
        }
    }
}
