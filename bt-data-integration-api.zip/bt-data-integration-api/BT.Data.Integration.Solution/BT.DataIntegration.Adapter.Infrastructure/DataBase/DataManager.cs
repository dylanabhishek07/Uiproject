﻿using AutoMapper;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Mappers;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Ports.Out;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase
{
    public  class DataManager: IDataManager
    {
        IClientRepository _clientRepository;
        IMapper _mapper;
        IEngagementRepository _engagementRepository;
        IWorkSpaceRepository _workSpaceRepository;

        public DataManager(IClientRepository clientRepository,IMapper mapper,IEngagementRepository engagementRepository, IWorkSpaceRepository workSpaceRepository)
        {
            _clientRepository = clientRepository;
            _mapper = mapper;
            _engagementRepository = engagementRepository;
            _workSpaceRepository = workSpaceRepository;
        }

        public async Task<Guid> AddWorkSpace(WorkSpaceDetailDomain wrkSpaceDetailDomain)
        {
            return await _workSpaceRepository.AddWorkSpaceByGuids(_mapper.Map<WorkSpace>(wrkSpaceDetailDomain));
        }

        public async Task<List<WorkSpaceDetailDomain>> CheckForExistingWorkSpace(string ClientEngagementMapGIds)
        {
            var workspaceDetail = new List<WorkSpaceDetailDomain>();
            var result = await _workSpaceRepository.CheckForExistingWorkSpaceByGuids(ClientEngagementMapGIds);
            if (result!= null && result.Any())
            {
                workspaceDetail = _mapper.Map<List<WorkSpaceDetailDomain>>(result.ToList());
            }
            return workspaceDetail;
        }

        public async Task<List<ClientDomain>> GetClientByIndex(int index, int count)
        {
            var clients = new List<ClientDomain>();
            var result=  await _clientRepository.GetByIndex(index, count);
            if (result.Any())
            {
                clients = _mapper.Map<List<ClientDomain>>(result.ToList());
            }             

            return clients;
        }

        public async Task<List<EngagementDomain>> GetClientSpecificEngagementsByIndex(string clientid, int index, int count)
        {
            var engagements = new List<EngagementDomain>();
            var result = await _engagementRepository.GetClientSpecificEngagementsByIndex(clientid, index, count);
            if (result.Any())
            {
                engagements = _mapper.Map<List<EngagementDomain>>(result.ToList());
            }

            return engagements;
        }

        public async Task<IEnumerable<TNEDetailDomain>> GetTimeDetails(string workSpaceGuid)
        {
            var tneDetail = new List<TNEDetailDomain>();
            var result = await _workSpaceRepository.GetTimeDetails(workSpaceGuid);
            if (result != null && result.Any())
            {
                tneDetail = _mapper.Map<List<TNEDetailDomain>>(result.ToList());
            }
            return tneDetail;
        }

        public async Task<bool> IsBillingDataReady(string workspaceId)
        {
            return await _workSpaceRepository.IsBillingDataReady(workspaceId);
        }

        public async Task<List<TNEDataTransferDomain>> UpdateTNEMapping(List<TNEDataTransferDomain> tneDataTransferDomain)
        {
            var modifiedTNEMappings = new List<TNEDataTransferDomain>();
            if (tneDataTransferDomain != null && tneDataTransferDomain.Any())
            {
                var tneDataTransfer = _mapper.Map<List<TNEDataTransfer>>(tneDataTransferDomain);
                var result = await _workSpaceRepository.UpdateTNEMappingTables(tneDataTransfer);
                if (result.Any())
                {
                    modifiedTNEMappings = _mapper.Map<List<TNEDataTransferDomain>>(result.ToList());
                }
            }
            return modifiedTNEMappings;
        }

    }
}
