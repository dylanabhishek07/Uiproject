﻿using BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Helper;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using BT.DataIntegration.Domain.Ports.Out;
using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Repositories
{
    public class AnnexePreviewRepository : BillingRepository<WorkSpaceFeeTextMapping>, IAnnexePreviewRepository
    {
        public AnnexePreviewRepository(IConfiguration config, IVaultManager vault) : base(config, vault)
        {
        }

        public async Task<IEnumerable<WorkSpaceFeeTextMapping>> GetFeeTextByWorkSpaceGids(List<string> workSpaceGIds)
        {
            using IDbConnection dbContext = await GetDbConnection();
            return await dbContext.QueryAsync<WorkSpaceFeeTextMapping>("SP_Get_FeeText_By_Workspace_Gids", new { workspaceItemGids = string.Join(",", workSpaceGIds) }, commandType: CommandType.StoredProcedure);
        }

        public async Task<int> SaveFeeDetails(List<FeeDetails> feeDetails)
        {
            int result = 0;
            if (feeDetails != null && feeDetails.Any())
            {
                DataTable dtAnnexeFeeDetails = DataBaseHelper.ConvertListToDataTable(feeDetails);
                using IDbConnection dbContext = await GetDbConnection();
                result = await dbContext.ExecuteAsync("SP_Create_Update_Annexe_Fee_Details", new { AnnexFeeDetailsData = dtAnnexeFeeDetails.AsTableValuedParameter("Type_Annexe_Fee_Details_Data") }, commandType: CommandType.StoredProcedure);
            }

            return result;
        }
    }
}
