﻿using BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using BT.DataIntegration.Domain.Ports.Out;
using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Repositories
{
    public class ClientRepository : BillingRepository<Client>, IClientRepository
    {
        public ClientRepository(IConfiguration config,IVaultManager vault) : base(config, vault)
        {
        }

        public async Task<IEnumerable<Client>> GetByIndex(int startIndex, int count)
        {
            int endIndex = startIndex + count + 1;
            using IDbConnection dbContext = await GetDbConnection();
            return await dbContext.QueryAsync<Client>("select clientId, ClientName from [dbo].[catalogue_client] where IsDeleted = 0 and Id<@endIndex and Id>@startIndex", new {endIndex=endIndex,startIndex=startIndex});
        }
    }
}
