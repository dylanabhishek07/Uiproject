﻿using BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Helper;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using BT.DataIntegration.Domain.Ports.Out;
using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Repositories
{
    public class InvoiceDetailsRepository : BillingRepository<Invoice>, IInvoiceDetailsRepository
    {
        public InvoiceDetailsRepository(IConfiguration config, IVaultManager vault) : base(config, vault)
        {
        }

        public async Task<int> SaveInvoiceDetails(List<Invoice> invoiceDetails)
        {
            int result = 0;
            if (invoiceDetails != null && invoiceDetails.Any())
            {
                DataTable dtInvoiceDetails = DataBaseHelper.ConvertListToDataTable(invoiceDetails);
                using IDbConnection dbContext = await GetDbConnection();
                result = await dbContext.ExecuteAsync("SP_Create_Update_Invoice_Details", new { InvoiceDetailsData = dtInvoiceDetails.AsTableValuedParameter("Type_Invoice_Details_Data") }, commandType: CommandType.StoredProcedure);
            }

            return result;
        }
    }
}
