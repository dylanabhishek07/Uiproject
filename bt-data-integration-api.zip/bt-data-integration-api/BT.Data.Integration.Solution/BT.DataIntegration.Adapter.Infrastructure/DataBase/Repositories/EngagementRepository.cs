﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using BT.DataIntegration.Domain.Ports.Out;
using Dapper;
using Microsoft.Extensions.Configuration;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Repositories
{
    public class EngagementRepository : BillingRepository<Engagement>, IEngagementRepository
    {
        public EngagementRepository(IConfiguration config, IVaultManager vault) : base(config, vault)
        {
        }

        public async Task<IEnumerable<Engagement>> GetClientSpecificEngagementsByIndex(string clientid, int startindex, int count)
        {
            int endIndex = startindex + count + 1;
            using IDbConnection dbContext = await GetDbConnection();
            return await dbContext.QueryAsync<Engagement>("SP_Get_Client_Specific_Engagements_By_Index", new { clientid = clientid, startindex= startindex , endindex= endIndex}, commandType: CommandType.StoredProcedure);
        }
    }
}
