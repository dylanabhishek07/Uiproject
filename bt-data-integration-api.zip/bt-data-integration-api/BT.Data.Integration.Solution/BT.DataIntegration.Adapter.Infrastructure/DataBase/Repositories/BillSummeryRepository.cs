﻿using BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Helper;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using BT.DataIntegration.Domain.Ports.Out;
using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Repositories
{
    public class BillSummeryRepository : BillingRepository<BillSummeryDetails>, IBillSummeryRepository
    {
        public BillSummeryRepository(IConfiguration config, IVaultManager vault) : base(config, vault)
        {
        }

        public async Task<IEnumerable<EngagementSummeryDetails>> GetEngagementSummeryDetails(string workspaceMasterGid)
        {
            using IDbConnection dbContext = await GetDbConnection();
            return await dbContext.QueryAsync<EngagementSummeryDetails>("Sp_Get_Engagementwise_TnE_Details_Workspace", new { workspaEngagementMapasterGid = workspaceMasterGid }, commandType: CommandType.StoredProcedure);
        }


        public async Task SaveEAFCalculationDetails(List<BillSummeryEngamentEafData> billSummeryEngamentEafData)
        {

            if (billSummeryEngamentEafData != null && billSummeryEngamentEafData.Any())
            {
                DataTable EafDataTables = DataBaseHelper.ConvertListToDataTable(billSummeryEngamentEafData);
                if (EafDataTables != null && EafDataTables.Rows.Count > 0)
                {
                    using IDbConnection dbContext = await GetDbConnection();
                    await dbContext.QueryAsync<TNEDataTransfer>("SP_Create_Update_BillSummery_Eaf_Details", new { TypeAdjustedTneMapping = EafDataTables.AsTableValuedParameter("Type_BillSummery_EAF_Cal_Data") }, commandType: CommandType.StoredProcedure);
                }
            }
        }


        public async Task<IEnumerable<BillSummeryEngamentEafData>> GetEAFCalculationDetails(string workspaceMasterGid)
        {
            using IDbConnection dbContext = await GetDbConnection();
            return await dbContext.QueryAsync<BillSummeryEngamentEafData>("SP_Get_BillSummery_Eaf_Details", new { WorkSpaceDetailMasterGId = workspaceMasterGid }, commandType: CommandType.StoredProcedure);
        }
    }
}

