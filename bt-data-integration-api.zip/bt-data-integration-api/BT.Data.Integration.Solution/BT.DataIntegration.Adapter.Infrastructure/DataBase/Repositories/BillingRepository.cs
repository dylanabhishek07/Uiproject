﻿using BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts;
using BT.DataIntegration.Domain.Ports.Out;
using Dapper;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Repositories
{
    public class BillingRepository<T> : IBillingRepository<T> where T : class
    {
        protected readonly IConfiguration _config;
        protected readonly IVaultManager _vaultManager;
        //private const string CONNECTIONSTRINGNAMEKEY = "DefaultConnection";
        protected IDbConnection dbContext;
        protected BillingRepository(IConfiguration config, IVaultManager vaultManager)
        {
            _config = config;
            _vaultManager = vaultManager;
        }

        protected async Task<IDbConnection> GetDbConnection()
        {
            //return new SqlConnection(_config.GetConnectionString(CONNECTIONSTRINGNAMEKEY));
            string conncetionstringkey = _config.GetValue<string>("KeyVault:DBConnectionStringKey");
            string connectionString = await _vaultManager.GetClientsSecrets(conncetionstringkey);
            return new SqlConnection(connectionString);
        }

        public async Task<IEnumerable<T>> GetAllAsync<T>(string storedProcedureName, object parameters, CommandType commandType = CommandType.StoredProcedure)
        {
            using IDbConnection db = await GetDbConnection();
            return await db.QueryAsync<T>(storedProcedureName, param: parameters, commandType: commandType);
        }
    }
}
