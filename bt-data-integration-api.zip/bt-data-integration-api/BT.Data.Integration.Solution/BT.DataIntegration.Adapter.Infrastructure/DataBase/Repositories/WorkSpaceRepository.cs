﻿using BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Helper;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using BT.DataIntegration.Domain.Model.Enums;
using BT.DataIntegration.Domain.Ports.Out;
using Dapper;
using Microsoft.Extensions.Configuration;
using System.Data;
using System.Transactions;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Repositories
{
    public class WorkSpaceRepository : BillingRepository<WorkSpace>, IWorkSpaceRepository
    {
        public WorkSpaceRepository(IConfiguration config, IVaultManager vault) : base(config, vault)
        {
        }

        public async Task<Guid> AddWorkSpaceByGuids(WorkSpace wrkSpace)
        {
            using IDbConnection dbContext = await GetDbConnection();
            return await dbContext.QuerySingleAsync<Guid>("SP_Create_New_Workspace", new { client_engagement_GIds = string.Join(",", wrkSpace.ClientEngagementMapGIds), workSpaceName = wrkSpace.WorkspaceName, beOneWrkFlowId = wrkSpace.BeOneWorkFlowId, createdBy = wrkSpace.CreatedBy }, commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<WorkSpace>> CheckForExistingWorkSpaceByGuids(string ClientEngagementMapGIds)
        {
            using IDbConnection dbContext = await GetDbConnection();
            return await dbContext.QueryAsync<WorkSpace>("SP_Get_Existing_Workspace", new { client_engagement_GIds = ClientEngagementMapGIds }, commandType: CommandType.StoredProcedure);
        }

        public async Task<IEnumerable<TNEData>> GetTimeDetails(string workSpaceGuid)
        {
            using IDbConnection dbContext = await GetDbConnection();
            return await dbContext.QueryAsync<TNEData>("SP_Get_Time_Details_Data_Against_Cosolidation", new { @workSpaceGuid = workSpaceGuid}, commandType: CommandType.StoredProcedure);
        }

        public async Task<bool> IsBillingDataReady(string workspaceGId)
        {
            using IDbConnection dbContext = await GetDbConnection();
            return await dbContext.QuerySingleAsync<bool>("select IsDataReady from [dbo].[workspace_detail_master] where IsDeleted = 0 and IsApproved = 0 and GId = @WorkSpaceGId", new { WorkSpaceGId = workspaceGId });
        }

        public async Task<List<WorkspaceCommonData>> GetWorkSpaceBillableData(string workspaceGId)
        {
            try
            {
                using IDbConnection dbContext = await GetDbConnection();
                var results = await dbContext.QueryAsync<WorkspaceCommonData>("Sp_Get_Workspace_Billable_TnE", new { workspaceGId = workspaceGId }, commandType: CommandType.StoredProcedure);
                return results.Select(item => { item.DataType = DataTypeDomainEnum.Billable; return item; }).ToList();
                //AssignDataType(results, (item) => item.DataType = DataTypeDomainEnum.Billable);
                //return results.ToList();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        public async Task<List<WorkspaceCommonData>> GetWorkSpaceNonBillableData(string workspaceGId)
        {
            using IDbConnection dbContext = await GetDbConnection();
            var results = await dbContext.QueryAsync<WorkspaceCommonData>("Sp_Get_Workspace_Nonbillable_TnE", new { workspaceGId = workspaceGId }, commandType: CommandType.StoredProcedure);
            return results.Select(item => { item.DataType = DataTypeDomainEnum.NonBillable; return item; }).ToList();
            //AssignDataType(results, (item) => item.DataType = DataTypeDomainEnum.NonBillable);
            //return results.ToList();
        }
        public async Task<List<WorkspaceCommonData>> GetWorkSpaceBillingOpportunityData(string workspaceGId)
        {
            using IDbConnection dbContext = await GetDbConnection();
            var results = await dbContext.QueryAsync<WorkspaceCommonData>("Sp_Get_Workspace_BillingOpportunity_TnE", new { workspaceGId = workspaceGId }, commandType: CommandType.StoredProcedure);
            return results.Select(item => { item.DataType = DataTypeDomainEnum.AdditionalBillingOppertunity; return item; }).ToList();
            //AssignDataType(results, (item) => item.DataType = DataTypeDomainEnum.AdditionalBillingOppertunity);
            //return results.ToList();
        }
        public async Task<List<WorkspaceCommonData>> GetWorkSpaceUncodedData(string workspaceGId)
        {
            using IDbConnection dbContext = await GetDbConnection();
            var results = await dbContext.QueryAsync<WorkspaceCommonData>("Sp_Get_Workspace_Uncoded_TnE", new { workspaceGId = workspaceGId }, commandType: CommandType.StoredProcedure);
            return results.Select(item => { item.DataType = DataTypeDomainEnum.Uncoded; return item; }).ToList();
            //AssignDataType(results, (item) => item.DataType = DataTypeDomainEnum.Uncoded);
            //return results.ToList();
        }
        public async Task<List<WorkspaceCommonData>> GetWorkSpaceExpenseData(string workspaceGId)
        {
            using IDbConnection dbContext = await GetDbConnection();
            var results = await dbContext.QueryAsync<WorkspaceCommonData>("Sp_Get_Workspace_Expense_Tne", new { workspaceGId = workspaceGId }, commandType: CommandType.StoredProcedure);
            return results.Select(item => { item.DataType = DataTypeDomainEnum.Expense; return item; }).ToList();
            //AssignDataType(results, (item) => item.DataType = DataTypeDomainEnum.Expense);
            //return results.ToList();
        }
        public async Task<List<WorkspaceCommonData>> GetWorkSpaceAdhocData(string workspaceGId)
        {
            using IDbConnection dbContext = await GetDbConnection();
            var results = await dbContext.QueryAsync<WorkspaceCommonData>("Sp_Get_Workspace_Adhoc_TnE", new { workspaceGId = workspaceGId }, commandType: CommandType.StoredProcedure);
            return results.Select(item => { item.DataType = DataTypeDomainEnum.Adhoc; return item; }).ToList();
            //AssignDataType(results, (item) => item.DataType = DataTypeDomainEnum.Adhoc);
            //return results.ToList();
        }
        public async Task<bool> UpdateWorkSpace(List<WorkSpaceAdjustedData> wrkSpcAdjustedRecords)
        {
            bool status = false;
            List<Task<int>> wrkSpaceUpdateTaskList = new List<Task<int>>();
            if (wrkSpcAdjustedRecords != null && wrkSpcAdjustedRecords.Count() > 0)
            {
                var wrkSpaceGroupedRecords = wrkSpcAdjustedRecords.GroupBy(t => t.WorkSpaceDataType).ToList();
                if (wrkSpaceGroupedRecords != null && wrkSpaceGroupedRecords.Count() > 0)
                {
                    using (var transaction = new TransactionScope(TransactionScopeOption.Required, new System.TimeSpan(0, 15, 0), TransactionScopeAsyncFlowOption.Enabled))
                    {
                        using (IDbConnection dbContext = await GetDbConnection())
                        {
                            dbContext.Open();
                            foreach (var recordGroup in wrkSpaceGroupedRecords)
                            {
                                switch (recordGroup.Key)
                                {
                                    case DataTypeDomainEnum.Billable:
                                        var updateBillableTask = UpdateWorkSpaceBillableData(recordGroup.ToList(), dbContext);
                                        wrkSpaceUpdateTaskList.Add(updateBillableTask);
                                        break;
                                    case DataTypeDomainEnum.AdditionalBillingOppertunity:
                                        var updateBillingOppertunityTask = UpdateWorkSpaceBillingOppertunityData(recordGroup.ToList(), dbContext);
                                        wrkSpaceUpdateTaskList.Add(updateBillingOppertunityTask);
                                        break;
                                    case DataTypeDomainEnum.NonBillable:
                                        var updateNonBillableTask = UpdateWorkSpaceNonBillableData(recordGroup.ToList(), dbContext);
                                        wrkSpaceUpdateTaskList.Add(updateNonBillableTask);
                                        break;
                                    case DataTypeDomainEnum.Adhoc:
                                        var updateAdhocTask = UpdateWorkSpaceAdhocData(recordGroup.ToList(), dbContext);
                                        wrkSpaceUpdateTaskList.Add(updateAdhocTask);
                                        break;
                                    case DataTypeDomainEnum.Uncoded:
                                        var updateUncodedTask = UpdateWorkSpaceUncodedData(recordGroup.ToList(), dbContext);
                                        wrkSpaceUpdateTaskList.Add(updateUncodedTask);
                                        break;
                                    case DataTypeDomainEnum.Expense:
                                        var updateExpenseTask = UpdateWorkSpaceExpensesData(recordGroup.ToList(), dbContext);
                                        wrkSpaceUpdateTaskList.Add(updateExpenseTask);
                                        break;
                                    default:
                                        break;
                                }
                            }
                            if (wrkSpaceUpdateTaskList.Any())
                            {
                                await Task.WhenAll(wrkSpaceUpdateTaskList);
                                transaction.Complete();
                                if (dbContext.State == ConnectionState.Open)
                                {
                                    dbContext.Close();
                                }
                                status = true;
                            }
                        } ;
                        
                    }
                }
            }
            return status;
        }
        public async Task<List<TNEDataTransfer>> UpdateTNEMappingTables(List<TNEDataTransfer> tNEDataTransferMapper)
        {
            var results = new List<TNEDataTransfer>();
            if ( tNEDataTransferMapper!= null && tNEDataTransferMapper.Any())
            {
                DataTable dtTNEMappingTables = DataBaseHelper.ConvertListToDataTable(tNEDataTransferMapper);
                if (dtTNEMappingTables != null && dtTNEMappingTables.Rows.Count > 0)
                {
                    using IDbConnection dbContext = await GetDbConnection();
                    results = (List<TNEDataTransfer>)await dbContext.QueryAsync<TNEDataTransfer>("SP_Update_Tne_Workspace_Mapping", new { TypeAdjustedTneMapping = dtTNEMappingTables.AsTableValuedParameter("Type_Adjusted_Tne_Mapping") }, commandType: CommandType.StoredProcedure);
                }
            }
            return results;
        }
        public async Task<Guid> CreateNewEmptyAdhocRecord(Guid wrkSpaceGuid, string createdBy)
        {
            using IDbConnection dbContext = await GetDbConnection();
            return await dbContext.QuerySingleAsync<Guid>("SP_Create_Empty_Adhoc_Record", new { @wrkSpaceGuid = wrkSpaceGuid.ToString(), @createdBy = createdBy }, commandType: CommandType.StoredProcedure);
        }

        private async Task<int> UpdateWorkSpaceBillableData(List<WorkSpaceAdjustedData> billableData, IDbConnection dbContext)
        {
            DataTable dtBillableData = DataBaseHelper.ConvertListToDataTable(billableData);
            dtBillableData.Columns.Remove("WorkSpaceDataType");
            var results = await dbContext.ExecuteAsync("SP_Update_WorkSpace_Billable_Data", new { TypeWorkSpaceAdjustedData = dtBillableData.AsTableValuedParameter("Type_WorkSpace_Adjusted_Data") }, commandType: CommandType.StoredProcedure);
            return results;
        }

        private async Task<int> UpdateWorkSpaceBillingOppertunityData(List<WorkSpaceAdjustedData> billingOppertunityData, IDbConnection dbContext)
        {
            DataTable dtBillingOppertunityData = DataBaseHelper.ConvertListToDataTable(billingOppertunityData);
            dtBillingOppertunityData.Columns.Remove("WorkSpaceDataType");
            var results = await dbContext.ExecuteAsync("SP_Update_WorkSpace_Billing_Oppertunity_Data", new { TypeWorkSpaceAdjustedData = dtBillingOppertunityData.AsTableValuedParameter("Type_WorkSpace_Adjusted_Data") }, commandType: CommandType.StoredProcedure);
            return results;
        }

        private async Task<int> UpdateWorkSpaceNonBillableData(List<WorkSpaceAdjustedData> nonBillableData, IDbConnection dbContext)
        {
            DataTable dtNonBillableData = DataBaseHelper.ConvertListToDataTable(nonBillableData);
            dtNonBillableData.Columns.Remove("WorkSpaceDataType");
            var results = await dbContext.ExecuteAsync("SP_Update_WorkSpace_Non_Billable_Data", new { TypeWorkSpaceAdjustedData = dtNonBillableData.AsTableValuedParameter("Type_WorkSpace_Adjusted_Data") }, commandType: CommandType.StoredProcedure);
            return results;
        }

        private async Task<int> UpdateWorkSpaceAdhocData(List<WorkSpaceAdjustedData> adhocData, IDbConnection dbContext)
        {
            DataTable dtAdhocData = DataBaseHelper.ConvertListToDataTable(adhocData);
            dtAdhocData.Columns.Remove("WorkSpaceDataType");
            var results = await dbContext.ExecuteAsync("SP_Update_WorkSpace_Adhoc_Data", new { TypeWorkSpaceAdjustedData = dtAdhocData.AsTableValuedParameter("Type_WorkSpace_Adjusted_Data") }, commandType: CommandType.StoredProcedure);
            return results;
        }

        private async Task<int> UpdateWorkSpaceUncodedData(List<WorkSpaceAdjustedData> uncodedData, IDbConnection dbContext)
        {
            DataTable dtUncodedData = DataBaseHelper.ConvertListToDataTable(uncodedData);
            dtUncodedData.Columns.Remove("WorkSpaceDataType");
            var results = await dbContext.ExecuteAsync("SP_Update_WorkSpace_Uncoded_Data", new { TypeWorkSpaceAdjustedData = dtUncodedData.AsTableValuedParameter("Type_WorkSpace_Adjusted_Data") }, commandType: CommandType.StoredProcedure);
            return results;
        }

        private async Task<int> UpdateWorkSpaceExpensesData(List<WorkSpaceAdjustedData> expensesData, IDbConnection dbContext)
        {
            DataTable dtExpensesData = DataBaseHelper.ConvertListToDataTable(expensesData);
            dtExpensesData.Columns.Remove("WorkSpaceDataType");
            var results = await dbContext.ExecuteAsync("SP_Update_WorkSpace_Expenses_Data", new { TypeWorkSpaceAdjustedData = dtExpensesData.AsTableValuedParameter("Type_WorkSpace_Adjusted_Data") }, commandType: CommandType.StoredProcedure);
            return results;
        }
        
        //private void AssignDataType<T>(IEnumerable<T> dataList, Action<T> action)
        //{
        //    if (dataList != null && dataList.Any())
        //        foreach (var data in dataList)
        //            action(data);
        //}

        

       
    }
}
