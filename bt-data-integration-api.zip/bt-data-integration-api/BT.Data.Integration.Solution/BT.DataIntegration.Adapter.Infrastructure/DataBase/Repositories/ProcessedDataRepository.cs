﻿
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using BT.DataIntegration.Domain.Ports.Out;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Repositories
{
    public class ProcessedDataRepository : BillingRepository<ProcessedData>, IProcessedDataRepository
    {
        public ProcessedDataRepository(IConfiguration config, IVaultManager vault) : base(config, vault) { }
    }
}
