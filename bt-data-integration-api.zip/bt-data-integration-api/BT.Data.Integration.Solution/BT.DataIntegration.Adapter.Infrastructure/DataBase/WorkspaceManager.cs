﻿using AutoMapper;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Model.Enums;
using BT.DataIntegration.Domain.Ports.Out;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase
{
    public class WorkspaceManager : IWorkSpaceManager
    {

        IMapper _mapper;
        IWorkSpaceRepository _workSpaceRepository;
        IProcessedDataRepository _processedDataRepository;
        ILogger<WorkspaceManager> _logger;

        public WorkspaceManager(IMapper mapper, IWorkSpaceRepository workSpaceRepository, IProcessedDataRepository processedDataRepository, ILogger<WorkspaceManager> logger)
        {
            _mapper = mapper;
            _workSpaceRepository = workSpaceRepository;
            _processedDataRepository = processedDataRepository;
            _logger = logger;
        }

        public async Task<List<WorkspaceBillingItemDomain>> GetWorkspaceBillingDetails(string workspaceGid)
        {
            List<WorkspaceCommonData> _workspaceBillingDetails = new List<WorkspaceCommonData>();
            List<WorkspaceBillingItemDomain> _workspaceBillingItemDomians = new List<WorkspaceBillingItemDomain>();
            var getBillingTask = _workSpaceRepository.GetWorkSpaceBillableData(workspaceGid);
            var getNonBillableTask = _workSpaceRepository.GetWorkSpaceNonBillableData(workspaceGid);
            var getBillingOppertunityTask = _workSpaceRepository.GetWorkSpaceBillingOpportunityData(workspaceGid);
            var getUncodedTask = _workSpaceRepository.GetWorkSpaceUncodedData(workspaceGid);
            var getExpenseTask = _workSpaceRepository.GetWorkSpaceExpenseData(workspaceGid);
            var getAdhocTask = _workSpaceRepository.GetWorkSpaceAdhocData(workspaceGid);

            var taskCollection = new Task<List<WorkspaceCommonData>>[] { getBillingTask, getNonBillableTask, getBillingOppertunityTask, getUncodedTask, getExpenseTask, getAdhocTask };

            await Task.WhenAll(taskCollection);

            foreach (var task in taskCollection)
            {
                _workspaceBillingDetails.AddRange(task.Result);
            }
            if (_workspaceBillingDetails.Any())
            {
                var processedGids = GetDistinctProcessedGids(_workspaceBillingDetails);

                var listOfProcessedData = await GetListOfProcessedTimeData(processedGids);

                LinkProcessedDataToWorkspaceBillingDetails(_workspaceBillingDetails, listOfProcessedData.ToList());
                _workspaceBillingItemDomians.AddRange(_mapper.Map<List<WorkspaceBillingItemDomain>>(_workspaceBillingDetails));
            }

            return _workspaceBillingItemDomians;
        }

        public async Task<List<ProcessedDataDomain>> GetListOfProcessedDataTimeForWorkspace(List<string> workspaceItemGids)
        {
            List<ProcessedDataDomain> result = new List<ProcessedDataDomain>();
            var linkedProcessedTnEs = await _workSpaceRepository.GetAllAsync<WorkspaceItemProcessedGIds>("[dbo].[Sp_Get_LinkedPTnEforWorkspaceItem]", new { workspaceItemGids = string.Join(",", workspaceItemGids) });
            if (linkedProcessedTnEs != null && linkedProcessedTnEs.Any())
            {
                var processedGids = new List<string>();
                var linkedProcessedTnEsList = linkedProcessedTnEs.ToList();
                linkedProcessedTnEsList.ForEach(item =>
                {
                    if (!string.IsNullOrEmpty(item.ProcessedTnEIds))
                        processedGids.AddRange(item.ProcessedTnEIds.Split(","));
                });
                var processedDataTimeDetails = await GetListOfProcessedTimeData(processedGids.Distinct().ToList());
                result = _mapper.Map<List<ProcessedDataDomain>>(processedDataTimeDetails?.ToList());
                TagProcessedTnEWithWorkspaceItemGid(result, linkedProcessedTnEsList);
            }

            return result;
        }

        public async Task<bool> UpdateWorkSpace(List<ModifiedWorkSpaceDetailsDomain> wrkSpcAdjustedRecords)
        {
            bool status = false;
            if (wrkSpcAdjustedRecords.Any())
            {
                status = await _workSpaceRepository.UpdateWorkSpace(_mapper.Map<List<WorkSpaceAdjustedData>>(wrkSpcAdjustedRecords));
            }
            return status;
        }

        private void TagProcessedTnEWithWorkspaceItemGid(List<ProcessedDataDomain> processedDataTimeDetails, List<WorkspaceItemProcessedGIds> linkedProcessedTnE)
        {
            if (processedDataTimeDetails != null && processedDataTimeDetails.Any() && linkedProcessedTnE.Any())
            {
                processedDataTimeDetails.ForEach(item =>
                {
                    var matchedItem = linkedProcessedTnE.FirstOrDefault(linkedPItem => linkedPItem != null && linkedPItem.ProcessedTnEIds.Contains(item.GId.ToString(), StringComparison.InvariantCultureIgnoreCase));
                    if (matchedItem != null)
                        item.LinkedWorkspaceItemGid = matchedItem.GId.ToString();
                });
            }
        }

        private async Task<IEnumerable<ProcessedData>> GetListOfProcessedTimeData(List<string> processedGids)
        {
            return await _processedDataRepository.GetAllAsync<ProcessedData>("Sp_Get_Processed_TimeDetails", new { processedGIds = string.Join(",", processedGids) });
        }

        private void LinkProcessedDataToWorkspaceBillingDetails(List<WorkspaceCommonData> workspaceBillingDetails, List<ProcessedData> processDataList)
        {
            if (workspaceBillingDetails.Any() && processDataList.Any())
            {
                workspaceBillingDetails.ForEach(item =>
                {
                    if (item != null)
                    {
                        var matchedProcessedData = processDataList.Where(pData => !string.IsNullOrEmpty(item.ProcessedTnEIds) && item.ProcessedTnEIds.Contains(pData.GId.ToString(), StringComparison.InvariantCultureIgnoreCase))?.ToList();
                        if (matchedProcessedData != null && matchedProcessedData.Any())
                        {
                            item.LinkedProcessedDataList.AddRange(matchedProcessedData);
                        }
                    }

                });
            }
        }

        private List<string> GetDistinctProcessedGids(List<WorkspaceCommonData> workspaceItems)
        {
            List<string> processedGids = new List<string>();
            if (workspaceItems != null && workspaceItems.Count > 0)
            {

                workspaceItems.ForEach(item =>
                {
                    if (!string.IsNullOrEmpty(item.ProcessedTnEIds))
                    {
                        processedGids.AddRange(item.ProcessedTnEIds.Split(","));
                    }
                });
                if (processedGids.Any())
                    processedGids = processedGids.Distinct().ToList();
            }

            return processedGids; ;
        }

        public async Task<Guid> CreateAdhocGuid(Guid wrkSpaceGuid, string createdBy)
        { 
            return await _workSpaceRepository.CreateNewEmptyAdhocRecord(wrkSpaceGuid, createdBy);
        }
    }
}
