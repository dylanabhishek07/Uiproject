﻿using BT.DataIntegration.Domain.Model.Enums;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Models
{
    public class WorkSpaceAdjustedData
    {
        public Guid? Gid { get; set; }
        public int BillingActionId { get; set; }
        public int AdjustedBillingActionId { get; set; }
        public float AdjustedInvoiceFee { get; set; }
        public string? AdjustedCurrency { get; set; }
        public string? AdjustedDescription { get; set; }
        public string? AdjustedBillingEntity { get; set; }
        public string? AdjustedCostCenter { get; set; }
        public string? AdjustedOOSNR { get; set; }
        public string? AdjustedGBTStatus { get; set; }
        public string? AdjustedGBTRef { get; set; }
        public string? ModifiedBy { get; set; }
        public DateTime? ModifiedDateTime { get; set; }
        public DataTypeDomainEnum WorkSpaceDataType { get; set; }       

    }
}
