﻿using BT.DataIntegration.Domain.Model.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Models
{
    public class WorkspaceCommonData: WorkSpaceAdjustedData
    {
        public WorkspaceCommonData()
        {
            this.LinkedProcessedDataList = new List<ProcessedData>();
        }

        //public Guid GId { get; set; }
        public DataTypeDomainEnum DataType { get; set; }
        public string WorkSpaceDetailMasterId { get; set; }
        public string ProcessedTnEIds { get; set; }
        public string ProductId { get; set; }
        public int ActivityId { get; set; }
        public string? ActivityDescription { get; set; }
        public string ExpenseReferenceId { get; set; }
        public string ExpenseAmount { get; set; }
        public List<ProcessedData> LinkedProcessedDataList { get; set; }
    }
}
