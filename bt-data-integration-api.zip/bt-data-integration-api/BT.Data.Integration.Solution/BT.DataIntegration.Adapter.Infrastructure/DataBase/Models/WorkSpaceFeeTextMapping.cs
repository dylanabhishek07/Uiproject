﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Models
{
    public class WorkSpaceFeeTextMapping
    {
        public Guid WorkSpaceRowGId { get; set; }
        public string FeeText { get; set; }
    }
}
