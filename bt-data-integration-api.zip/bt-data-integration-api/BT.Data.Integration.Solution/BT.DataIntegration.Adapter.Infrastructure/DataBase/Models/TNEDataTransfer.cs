﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Models
{
    public  class TNEDataTransfer
    {
        public Guid? TransferToWorkspaceGId { get; set; }
        public bool? IsSourceCategory { get; set; }
        public int? TransferToDataCategory { get; set; }
        public string? FinalProcessedTnEList { get; set; }
    }
}
