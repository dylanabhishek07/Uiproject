﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Models
{
    public class EngagementSummeryDetails
    {
        public Guid GId { get; set; }
        public int BillingActionId { get; set; }

        public int AdjustedBillingActionId { get; set; }

        public string ProcessedTnEId { get; set; }

        public float NSR { get; set; }

        public float ANSR { get; set; }

        public float EAF { get; set; }

        public float ExpenseAmount { get; set; }

        public string EngagementId { get; set; }
    }
}
