﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Models
{
    public class ProcessedData
    {
        public Guid GId { get; set; }
        public int ActivityId { get; set; }
        public string ProductId { get; set; }
        public float ChargedHours { get; set; }
        //public string ChargedHoursDescription { get; set; }
        public float NSR { get; set; }
        public float ANSR { get; set; }
        public float ExpenseAmount { get; set; }
    }
}
