﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Models
{
    public class Invoice
    {
        public Guid? GId { get; set; }
        public string? EntityId { get; set; }
        public string? EntityName { get; set; }
        public string? WorkSpaceDetailMasterGId { get; set; }
        public int InvoiceType { get; set; }
        public DateTime ProcessingDate { get; set; }
        public int InvoiceLanguage { get; set; }
        public DateTime PeriodStartData { get; set; }
        public DateTime PeriodEndData { get; set; }
        public string? ClientName { get; set; }
        public string? ClientAddress { get; set; }
        public string? ClientContactName { get; set; }
        public float NetAmount { get; set; }
        public float TFeesPercentage { get; set; }
        public float CoordinationFee { get; set; }
        public float TotalAmountExVat { get; set; }
        public float VatAmount { get; set; }
        public float TotalAmountIncVat { get; set; }
        public int Currency { get; set; }
        public string? Description { get; set; }
        public string? CostCenter { get; set; }
        public bool PreApprovalRequired { get; set; } = false;
        public string? MailingAddress { get; set; }
        public float TotalInvoiceAllocation { get; set; }
        public string? Comments { get; set; }
        public bool IsDeleted { get; set; } = false;
        public DateTime? ModifiedDateTime { get; set; }
        public string? ModifiedBy { get; set; }
    }
}
