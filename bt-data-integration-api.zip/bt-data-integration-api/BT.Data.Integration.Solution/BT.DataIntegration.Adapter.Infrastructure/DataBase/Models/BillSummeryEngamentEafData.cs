﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Models
{
    public class BillSummeryEngamentEafData
    {
        public string WorkSpaceDetailMasterGId  { get; set; }
        public string EngagementId { get; set; }
        public float ETDNSR { get; set; }
        public float ETDExpense { get; set; }
        public float ETDInvoices { get; set; }
        public float ETCNSR { get; set; }
        public float ETCExpenses { get; set; }
        public float ETCSales { get; set; }
        public float NUI { get; set; }
        public bool ETCToBeProcessed { get; set; }
        public bool IsDeleted { get; set; }
        public string CreatedBy { get; set; }
        public string ModifiedBy { get; set; }
    }
}
