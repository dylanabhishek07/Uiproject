﻿using AutoMapper;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Ports.Out;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase
{
    public class AnnexePreviewManager : IAnnexePreviewManager
    {
        IAnnexePreviewRepository _annexPreviewRepository;
        IMapper _mapper;
        

        public AnnexePreviewManager(IAnnexePreviewRepository annexPreviewRepository, IMapper mapper)
        {
            _annexPreviewRepository = annexPreviewRepository;
            _mapper = mapper;
        }
        public async Task<List<WorkSpaceFeeTextMappingDomain>> GetFeeTextByWorkSpaceGIds(List<string?> workSpaceGIDs)
        {
            var workSpaceFeeMapping = new List<WorkSpaceFeeTextMappingDomain>();
            var result = await _annexPreviewRepository.GetFeeTextByWorkSpaceGids(workSpaceGIDs);
            if (result.Any())
            {
                workSpaceFeeMapping = _mapper.Map<List<WorkSpaceFeeTextMappingDomain>>(result.ToList());
            }

            return workSpaceFeeMapping;
        }

        public async Task<int> SaveFeeDetails(List<AnnexPreviewFeeDetailDomain> feeDetails)
        {
            return await _annexPreviewRepository.SaveFeeDetails(_mapper.Map<List<FeeDetails>>(feeDetails));
        }
    }
}
