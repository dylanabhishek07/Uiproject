﻿using AutoMapper;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using BT.DataIntegration.Domain.Model;
using BT.DataIntegration.Domain.Ports.Out;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase
{
    public class InvoiceDetailsManager : IInvoiceDetailsManager
    {

        IMapper _mapper;
        ILogger<WorkspaceManager> _logger;
        IInvoiceDetailsRepository _invoiceDetailsRepository;

        public InvoiceDetailsManager(IMapper mapper, ILogger<WorkspaceManager> logger, IInvoiceDetailsRepository invoiceDetailsRepository)
        {
            _mapper = mapper;
            _logger = logger;
            _invoiceDetailsRepository = invoiceDetailsRepository;
        }

        public async Task<int> SaveInvoiceDetails(List<InvoiceDetailsDomain> invoiceDetails)
        {
            return await _invoiceDetailsRepository.SaveInvoiceDetails(_mapper.Map<List<Invoice>>(invoiceDetails));
        }
    }
}
