﻿using BT.DataIntegration.Adapter.Infrastructure.DataBase.Mappers;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts
{
    public interface IProcessedDataRepository : IBillingRepository<ProcessedData>
    {
    }
}
