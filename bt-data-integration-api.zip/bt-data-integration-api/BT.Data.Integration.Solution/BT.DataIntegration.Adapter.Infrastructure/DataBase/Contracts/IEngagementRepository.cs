﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts
{
    public interface IEngagementRepository : IBillingRepository<Engagement>
    {
        Task<IEnumerable<Engagement>> GetClientSpecificEngagementsByIndex(string clientid, int startindex, int count);
        
    }
}
