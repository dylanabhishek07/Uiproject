﻿using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts
{
    public interface IWorkSpaceRepository : IBillingRepository<WorkSpace>
    {
        Task<Guid> AddWorkSpaceByGuids(WorkSpace wrkSpace);
        Task<IEnumerable<WorkSpace>> CheckForExistingWorkSpaceByGuids(string ClientEngagementMapGIds);
        Task<bool> IsBillingDataReady(string workspaceId);
        Task<IEnumerable<TNEData>> GetTimeDetails(string workSpaceGuid);
        Task<List<WorkspaceCommonData>> GetWorkSpaceBillableData(string workspaceGId);
        Task<List<WorkspaceCommonData>> GetWorkSpaceNonBillableData(string workspaceGId);
        Task<List<WorkspaceCommonData>> GetWorkSpaceBillingOpportunityData(string workspaceGId);
        Task<List<WorkspaceCommonData>> GetWorkSpaceUncodedData(string workspaceGId);
        Task<List<WorkspaceCommonData>> GetWorkSpaceExpenseData(string workspaceGId);
        Task<List<WorkspaceCommonData>> GetWorkSpaceAdhocData(string workspaceGId);
        Task<List<TNEDataTransfer>> UpdateTNEMappingTables(List<TNEDataTransfer> tNEDataTransferMapper);
        Task<bool> UpdateWorkSpace(List<WorkSpaceAdjustedData> wrkSpcAdjustedRecords);
        Task<Guid> CreateNewEmptyAdhocRecord(Guid wrkSpaceGuid, string createdBy);
    }
}
