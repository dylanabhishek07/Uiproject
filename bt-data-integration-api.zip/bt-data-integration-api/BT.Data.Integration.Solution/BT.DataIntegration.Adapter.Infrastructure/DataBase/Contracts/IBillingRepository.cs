﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts
{
    public interface IBillingRepository<T> where T : class
    {
        Task<IEnumerable<T>> GetAllAsync<T>(string storedProcedureName, object parameters, CommandType commandType = CommandType.StoredProcedure);

    }
}
