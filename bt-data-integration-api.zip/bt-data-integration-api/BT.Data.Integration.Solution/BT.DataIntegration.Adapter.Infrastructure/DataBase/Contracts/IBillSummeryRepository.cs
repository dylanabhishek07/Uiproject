﻿using BT.DataIntegration.Adapter.Infrastructure.DataBase.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BT.DataIntegration.Adapter.Infrastructure.DataBase.Contracts
{
    public interface IBillSummeryRepository : IBillingRepository<BillSummeryDetails>
    {
        public Task<IEnumerable<EngagementSummeryDetails>> GetEngagementSummeryDetails(string workspaceMasterGid);
        public Task<IEnumerable<BillSummeryEngamentEafData>> GetEAFCalculationDetails(string workspaceMasterGid);
        public Task SaveEAFCalculationDetails(List<BillSummeryEngamentEafData> billSummeryEngamentEafData);
    }
}
