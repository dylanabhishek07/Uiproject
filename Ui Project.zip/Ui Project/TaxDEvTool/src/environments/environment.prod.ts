export const environment = {
  production: true,
  sp_apiBaseUrl: 'https://sites.ey.com/sites/TaxLabDev/_api/',
  sp_url: 'https://sites.ey.com/sites/TaxLabDev',  
};
