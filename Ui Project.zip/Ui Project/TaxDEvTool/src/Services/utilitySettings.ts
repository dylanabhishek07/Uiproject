
export class utilitySettings {

    //#region common
    // public readonly SPDomain: string = "https://sites.ey.com/";//Dev
    // public readonly SPServer: string = "sites/vnext_spdev/";//Dev
    // public readonly BASE_API_URL: string = "localhost:9612/api"; //local DB

    // public readonly SPDomain: string = "https://sites.ey.com/";//Dev
    // public readonly SPServer: string = "sites/vnext_spdev/";//Dev

    // public readonly SPDomain:string="https://sites.ey.com/";//QA
    // public readonly SPServer:string="sites/CADUSBILLTOOL/";//QA

    public readonly SPDomain: string = "https://sites.ey.com/";//UAT
    public readonly SPServer: string = "sites/TaxLabDev/";//UAT

    //public readonly SPDomain: string = "https://sites.ey.com/";//prod
    //public readonly SPServer: string = "sites/AIRTool/";//prod

    // public readonly  SPDomain:string="https://sites.ey.com/";//prod
    // public readonly  SPServer:string="sites/AIRTool/";//prod
    
    public readonly SPSiteURL: string = this.SPDomain + this.SPServer;
    //public readonly SPSiteURL: string = "";// when running proxy server

    //public readonly APIbaseUrl:string = "https://cibapi.ey.com/api/";//Prod
    public readonly APIbaseUrl: string = "https://cacuint09zwap01.azurewebsites.net/api/";//UAT
    //public readonly APIbaseUrl:string = "https://cacqint09iwap01.azurewebsites.net/api/";//QA
    //public readonly APIbaseUrl: string = "http://localhost:49215/api/"; //local

    public appName: string = "";

    public currentUser: { name: string, email: string } = { name: "", email: "" };
    static loggedInUser: { name: string, email: string } = { name: "", email: "" };

    public readonly SPSiteAssets: string = this.SPSiteURL + "SiteAssets/"//Sharepoint Site Assests //comment when running local SP server

    replaceSpecialCharacters(attribute) {
        attribute = attribute.replace(/'/g, "''");
        attribute = attribute.replace(/%/g, "%25");
        attribute = attribute.replace(/\+/g, "%2B");
        attribute = attribute.replace(/\//g, "%2F");
        attribute = attribute.replace(/\?/g, "%3F");
        attribute = attribute.replace(/#/g, "%23");
        attribute = attribute.replace(/&/g, "%26");
        return attribute;
    }

    downloadFile(relativeURL: string, fileName: string): string {
        try {
            return this.SPSiteURL + "_layouts/15/download.aspx?SourceUrl=" + relativeURL + fileName;
        }
        catch (err) {
            console.log(err);
        }
    }

    readonly refreshSPFormDigest: string = this.SPSiteURL + "_api/contextinfo";

    getReceiptByID(libraryName: string, id: number) {
        try {
            return this.SPSiteURL + "_api/web/lists/GetByTitle('" + libraryName + "')/items(" + id + ")?$select=Id,File/ServerRelativeUrl,File/Name&$expand=File";
        } catch (err) {
            console.log(err);
        }
    }

    readonly sendEmailAPI: string = this.SPSiteURL + "_api/SP.Utilities.Utility.SendEmail";

    readonly sendGridEmail: string = this.APIbaseUrl + "MailNotification/SendEmailByStatus";

    getReceiptDoc(libraryName: string, sqlTableColumn: string, sqlId: number) {
        try {
            return `${this.SPSiteURL}_api/web/lists/GetByTitle('${libraryName}')/items?$filter=(${sqlTableColumn} eq ${sqlId})&$select=Id,File/ServerRelativeUrl,File/Name&$expand=File&$orderby=ID desc`;
        } catch (err) {
            console.log(err);
        }
    }

    deleteItem(listName: string, id: number): string {
        try {
            return this.SPSiteURL + "_api/web/lists/getbytitle('" + listName + "')/items(" + id + ")"
        }
        catch (err) {
            console.log(err);
        }
    }
    //#endregion

    //#region chequeRequest
    readonly saveChequeRequest: string = this.APIbaseUrl + "Cheque/SaveChequeDetails/";

    readonly saveEYUSCheque: string = this.APIbaseUrl + "Cheque/SaveOrUpdateUSCheque/";

    readonly getChequeById: string = this.APIbaseUrl + "Cheque/";

    readonly getEYUSChequeById: string = this.APIbaseUrl + "Cheque/GetUSChequeById/";

    readonly getAllCheques: string = this.APIbaseUrl + "Cheque/FetchChequeListSP";

    readonly getAllEYUSCheques: string = this.APIbaseUrl + "Cheque/GetAllUSChequeList";

    readonly exportAllCheques: string = this.APIbaseUrl + "Cheque/ExportChequeList";

    readonly exportAllUSChequeList: string = this.APIbaseUrl + "Cheque/ExportAllUSChequeList";

    readonly exportAllMercuryReportList: string = this.APIbaseUrl + "ReportFileUpload/ExportAllMercuryList";

    readonly deleteUSChequeById: string = this.APIbaseUrl + "Cheque/DeleteUSChequeRequest";

    readonly deleteChequeById: string = this.APIbaseUrl + "Cheque/";

    readonly getChequeEngCodes: string = `${this.APIbaseUrl}GetAllChequeEngagementCodes`;

    readonly getFilingAddress: string = `${this.APIbaseUrl}GetAllFilingAddress`;

    readonly GetUscisFees: string = `${this.APIbaseUrl}GetAllUscisFees`;
    //#endregion

    //#region  credit Request
    readonly saveCreditRequest: string = this.APIbaseUrl + "Credit/SaveCreditDetails/";

    readonly getCreditById: string = this.APIbaseUrl + "Credit/";

    readonly deleteCreditById: string = this.APIbaseUrl + "Credit/DeleteCredit/";

    readonly getAllCredit: string = this.APIbaseUrl + "Credit/FetchCreditListSP";

    readonly exportAllCredit: string = this.APIbaseUrl + "Credit/ExportCreditList/";

    readonly getCreditEngCodes: string = `${this.APIbaseUrl}GetAllCreditRequestEngagementCodes`;

    readonly getCreditCaseTypes: string = `${this.APIbaseUrl}GetAllCreditCaseTypes`;

    readonly getCreditStaff: string = `${this.APIbaseUrl}GetAllCreditStaffInfo`;
    //#endregion

    //#region Consolidated Fee
    readonly getAllConsolidateFeeData: string = this.APIbaseUrl + "GetAllConsolidatedFees";

    readonly saveConsolidatedFeeRecord: string = this.APIbaseUrl + "ReportFileUpload/SaveConsolidatedDetails";

    readonly deleteConsolidatedFeeRecords: string = this.APIbaseUrl + "ReportFileUpload/DeleteConsolidatedDetails";
    //#endregion

    //#region mercury fee
    readonly saveMercuryFeeRecord: string = this.APIbaseUrl + "ReportFileUpload/SaveOrUpdateMercuryByEng";

    readonly deleteMercuryFeeRecords: string = this.APIbaseUrl + "ReportFileUpload/DeleteMercuryEngagement";

    readonly getAllMercuryData: string = this.APIbaseUrl + "ReportFileUpload/FetchAllMercuryInvoice/";
    //#endregion

    //#region IRF
    readonly getMercuryDataByEngID: string = this.APIbaseUrl + "ReportFileUpload/";

    readonly saveZoomVendorWithExpenses: string = this.APIbaseUrl + "ReportFileUpload/SaveZoomVendorWithExpensesDetails";

    readonly updateZoomCaseRecordByStatus: string = this.APIbaseUrl + "Invoice/UpdateZoomCaseRecordByStatus";
    //#endregion

    //#region  Configuration Details
    readonly getConfigurationTable: string = `${this.APIbaseUrl}GetAllConfigurations`;

    readonly getPDFConfig: string = `${this.APIbaseUrl}GetAllPdfInvoiceConfigurations`;

    readonly getEmailConfig: string = `${this.APIbaseUrl}GetAllEmailConfigurations`;

    readonly getAllGBTClients: string = `${this.APIbaseUrl}GetAllGbtList`;

    readonly checkGBTClient: string = this.APIbaseUrl + "GetAllGbtListByClient?client=";
    //#endregion

    //#region Users Data
    readonly getAllUsers: string = `${this.APIbaseUrl}User/GetAllUsers`;

    readonly getUsersEmailIdsByGroupId: string = this.APIbaseUrl + "User/GetUsersEmailIdsByGroupId?id=";

    readonly getUsersByGroupId: string = this.APIbaseUrl + "User/GetUsersByGroupId?id=";

    readonly peopleSearchFeed: string = this.SPSiteURL + "_api/SP.UI.ApplicationPages.ClientPeoplePickerWebServiceInterface.clientPeoplePickerSearchUser".replace(/\/\//g, '/');

    readonly getCurrentUserURL: string = "_api/web/currentuser";
    //readonly getCurrentUserURL: string = `${environment.siteURl}`+ "_api/web/currentuser"

    addUserToSharePoint(group: string): string {
        try {
            return `${this.SPSiteURL}_api/web/sitegroups/getbyname('${group}')/users`
        }
        catch (err) {
            console.log(err);
        }
    }

    readonly getUserByEmail: string = this.APIbaseUrl + "User/" + "GetUserByEmail?email=";

    readonly verifyUserByEmail: string = this.APIbaseUrl + "User/" + "VerifyUserByEmail?email=";
    //#endregion

    //#region Exceptions log
    readonly getAllExceptions: string = this.APIbaseUrl + "Common/GetExceptionsLog";

    readonly getExceptionById: string = this.APIbaseUrl + "Common/GetExceptionsLogById?id=";

    readonly getCadActionStatusTypes: string = this.APIbaseUrl + "Common/GetCadActionStatusTypes";

    readonly getCadIssuePriorityTypes: string = this.APIbaseUrl + "Common/GetCadIssuePriorityTypes";

    readonly getCadActionStatusTypeById: string = this.APIbaseUrl + "Common/GetCadActionStatusTypeById?id=";

    readonly saveOrUpdateCadExceptionLog: string = this.APIbaseUrl + "Common/SaveOrUpdateCadExceptionLog";

    readonly getIrfMailLogs: string = this.APIbaseUrl + "Common/GetCADIrfDraftSummaryMailLogs";

    readonly updateIRFEmailLog: string = this.APIbaseUrl + "Common/UpdateIrfMail";

    serachIRFEmail(caseID: string, approvalDate: string): string {
        if (approvalDate == null) {
            return `${this.APIbaseUrl}Common/GetIrfMailsByCaseId?caseId=${caseID}`;
        } else {
            return `${this.APIbaseUrl}Common/GetIrfMailByCaseIdAndApprovedDate?caseId=${caseID}&irfApprovedDate=${approvalDate}`;
        }
    }
    //#endregion

    readonly getZoomVendorData: string = this.APIbaseUrl + "ReportFileUpload/FetchZoomVendorList/";

    readonly getTrustforteData: string = this.APIbaseUrl + "Trustforte/FetchAllTrustForteDetails/";

    readonly getAllExpenseData: string = this.APIbaseUrl + "Expenses/FetchAllExpenses/";

    readonly saveExpense: string = this.APIbaseUrl + "Expenses/SaveOrUpdateExpense/";

    readonly deleteExpenseById: string = this.APIbaseUrl + "Expenses/";

    readonly deleteEYUSExpenseById: string = this.APIbaseUrl + "Expenses/";

    readonly getExpenses: string = this.APIbaseUrl + "Expenses/GetAllExpensesByZoomCaseId/";

    readonly getExpenseById: string = this.APIbaseUrl + "GetExpenses/";

    readonly fetchInvoiceByCaseId: string = this.APIbaseUrl + "Invoice/FetchInvoiceByCaseId/";

    readonly saveStatus: string = this.APIbaseUrl + "Invoice/UpdateInvoice/";

    readonly getInvoicesGroup: string = this.APIbaseUrl + "Expenses/GetAllExpensesGroupByZoomCaseId";

    readonly getInvoicesByBnfAndOpenDate: string = this.APIbaseUrl + "Expenses/GetAllExpensesByBnfIdAndOpenDate";

    readonly approveFinalInvoices: string = this.APIbaseUrl + "Invoice/ApproveFinalInvoices";

    readonly fetchAllExpensesBySP: string = this.APIbaseUrl + "Expenses/FetchAllExpensesBySP";

    readonly fetchAllReportExpenses: string = this.APIbaseUrl + "Expenses/FetchAllReportExpenses";

    readonly exportAllReportExpenses: string = this.APIbaseUrl + "Expenses/ExportAllReportExpenses";

    readonly exportAllExpensesBySP: string = this.APIbaseUrl + "Expenses/ExportAllExpensesBySP";

    readonly fetchAllExpensesGroupByZoomCaseId: string = this.APIbaseUrl + "Expenses/FetchAllExpensesGroupByZoomCaseId";

    readonly exportAllExpensesGroupByZoomCaseId: string = this.APIbaseUrl + "Expenses/ExportAllExpensesGroupByZoomCaseId";

}