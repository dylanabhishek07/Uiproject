import { utilitySettings } from './utilitySettings';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { map, tap, catchError } from 'rxjs/operators';
import { GridDataResult } from '@progress/kendo-angular-grid';

@Injectable({
  providedIn: 'root'
})
export class CommonService {

  constructor(private _http: HttpClient, public utilitySettings: utilitySettings) { }

  postData(URL: string, body: any, options?: any) {
    try {
      return this._http.post(URL, body, options);
    }
    catch (err) {
      console.log(err);
    }
  }

  getFormDigest() {
    try {
      return this.postData(this.utilitySettings.refreshSPFormDigest, { "Accept": "application/json; odata=verbose" });
    }
    catch (err) {
      console.log(err);
    }
  }


  searchUser(name: string, formDigest: any): Observable<any> {
    let body = JSON.stringify({
      queryParams: {
        __metadata: {
          type: 'SP.UI.ApplicationPages.ClientPeoplePickerQueryParameters'
        },
        AllowEmailAddresses: true,
        AllowMultipleEntities: false,
        AllUrlZones: false,
        MaximumEntitySuggestions: 50,
        PrincipalSource: 15,
        PrincipalType: 15,
        QueryString: name
      }
    }
    );
    const headers = new HttpHeaders({
      'Content-Type': 'application/json;odata=verbose',
      'Accept': 'application/json;odata=verbose',
      'X-RequestDigest': formDigest
    });
    const options = { headers: headers };

    return this.postData(this.utilitySettings.peopleSearchFeed, body, options);
  }
}