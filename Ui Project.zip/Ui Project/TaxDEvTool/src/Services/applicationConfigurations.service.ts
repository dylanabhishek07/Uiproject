import { Injectable } from '@angular/core';
import { CommonService } from './common.service';
import { MsAdalAngular6Service } from 'microsoft-adal-angular6';
import { utilitySettings } from './utilitySettings';
import { NotifierService } from 'angular-notifier';
import { BehaviorSubject} from 'rxjs';
@Injectable()
export class ApplicationConfigurationsService {

  private readonly notifier: NotifierService;

  private SPformDigest : BehaviorSubject<string> = new BehaviorSubject("");

  constructor(private commService: CommonService,
    notifierService: NotifierService, private utilitySettings: utilitySettings) {
    this.notifier = notifierService;
  }

  public getSPformDigest(): any {
    return this.SPformDigest;
  }

  public setSPformDigest(SPformDigest: any): any {
    this.SPformDigest.next(SPformDigest);
  }

  // public getAppPermissions(): any {
  //   return this.appPermissions;
  // }


}