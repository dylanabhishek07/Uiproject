import { Component, ApplicationRef, NgZone } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Tax Lab';
  routerurl: string;
  paramarr: string[];
  paramurl: string;

  constructor(
    private router: Router,
    private applicationRef: ApplicationRef,
    private zone: NgZone
  ) {
    router.events.subscribe(() => {
      zone.run(() =>
        setTimeout(() => {
          this.applicationRef.tick();
        }, 0)
      );
    });
    this.paramarr = location.pathname.split('_');
    this.paramurl = this.paramarr[1];
    //this.routerurl = router.url; 
  }
}
