import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { guid } from '@progress/kendo-angular-common';
import { combineLatest, forkJoin, pipe } from 'rxjs';
import { Router } from '@angular/router';
import { _DEFAULT_FIELDS } from '../Models/form-fields';
import { _DEFAULT_FORM } from '../Models/form-schema';
import { _FORM_STAGES, _FORM_STATUS } from '../Models/formstatus';
import { MasterListModel } from '../Models/masterListModel';
import { EstimationColumns, TechnicalEstimatesModel } from '../Models/technicalEstimatesModel';
import { DashboardSPService } from '../Services/Implementations/dashboardService';
import { MasterListService } from '../Services/Implementations/masterListService';
import { TechnicalEstimatesSPService } from '../Services/Implementations/technicalEstimatesService';
import * as _ from 'lodash';
import { DashboardColumns, _Dashboard_Column } from '../Models/dashboard-columns';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { Form7Columns, Form7Model } from '../Models/form7model';
import { Form7SPService } from '../Services/Implementations/form7Service';
import { ExcelDataModel } from '../Models/excelDataModel';
import { ExcelUtil } from '../Utilities/excelUtil';
import { combineAll } from 'rxjs/operators';
import { Form2SPService } from '../Services/Implementations/form2Service';
import { Form3SPService } from '../Services/Implementations/form3Service';
import { Form6SPService } from '../Services/Implementations/form6Service';
import { Form2Model } from '../Models/form2model';
import { Form3Model } from '../Models/form3model';
import { Form4SPService } from '../Services/Implementations/form4Service';
import { Form5SPService } from '../Services/Implementations/form5Service';
import { Form4Model } from '../Models/form4model';
import { Form5Model } from '../Models/form5model';
import { HttpClient } from '@angular/common/http';
import * as XLSX from 'xlsx';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  providers: [DashboardSPService, MasterListService, TechnicalEstimatesSPService, Form7SPService, Form2SPService, Form3SPService, Form6SPService, Form4SPService, Form5SPService]
})
export class DashboardComponent implements OnInit {

  selectedTab: string = "";

  totalUseCase: number = 0;
  newUseCase: number = 0;
  integrationUseCase: number = 0;
  geographyUseCase: number = 0;
  inProgressCount: number = 0;
  parkedCount: number = 0;
  stage1ApprovedCount: number = 0;
  stage2ApprovedCount: number = 0;
  handoffCount: number = 0;

  dashboardData: any[] = [];
  originalDashboardData: any[] = [];
  tableDashboardData: any[] = [];
  currentUseCase: any = null;
  isShowSubmitPopup: boolean = false;
  isShowEstimatePopup: boolean = false;
  isShowFastTrackPopup: boolean = false;
  isShowGovernancePopup: boolean = false;
  fastTrackStatusArray: string[] = ['', 'Pass', 'Fail'];
  dashboardHeaders: DashboardColumns[] = _Dashboard_Column;
  dropdownList: any = {};
  selectedItems0: any[] = [];
  selectedItems1: any[] = [];
  selectedItems2: any[] = [];
  selectedItems3: any[] = [];
  selectedItems4: any[] = [];
  selectedItems5: any[] = [];
  selectedItems6: any[] = [];
  selectedItems7: any[] = [];
  selectedItems8: any[] = [];
  selectedItems9: any[] = [];
  selectedItems10: any[] = [];
  selectedItems11: any[] = [];
  selectedItems12: any[] = [];
  selectedItems13: any[] = [];
  dropdownSettings: IDropdownSettings = {
    singleSelection: false,
    idField: 'id',
    textField: 'value',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    itemsShowLimit: 3,
    allowSearchFilter: false,
    enableCheckAll: false,
  };
  isFinalHandoff: boolean = false;

  constructor(private _dashboardSvc: DashboardSPService,
    private _masterListSvc: MasterListService,
    private _estimationSvc: TechnicalEstimatesSPService,
    private _form7Svc: Form7SPService, private router: Router,
    private changeDetector: ChangeDetectorRef, private _form2Svc: Form2SPService,
    private _form3Svc: Form3SPService, private _form6Svc: Form6SPService,
    private _form4Svc: Form4SPService, private _form5Svc: Form5SPService,
    private _http: HttpClient) { }

  ngOnInit() {
    this.totalUseCase = 0;
    this.newUseCase = 0;
    this.integrationUseCase = 0;
    this.geographyUseCase = 0;
    this.inProgressCount = 0;
    this.parkedCount = 0;
    this.stage1ApprovedCount = 0;
    this.stage2ApprovedCount = 0;
    this.handoffCount = 0;

    this.populateDashboardData();

    this.selectedTab = "Total";

  }

  calculateCounts(data: any[]) {
    // In progress count
    this.totalUseCase = data.length;
    this.newUseCase = data.filter(d => d.DemandType === "New use case / product").length;
    this.integrationUseCase = data.filter(d => d.DemandType === "Integration / globalisation of existing product").length;
    this.geographyUseCase = data.filter(d => d.DemandType === "New Geography for existing use case / product").length;

    this.inProgressCount = data.filter(d => d.FormStatus === _FORM_STATUS.inProgress).length;
    this.parkedCount = data.filter(d => d.FormStatus === _FORM_STATUS.parked).length;
    this.stage1ApprovedCount = data.filter(d => (d.FormStatus === _FORM_STATUS.approved && d.Stage === _FORM_STAGES.stage1)).length;
    this.stage2ApprovedCount = data.filter(d => (d.FormStatus === _FORM_STATUS.approved && d.Stage === _FORM_STAGES.stage2)).length;
    this.handoffCount = data.filter(d => d.FormStatus === _FORM_STATUS.completed).length;
  }

  openFastTrackModal(useCase) {
    this.currentUseCase = useCase;
    this.currentUseCase.fastTrackModalTitle = "Pass/ Fail DI Fast Track for " + useCase.UseCaseName;
    this.currentUseCase.Stage = useCase.Stage;
    this.currentUseCase.FormStatus = useCase.FormStatus;
    this.currentUseCase.masterRecordId = useCase.MasterRecordId;
    this.currentUseCase.fastTrackStatusStr = useCase.FastTrackStatus !== 'NA' ? useCase.FastTrackStatus : "";
    this.currentUseCase.invalidFastTrackStatus = false;
    this.currentUseCase.invalidFastTrackStatusMsg = "";
    this.isShowFastTrackPopup = true;
  }

  closeFastTrackModal() {
    this.currentUseCase = null;
    this.isShowFastTrackPopup = false;
  }

  openModal(useCase, Stage) {
    this.isFinalHandoff = Stage == "HANDOFF" ? true : false;
    this.currentUseCase = useCase;
    this.currentUseCase.submitModalTitle = Stage == "HANDOFF" ? "Final Handoff " + useCase.UseCaseName : "GO/ No GO " + useCase.UseCaseName;
    this.currentUseCase.comments = "";
    this.currentUseCase.Stage = useCase.Stage;
    this.currentUseCase.masterRecordId = useCase.MasterRecordId;
    this.isShowSubmitPopup = true;
  }

  closeModal() {
    this.currentUseCase = null;
    this.isShowSubmitPopup = false;
  }

  openEstimateModal(useCase) {
    this.currentUseCase = useCase;

    this.currentUseCase.invalidEffortEstimate = false;
    this.currentUseCase.invalidEffortEstimateMsg = "";
    this.currentUseCase.invalidCostEstimate = false;
    this.currentUseCase.invalidCostEstimateMsg = "";
    this.currentUseCase.invalidTimeline = false;
    this.currentUseCase.invalidTimelineMsg = "";

    this.currentUseCase.estimateModalTitle = "Technical Teams Estimates for " + useCase.UseCaseName;
    this.currentUseCase.masterRecordId = useCase.MasterRecordId;
    this.currentUseCase.technicalEstimateLookupId = (useCase.TechnicalEstimatesLookupId && useCase.TechnicalEstimatesLookupId.toString().length > 0) ?
      Number(useCase.TechnicalEstimatesLookupId) : null;
    this.currentUseCase.effortEstimates = useCase.EffortEstimates;
    this.currentUseCase.costEstimates = useCase.CostEstimates;
    this.currentUseCase.approxTimeline = useCase.ApproximateTimeline;
    this.currentUseCase.Stage = useCase.Stage;
    this.currentUseCase.FormStatus = useCase.FormStatus;

    // Values table
    this.currentUseCase.TotalGTERValueByAlwin = null;
    this.currentUseCase.FTECostSavings = null;
    this.currentUseCase.QualityImprovementCostSavings = null;
    this.currentUseCase.RiskMitigationCostSavings = null;
    this.currentUseCase.TotalBusinessValue = null;
    this.currentUseCase.EstimateValues = null;

    let isForm7ValueValid = false;

    if (useCase.Form7DemandListLookupId && !isNaN(Number(useCase.Form7DemandListLookupId))) {
      this._form7Svc.getSavedRecord(Number(useCase.Form7DemandListLookupId)).subscribe((form7Data: Form7Model) => {
        if (form7Data) {
          if (form7Data.TotalGTERValueByAlwin && form7Data.TotalGTERValueByAlwin.length > 0) {
            let totalGTERByAlwinJSON = JSON.parse(form7Data.TotalGTERValueByAlwin) as Form7Columns;
            if (totalGTERByAlwinJSON.TotalFY21 && totalGTERByAlwinJSON.TotalFY21.toString().length > 0
              && totalGTERByAlwinJSON.TotalFY22 && totalGTERByAlwinJSON.TotalFY22.toString().length > 0
              && totalGTERByAlwinJSON.TotalFY23 && totalGTERByAlwinJSON.TotalFY23.toString().length > 0
              && totalGTERByAlwinJSON.Total3YearValue && totalGTERByAlwinJSON.Total3YearValue.toString().length > 0) {
              this.currentUseCase.TotalGTERValueByAlwin = totalGTERByAlwinJSON;
            }
          }
          if (form7Data.FTECostSavings && form7Data.FTECostSavings.length > 0) {
            let fteCostSavingsJSON = JSON.parse(form7Data.FTECostSavings) as Form7Columns;
            if (fteCostSavingsJSON.TotalFY21 && fteCostSavingsJSON.TotalFY21.toString().length > 0
              && fteCostSavingsJSON.TotalFY22 && fteCostSavingsJSON.TotalFY22.toString().length > 0
              && fteCostSavingsJSON.TotalFY23 && fteCostSavingsJSON.TotalFY23.toString().length > 0
              && fteCostSavingsJSON.Total3YearValue && fteCostSavingsJSON.Total3YearValue.toString().length > 0) {
              this.currentUseCase.FTECostSavings = fteCostSavingsJSON;
            }
          }
          if (form7Data.QualityImprovementCostSavings && form7Data.QualityImprovementCostSavings.length > 0) {
            let qualityImprovementCostSavings = JSON.parse(form7Data.QualityImprovementCostSavings) as Form7Columns;
            if (qualityImprovementCostSavings.TotalFY21 && qualityImprovementCostSavings.TotalFY21.toString().length > 0
              && qualityImprovementCostSavings.TotalFY22 && qualityImprovementCostSavings.TotalFY22.toString().length > 0
              && qualityImprovementCostSavings.TotalFY23 && qualityImprovementCostSavings.TotalFY23.toString().length > 0
              && qualityImprovementCostSavings.Total3YearValue && qualityImprovementCostSavings.Total3YearValue.toString().length > 0) {
              this.currentUseCase.QualityImprovementCostSavings = qualityImprovementCostSavings;
            }
          }
          if (form7Data.RiskMitigationCostSavings && form7Data.RiskMitigationCostSavings.length > 0) {
            let riskMitigationCostSavings = JSON.parse(form7Data.RiskMitigationCostSavings) as Form7Columns;
            if (riskMitigationCostSavings.TotalFY21 && riskMitigationCostSavings.TotalFY21.toString().length > 0
              && riskMitigationCostSavings.TotalFY22 && riskMitigationCostSavings.TotalFY22.toString().length > 0
              && riskMitigationCostSavings.TotalFY23 && riskMitigationCostSavings.TotalFY23.toString().length > 0
              && riskMitigationCostSavings.Total3YearValue && riskMitigationCostSavings.Total3YearValue.toString().length > 0) {
              this.currentUseCase.RiskMitigationCostSavings = riskMitigationCostSavings;
            }
          }
          if (this.currentUseCase.TotalGTERValueByAlwin && this.currentUseCase.FTECostSavings
            && this.currentUseCase.QualityImprovementCostSavings && this.currentUseCase.RiskMitigationCostSavings) {
            this.currentUseCase.TotalBusinessValue = new Form7Columns();
            this.currentUseCase.TotalBusinessValue.TotalFY21 = Number(this.currentUseCase.TotalGTERValueByAlwin.TotalFY21) +
              Number(this.currentUseCase.FTECostSavings.TotalFY21) + Number(this.currentUseCase.QualityImprovementCostSavings.TotalFY21) +
              Number(this.currentUseCase.RiskMitigationCostSavings.TotalFY21);

            this.currentUseCase.TotalBusinessValue.TotalFY22 = Number(this.currentUseCase.TotalGTERValueByAlwin.TotalFY22) +
              Number(this.currentUseCase.FTECostSavings.TotalFY22) + Number(this.currentUseCase.QualityImprovementCostSavings.TotalFY22) +
              Number(this.currentUseCase.RiskMitigationCostSavings.TotalFY22);

            this.currentUseCase.TotalBusinessValue.TotalFY23 = Number(this.currentUseCase.TotalGTERValueByAlwin.TotalFY23) +
              Number(this.currentUseCase.FTECostSavings.TotalFY23) + Number(this.currentUseCase.QualityImprovementCostSavings.TotalFY23) +
              Number(this.currentUseCase.RiskMitigationCostSavings.TotalFY23);

            this.currentUseCase.TotalBusinessValue.Total3YearValue = Number(this.currentUseCase.TotalGTERValueByAlwin.Total3YearValue) +
              Number(this.currentUseCase.FTECostSavings.Total3YearValue) + Number(this.currentUseCase.QualityImprovementCostSavings.Total3YearValue) +
              Number(this.currentUseCase.RiskMitigationCostSavings.Total3YearValue);
            isForm7ValueValid = true;
          }
        }

        if (isForm7ValueValid) {
          this.currentUseCase.EstimateValues = {};
          if (this.currentUseCase.technicalEstimateLookupId && !isNaN(this.currentUseCase.technicalEstimateLookupId)) {
            // Fetch technical estimates data
            this._estimationSvc.getSavedRecord(Number(this.currentUseCase.technicalEstimateLookupId))
              .subscribe((estimateData: TechnicalEstimatesModel) => {
                this.currentUseCase.EstimateValues.ProductDevelopmentCost = (estimateData.ProductDevelopmentCost && estimateData.ProductDevelopmentCost.length > 0) ?
                  JSON.parse(estimateData.ProductDevelopmentCost) as EstimationColumns :
                  new EstimationColumns();

                // this.currentUseCase.EstimateValues.MiscDevelopmentCost = (estimateData.MiscDevelopmentCost && estimateData.MiscDevelopmentCost.length > 0) ?
                //   JSON.parse(estimateData.MiscDevelopmentCost) as EstimationColumns :
                //   new EstimationColumns();

                // this.currentUseCase.EstimateValues.IntegrationCost = (estimateData.IntegrationCost && estimateData.IntegrationCost.length > 0) ?
                //   JSON.parse(estimateData.IntegrationCost) as EstimationColumns :
                //   new EstimationColumns();

                // this.currentUseCase.EstimateValues.DataCost = (estimateData.DataCost && estimateData.DataCost.length > 0) ?
                //   JSON.parse(estimateData.DataCost) as EstimationColumns :
                //   new EstimationColumns();

                this.currentUseCase.EstimateValues.InfrastructureCostDevelopment = (estimateData.InfrastructureCostDevelopment && estimateData.InfrastructureCostDevelopment.length > 0) ?
                JSON.parse(estimateData.InfrastructureCostDevelopment) as EstimationColumns :
                new EstimationColumns();


                this.currentUseCase.EstimateValues.CostToIndustrialise = (estimateData.CostToIndustrialise && estimateData.CostToIndustrialise.length > 0) ?
                  JSON.parse(estimateData.CostToIndustrialise) as EstimationColumns :
                  new EstimationColumns();

                // this.currentUseCase.EstimateValues.ProductMaintainCost = (estimateData.ProductMaintainCost && estimateData.ProductMaintainCost.length > 0) ?
                //   JSON.parse(estimateData.ProductMaintainCost) as EstimationColumns :
                //   new EstimationColumns();

                // this.currentUseCase.EstimateValues.OperationalRunCost = (estimateData.OperationalRunCost && estimateData.OperationalRunCost.length > 0) ?
                //   JSON.parse(estimateData.OperationalRunCost) as EstimationColumns :
                //   new EstimationColumns();

                // this.currentUseCase.EstimateValues.OtherServiceDeliveryCost = (estimateData.OtherServiceDeliveryCost && estimateData.OtherServiceDeliveryCost.length > 0) ?
                // JSON.parse(estimateData.OtherServiceDeliveryCost) as EstimationColumns :
                // new EstimationColumns();
               
                  this.currentUseCase.EstimateValues.CTServiceModelOperationalCost = (estimateData.CTServiceModelOperationalCost && estimateData.CTServiceModelOperationalCost.length > 0) ?
                  JSON.parse(estimateData.CTServiceModelOperationalCost) as EstimationColumns :
                  new EstimationColumns();

                  this.currentUseCase.EstimateValues.OperationalInfrastructureCost = (estimateData.OperationalInfrastructureCost && estimateData.OperationalInfrastructureCost.length > 0) ?
                  JSON.parse(estimateData.OperationalInfrastructureCost) as EstimationColumns :
                  new EstimationColumns();


                this.calculateTotalTechCost();
              });
          }
          else {
            this.currentUseCase.EstimateValues.ProductDevelopmentCost = new EstimationColumns();
           // this.currentUseCase.EstimateValues.MiscDevelopmentCost = new EstimationColumns();
            //this.currentUseCase.EstimateValues.IntegrationCost = new EstimationColumns();
           // this.currentUseCase.EstimateValues.DataCost = new EstimationColumns();
            this.currentUseCase.EstimateValues.InfrastructureCostDevelopment = new EstimationColumns();
            this.currentUseCase.EstimateValues.CostToIndustrialise = new EstimationColumns();
           // this.currentUseCase.EstimateValues.ProductMaintainCost = new EstimationColumns();
           // this.currentUseCase.EstimateValues.OperationalRunCost = new EstimationColumns();
           // this.currentUseCase.EstimateValues.OtherServiceDeliveryCost = new EstimationColumns();
          
            this.currentUseCase.EstimateValues.CTServiceModelOperationalCost = new EstimationColumns();
            this.currentUseCase.EstimateValues.OperationalInfrastructureCost = new EstimationColumns();
            this.calculateTotalTechCost();
          }
        }
      });
    }

    this.isShowEstimatePopup = true;
  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }

  updateEstimateValues(evt, keyName, colName) {
    this.currentUseCase.EstimateValues[keyName][colName] = evt.target.value;
    this.calculateTotalTechCost();
    this.changeDetector.detectChanges();
  }

  calculateTotalTechCost() {
    if (this.currentUseCase && this.currentUseCase.EstimateValues) {
      let columns: string[] = ["FY21", "FY22", "FY23"];
      this.currentUseCase.EstimateValues.TotalTechCost = {};
      columns.forEach(col => {
        this.currentUseCase.EstimateValues.TotalTechCost[col] = 0;
        Object.keys(this.currentUseCase.EstimateValues).forEach(key => {
          if (key !== "TotalTechCost" && key !== "ROI") {
            if (this.currentUseCase.EstimateValues[key][col]
              && !isNaN(Number(this.currentUseCase.EstimateValues[key][col]))) {
              this.currentUseCase.EstimateValues.TotalTechCost[col] =
                this.currentUseCase.EstimateValues.TotalTechCost[col] + Number(this.currentUseCase.EstimateValues[key][col]);
            }
          }
        });
      });
      // Calculate 3 Years value
      Object.keys(this.currentUseCase.EstimateValues).forEach(key => {
        this.currentUseCase.EstimateValues[key]["Total3Year"] = 0;
        columns.forEach(col => {
          if (this.currentUseCase.EstimateValues[key][col]
            && !isNaN(Number(this.currentUseCase.EstimateValues[key][col]))) {
            this.currentUseCase.EstimateValues[key]["Total3Year"] =
              this.currentUseCase.EstimateValues[key]["Total3Year"] + Number(this.currentUseCase.EstimateValues[key][col]);
          }
        });
      });

      // Calculate ROI
      if (this.currentUseCase && this.currentUseCase.TotalBusinessValue) {
        this.currentUseCase.EstimateValues.ROI = {};
        let totalBusinessValue: Form7Columns = this.currentUseCase.TotalBusinessValue as Form7Columns;
        let totalTechCost: EstimationColumns = this.currentUseCase.EstimateValues.TotalTechCost as EstimationColumns;
        this.currentUseCase.EstimateValues.ROI["FY21"] = Number(totalBusinessValue.TotalFY21) - Number(totalTechCost.FY21);
        this.currentUseCase.EstimateValues.ROI["FY22"] = Number(totalBusinessValue.TotalFY22) - Number(totalTechCost.FY22);
        this.currentUseCase.EstimateValues.ROI["FY23"] = Number(totalBusinessValue.TotalFY23) - Number(totalTechCost.FY23);
        this.currentUseCase.EstimateValues.ROI["Total3Year"] = Number(totalBusinessValue.Total3YearValue) - Number(totalTechCost.Total3Year);
      }
    }
  }

  openGovernanceModal(useCase) {
    this.dashboardData.forEach(item => {
      item.isShowDashboardItemMenu = item.isShowDashboardItemMenu ? false : false;
    });
    this.currentUseCase = useCase;
    this.currentUseCase.governancePopupTitle = "Governance Info for " + useCase.UseCaseName;
    if (useCase.MasterRecordId) {
      this._masterListSvc.getVersionHistory(Number(useCase.MasterRecordId)).subscribe((result) => {
        this.currentUseCase.versionHistory = [];
        this.currentUseCase.fastTrackStatusHistory = [];
        // Calculate the status and stage changes
        if (result && result.length > 0) {
          result = result.sort((a, b) => (new Date(b["Modified"]) > new Date(a["Modified"])) ? 1 : ((new Date(a["Modified"]) > new Date(b["Modified"])) ? -1 : 0));
          for (let i = 0; i < result.length; i++) {
            if (i === 0) {
              this.currentUseCase.versionHistory.push({
                stage: result[i].Stage,
                status: result[i].FormStatus,
                modifiedBy: result[i]["Editor"]["LookupValue"],
                modified: new Date(result[i]["Modified"]).toLocaleString()
              });
              this.currentUseCase.fastTrackStatusHistory.push({
                fastTrackStatus: result[i].FastTrackStatus,
                modifiedBy: result[i]["Editor"]["LookupValue"],
                modified: new Date(result[i]["Modified"]).toLocaleString()
              });
            }
            else {
              if (result[i].FormStatus !== result[i - 1].FormStatus
                || result[i].Stage !== result[i - 1].Stage) {
                this.currentUseCase.versionHistory.push({
                  stage: result[i].Stage,
                  status: result[i].FormStatus,
                  modifiedBy: result[i]["Editor"]["LookupValue"],
                  modified: new Date(result[i]["Modified"]).toLocaleString()
                });
              }
              if (result[i].FastTrackStatus !== result[i - 1].FastTrackStatus) {
                this.currentUseCase.fastTrackStatusHistory.push({
                  fastTrackStatus: result[i].FastTrackStatus,
                  modifiedBy: result[i]["Editor"]["LookupValue"],
                  modified: new Date(result[i]["Modified"]).toLocaleString()
                });
              }
            }
          }
        }
        this.isShowGovernancePopup = true;
      });
    }
  }

  closeGovernanceModal() {
    this.currentUseCase = null;
    this.isShowGovernancePopup = false;
  }

  closeEstimateModal() {
    this.currentUseCase = null;
    this.isShowEstimatePopup = false;
  }

  validateFastTrackInput(): boolean {
    this.currentUseCase.invalidFastTrackStatus = false;
    this.currentUseCase.invalidFastTrackStatusMsg = "";

    if (this.currentUseCase.fastTrackStatusStr !== "Pass" &&
      this.currentUseCase.fastTrackStatusStr !== "Fail") {
      this.currentUseCase.invalidFastTrackStatus = true;
      this.currentUseCase.invalidFastTrackStatusMsg = "Invalid fast track status.";
    }
    return !this.currentUseCase.invalidFastTrackStatus;
  }

  saveFastTrackInput() {
    if (!this.validateFastTrackInput()) {
      return;
    }
    this.currentUseCase.invalidFastTrackStatus = false;
    this.currentUseCase.invalidFastTrackStatusMsg = "";
    let masterId = this.currentUseCase.masterRecordId;
    this._masterListSvc.getSavedRecord(Number(masterId)).subscribe((mdata: MasterListModel) => {
      mdata.FastTrackStatus = this.currentUseCase.fastTrackStatusStr;
      this._masterListSvc.updateData(mdata, Number(masterId)).subscribe(result => {
        this.closeFastTrackModal();
        this.dashboardData = [];
        this.populateDashboardData();
      });
    });
  }

  validateEstimates(): boolean {
    this.currentUseCase.invalidEffortEstimate = false;
    this.currentUseCase.invalidEffortEstimateMsg = "";
    this.currentUseCase.invalidCostEstimate = false;
    this.currentUseCase.invalidCostEstimateMsg = "";
    this.currentUseCase.invalidTimeline = false;
    this.currentUseCase.invalidTimelineMsg = "";

    if (!this.currentUseCase.approxTimeline || this.currentUseCase.approxTimeline.length === 0) {
      this.currentUseCase.invalidTimeline = true;
      this.currentUseCase.invalidTimelineMsg = "Please enter the timeline.";
    }
    if (!this.currentUseCase.costEstimates || this.currentUseCase.costEstimates.length === 0) {
      this.currentUseCase.invalidCostEstimate = true;
      this.currentUseCase.invalidCostEstimateMsg = "Please enter the cost estimates.";
    }
    if (!this.currentUseCase.effortEstimates || this.currentUseCase.effortEstimates.length === 0) {
      this.currentUseCase.invalidEffortEstimate = true;
      this.currentUseCase.invalidEffortEstimateMsg = "Please enter the effort estimates.";
    }

    if (this.currentUseCase.invalidEffortEstimate ||
      this.currentUseCase.invalidCostEstimate ||
      this.currentUseCase.invalidTimeline) {
      return false;
    }
    return true;
  }

  saveEstimates() {
    if (!this.validateEstimates()) {
      return;
    }
    this.currentUseCase.invalidEffortEstimate = false;
    this.currentUseCase.invalidEffortEstimateMsg = "";
    this.currentUseCase.invalidCostEstimate = false;
    this.currentUseCase.invalidCostEstimateMsg = "";
    this.currentUseCase.invalidTimeline = false;
    this.currentUseCase.invalidTimelineMsg = "";

    let masterId = this.currentUseCase.masterRecordId;
    this._masterListSvc.getSavedRecord(Number(masterId)).subscribe((mdata: MasterListModel) => {
      let techEstimation = new TechnicalEstimatesModel();
      techEstimation["Title"] = guid();
      techEstimation.ApproximateTimeline = this.currentUseCase.approxTimeline;
      techEstimation.CostEstimates = this.currentUseCase.costEstimates;
      techEstimation.EffortEstimates = this.currentUseCase.effortEstimates;
      if (this.currentUseCase.EstimateValues && this.currentUseCase.EstimateValues.ProductDevelopmentCost) {
        techEstimation.ProductDevelopmentCost = JSON.stringify(this.currentUseCase.EstimateValues.ProductDevelopmentCost);
      }
      if (this.currentUseCase.EstimateValues && this.currentUseCase.EstimateValues.InfrastructureCostDevelopment) {
        techEstimation.InfrastructureCostDevelopment = JSON.stringify(this.currentUseCase.EstimateValues.InfrastructureCostDevelopment);
      }
      // if (this.currentUseCase.EstimateValues && this.currentUseCase.EstimateValues.MiscDevelopmentCost) {
      //   techEstimation.MiscDevelopmentCost = JSON.stringify(this.currentUseCase.EstimateValues.MiscDevelopmentCost);
      // }
      // if (this.currentUseCase.EstimateValues && this.currentUseCase.EstimateValues.IntegrationCost) {
      //   techEstimation.IntegrationCost = JSON.stringify(this.currentUseCase.EstimateValues.IntegrationCost);
      // }
      // if (this.currentUseCase.EstimateValues && this.currentUseCase.EstimateValues.DataCost) {
      //   techEstimation.DataCost = JSON.stringify(this.currentUseCase.EstimateValues.DataCost);
      // }
      if (this.currentUseCase.EstimateValues && this.currentUseCase.EstimateValues.CostToIndustrialise) {
        techEstimation.CostToIndustrialise = JSON.stringify(this.currentUseCase.EstimateValues.CostToIndustrialise);
      }
      // if (this.currentUseCase.EstimateValues && this.currentUseCase.EstimateValues.ProductMaintainCost) {
      //   techEstimation.ProductMaintainCost = JSON.stringify(this.currentUseCase.EstimateValues.ProductMaintainCost);
      // }
      // if (this.currentUseCase.EstimateValues && this.currentUseCase.EstimateValues.OperationalRunCost) {
      //   techEstimation.OperationalRunCost = JSON.stringify(this.currentUseCase.EstimateValues.OperationalRunCost);
      // }
      // if (this.currentUseCase.EstimateValues && this.currentUseCase.EstimateValues.OtherServiceDeliveryCost) {
      //   techEstimation.OtherServiceDeliveryCost = JSON.stringify(this.currentUseCase.EstimateValues.OtherServiceDeliveryCost);
      // }
      if (this.currentUseCase.EstimateValues && this.currentUseCase.EstimateValues.CTServiceModelOperationalCost) {
        techEstimation.CTServiceModelOperationalCost = JSON.stringify(this.currentUseCase.EstimateValues.CTServiceModelOperationalCost);
      }
      if (this.currentUseCase.EstimateValues && this.currentUseCase.EstimateValues.OperationalInfrastructureCost) {
        techEstimation.OperationalInfrastructureCost = JSON.stringify(this.currentUseCase.EstimateValues.OperationalInfrastructureCost);
      }

      if (this.currentUseCase.EstimateValues && this.currentUseCase.EstimateValues.TotalTechCost) {
        techEstimation.TotalTechCost = JSON.stringify(this.currentUseCase.EstimateValues.TotalTechCost);
      }

      if (this.currentUseCase.technicalEstimateLookupId) {
        // Edit existing record
        this._estimationSvc.updateData(techEstimation,
          this.currentUseCase.technicalEstimateLookupId).subscribe(data => {
            mdata.TechnicalEstimatesLookupId = Number(this.currentUseCase.technicalEstimateLookupId);
            mdata.FormStatus = _FORM_STATUS.techTeamInput;
            // Update master list with id and status
            this._masterListSvc.updateData(mdata, Number(masterId)).subscribe(result => {
              this.closeEstimateModal();
              this.dashboardData = [];
              this.populateDashboardData();
            });
          });
      }
      else {
        // Insert new estimation record
        this._estimationSvc.saveData(techEstimation).subscribe(data => {
          mdata.TechnicalEstimatesLookupId = Number(data.data.Id);
          mdata.FormStatus = _FORM_STATUS.techTeamInput;
          // Update master list with id and status
          this._masterListSvc.updateData(mdata, Number(masterId)).subscribe(result => {
            this.closeEstimateModal();
            this.dashboardData = [];
            this.populateDashboardData();
          });
        });
      }
    });
  }
  redirect(redirectType, masterId, demandType, formStatus, stage) {
    localStorage.setItem('masterRecordId', masterId);
    // clearing all default field values
    this.clearAllFormData();
    let stageString = _FORM_STAGES.stage1;
    if (formStatus === _FORM_STATUS.approved && stage === _FORM_STAGES.stage1) {
      stageString = _FORM_STAGES.stage2;
      formStatus = _FORM_STATUS.inProgress;
    }
    else if (stage === _FORM_STAGES.stage2) {
      stageString = _FORM_STAGES.stage2;
    }
    this.router.navigate(['./NewDemand'], {
      state: { selectedVal: demandType, formStatus: formStatus, stage: stageString }
    });
  }
  clearAllFormData() {
    _DEFAULT_FIELDS.stage1.forEach(form => {
      form.fields.forEach(field => {
        field.value = "";
      });
    });
    _DEFAULT_FIELDS.stage2.forEach(form => {
      form.fields.forEach(field => {
        field.value = "";
      });
    });
    _DEFAULT_FORM.stage1.forEach(form => {
      form.childFormDetails.forEach(cForm => {
        cForm.childFormStatus = 'notstarted';
      });
    });
    _DEFAULT_FORM.stage2.forEach(form => {
      form.childFormDetails.forEach(cForm => {
        cForm.childFormStatus = 'notstarted';
      });
    });
  }

  toggleMenu(dataItem) {
    this.dashboardData.forEach(item => {
      item.isShowDashboardItemMenu = item.isShowDashboardItemMenu ? false : false;
    })
    if (dataItem.isShowDashboardItemMenu) {
      dataItem.isShowDashboardItemMenu = false;
    }
    else {
      dataItem.isShowDashboardItemMenu = true;
    }
  }

  approveRejectForm(action) {
    let masterId = this.currentUseCase.masterRecordId;
    this._masterListSvc.getSavedRecord(Number(masterId)).subscribe((data: MasterListModel) => {
      data.Stage = this.currentUseCase.Stage;
      if ((data.Stage === _FORM_STAGES.stage2 && data.FormStatus === _FORM_STATUS.approved) || (data.Stage === _FORM_STAGES.completed && data.FormStatus === _FORM_STATUS.parked)) {
        data.HandoffNotes = this.currentUseCase.comments;
        if (action === "HANDOFF") {
          data.Stage = _FORM_STAGES.completed;
          data.FormStatus = _FORM_STATUS.completed;
        }
        else {
          data.Stage = _FORM_STAGES.completed;
          data.FormStatus = _FORM_STATUS.parked;
        }
      }
      else {
        if (data.Stage === _FORM_STAGES.stage1) {
          data.Stage1Note = this.currentUseCase.comments;
        }
        else if (data.Stage === _FORM_STAGES.stage2) {
          data.Stage2Note = this.currentUseCase.comments;
        }
        if (action === "APPROVE") {
          data.FormStatus = _FORM_STATUS.approved;
        }
        else if (action === "REJECT") {
          data.FormStatus = _FORM_STATUS.rejected;
        }
        else {
          data.FormStatus = _FORM_STATUS.parked;
        }
      }
      this._masterListSvc.updateData(data, Number(masterId)).subscribe(result => {
        this.closeModal();
        this.dashboardData = [];
        this.populateDashboardData();
      });
    });
  }

  repopulateDashboardData(data: any[]) {
    this.dashboardData = [];
    if (data && data.length > 0) {
      data.forEach(item => {
        this.dashboardData.push({
          MasterRecordId: item.MasterRecordId,
          isShowDashboardItemMenu: false,
          UseCaseName: item.UseCaseName,
          Form2Status: item.Form2Status,
          Form3Status: item.Form3Status,
          Form4Status: item.Form4Status,
          Form5Status: item.Form5Status,
          Form6Status: item.Form6Status,
          Form7Status: item.Form7Status,
          StartDate: item.StartDate,
          Stage: item.Stage,
          StatusStage: `${item.Stage} ${item.FormStatus == null ? "Inprogress" : item.FormStatus}` == "Completed Completed" ? "Completed" : `${item.Stage} ${item.FormStatus == null ? "Inprogress" : item.FormStatus}`,
          FormStatus: item.FormStatus,
          DemandType: item.DemandType,
          Triage: (item.Stage === _FORM_STAGES.stage1 && item.FormStatus === _FORM_STATUS.inProgress) ? "Yes" : "No",
          LastEdited: item.LastEdited,
          TechnicalEstimatesLookupId: item.TechnicalEstimatesLookupId,
          EffortEstimates: item.EffortEstimates,
          CostEstimates: item.CostEstimates,
          ApproximateTimeline: item.ApproximateTimeline,
          FastTrackStatus: item.FastTrackStatus,
          IsFastTrackDisabled: item.IsFastTrackDisabled,
          Form7DemandListLookupId: item.Form7DemandListLookupId
        });
      });
      this.tableDashboardData = this.dashboardData;
      this.constructFilterData();
    }
  }

  populateDashboardData(filterType: string = null, filterValue: string = null, stage: string = null) {
    this.selectedTab = "Total";
    this._dashboardSvc.getDashboardData(filterType, filterValue, stage).subscribe((data: MasterListModel[]) => {
      if (data && data.length > 0) {
        data.forEach(item => {
          let useCaseName: string = "";
          if (item.DemandType === "New Geography for existing use case / product") {
            useCaseName = (item.Form4DemandListLookup && item.Form4DemandListLookup.Form4UseCaseName) ? item.Form4DemandListLookup.Form4UseCaseName : "";
          }
          else {
            useCaseName = (item.Form2DemandListLookup && item.Form2DemandListLookup.UseCaseName) ? item.Form2DemandListLookup.UseCaseName : "";
          }
          this.dashboardData.push({
            MasterRecordId: item["ID"],
            isShowDashboardItemMenu: false,
            UseCaseName: useCaseName,
            Form2Status: item.Form2DemandListLookup ? item.Form2DemandListLookup.CompletionStatus : "Not Started",
            Form3Status: item.Form3DemandListLookup ? item.Form3DemandListLookup.CompletionStatus : "Not Started",
            Form4Status: item.Form4DemandListLookup ? item.Form4DemandListLookup.CompletionStatus : "Not Started",
            Form5Status: item.Form5DemandListLookup ? item.Form5DemandListLookup.CompletionStatus : "Not Started",
            Form6Status: item.Form6DemandListLookup ? item.Form6DemandListLookup.CompletionStatus : "Not Started",
            Form7Status: item.Form7DemandListLookup ? item.Form7DemandListLookup.CompletionStatus != null ? item.Form7DemandListLookup.CompletionStatus : "Not Started" : "Not Started",
            StartDate: item["Created"] ? new Date(item["Created"]).toLocaleDateString() : "",
            Stage: item.Stage,
            StatusStage: `${item.Stage} ${item.FormStatus == null ? "Inprogress" : item.FormStatus}` == "Completed Completed" ? "Completed" : `${item.Stage} ${item.FormStatus == null ? "Inprogress" : item.FormStatus}`,
            FormStatus: item.FormStatus,
            DemandType: item.DemandType,
            Triage: (item.Stage === _FORM_STAGES.stage1 && item.FormStatus === _FORM_STATUS.inProgress) ? "Yes" : "No",
            LastEdited: this.calculateLastEdited(item),
            TechnicalEstimatesLookupId: item.TechnicalEstimatesLookupId,
            EffortEstimates: item.TechnicalEstimatesLookup ? item.TechnicalEstimatesLookup.EffortEstimates : null,
            CostEstimates: item.TechnicalEstimatesLookup ? item.TechnicalEstimatesLookup.CostEstimates : null,
            ApproximateTimeline: item.TechnicalEstimatesLookup ? item.TechnicalEstimatesLookup.ApproximateTimeline : null,
            FastTrackStatus: item.FastTrackStatus && item.FastTrackStatus.length > 0 ? item.FastTrackStatus : "NA",
            IsFastTrackDisabled: (item.Stage === _FORM_STAGES.stage1 && (!item.FormStatus || item.FormStatus.length === 0 || item.FormStatus === _FORM_STATUS.inProgress)) ? true : false,
            Form7DemandListLookupId: item.Form7DemandListLookupId
          });
        });

        // Changed for view logic of demand forms
        if (this.dashboardData && this.dashboardData.length > 0) {
          let changedForDTs = ["New use case / product", "Integration / globalisation of existing product"];
          this.dashboardData.forEach(item => {
            if (item.DemandType && item.DemandType.length > 0 && changedForDTs.indexOf(item.DemandType) > -1) {
              item.Form4Status = item.Form5Status;
              item.Form5Status = item.Form6Status;
            }
            else {
              item.Form2Status = item.Form4Status;
              item.Form3Status = "N/A";
              item.Form4Status = item.Form5Status;
              item.Form5Status = item.Form6Status;
            }
          });
        }
        this.tableDashboardData = this.dashboardData;
        this.constructFilterData();
        this.originalDashboardData = [...this.dashboardData];
        this.calculateCounts(this.dashboardData);
      }
    }, (err => {
      console.log(err);
    }));
  }

  calculateLastEdited(item: MasterListModel): string {
    if (!item) {
      return "";
    }
    let dateArray: Date[] = [];
    dateArray.push(item["Modified"]);
    if (item.Form2DemandListLookup && item.Form2DemandListLookup.Modified) {
      dateArray.push(new Date(item.Form2DemandListLookup.Modified));
    }
    if (item.Form3DemandListLookup && item.Form3DemandListLookup.Modified) {
      dateArray.push(new Date(item.Form3DemandListLookup.Modified));
    }
    if (item.Form4DemandListLookup && item.Form4DemandListLookup.Modified) {
      dateArray.push(new Date(item.Form4DemandListLookup.Modified));
    }
    if (item.Form5DemandListLookup && item.Form5DemandListLookup.Modified) {
      dateArray.push(new Date(item.Form5DemandListLookup.Modified));
    }
    if (item.Form6DemandListLookup && item.Form6DemandListLookup.Modified) {
      dateArray.push(new Date(item.Form6DemandListLookup.Modified));
    }

    var maxDate = dateArray.reduce(function (a, b) { return new Date(a) > new Date(b) ? new Date(a) : new Date(b); });;
    return new Date(maxDate).toLocaleDateString();
  }

  selectTab(tabName: string) {
    this.selectedTab = tabName;
    switch (tabName) {
      case "Total":
        this.repopulateDashboardData(this.originalDashboardData);
        break;
      case "NewUseCase":
        this.repopulateDashboardData(this.originalDashboardData.filter(d => d.DemandType === "New use case / product"));
        break;
      case "IntUseCase":
        this.repopulateDashboardData(this.originalDashboardData.filter(d => d.DemandType === "Integration / globalisation of existing product"));
        break;
      case "GeoUseCase":
        this.repopulateDashboardData(this.originalDashboardData.filter(d => d.DemandType === "New Geography for existing use case / product"));
        break;
      case "InProgress":
        this.repopulateDashboardData(this.originalDashboardData.filter(d => d.FormStatus === _FORM_STATUS.inProgress));
        break;
      case "Parked":
        this.repopulateDashboardData(this.originalDashboardData.filter(d => d.FormStatus === _FORM_STATUS.parked));
        break;
      case "S1Approved":
        this.repopulateDashboardData(this.originalDashboardData.filter(d => (d.FormStatus === _FORM_STATUS.approved && d.Stage === _FORM_STAGES.stage1)));
        break;
      case "S2Approved":
        this.repopulateDashboardData(this.originalDashboardData.filter(d => (d.FormStatus === _FORM_STATUS.approved && d.Stage === _FORM_STAGES.stage2)));
        break;
      case "Handoff":
        this.repopulateDashboardData(this.originalDashboardData.filter(d => d.FormStatus === _FORM_STATUS.completed));
        break;
    }
  }

  getHandoffStatus(data: any) {
    let handOffStatus: boolean = false;
    if ((data.FormStatus === _FORM_STATUS.approved && data.Stage === _FORM_STAGES.stage2) || (data.FormStatus === _FORM_STATUS.parked && data.Stage === _FORM_STAGES.completed))
      handOffStatus = true;
    else
      handOffStatus = false;
    return handOffStatus;
  }

  sortDashboardData(colName: string, order: string) {

    this.tableDashboardData.forEach(columns => { columns[colName] === null ? columns[colName] = '' : columns[colName] = columns[colName]; });
    if (order == 'ASC')
      this.tableDashboardData = _.orderBy(this.tableDashboardData, [user => user[colName].toLowerCase()], ['asc']);
    else
      this.tableDashboardData = _.orderBy(this.tableDashboardData, [user => user[colName].toLowerCase()], ['desc']);
  }

  onEnter(colId: any) {
    var id = 'input' + colId;
    let colName = _Dashboard_Column.find(x => x.columnId == colId)
    var inputElement = document.getElementById(id) as HTMLInputElement;
    let tempTableDashboardData: any[] = [];
    this.dashboardData.forEach(columns => { columns[colName.columnName] === null ? columns[colName.columnName] = '' : columns[colName.columnName] = columns[colName.columnName]; });
    if (inputElement.value.length > 0) {
      tempTableDashboardData = this.dashboardData.filter((val) => {
        return val[colName.columnName].toUpperCase().indexOf(inputElement.value.toUpperCase()) > -1;
      });
      this.tableDashboardData = [];
      this.tableDashboardData = tempTableDashboardData;
    }
    else {
      this.tableDashboardData = [];
      this.tableDashboardData = this.dashboardData;
    }
    inputElement.value = '';
  }

  constructFilterData() {
    let columnList: any[] = [];
    _Dashboard_Column.forEach(x => { columnList.push(x.columnName) });
    columnList.forEach(item => { this.dropdownList[item] = this.getUniqueItems(this.dashboardData, item) });
  }

  getUniqueItems(arrayList: any[], columnName: string) {
    var filterList = [];
    var colId: number = 0
    arrayList.map(item => item[columnName])
      .filter((value, index, self) => self.indexOf(value) === index).forEach((x) => { filterList.push({ id: colId + 1, value: x }); colId++ })
    return filterList;
  }

  onItemSelect(event: any, columnName: string, ind: any) {
    try {
      let columnProperty = _Dashboard_Column.find(x => x.columnName == columnName)
      let tempTableDashboardData: any[] = [];
      this.tableDashboardData = [];
      //this.clearOtherFilters(this[`selectedItems${columnProperty.columnId}`]);
      if (event.length > 0) {
        this[`selectedItems${columnProperty.columnId}`] = [...this[`selectedItems${columnProperty.columnId}`], ...event]
      }
      else {
        if (this[`selectedItems${columnProperty.columnId}`].length == 0) {
          let tempSelected: any[] = [event];
          this[`selectedItems${columnProperty.columnId}`] = [...this[`selectedItems${columnProperty.columnId}`], ...tempSelected];
        }
        else {
          this[`selectedItems${columnProperty.columnId}`].push(event);
        }
        // for (var i = 0; i < this[`selectedItems${columnProperty.columnId}`].length; i++) {
        //   this.dashboardData.forEach(columns => { columns[columnName] === null ? columns[columnName] = '' : columns[columnName] = columns[columnName]; });
        //   tempTableDashboardData = this.dashboardData.filter((val) => {
        //     return val[columnName].toUpperCase() == this[`selectedItems${columnProperty.columnId}`][i].value.toUpperCase();
        //   });
        //   this.tableDashboardData = [...this.tableDashboardData, ...tempTableDashboardData];
        // }
      }
      this.constructTableFilteredData();
    }
    catch {
      this.tableDashboardData = [];
      this.tableDashboardData = this.dashboardData;
    }

  }

  constructTableFilteredData() {
    try {
      //let filtersCount = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12,13];
      let emptyFilters: number = 0;
      let tempTableDashboardData: any;
      let masterData: any = this.dashboardData;
      let tempAssignedData: any;
      for (var count = 0; count < _Dashboard_Column.length; count++) {
        let columnProperty = _Dashboard_Column.find(x => x.columnId == count)
        if (this[`selectedItems${count}`].length > 0) {
          tempAssignedData = []
          for (var i = 0; i < this[`selectedItems${count}`].length; i++) {
            tempTableDashboardData = [];
            masterData.forEach(columns => { columns[columnProperty.columnName] === null ? columns[columnProperty.columnName] = '' : columns[columnProperty.columnName] = columns[columnProperty.columnName]; });
            tempTableDashboardData = masterData.filter((val) => {
              return val[columnProperty.columnName].toUpperCase() == this[`selectedItems${columnProperty.columnId}`][i].value.toUpperCase();
            });
            tempAssignedData = [...tempAssignedData, ...tempTableDashboardData];
          }
          masterData = []
          masterData = [...masterData, ...tempAssignedData];
        }
        else {
          emptyFilters++
        }
      }
      if (emptyFilters == _Dashboard_Column.length) {
        this.tableDashboardData = [];
        this.tableDashboardData = this.dashboardData;
      }
      else {
        this.tableDashboardData = [];
        this.tableDashboardData = [...this.tableDashboardData, ...masterData];
      }
    }
    catch {
      this.tableDashboardData = [];
      this.tableDashboardData = this.dashboardData;
    }
  }

  // clearOtherFilters(currentFilter: any) {
  //   let filtersCount = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12];
  //   for (var count = 0; count < filtersCount.length; count++) {
  //     if (this[`selectedItems${filtersCount[count]}`] != currentFilter)
  //       this[`selectedItems${filtersCount[count]}`] = [];
  //   }
  // }
  onItemDeSelect(event: any, columnName: string, ind: any) {
    try {
      let columnProperty = _Dashboard_Column.find(x => x.columnName == columnName)
      let tempTableDashboardData: any[] = [];
      this.tableDashboardData = [];
      this[`selectedItems${columnProperty.columnId}`] = this[`selectedItems${columnProperty.columnId}`].filter(x => { return x.id != event.id });
      // if (this[`selectedItems${columnProperty.columnId}`].length > 0) {
      //   for (var i = 0; i < this[`selectedItems${columnProperty.columnId}`].length; i++) {
      //     this.dashboardData.forEach(columns => { columns[columnName] === null ? columns[columnName] = '' : columns[columnName] = columns[columnName]; });
      //     tempTableDashboardData = this.dashboardData.filter((val) => {
      //       return val[columnName].toUpperCase() == this[`selectedItems${columnProperty.columnId}`][i].value.toUpperCase();
      //     });
      //     this.tableDashboardData = [...this.tableDashboardData, ...tempTableDashboardData];
      //   }
      // }
      // else {
      //   this.tableDashboardData = [];
      //   this.tableDashboardData = this.dashboardData;
      // }
      this.constructTableFilteredData();
    }
    catch {
      this.tableDashboardData = [];
      this.tableDashboardData = this.dashboardData;
    }
  }

  downloadReport() {
    // this._http.get('files/defined_names_simple.xlsx', {
    //   responseType: 'arraybuffer',
    //   headers: { 'content-type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }
    //   }).subscribe((response)=>{
          
    //       debugger;
    //       var workBook = XLSX.read(response, {type: 'buffer', bookVBA: true});
    //       let data: any = [ [1, 2], [3, 4] ];
          
    //       XLSX.utils.sheet_add_aoa(workBook.Sheets["Sheet1"], [
    //         ["Col 1", "Col 2"],
    //         ["Data 3", 3],
    //         ["Data 4", 4],
    //         ["Data 5", 5]
    //       ], {origin:'A1'});
    //       workBook.Workbook.Names[0].Ref = "Sheet1!$A$2:$A$4";
    //       workBook.Workbook.Names.push({
    //         Name: 'TestRange',
    //         Ref: 'Sheet1!$A$2:$A$4'
    //       })
    //       XLSX.writeFile(workBook, 'out.xlsm');
    //       /* at this point, out.xlsb will have been downloaded */
    //   });
    this.populateDashboardDataForReport();
  }

  populateDashboardDataForReport(filterType: string = null, filterValue: string = null, stage: string = null) {
    combineLatest(this._dashboardSvc.getReportData(filterType, filterValue, stage),
      this._form2Svc.getAllListData(),
      this._form3Svc.getAllListData(), this._form4Svc.getAllListData(), this._form5Svc.getAllListData(),
      this._form6Svc.getAllListData(), this._form7Svc.getAllListData()).subscribe(result => {
        let masterListData = result[0];
        let form2Data = result[1];
        let form3Data = result[2];
        let form4Data = result[3];
        let form5Data = result[4];
        let form6ListData = result[5];
        let form7ListData = result[6];
        let excelDataCollection: ExcelDataModel[] = [];
        let dashboardReportData: any[] = [];
        if (masterListData && masterListData.length > 0) {
          dashboardReportData = this.formatMasterRecordExcelData(masterListData);
          // Download in excel
          let masterListExcelData: ExcelDataModel = this.populateMasterRecordExcelData(dashboardReportData);
          excelDataCollection.push(masterListExcelData);
        }
        if (form2Data && form2Data.length > 0) {
          let form2ListExcelData: ExcelDataModel = this.formatForm2RecordExcelData(form2Data, dashboardReportData);
          excelDataCollection.push(form2ListExcelData);
        }
        if (form3Data && form3Data.length > 0) {
          let form3ListExcelData: ExcelDataModel = this.formatForm3RecordExcelData(form3Data, dashboardReportData);
          excelDataCollection.push(form3ListExcelData);
        }
        if (form4Data && form4Data.length > 0) {
          let form4ListExcelData: ExcelDataModel = this.formatForm4RecordExcelData(form4Data, dashboardReportData);
          excelDataCollection.push(form4ListExcelData);

        }
        if (form5Data && form5Data.length > 0) {
          let form5ListExcelData: ExcelDataModel[] = this.formatForm5RecordExcelData(form5Data, dashboardReportData);
          form5ListExcelData.forEach(item=>{
            excelDataCollection.push(item);
          });
        }
        if (form6ListData && form6ListData.length > 0) {
          let form6ListExcelData: ExcelDataModel[] = this.formatForm6ExcelData(form6ListData, dashboardReportData);
          form6ListExcelData.forEach(item=>{
            excelDataCollection.push(item);
          });
        }
        if (form7ListData && form7ListData.length > 0) {
          let form7ReportData: any[] = this.formatForm7ExcelData(form7ListData, dashboardReportData);
          // Download in excel
          let form7ListExcelData: ExcelDataModel = this.populateForm7ExcelData(form7ReportData);
          excelDataCollection.push(form7ListExcelData);
        }
        if (excelDataCollection.length > 0) {
          ExcelUtil.writeToExcelFile(excelDataCollection, this._http);
        }
      });
  }

  formatMasterRecordExcelData(masterListData) {
    let dashboardReportData: any[] = [];
    if (masterListData && masterListData.length > 0) {
      masterListData.forEach(item => {
        let useCaseName: string = "";
        if (item.DemandType === "New Geography for existing use case / product") {
          useCaseName = (item.Form4DemandListLookup && item.Form4DemandListLookup.Form4UseCaseName) ? item.Form4DemandListLookup.Form4UseCaseName : "";
        }
        else {
          useCaseName = (item.Form2DemandListLookup && item.Form2DemandListLookup.UseCaseName) ? item.Form2DemandListLookup.UseCaseName : "";
        }
        dashboardReportData.push({
          MasterRecordId: item["ID"],
          isShowDashboardItemMenu: false,
          UseCaseName: useCaseName,
          Form2Status: item.Form2DemandListLookup ? item.Form2DemandListLookup.CompletionStatus : "Not Started",
          Form3Status: item.Form3DemandListLookup ? item.Form3DemandListLookup.CompletionStatus : "Not Started",
          Form4Status: item.Form4DemandListLookup ? item.Form4DemandListLookup.CompletionStatus : "Not Started",
          Form5Status: item.Form5DemandListLookup ? item.Form5DemandListLookup.CompletionStatus : "Not Started",
          Form6Status: item.Form6DemandListLookup ? item.Form6DemandListLookup.CompletionStatus : "Not Started",
          Form7Status: item.Form7DemandListLookup ? item.Form7DemandListLookup.CompletionStatus : "Not Started",
          StartDate: item["Created"] ? new Date(item["Created"]).toLocaleDateString() : "",
          Stage: item.Stage,
          StatusStage: `${item.Stage} ${item.FormStatus == null ? "Inprogress" : item.FormStatus}` == "Completed Completed" ? "Completed" : `${item.Stage} ${item.FormStatus == null ? "Inprogress" : item.FormStatus}`,
          FormStatus: item.FormStatus,
          DemandType: item.DemandType,
          Triage: (item.Stage === _FORM_STAGES.stage1 && item.FormStatus === _FORM_STATUS.inProgress) ? "Yes" : "No",
          LastEdited: this.calculateLastEdited(item),
          TechnicalEstimatesLookupId: item.TechnicalEstimatesLookupId,
          EffortEstimates: item.TechnicalEstimatesLookup ? item.TechnicalEstimatesLookup.EffortEstimates : null,
          CostEstimates: item.TechnicalEstimatesLookup ? item.TechnicalEstimatesLookup.CostEstimates : null,
          ApproximateTimeline: item.TechnicalEstimatesLookup ? item.TechnicalEstimatesLookup.ApproximateTimeline : null,
          FastTrackStatus: item.FastTrackStatus && item.FastTrackStatus.length > 0 ? item.FastTrackStatus : "NA",
          IsFastTrackDisabled: (item.Stage === _FORM_STAGES.stage1 && (!item.FormStatus || item.FormStatus.length === 0 || item.FormStatus === _FORM_STATUS.inProgress)) ? true : false,
          Form2DemandListLookupId: item.Form2DemandListLookupId,
          Form3DemandListLookupId: item.Form3DemandListLookupId,
          Form4DemandListLookupId: item.Form4DemandListLookupId,
          Form5DemandListLookupId: item.Form5DemandListLookupId,
          Form6DemandListLookupId: item.Form6DemandListLookupId,
          Form7DemandListLookupId: item.Form7DemandListLookupId
        });
      });

      // Changed for view logic of demand forms
      if (dashboardReportData && dashboardReportData.length > 0) {
        dashboardReportData.forEach(item => {
          if (item.DemandType && item.DemandType.length > 0 
              && (item.DemandType==="New use case / product"||item.DemandType==="Integration / globalisation of existing product")) {
            item.Form1StatusView = item.Form2Status;
            item.Form2StatusView = item.Form3Status;
            item.Form3StatusView = item.Form5Status;
            item.Form4StatusView = item.Form6Status;
            item.Form5StatusView = "N/A";
            item.Form6StatusView = "N/A";
            item.Form7StatusView = "N/A";
            item.Form8StatusView = item.Form7Status;
          }
          else {
            item.Form1StatusView = "N/A";
            item.Form2StatusView = "N/A";
            item.Form3StatusView = "N/A";
            item.Form4StatusView = "N/A";
            item.Form5StatusView = item.Form4Status;
            item.Form6StatusView = item.Form5Status;
            item.Form7StatusView = item.Form6Status;
            item.Form8StatusView = item.Form7Status;
          }
        });
      }
    }
    return dashboardReportData;
  }

  populateMasterRecordExcelData(masterReportData) {
    let excelData: ExcelDataModel = new ExcelDataModel();
    excelData.sheetData = masterReportData;
    excelData.sheetName = "Dashboard";
    excelData.columnInfo = [];
    excelData.columnInfo.push({
      columnFieldName: "UseCaseName",
      columnHeader: "Use Cases"
    });
    excelData.columnInfo.push({
      columnFieldName: "DemandType",
      columnHeader: "Demand Type"
    });
    excelData.columnInfo.push({
      columnFieldName: "Form1StatusView",
      columnHeader: "Form1: Use case description"
    });
    excelData.columnInfo.push({
      columnFieldName: "Form2StatusView",
      columnHeader: "Form 2: Ownership"
    });
    excelData.columnInfo.push({
      columnFieldName: "Form3StatusView",
      columnHeader: "Form 3: Value Model"
    });
    excelData.columnInfo.push({
      columnFieldName: "Form4StatusView",
      columnHeader: "Form 4: Data"
    });
    excelData.columnInfo.push({
      columnFieldName: "Form5StatusView",
      columnHeader: "Form 5: Use case description"
    });
    excelData.columnInfo.push({
      columnFieldName: "Form6StatusView",
      columnHeader: "Form 6: Value Model"
    });
    excelData.columnInfo.push({
      columnFieldName: "Form7StatusView",
      columnHeader: "Form 7: Data"
    });
    excelData.columnInfo.push({
      columnFieldName: "Form8StatusView",
      columnHeader: "Form 8: Detailed Value Pipeline"
    });
    excelData.columnInfo.push({
      columnFieldName: "StatusStage",
      columnHeader: "Status"
    });
    excelData.columnInfo.push({
      columnFieldName: "StartDate",
      columnHeader: "Start Date"
    });
    excelData.columnInfo.push({
      columnFieldName: "LastEdited",
      columnHeader: "Last Edited Date"
    });
    return excelData;
  }

  formatForm6ExcelData(form6ListData, dashboardReportData): ExcelDataModel[] {

    let excelDataModelColl: ExcelDataModel[] = [];

    let form6ReportDataForm4Sheet: any[] = [];
    let form6ReportDataForm7Sheet: any[] = [];

    let excelDataForm4: ExcelDataModel = new ExcelDataModel();
    excelDataForm4.sheetName = "Form4";
    excelDataForm4.columnInfo = [];
    excelDataForm4.sheetData = [];

    let excelDataForm7: ExcelDataModel = new ExcelDataModel();
    excelDataForm7.sheetName = "Form7";
    excelDataForm7.columnInfo = [];
    excelDataForm7.sheetData = [];

    let demandType: string = "";

    if (form6ListData && form6ListData.length > 0) {
      form6ListData.forEach(item => {
        let useCaseName: string = "";
        if(dashboardReportData && dashboardReportData.length>0){
          let masterRecord = dashboardReportData.filter(d=>d.Form6DemandListLookupId && item["ID"] && d.Form6DemandListLookupId.toString()===item["ID"].toString());
          if(masterRecord && masterRecord.length>0){
            useCaseName = masterRecord[0]["UseCaseName"];
            demandType = masterRecord[0]["DemandType"];
          }
        }
        if(demandType==="New Geography for existing use case / product"){
          form6ReportDataForm7Sheet.push({
            // ID: item["ID"],
            UseCaseName: useCaseName,
            OverViewInputDataRequirements: item.OverViewInputDataRequirements ? item.OverViewInputDataRequirements : "",
            DataTranscationVolumes: item.DataTranscationVolumes ? item.DataTranscationVolumes : "",
            DataAccuracyRequiredProduct: item.DataAccuracyRequiredProduct ? item.DataAccuracyRequiredProduct : "",
            ClientDataSubmitted: item.ClientDataSubmitted ? item.ClientDataSubmitted : "",
            DataBelongsToClient: item.DataBelongsToClient ? item.DataBelongsToClient : "",
            AdditionalInfo: item.AdditionalInfo ? item.AdditionalInfo : "",
            FileDetailsJson: item.FileDetailsJson ? item.FileDetailsJson : "",
            CompletionStatus: item.CompletionStatus ? item.CompletionStatus : "",
          });
        }
        else{
          form6ReportDataForm4Sheet.push({
            // ID: item["ID"],
            UseCaseName: useCaseName,
            OverViewInputDataRequirements: item.OverViewInputDataRequirements ? item.OverViewInputDataRequirements : "",
            DataTranscationVolumes: item.DataTranscationVolumes ? item.DataTranscationVolumes : "",
            DataAccuracyRequiredProduct: item.DataAccuracyRequiredProduct ? item.DataAccuracyRequiredProduct : "",
            ClientDataSubmitted: item.ClientDataSubmitted ? item.ClientDataSubmitted : "",
            DataBelongsToClient: item.DataBelongsToClient ? item.DataBelongsToClient : "",
            AdditionalInfo: item.AdditionalInfo ? item.AdditionalInfo : "",
            FileDetailsJson: item.FileDetailsJson ? item.FileDetailsJson : "",
            CompletionStatus: item.CompletionStatus ? item.CompletionStatus : "",
          });
        }
      });

      if (form6ReportDataForm4Sheet.length > 0) {
        excelDataForm4.sheetData = form6ReportDataForm4Sheet;
        excelDataForm4 = this.populateForm6ExcelData(excelDataForm4);
        excelDataModelColl.push(excelDataForm4);
      }
      if(form6ReportDataForm7Sheet.length>0){
        excelDataForm7.sheetData = form6ReportDataForm7Sheet;
        excelDataForm7 = this.populateForm6ExcelData(excelDataForm7);
        excelDataModelColl.push(excelDataForm7);
      }
    }
    return excelDataModelColl;
  }

  populateForm6ExcelData(form6ExcelData: ExcelDataModel) : ExcelDataModel {
    form6ExcelData.columnInfo = [];
    form6ExcelData.columnInfo.push({
      columnFieldName: "UseCaseName",
      columnHeader: "Use Case"
    });
    form6ExcelData.columnInfo.push({
      columnFieldName: "OverViewInputDataRequirements",
      columnHeader: "OverView InputData Requirements"
    });
    form6ExcelData.columnInfo.push({
      columnFieldName: "DataTranscationVolumes",
      columnHeader: "Data Transcation Volumes"
    });
    form6ExcelData.columnInfo.push({
      columnFieldName: "DataAccuracyRequiredProduct",
      columnHeader: "Data Accuracy Required Product"
    });
    form6ExcelData.columnInfo.push({
      columnFieldName: "ClientDataSubmitted",
      columnHeader: "Client Data Submitted"
    });
    form6ExcelData.columnInfo.push({
      columnFieldName: "DataBelongsToClient",
      columnHeader: "Data Belongs To Client"
    });
    form6ExcelData.columnInfo.push({
      columnFieldName: "AdditionalInfo",
      columnHeader: "Additional Info"
    });
    form6ExcelData.columnInfo.push({
      columnFieldName: "FileDetailsJson",
      columnHeader: "File Details Json"
    });
    form6ExcelData.columnInfo.push({
      columnFieldName: "CompletionStatus",
      columnHeader: "Completion Status"
    });
    return form6ExcelData;
  }

  formatForm7ExcelData(form7ListData, dashboardReportData:any[]) {
    let form7ReportData: any[] = [];
    if (form7ListData && form7ListData.length > 0) {
      form7ListData.forEach(item => {
        let useCaseName: string = "";
        if(dashboardReportData && dashboardReportData.length>0){
          let masterRecord = dashboardReportData.filter(d=>d.Form7DemandListLookupId && item["ID"] && d.Form7DemandListLookupId.toString()===item["ID"].toString());
          if(masterRecord && masterRecord.length>0){
            useCaseName = masterRecord[0]["UseCaseName"];
          }
        }
        form7ReportData.push({
          // ID: item["ID"],
          UseCaseName: useCaseName,
          NumberOfExistingClients: item.NumberOfExistingClients ? item.NumberOfExistingClients : "",
          NumberOfExistingClientsInfused: item.NumberOfExistingClientsInfused ? item.NumberOfExistingClientsInfused : "",
          PenetrationOnExistingClients: item.PenetrationOnExistingClients ? item.PenetrationOnExistingClients : "",
          TargetNumberOfExistingClients: item.TargetNumberOfExistingClients ? item.TargetNumberOfExistingClients : "",
          TargetPenetrationOfExistingClien: item.TargetPenetrationOfExistingClien ? item.TargetPenetrationOfExistingClien : "",
          TargetGTERperEngagementOfNewClie: item.TargetGTERperEngagementOfNewClie ? item.TargetGTERperEngagementOfNewClie : "",
          TargetGTERperEngagement: item.TargetGTERperEngagement ? item.TargetGTERperEngagement : "",
          TargetGTERValueOfExistingClients: item.TargetGTERValueOfExistingClients ? item.TargetGTERValueOfExistingClients : "",
          NewClientsTargetGrowthRate: item.NewClientsTargetGrowthRate ? item.NewClientsTargetGrowthRate : "",
          TargetNumberOfNewClients: item.TargetNumberOfNewClients ? item.TargetNumberOfNewClients : "",
          TargetNumberOfNewClientsInfused: item.TargetNumberOfNewClientsInfused ? item.TargetNumberOfNewClientsInfused : "",
          TargetPenetrationNewClients: item.TargetPenetrationNewClients ? item.TargetPenetrationNewClients : "",
          GTERTargetValueOfNewClients: item.GTERTargetValueOfNewClients ? item.GTERTargetValueOfNewClients : "",
          TargetTotalNumberClientsInfused: item.TargetTotalNumberClientsInfused ? item.TargetTotalNumberClientsInfused : "",
          TargetTotalValueClientsInfused: item.TargetTotalValueClientsInfused ? item.TargetTotalValueClientsInfused : "",
          CompletionStatus: item.CompletionStatus ? item.CompletionStatus : "",
          TotalGTERValueByAlwin: item.TotalGTERValueByAlwin ? item.TotalGTERValueByAlwin : "",
          FTECostSavings: item.FTECostSavings ? item.FTECostSavings : "",
          QualityImprovementCostSavings: item.QualityImprovementCostSavings ? item.QualityImprovementCostSavings : "",
          RiskMitigationCostSavings: item.RiskMitigationCostSavings ? item.RiskMitigationCostSavings : "",
        });
      });
    }
    return form7ReportData;
  }

  populateForm7ExcelData(form7ReportData) {
    let form7ExcelData: ExcelDataModel = new ExcelDataModel();
    let form7ReportObj: any = {};
    let form7ReporExcelData: any = [];
    form7ExcelData.sheetData = form7ReporExcelData;
    form7ExcelData.sheetName = "Form8";
    form7ExcelData.columnInfo = [];
    form7ReportData.forEach(form7Item => {
      Object.keys(form7Item).forEach(key => {
        if (key != "CompletionStatus") {
          if(key==="UseCaseName"){
            let fieldValue = form7Item[key];
            form7ReportObj[key] = fieldValue;
            form7ExcelData.columnInfo.push({
              columnFieldName: "UseCaseName",
              columnHeader: "Use Case"
            });
          }
          else{
            let fieldValue = form7Item[key];
            let parsedJSON = fieldValue != "" ? JSON.parse(fieldValue) : "";
            Object.keys(parsedJSON).forEach(jKey => {
              form7ReportObj[key + jKey] = parsedJSON[jKey];
              if (form7ExcelData.columnInfo.filter(colInf => colInf.columnFieldName === key + jKey).length === 0) {
                form7ExcelData.columnInfo.push({
                  columnFieldName: key + jKey,
                  columnHeader: key + jKey
                });
              }
            });
          }
        }
      });
      form7ReporExcelData.push(form7ReportObj);
      form7ReportObj = {};
    });
    return form7ExcelData;
  }
  formatForm2RecordExcelData(form2Data: Form2Model[], dashboardReportData: any[]): ExcelDataModel {
    let form2ReportData: any[] = [];
    let excelData: ExcelDataModel = new ExcelDataModel();
    excelData.sheetName = "Form1";
    excelData.columnInfo = [];
    excelData.sheetData = [];

    if (form2Data && form2Data.length > 0) {
      let maxPJurisdictionLength = 0;
      form2Data.forEach(form2Item => {
        let form2ReportItem = { ...form2Item };
        // form2ReportItem["ID"] = form2Item["ID"];
        if(dashboardReportData && dashboardReportData.length>0){
          let masterRecord = dashboardReportData.filter(d=>d.Form2DemandListLookupId && form2Item["ID"] && d.Form2DemandListLookupId.toString()===form2Item["ID"].toString());
          if(masterRecord && masterRecord.length>0){
            form2ReportItem["UseCaseName"] = masterRecord[0]["UseCaseName"];
          }
        }
        if (form2Item.PriorityJurisdictions && form2Item.PriorityJurisdictions.length > 0) {
          let pJurisdictions: any[] = JSON.parse(form2Item.PriorityJurisdictions);
          if (pJurisdictions && pJurisdictions.length > 0) {
            if (pJurisdictions.length > maxPJurisdictionLength) {
              maxPJurisdictionLength = pJurisdictions.length;
            }
            for (let i = 0; i < pJurisdictions.length; i++) {
              form2ReportItem["PriorityJurisdiction" + i.toString()] = pJurisdictions[i].PriorityJurisdiction;
              form2ReportItem["LaunchDate" + i.toString()] = pJurisdictions[i].LaunchDate;
            }
          }
        }
        form2ReportData.push(form2ReportItem);
      });
      if (form2ReportData.length > 0) {
        excelData.sheetData = form2ReportData;
        excelData = this.populateForm2RecordExcelData(excelData, maxPJurisdictionLength);
      }
    }
    return excelData;
  }

  formatForm4RecordExcelData(form4Data: Form4Model[], dashboardReportData: any[]): ExcelDataModel {
    let form4ReportData: any[] = [];
    let excelData: ExcelDataModel = new ExcelDataModel();
    excelData.sheetName = "Form5";
    excelData.columnInfo = [];
    excelData.sheetData = [];
    if (form4Data && form4Data.length > 0) {
      let maxnewJurisdictionLength = 0;
      form4Data.forEach(form4Item => {

        let form4ReportItem = { ...form4Item };
        // form4ReportItem["ID"] = form4Item["ID"];
        if(dashboardReportData && dashboardReportData.length>0){
          let masterRecord = dashboardReportData.filter(d=>d.Form4DemandListLookupId && form4Item["ID"] && d.Form4DemandListLookupId.toString()===form4Item["ID"].toString());
          if(masterRecord && masterRecord.length>0){
            form4ReportItem["UseCaseName"] = masterRecord[0]["UseCaseName"];
          }
        }
        if (form4Item.NewJurisdictionRequired && form4Item.NewJurisdictionRequired.length > 0) {
          let newJurisdictions: any[] = JSON.parse(form4Item.NewJurisdictionRequired);
          if (newJurisdictions && newJurisdictions.length > 0) {
            if (newJurisdictions.length > maxnewJurisdictionLength) {
              maxnewJurisdictionLength = newJurisdictions.length;
            }
            for (let i = 0; i < newJurisdictions.length; i++) {
              form4ReportItem["NewJurisdiction" + i.toString()] = newJurisdictions[i].NewJurisdiction;
              form4ReportItem["LaunchDate" + i.toString()] = newJurisdictions[i].LaunchDate;
            }
          }
        }
        form4ReportData.push(form4ReportItem);
      });
      if (form4ReportData.length > 0) {
        excelData.sheetData = form4ReportData;
        excelData = this.populateForm4RecordExcelData(excelData, maxnewJurisdictionLength);
      }
    }
    return excelData;
  }
  populateForm4RecordExcelData(excelData: ExcelDataModel, maxnewJurisdictionLength: Number) {
    excelData.columnInfo = [];
    excelData.columnInfo.push({
      columnFieldName: "UseCaseName",
      columnHeader: "Use Case"
    });
    excelData.columnInfo.push({
      columnFieldName: "Technology",
      columnHeader: "Technology"
    });
    excelData.columnInfo.push({
      columnFieldName: "DescriptionUseCase",
      columnHeader: "Description UseCase"
    });
    excelData.columnInfo.push({
      columnFieldName: "OtherSystemIntegrationUseCase",
      columnHeader: "Other System Integration UseCase"
    });
    excelData.columnInfo.push({
      columnFieldName: "BarrierChallengesImpact",
      columnHeader: "Barrier Challenges Impact"
    });
    excelData.columnInfo.push({
      columnFieldName: "Form4ClientImmediateDemand",
      columnHeader: "Client Immediate Demand"
    });
    excelData.columnInfo.push({
      columnFieldName: "Form4ClientImmediateDemandDetail",
      columnHeader: "Client Immediate DemandDetail"
    });
    excelData.columnInfo.push({
      columnFieldName: "Form4ListClientTarget",
      columnHeader: "List Client Target"
    });
    for (let i = 0; i < maxnewJurisdictionLength; i++) {
      excelData.columnInfo.push({
        columnFieldName: "NewJurisdiction" + i.toString(),
        columnHeader: "New Jurisdiction " + i.toString()
      });
      excelData.columnInfo.push({
        columnFieldName: "LaunchDate" + i.toString(),
        columnHeader: "Launch Date " + i.toString()
      });
    }
    excelData.columnInfo.push({
      columnFieldName: "NewJurisdictionRequired",
      columnHeader: " NewJurisdiction Required"
    });
    excelData.columnInfo.push({
      columnFieldName: "Form4DeploymentConditionsBarrier",
      columnHeader: " Deployment Conditions Barrier"
    });
    excelData.columnInfo.push({
      columnFieldName: "Form4MarketOwnerJurisdictionSpec",
      columnHeader: " MarketOwner Jurisdiction Specification"
    });
    excelData.columnInfo.push({
      columnFieldName: "CompletionStatus",
      columnHeader: " Completion Status"
    });
    return excelData;
  }

  populateForm2RecordExcelData(excelData: ExcelDataModel, maxPJurisdictionLength: Number) {
    excelData.columnInfo = [];
    // excelData.columnInfo.push({
    //   columnFieldName: "ID",
    //   columnHeader: "ID"
    // });
    excelData.columnInfo.push({
      columnFieldName: "UseCaseName",
      columnHeader: "Use Case"
    });
    excelData.columnInfo.push({
      columnFieldName: "UseCaseExist",
      columnHeader: "Use Case Exist"
    });
    excelData.columnInfo.push({
      columnFieldName: "IsDeployedClients",
      columnHeader: "Is Deployed Clients"
    });
    excelData.columnInfo.push({
      columnFieldName: "ClientList",
      columnHeader: "Client List"
    });
    excelData.columnInfo.push({
      columnFieldName: "DescribeUseCase",
      columnHeader: "Description"
    });
    excelData.columnInfo.push({
      columnFieldName: "ResultUseCase",
      columnHeader: "Result Use Case"
    });
    excelData.columnInfo.push({
      columnFieldName: "DescribeCurrentProcessWorks",
      columnHeader: "Describe Current Process"
    });
    excelData.columnInfo.push({
      columnFieldName: "ReasonChangeCurrentProcess",
      columnHeader: "Reason For Change"
    });
    excelData.columnInfo.push({
      columnFieldName: "OtherRequirementUseCaseProduct",
      columnHeader: "Other Requirement Use Case Product"
    });
    excelData.columnInfo.push({
      columnFieldName: "BarriersImpactSuccessfulRollout",
      columnHeader: "Barriers Impact Successful Rollout"
    });
    excelData.columnInfo.push({
      columnFieldName: "ImmediateClientDemand",
      columnHeader: "Immediate Client Demand"
    });
    excelData.columnInfo.push({
      columnFieldName: "ImmediateClientDemandDetails",
      columnHeader: "Immediate Client Demand Details"
    });
    excelData.columnInfo.push({
      columnFieldName: "ClientListTarget",
      columnHeader: "Target Clients List"
    });
    excelData.columnInfo.push({
      columnFieldName: "ClientServiceDetails",
      columnHeader: "Client Service Details"
    });
    excelData.columnInfo.push({
      columnFieldName: "BusinessModel",
      columnHeader: "Business Model"
    });
    excelData.columnInfo.push({
      columnFieldName: "MarketPriority",
      columnHeader: "Market Priority"
    });
    excelData.columnInfo.push({
      columnFieldName: "MultiJurisdictional",
      columnHeader: "Multi Jurisdictional"
    });
    for (let i = 0; i < maxPJurisdictionLength; i++) {
      excelData.columnInfo.push({
        columnFieldName: "PriorityJurisdiction" + i.toString(),
        columnHeader: "Priority Jurisdiction " + i.toString()
      });
      excelData.columnInfo.push({
        columnFieldName: "LaunchDate" + i.toString(),
        columnHeader: "Launch Date " + i.toString()
      });
    }
    excelData.columnInfo.push({
      columnFieldName: "EndUserClientService_x002f_produ",
      columnHeader: "End User Client Service Product"
    });
    excelData.columnInfo.push({
      columnFieldName: "InfusionExistingCampaign",
      columnHeader: "Infusion Existing Campaign"
    });
    excelData.columnInfo.push({
      columnFieldName: "ExistingCampaignDetails",
      columnHeader: "Existing Campaign Details"
    });
    excelData.columnInfo.push({
      columnFieldName: "NewCampaignLaunchDate",
      columnHeader: "New Campaign Launch Date"
    });
    excelData.columnInfo.push({
      columnFieldName: "InfusionExistingNewClientService",
      columnHeader: "Infusion Existing New ClientService"
    });
    excelData.columnInfo.push({
      columnFieldName: "InfusionExistingNewClientService0",
      columnHeader: "Infusion Existing New ClientService"
    });
    excelData.columnInfo.push({
      columnFieldName: "DeploymentConditionsBarriers",
      columnHeader: "Deployment Conditions Barriers"
    });
    return excelData;
  }

  formatForm3RecordExcelData(form3Data: Form3Model[], dashboardReportData: any[]): ExcelDataModel {
    let form3ReportData: any[] = [];
    let excelData: ExcelDataModel = new ExcelDataModel();
    excelData.sheetName = "Form2";
    excelData.columnInfo = [];
    excelData.sheetData = [];
    if (form3Data && form3Data.length > 0) {
      form3Data.forEach(form3Item => {
        let form3ReportItem = { ...form3Item };
        // form3ReportItem["ID"] = form3Item["ID"];
        if(dashboardReportData && dashboardReportData.length>0){
          let masterRecord = dashboardReportData.filter(d=>d.Form3DemandListLookupId && form3Item["ID"] && d.Form3DemandListLookupId.toString()===form3Item["ID"].toString());
          if(masterRecord && masterRecord.length>0){
            form3ReportItem["UseCaseName"] = masterRecord[0]["UseCaseName"];
          }
        }
        if (form3Item.SSLsolutionOwnerName && form3Item.SSLsolutionOwnerName.length > 0) {
          let sslSolutionOwner = JSON.parse(form3Item.SSLsolutionOwnerName);
          if (sslSolutionOwner) {
            form3ReportItem["SSLOwnerEmail"] = sslSolutionOwner.Id;
            form3ReportItem["SSLOwnerName"] = sslSolutionOwner.Name;
          }
        }
        if (form3Item.SSLsolutionDeputyName && form3Item.SSLsolutionDeputyName.length > 0) {
          let sslSolutionDeputy = JSON.parse(form3Item.SSLsolutionDeputyName);
          if (sslSolutionDeputy) {
            form3ReportItem["SSLDeputyEmail"] = sslSolutionDeputy.Id;
            form3ReportItem["SSLDeputyName"] = sslSolutionDeputy.Name;
          }
        }
        if (form3Item.SSLSponsoringPartnerName && form3Item.SSLSponsoringPartnerName.length > 0) {
          let sslSponsoringPartner = JSON.parse(form3Item.SSLSponsoringPartnerName);
          if (sslSponsoringPartner) {
            form3ReportItem["SSLSponsorEmail"] = sslSponsoringPartner.Id;
            form3ReportItem["SSLSponsorName"] = sslSponsoringPartner.Name;
          }
        }
        form3ReportData.push(form3ReportItem);
      });
      if (form3ReportData.length > 0) {
        excelData.sheetData = form3ReportData;
        excelData = this.populateForm3RecordExcelData(excelData);
      }
    }
    return excelData;
  }

  populateForm3RecordExcelData(excelData: ExcelDataModel) {
    excelData.columnInfo = [];
    excelData.columnInfo.push({
      columnFieldName: "UseCaseName",
      columnHeader: "Use Case"
    });
    excelData.columnInfo.push({
      columnFieldName: "OwningSSL",
      columnHeader: "Owning SSL"
    });
    excelData.columnInfo.push({
      columnFieldName: "SSLCompetencyService",
      columnHeader: "SSL Competency Service"
    });
    excelData.columnInfo.push({
      columnFieldName: "SSLOwnerName",
      columnHeader: "SSL Owner Name"
    });
    excelData.columnInfo.push({
      columnFieldName: "SSLOwnerEmail",
      columnHeader: "SSL Owner Email"
    });
    excelData.columnInfo.push({
      columnFieldName: "SSLDeputyName",
      columnHeader: "SSL Deputy Name"
    });
    excelData.columnInfo.push({
      columnFieldName: "SSLDeputyEmail",
      columnHeader: "SSL Deputy Email"
    });
    excelData.columnInfo.push({
      columnFieldName: "SSLSponsorName",
      columnHeader: "SSL Sponsor Name"
    });
    excelData.columnInfo.push({
      columnFieldName: "SSLSponsorEmail",
      columnHeader: "SSL Sponsor Email"
    });
    excelData.columnInfo.push({
      columnFieldName: "MarketOwnerJurisdictionSpecifica",
      columnHeader: "Market Owner Jurisdiction Specification"
    });
    excelData.columnInfo.push({
      columnFieldName: "LocalFunding",
      columnHeader: "Local Funding"
    });
    excelData.columnInfo.push({
      columnFieldName: "LocalGlobalFundingApproved",
      columnHeader: "Funding Approved"
    });
    return excelData;
  }

  formatForm5RecordExcelData(form5Data: Form5Model[], dashboardReportData: any[]): ExcelDataModel[] {
    let excelDataModelColl: ExcelDataModel[] = [];

    let form5ReportDataForm3Sheet: any[] = [];
    let form5ReportDataForm6Sheet: any[] = [];

    let excelDataForm3: ExcelDataModel = new ExcelDataModel();
    excelDataForm3.sheetName = "Form3";
    excelDataForm3.columnInfo = [];
    excelDataForm3.sheetData = [];

    let excelDataForm6: ExcelDataModel = new ExcelDataModel();
    excelDataForm6.sheetName = "Form6";
    excelDataForm6.columnInfo = [];
    excelDataForm6.sheetData = [];

    if (form5Data && form5Data.length > 0) {
      form5Data.forEach(form5Item => {
        let form5ReportItem = { ...form5Item };
        let demandType: string = "";
        // form5ReportItem["ID"] = form5Item["ID"];
        if(dashboardReportData && dashboardReportData.length>0){
          let masterRecord = dashboardReportData.filter(d=>d.Form5DemandListLookupId && form5Item["ID"] && d.Form5DemandListLookupId.toString()===form5Item["ID"].toString());
          if(masterRecord && masterRecord.length>0){
            form5ReportItem["UseCaseName"] = masterRecord[0]["UseCaseName"];
            demandType = masterRecord[0]["DemandType"];
          }
        }
        Object.keys(form5Item).forEach(key => {
          if (key === "CalculatedData") {
            let fieldValue = form5Item[key];
            let parsedJSON = fieldValue != "" ? JSON.parse(fieldValue) : "";
            Object.keys(parsedJSON).forEach(jKey => {
              form5ReportItem[jKey] = parsedJSON[jKey];
            })
          }
        });
        if(demandType==="New Geography for existing use case / product"){
          form5ReportDataForm6Sheet.push(form5ReportItem);
        }
        else{
          form5ReportDataForm3Sheet.push(form5ReportItem);
        }

      });
      if (form5ReportDataForm3Sheet.length > 0) {
        excelDataForm3.sheetData = form5ReportDataForm3Sheet;
        excelDataForm3 = this.populateForm5RecordExcelData(excelDataForm3);
        excelDataModelColl.push(excelDataForm3);
      }
      if(form5ReportDataForm6Sheet.length>0){
        excelDataForm6.sheetData = form5ReportDataForm6Sheet;
        excelDataForm6 = this.populateForm5RecordExcelData(excelDataForm6);
        excelDataModelColl.push(excelDataForm6);
      }
    }
    return excelDataModelColl;
  }

  populateForm5RecordExcelData(excelData: ExcelDataModel) {
    excelData.columnInfo = [];

    excelData.columnInfo.push({
      columnFieldName: "UseCaseName",
      columnHeader: "Use Case"
    });
    excelData.columnInfo.push({
      columnFieldName: "BusinessType",
      columnHeader: "Business Type"
    });
    excelData.columnInfo.push({
      columnFieldName: "otherBusinessType",
      columnHeader: "other BusinessType"
    });
    excelData.columnInfo.push({
      columnFieldName: "EstimatedAnnualGTER",
      columnHeader: "Estimated AnnualGTER"
    });
    excelData.columnInfo.push({
      columnFieldName: "Estimated3YearGTER",
      columnHeader: "Estimated 3YearGTER"
    });
    excelData.columnInfo.push({
      columnFieldName: "Client",
      columnHeader: "Client"
    });
    excelData.columnInfo.push({
      columnFieldName: "Geographies",
      columnHeader: "Geographies"
    });
    excelData.columnInfo.push({
      columnFieldName: "EngagementPenetration",
      columnHeader: "Engagement Penetration"
    });
    excelData.columnInfo.push({
      columnFieldName: "USDperEngagement",
      columnHeader: "USDper Engagement"
    });
    excelData.columnInfo.push({
      columnFieldName: "RegulationResons",
      columnHeader: " Regulation Resons"
    });
    excelData.columnInfo.push({
      columnFieldName: "RegulationDetails",
      columnHeader: " Regulation Details"
    });
    excelData.columnInfo.push({
      columnFieldName: "ImprovingMarket",
      columnHeader: " Improving Market"
    });
    excelData.columnInfo.push({
      columnFieldName: "NewNovelOffered",
      columnHeader: " NewNovel Offered"
    });
    excelData.columnInfo.push({
      columnFieldName: "NewNovelOfferedDetails",
      columnHeader: " NewNovel Offered Details"
    });
    excelData.columnInfo.push({
      columnFieldName: "ImprovingMarketDetails",
      columnHeader: " ImprovingMarket Details"
    });
    excelData.columnInfo.push({
      columnFieldName: "CompletionStatus",
      columnHeader: " Completion Status"
    });

    excelData.columnInfo.push({
      columnFieldName: "Task",
      columnHeader: " Task"
    });
    excelData.columnInfo.push({
      columnFieldName: "Frequency",
      columnHeader: " Frequency"
    });
    excelData.columnInfo.push({
      columnFieldName: "FTEassignedPerTask",
      columnHeader: " FTEassignedPerTask"
    });
    excelData.columnInfo.push({
      columnFieldName: "ApproxFTEassignedHourly",
      columnHeader: " ApproxFTEassignedHourly"
    });
    excelData.columnInfo.push({
      columnFieldName: "HoursFTE",
      columnHeader: " HoursFTE"
    });
    excelData.columnInfo.push({
      columnFieldName: "TotalHoursPA",
      columnHeader: " TotalHoursPA"
    });
    excelData.columnInfo.push({
      columnFieldName: "TotalCostPAapprox",
      columnHeader: " TotalCostPAapprox"
    });
    excelData.columnInfo.push({
      columnFieldName: "TargetNumberHours",
      columnHeader: " TargetNumberHours"
    });
    excelData.columnInfo.push({
      columnFieldName: "ExpectedTotalGrowth",
      columnHeader: " ExpectedTotalGrowth"
    });
    excelData.columnInfo.push({
      columnFieldName: "TargetTotalCost",
      columnHeader: " TargetTotalCost"
    });
    excelData.columnInfo.push({
      columnFieldName: "CostSavingPA",
      columnHeader: " CostSavingPA"
    });
    excelData.columnInfo.push({
      columnFieldName: "Task1",
      columnHeader: " Task1"
    });
    excelData.columnInfo.push({
      columnFieldName: "Frequency1",
      columnHeader: " Frequency1"
    });
    excelData.columnInfo.push({
      columnFieldName: "FTEassignedPerTask1",
      columnHeader: " FTEassignedPerTask1"
    });
    excelData.columnInfo.push({
      columnFieldName: "ApproxFTEassignedHourly1",
      columnHeader: " ApproxFTEassignedHourly1"
    });
    excelData.columnInfo.push({
      columnFieldName: "HoursFTE1",
      columnHeader: " HoursFTE1"
    });
    excelData.columnInfo.push({
      columnFieldName: "TotalHoursPA1",
      columnHeader: " TotalHoursPA1"
    });
    excelData.columnInfo.push({
      columnFieldName: "TotalCostPAapprox1",
      columnHeader: " TotalCostPAapprox1"
    });
    excelData.columnInfo.push({
      columnFieldName: "TargetNumberHours1",
      columnHeader: " TargetNumberHours1"
    });
    excelData.columnInfo.push({
      columnFieldName: "ExpectedTotalGrowth1",
      columnHeader: " ExpectedTotalGrowth1"
    });
    excelData.columnInfo.push({
      columnFieldName: "TargetTotalCost1",
      columnHeader: " TargetTotalCost1"
    });
    excelData.columnInfo.push({
      columnFieldName: "CostSavingPA1",
      columnHeader: " CostSavingPA1"
    });
    excelData.columnInfo.push({
      columnFieldName: "TotalFTEassignedPerTask",
      columnHeader: " TotalFTEassignedPerTask"
    });
    excelData.columnInfo.push({
      columnFieldName: "TotalHoursFTE",
      columnHeader: " TotalHoursFTE"
    });
    excelData.columnInfo.push({
      columnFieldName: "TotalHoursPATotal",
      columnHeader: " TotalHoursPATotal"
    });
    excelData.columnInfo.push({
      columnFieldName: "TotalCostPAapproxTotal",
      columnHeader: " TotalCostPAapproxTotal"
    });
    excelData.columnInfo.push({
      columnFieldName: "TotalTargetNumberHours",
      columnHeader: " TotalTargetNumberHours"
    });
    excelData.columnInfo.push({
      columnFieldName: "TotalTargetTotalCost",
      columnHeader: " TotalTargetTotalCost"
    });

    excelData.columnInfo.push({
      columnFieldName: "TotalCostSavingPA",
      columnHeader: " TotalCostSavingPA"
    });

    return excelData;

  }

}
