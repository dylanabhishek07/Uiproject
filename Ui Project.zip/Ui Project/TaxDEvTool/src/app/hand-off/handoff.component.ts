import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { Subject } from 'rxjs';
import { AutocompleteInterface } from '../Common/ey-autocomplete-input/autocomplete.interface';
import { _FORM_STAGES, _FORM_STATUS } from '../Models/formstatus';
import { MasterListModel } from '../Models/masterListModel';
import { DashboardSPService } from '../Services/Implementations/dashboardService';
import { MasterListService } from '../Services/Implementations/masterListService';

@Component({
  selector: 'handOverS1',
  templateUrl: './handoff.component.html',
  styleUrls: ['./handoff.component.css'],
  encapsulation: ViewEncapsulation.None,
  providers: [DashboardSPService, MasterListService]
})
export class HandoffComponent implements OnInit {

  constructor(private _dashboardSvc: DashboardSPService, private _masterListSvc: MasterListService) { }

  handOffRecords: any[] = [];
  assignedToSubject: Subject<AutocompleteInterface[]> = new Subject();
  usersRecords: any[] = [];
  isShowSubmitPopup: boolean = false;
  currentUseCase: any = null;

  ngOnInit() {
    this.populateHandoffRecords();
    setTimeout(()=>{
      this.loadUsersList();
      this.assignedToSubject.next(this.usersRecords);
    },1000);
  }

  loadUsersList(){
    for(let i=0;i<20;i++){
      this.usersRecords.push({id:(i+1).toString(), description: "User "+(i+1).toString()});
    }
  }

  filterUser(uName){
    let filteredUser = this.usersRecords.filter(u=>u.description.indexOf(uName)>-1);
    this.assignedToSubject.next(filteredUser);
  }

  setValidUser(uc, user){
    uc["AssignedTo"] = user.description;
    this.loadUsersList();
    this.assignedToSubject.next(this.usersRecords);
  }

  approveRejectStage1Form(action){
    let masterId = this.currentUseCase.masterRecordId;
    this._masterListSvc.getSavedRecord(Number(masterId)).subscribe((data: MasterListModel)=>{
      data.Stage = _FORM_STAGES.stage1;
      data.Stage1Note = this.currentUseCase.comments;
      if(action==="APPROVE"){
        data.FormStatus = _FORM_STATUS.approved;
      }
      else{
        data.FormStatus = _FORM_STATUS.parked;
      }
      this._masterListSvc.updateData(data, Number(masterId)).subscribe(result=>{
        this.closeModal();
        this.handOffRecords = [];
        this.populateHandoffRecords();
      });
    });
  }

  populateHandoffRecords(){
    this._dashboardSvc.getStage1GoNoGoData().subscribe((data: MasterListModel[])=>{
      if(data && data.length>0){
        data.forEach(item=>{
          this.handOffRecords.push({
            MasterRecordId: item["ID"],
            UseCaseName: item.Form2DemandListLookup? item.Form2DemandListLookup.UseCaseName: "",
            UseCaseDescription: item.Form2DemandListLookup? item.Form2DemandListLookup.DescribeUseCase: "",
            IsExistingUseCase: item.Form2DemandListLookup? item.Form2DemandListLookup.UseCaseExist: "",
            AssignedTo: item.AssignedTo? item.AssignedTo.Title: "",
            Status: item.FormStatus,            
          });
        });
      }
    }, (err=>{
      console.log(err);
    }));
    // for(let i=0;i<10;i++){
    //   let handoffRecord: any = {};
    //   handoffRecord["UseCaseId"] = "UC"+(i+1).toString();
    //   handoffRecord["UseCaseName"] = "Use Case "+(i+1).toString();
    //   handoffRecord["UseCaseDescription"] = "Use Case Description "+(i+1).toString();
    //   handoffRecord["IsExistingUseCase"] = false;
    //   handoffRecord["Status"] = "Submitted";
    //   handoffRecord["AssignedTo"] = "";
    //   this.handOffRecords.push(handoffRecord); 
    // }
  }

  openModal(useCase){
    this.currentUseCase = useCase;
    this.currentUseCase.submitModalTitle = "Approve/ Reject "+useCase.UseCaseName;
    this.currentUseCase.comments = "";
    this.currentUseCase.masterRecordId = useCase.MasterRecordId;
    this.isShowSubmitPopup = true;
  }

  closeModal(){
    this.currentUseCase = null;
    this.isShowSubmitPopup = false;
  }

}
