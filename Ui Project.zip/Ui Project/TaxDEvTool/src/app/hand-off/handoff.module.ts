import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HandoffComponent } from './handoff.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AutocompleteInputModule } from '../Common/ey-autocomplete-input/ey-autocomplete-input.module';

@NgModule({
  declarations: [
    HandoffComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AutocompleteInputModule
  ],
  providers: []
})
export class HandoffModule { }
