import { Component, OnInit } from '@angular/core';
import { spPnpAPIService } from '../Services/Implementations/spPnPAPIService';
import { ActivatedRoute, Router } from '@angular/router';
import { environment } from '../../environments/environment';
import { NgxSpinnerModule, NgxSpinnerService } from "ngx-spinner";
import { _DEFAULT_FIELDS } from '../Models/form-fields';
import { _DEFAULT_FORM } from '../Models/form-schema';
import { _FORM_STAGES, _FORM_STATUS } from '../Models/formstatus';
import { MasterListModel } from '../Models/masterListModel';
import { MasterListService } from '../Services/Implementations/masterListService';

@Component({
  selector: 'appHome',
  templateUrl: './app-home.component.html',
  styleUrls: ['./app-home.component.css'],
  providers: [spPnpAPIService, MasterListService]
})
export class AppHomeComponent implements OnInit {
 
  constructor(private _spSvc: spPnpAPIService, 
    private router:Router, 
    private spinnerService: NgxSpinnerService,
    private _route: ActivatedRoute,
    private _masterListSvc: MasterListService) { }

  ngOnInit() {
    this._route.queryParams.subscribe(params=>{
      let masterId = params["mid"];
      if(masterId && masterId.toString().length>0){
        this.routeToForm(masterId.toString());
      }
      else{
        this.routeToLanding();
      }
    });
  }

  routeToLanding(){
    setTimeout(()=>{      
      this.spinnerService.show();
      this.routeToUrl();
    });
  }

  routeToUrl(){
    this._spSvc.getCurrentUserGroups().subscribe(data=>{
      let taxlab_sp_group = environment.tax_lab_sp_group.toLowerCase();
      let filteredGroup = data.Groups.filter(g=>g.Title.toLowerCase()===taxlab_sp_group);
      if(filteredGroup && filteredGroup.length>0){
        this.router.navigate(['./dashboard']);
      }
      else{
        this.router.navigate(['./home']);
      }
    });
  }

  clearAllFormData(){
    _DEFAULT_FIELDS.stage1.forEach(form=>{
      form.fields.forEach(field=>{
        field.value = "";
      });
    });
    _DEFAULT_FIELDS.stage2.forEach(form=>{
      form.fields.forEach(field=>{
        field.value = "";
      });
    });
    _DEFAULT_FORM.stage1.forEach(form=>{
      form.childFormDetails.forEach(cForm=>{
        cForm.childFormStatus = 'notstarted';
      });
    });
    _DEFAULT_FORM.stage2.forEach(form=>{
      form.childFormDetails.forEach(cForm=>{
        cForm.childFormStatus = 'notstarted';
      });
    });
  }

  routeToForm(masterId: string){
    setTimeout(()=>{      
      this.spinnerService.show();
      // Load data with passed query parameter
      let nMasterId = Number(masterId);
      this._masterListSvc.getSavedRecord(nMasterId).subscribe((mdata: MasterListModel)=>{
        let demandType = mdata.DemandType;
        let formStatus = mdata.FormStatus;
        let stage = mdata.Stage;

        localStorage.setItem('masterRecordId', masterId);
        // clearing all default field values
        this.clearAllFormData();
        let stageString = _FORM_STAGES.stage1;
        if(formStatus===_FORM_STATUS.approved && stage===_FORM_STAGES.stage1){
          stageString = _FORM_STAGES.stage2;
          formStatus = _FORM_STATUS.inProgress;
        }
        else if(stage===_FORM_STAGES.stage2){
          stageString = _FORM_STAGES.stage2;
        }
        this.router.navigate(['./NewDemand'], { 
          state: { selectedVal: demandType, formStatus: formStatus, stage: stageString } 
        });
      }, (error)=>{
        this.routeToLanding();
      });
    });
  }
}
