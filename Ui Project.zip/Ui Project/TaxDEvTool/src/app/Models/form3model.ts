export class Form3Model{
    Title: string;
    OwningSSL: string;
    SSLCompetencyService: string;
    
    SSLSponsoringPartnerEmail: string;
    SSLSponsoringPartnerRole: string;
    //SSLsolutionOwnerNameStringId: string;
   // SSLsolutionOwnerNameId: number;
    SSLsolutionOwnerName: any;
    SSLsolutionOwnerEmail: string;
    SSLsolutionOwnerRole: string;
   // SSLsolutionDeputyNameStringId: string;
    //SSLsolutionDeputyNameId: number;
    SSLsolutionDeputyName: any;
    SSLsolutionDeputyEmail: string;
    SSLsolutionDeputyRole: string;
    MarketOwnerJurisdictionSpecifica: string;
    LocalFunding: string;
    LocalGlobalFundingApproved: string;
    LocalGlobalFundingDetails: string;
    //SSLSponsoringPartnerNameStringId: string;
   // SSLSponsoringPartnerNameId: number;
    SSLSponsoringPartnerName: any;
    CompletionStatus: string;
}