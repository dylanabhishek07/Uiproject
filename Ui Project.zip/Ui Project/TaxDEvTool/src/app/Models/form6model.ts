export class Form6Model{
    Title: string;
    OverViewInputDataRequirements: string;
    DataTranscationVolumes: string;
    DataAccuracyRequiredProduct: string;
    ClientDataSubmitted: string;
    DataBelongsToClient: string;
    AdditionalInfo: string;
    FileDetailsJson: string;
    CompletionStatus: string;
}