export class MasterListModel{
    DemandType: string;
    FormStatus: string;
    Stage: string;
    Stage1Note: string;
    Stage2Note: string;
    HandoffNotes: string;
    FastTrackStatus: string;
    
    // Lookup columns info
    Form2DemandListLookupId: number;
    Form3DemandListLookupId: number;
    Form4DemandListLookupId: number;
    Form5DemandListLookupId: number;
    Form6DemandListLookupId: number;
    Form7DemandListLookupId: number;
    TechnicalEstimatesLookupId: number;

    // Reference objects
    Form2DemandListLookup: any;
    Form3DemandListLookup: any;
    Form4DemandListLookup: any;
    Form5DemandListLookup: any;
    Form6DemandListLookup: any;
    Form7DemandListLookup: any;
    TechnicalEstimatesLookup: any;

    // Assigned To
    AssignedToId: number;
    AssignedToStringId: string;
    AssignedTo: any;

    //form3 Email 
    Form3SSLsolutionOwnerEmail : string;
    Form3SSLsolutionDeputyEmail : string;
    Form3SSLSponsoringPartnerEmail : string;
}