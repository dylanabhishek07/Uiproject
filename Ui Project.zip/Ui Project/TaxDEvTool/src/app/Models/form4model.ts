export class Form4Model{
    Title: string;
    Form4UseCaseName: string;
    Technology: string;
    DescriptionUseCase: string;
    OtherSystemIntegrationUseCase: string;
    BarrierChallengesImpact: string;
    Form4ClientImmediateDemand: string;
    Form4ClientImmediateDemandDetail: string;
    Form4ListClientTarget: string;
    NewJurisdictionRequired: string;
    // Form4TargetLaunchDate: string;
    Form4DeploymentConditionsBarrier: string;
    Form4MarketOwnerJurisdictionSpec: string;
    CompletionStatus: string;
}