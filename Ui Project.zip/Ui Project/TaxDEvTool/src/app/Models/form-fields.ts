import {_FORM_NAMES} from './form-names';
export const _DEFAULT_FIELDS = {
    stage1 : [{
    formName: _FORM_NAMES.form2,
    fields: [{
      fieldName: 'useCase',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "ProblemDescription"
    },
    {
      fieldName: 'versionExist',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "ProblemDescription"
    }, {
      fieldName: 'hasDeployed',
      isMandatory: true,
      mandatoryDependency: {
        dependentOn: 'versionExist',
        dependencyType: 'Value',
        dependsOnValue: 'Yes'
      },
      type: 'string',
      value: "",
      mappedToChild: "ProblemDescription"
    },
    {
      fieldName: 'geography',
      isMandatory: true,
      mandatoryDependency: {
        dependentOn: 'hasDeployed',
        dependencyType: 'Value',
        dependsOnValue: 'Yes'
      },
      type: 'string',
      value: "",
      mappedToChild: "ProblemDescription"
    },
    {
      fieldName: 'describeProduct',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "ProblemDescription"
    },
    {
      fieldName: 'successful',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "ProblemDescription"
    },
    {
      fieldName: 'currentProcess',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "ProblemDescription"
    },
    {
      fieldName: 'changeProcess',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "ProblemDescription"
    },
    {
      fieldName: 'requirements',
      isMandatory: false,
      type: 'string',
      value: "",
      mappedToChild: "ProblemDescription"
    },
    {
      fieldName: 'challenges',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "ProblemDescription"
    },
    {
      fieldName: 'immediateDemand',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "Clients"
    },
    {
      fieldName: 'provideDetail',
      isMandatory: true,
      mandatoryDependency: {
        dependentOn: 'immediateDemand',
        dependencyType: 'Value',
        dependsOnValue: 'Yes'
      },
      type: 'string',
      value: "",
      mappedToChild: "Clients"
    },
    {
      fieldName: 'listClients',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "Clients"
    },
    {
      fieldName: 'clientDetails',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "Clients"
    },
    {
      fieldName: 'BusinessModel',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "Clients"
    },
    {
      fieldName: 'marketPriority',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "MarketDeployment"
    },
    {
      fieldName: 'mJurisdictional',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "MarketDeployment"
    },
    /* {
      fieldName: 'launchDate',
      isMandatory: false,
      type: 'string',
      value: "",
      mappedToChild: "MarketDeployment"
    }, */
    {
      fieldName: 'endUser',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "MarketDeployment"
    },
    {
      fieldName: 'campaign',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "MarketDeployment"
    },
    {
      fieldName: 'exCampaign',
      isMandatory: true,
      mandatoryDependency: {
        dependentOn: 'campaign',
        dependencyType: 'Value',
        dependsOnValue: 'Yes'
      },
      type: 'string',
      value: "",
      mappedToChild: "MarketDeployment"
    },
    {
      fieldName: 'newCampaign',
      isMandatory: true,
      mandatoryDependency: {
        dependentOn: 'campaign',
        dependencyType: 'Value',
        dependsOnValue: 'No'
      },
      type: 'string',
      value: "",
      mappedToChild: "MarketDeployment"
    },
    {
      fieldName: 'serviceOffering',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "MarketDeployment"
    },
    {
      fieldName: 'serviceDetails',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "MarketDeployment"
    },
    {
      fieldName: 'deployment',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "MarketDeployment"
    },
    {
      fieldName: 'jurisdictionArr',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "MarketDeployment"
    } //,
    /* {
      fieldName: 'marketArr',
      isMandatory: false,
      type: 'string',
      value: "",
      mappedToChild: "MarketDeployment"
    } */
  ]
  },
  {
    formName: _FORM_NAMES.form3,
    fields: [{
      fieldName: 'owningSSL',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "SSLOwnership"
    },
    {
      fieldName: 'sslCompetency',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "SSLOwnership"
    },
    {
      fieldName: 'sslSponsoringName',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "SSLSponsorship"
    },
    {
      fieldName: 'sslSponsoringDisplayName',
      isMandatory: false,
      type: 'string',
      value: "",
      mappedToChild: "SSLSponsorship"
    },
    {
      fieldName: 'sslSponsoringEmail',
      isMandatory: false,
      type: 'string',
      value: "",
      mappedToChild: "SSLSponsorship"
    },
    {
      fieldName: 'sslSponsoringRole',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "SSLSponsorship"
    },
    {
      fieldName: 'sslSolutionOwnerName',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "SSLMainPOC"
    },
    {
      fieldName: 'sslSolutionOwnerDisplayName',
      isMandatory: false,
      type: 'string',
      value: "",
      mappedToChild: "SSLMainPOC"
    },
    {
      fieldName: 'sslSolutionOwnerEmail',
      isMandatory: false,
      type: 'string',
      value: "",
      mappedToChild: "SSLMainPOC"
    },
    {
      fieldName: 'sslSolutionOwnerRole',
      isMandatory: false,
      type: 'string',
      value: "",
      mappedToChild: "SSLMainPOC"
    },   
    {
      fieldName: 'sslSolutionDeputyName',
      isMandatory: false,
      type: 'string',
      value: "",
      mappedToChild: "SSLDeputyPOC"
    },   
    {
      fieldName: 'sslSolutionDeputyDisplayName',
      isMandatory: false,
      type: 'string',
      value: "",
      mappedToChild: "SSLDeputyPOC"
    },
    {
      fieldName: 'sslSolutionDeputyEmail',
      isMandatory: false,
      type: 'string',
      value: "",
      mappedToChild: "SSLDeputyPOC"
    },
    {
      fieldName: 'sslSolutionDeputyRole',
      isMandatory: false,
      type: 'string',
      value: "",
      mappedToChild: "SSLDeputyPOC"
    },
    {
      fieldName: 'marketOwners',
      isMandatory: true,
      mandatoryDependency: {
        formId: _FORM_NAMES.form2,
        dependentOn: 'jurisdictionArr',
        dependencyType: 'ValueLength',
        dependsOnValue: 1
      },
      type: 'string',
      value: "",
      mappedToChild: "MarketOwnership"
    },
    {
      fieldName: 'radioQuesA',
      isMandatory: true,
      type: 'boolean',
      value: "",
      mappedToChild: "FundingRequirement"
    },
    {
      fieldName: 'radioQuesB',
      isMandatory: true,
      type: 'boolean',
      value: "",
      mappedToChild: "FundingRequirement"
    },
    {
      fieldName: 'form3AdditionalDetails',
      isMandatory: false,
      type: 'string',
      value: "",
      mappedToChild: "FundingRequirement"
    }
  ]
  },
  {
    formName: _FORM_NAMES.form4,
    fields: [{
      fieldName: 'useCaseForm4',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "ProblemDescription"
    },
    {
      fieldName: 'technology',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "ProblemDescription"
    },
    {
      fieldName: 'description',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "ProblemDescription"
    },
    {
      fieldName: 'systemIntegration',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "ProblemDescription"
    },
    {
      fieldName: 'barriers',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "ProblemDescription"
    },
    {
      fieldName: 'IsImmediate',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "Clients"
    },
    {
      fieldName: 'form4AdditionalDetailsIsImmediate',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "Clients"
    },
    {
      fieldName: 'listOfClients',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "Clients"
    },
    /* {
      fieldName: 'launchDate',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "Clients"
    }, */
    {
      fieldName: 'newJurisdictionArr',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "MarketDeployment"
    },
    {
      fieldName: 'deploymentConditions',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "MarketDeployment"
    },
    {
      fieldName: 'marketOwners',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "MarketOwnership"
    }
  ]
  },
  {
    formName: _FORM_NAMES.form5,
    fields: [
    {
        fieldName: 'businessTypeVal',
        isMandatory: true,
        type: 'string',
        value: "",
        mappedToChild: "ValueFramework"
     },
    {
      fieldName: 'form5AdditionalDetailsbusinessType',
      isMandatory: false,
      type: 'string',
      value: "",
      mappedToChild: "ValueFramework"
    },
    {
      fieldName: 'estimatedGTER',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "ValueFramework"
    },
    {
      fieldName: 'estimated3YearGTER',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "ValueFramework"
    },
    {
      fieldName: 'radioClient',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "ValueFramework"
    },
    {
      fieldName: 'radioGeographie',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "ValueFramework"
    },
    {
      fieldName: 'radioUSD',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "ValueFramework"
    },
    {
      fieldName: 'radioEngagement',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "ValueFramework"
    },
    {
      fieldName: 'radioRegulation',
      isMandatory: false,
      type: 'boolean',
      value: "",
      mappedToChild: "OtherMarketValue"
    },
    {
      fieldName: 'radioImproving',
      isMandatory: false,
      type: 'boolean',
      value: "",
      mappedToChild: "OtherMarketValue"
    },
    {
      fieldName: 'radioNewNovel',
      isMandatory: false,
      type: 'boolean',
      value: "",
      mappedToChild: "OtherMarketValue"
    },
    {
      fieldName: 'form5AdditionalDetailsImproving',
      isMandatory: true,
      mandatoryDependency: {
        dependentOn: 'radioImproving',
        dependencyType: 'Value',
        dependsOnValue: 'Yes'
      },
      type: 'string',
      value: "",
      mappedToChild: "OtherMarketValue"
    },
    {
      fieldName: 'form5AdditionalDetailsRegulation',
      isMandatory: true,
      mandatoryDependency: {
        dependentOn: 'radioRegulation',
        dependencyType: 'Value',
        dependsOnValue: 'Yes'
      },
      type: 'string',
      value: "",
      mappedToChild: "OtherMarketValue"
    },
    {
      fieldName: 'form5AdditionalDetailsNewNovel',
      isMandatory: true,
      mandatoryDependency: {
        dependentOn: 'radioNewNovel',
        dependencyType: 'Value',
        dependsOnValue: 'Yes'
      },
      type: 'string',
      value: "",
      mappedToChild: "OtherMarketValue"
    },
    {
    fieldName: 'TotalFTEassignedPerTask',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'TotalHoursFTE',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'TotalHoursPATotal',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'TotalCostPAapproxTotal',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'TotalTargetNumberHours',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'TotalTargetTotalCost',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'TotalCostSavingPA',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'Task',
    isMandatory: false,
    type: 'string',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'Frequency',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'FTEassignedPerTask',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'ApproxFTEassignedHourly',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'HoursFTE',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'TotalHoursPA',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'TotalCostPAapprox',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'TargetNumberHours',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'ExpectedTotalGrowth',
    isMandatory: false,
    type: 'string',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'TargetTotalCost',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'CostSavingPA',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'Task1',
    isMandatory: false,
    type: 'string',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'Frequency1',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'FTEassignedPerTask1',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'ApproxFTEassignedHourly1',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'HoursFTE1',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'TotalHoursPA1',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'TotalCostPAapprox1',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'TargetNumberHours1',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'ExpectedTotalGrowth1',
    isMandatory: false,
    type: 'string',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'TargetTotalCost1',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  },
  {
    fieldName: 'CostSavingPA1',
    isMandatory: false,
    type: 'Integer',
    value: "",
    mappedToChild: "TimeSavingsAndOptCosts"
  }]
},
  {
    formName: _FORM_NAMES.form6,
    fields: [{
      fieldName: 'dataRequirement',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "Data"
    },
    {
      fieldName: 'dataVolume',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "Data"
    },
    {
      fieldName: 'dataAccuracy',
      isMandatory: true,
      type: 'string',
      value: "",
      mappedToChild: "Data"
    },
    {
      fieldName: 'fileInfoJson',
      isMandatory: false,
      type: 'string',
      value: "",
      mappedToChild: "SubmissionOfData"
    },
    {
      fieldName: 'submitClientData',
      isMandatory: true,
      // mandatoryDependency: {
      //   dependentOn: 'fileInfoJson',
      //   dependencyType: 'ValueLength',
      //   dependsOnValue: 0
      // },
      type: 'string',
      value: "",
      mappedToChild: "SubmissionOfData"
    },
    {
      fieldName: 'dataBelong',
      isMandatory: true,
      mandatoryDependency: {
        dependentOn: 'submitClientData',
        dependencyType: 'Value',
        dependsOnValue: 'Yes'
      },
      type: 'string',
      value: "",
      mappedToChild: "SubmissionOfData"
    },
    {
      fieldName: 'otherInfo',
      isMandatory: false,
      type: 'string',
      value: "",
      mappedToChild: "AdditionalInfo"
    }]
  }],
  stage2: [
    {
      formName: _FORM_NAMES.form7,
      fields: [
      {
        fieldName: 'row1_Q1',
        isMandatory: false,
        skipCell: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row1_Q2',
        isMandatory: false,
        skipCell: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row1_Q3',
        isMandatory: false,
        skipCell: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row1_Q4',
        isMandatory: false,
        skipCell: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row1_TotalFY21',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row1_TotalFY22',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row1_TotalFY23',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      
      {
        fieldName: 'row2_Q1',
        isMandatory: false,
        skipCell: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row2_Q2',
        skipCell: true,
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row2_Q3',
        skipCell: true,
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row2_Q4',
        skipCell: true,
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row2_TotalFY21',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row2_TotalFY22',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row2_TotalFY23',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      /* Start: Row 3 */
      {
        fieldName: 'row3_Q1',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row2_TotalFY21}}/{{row1_TotalFY21}}) * 100)",
        mappedToChild: "ExistingClient",
        disabled: true
      },
      {
        fieldName: 'row3_Q2',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row2_TotalFY21}}/{{row1_TotalFY21}}) * 100)",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row3_Q3',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row2_TotalFY21}}/{{row1_TotalFY21}}) * 100)",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row3_Q4',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row2_TotalFY21}}/{{row1_TotalFY21}}) * 100)",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row3_TotalFY21',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row2_TotalFY21}}/{{row1_TotalFY21}}) * 100)",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row3_TotalFY22',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row2_TotalFY22}}/{{row1_TotalFY22}}) * 100)",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row3_TotalFY23',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row2_TotalFY23}}/{{row1_TotalFY23}}) * 100)",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      /* End: Row 3 */
      /* Start: Row 4 */
      {
        fieldName: 'row4_Q1',
        isMandatory: true,
        type: 'Integer',
        value: "",
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row4_Q2',
        isMandatory: true,
        type: 'Integer',
        value: "",
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row4_Q3',
        isMandatory: true,
        type: 'Integer',
        value: "",
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row4_Q4',
        isMandatory: true,
        type: 'Integer',
        value: "",
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row4_TotalFY21',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row4_Q1}} + {{row4_Q2}} + {{row4_Q3}} + {{row4_Q4}})",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row4_TotalFY22',
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row4_TotalFY23',
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      /* End: Row 4 */
      /* Start: Row 5 */
      {
        fieldName: 'row5_Q1',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row4_Q1}}/{{row1_TotalFY21}}) * 100)",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row5_Q2',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row4_Q2}}/{{row1_TotalFY21}}) * 100)",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row5_Q3',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row4_Q3}}/{{row1_TotalFY21}}) * 100)",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row5_Q4',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row4_Q4}}/{{row1_TotalFY21}}) * 100)",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row5_TotalFY21',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row4_TotalFY21}}/{{row1_TotalFY21}}) * 100)",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row5_TotalFY22',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row4_TotalFY22}}/{{row1_TotalFY22}}) * 100)",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row5_TotalFY23',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row4_TotalFY23}}/{{row1_TotalFY23}}) * 100)",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      /* End: Row 5 */
      /* Start: Row 6 */
      {
        fieldName: 'row6_Q1',
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row6_Q2',
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row6_Q3',
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row6_Q4',
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row6_TotalFY21',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row6_Q4}})",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row6_TotalFY22',
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row6_TotalFY23',
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "ExistingClient"
      },
      /* End: Row 6 */
      /* Start: Row 7 */
      {
        fieldName: 'row7_Q1',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row4_Q1}}*{{row6_Q1}})",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row7_Q2',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row4_Q2}}*{{row6_Q2}})",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row7_Q3',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row4_Q3}}*{{row6_Q3}})",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row7_Q4',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row4_Q4}}*{{row6_Q4}})",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row7_TotalFY21',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row7_Q1}}+{{row7_Q2}}+{{row7_Q3}}+{{row7_Q4}})",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row7_TotalFY22',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row4_TotalFY22}}*{{row6_TotalFY22}})",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row7_TotalFY23',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row4_TotalFY23}}*{{row6_TotalFY23}})",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      {
        fieldName: 'row7_Total3YearValue',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row7_TotalFY21}}+{{row7_TotalFY22}}+{{row7_TotalFY23}})",
        disabled: true,
        mappedToChild: "ExistingClient"
      },
      /* End: Row 7 */
      /* Start: Row 8 */
      {
        fieldName: 'row8_Q1',
        isMandatory: false,
        skipCell: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row8_Q2',
        isMandatory: false,
        skipCell: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row8_Q3',
        isMandatory: false,
        skipCell: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row8_Q4',
        isMandatory: false,
        skipCell: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row8_TotalFY21',
        isMandatory: true,
        type: 'Integer',
        value: "",
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row8_TotalFY22',
        isMandatory: true,
        type: 'Integer',
        value: "",
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row8_TotalFY23',
        isMandatory: true,
        type: 'Integer',
        value: "",
        mappedToChild: "NewClient"
      },
      /* End: Row 8 */
      /* Start: Row 9 */
      {
        fieldName: 'row9_Q1',
        isMandatory: false,
        skipCell: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row9_Q2',
        isMandatory: false,
        skipCell: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row9_Q3',
        isMandatory: false,
        skipCell: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row9_Q4',
        isMandatory: false,
        skipCell: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row9_TotalFY21',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row1_TotalFY21}}*{{row8_TotalFY21}})/100)",
        disabled: true,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row9_TotalFY22',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row1_TotalFY22}}*{{row8_TotalFY22}})/100)",
        disabled: true,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row9_TotalFY23',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row1_TotalFY23}}*{{row8_TotalFY23}})/100)",
        disabled: true,
        mappedToChild: "NewClient"
      },
      /* End: Row 9 */
      /* Start: Row 10 */
      {
        fieldName: 'row10_Q1',
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row10_Q2',
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row10_Q3',
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row10_Q4',
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row10_TotalFY21',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row10_Q1}}+{{row10_Q2}}+{{row10_Q3}}+{{row10_Q4}})",
        disabled: true,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row10_TotalFY22',
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row10_TotalFY23',
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "NewClient"
      },
      /* End: Row 10 */
      /* Start: Row 11 */
      {
        fieldName: 'row11_Q1',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row10_Q1}}/{{row9_TotalFY21}})*100)",
        disabled: true,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row11_Q2',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row10_Q2}}/{{row9_TotalFY21}})*100)",
        disabled: true,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row11_Q3',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row10_Q3}}/{{row9_TotalFY21}})*100)",
        disabled: true,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row11_Q4',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row10_Q4}}/{{row9_TotalFY21}})*100)",
        disabled: true,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row11_TotalFY21',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row10_TotalFY21}}/{{row1_TotalFY21}})*100)",
        disabled: true,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row11_TotalFY22',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row10_TotalFY22}}/{{row9_TotalFY22}})*100)",
        disabled: true,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row11_TotalFY23',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "(({{row10_TotalFY23}}/{{row9_TotalFY23}})*100)",
        disabled: true,
        mappedToChild: "NewClient"
      },
      /* End: Row 11 */
      /* Start: Row 12 */
      {
        fieldName: 'row12_Q1',
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row12_Q2',
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row12_Q3',
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row12_Q4',
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row12_TotalFY21',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row12_Q4}})",
        disabled: true,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row12_TotalFY22',
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row12_TotalFY23',
        isMandatory: false,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "NewClient"
      },
      /* End: Row 12 */
      /* Start: Row 13 */
      {
        fieldName: 'row13_Q1',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row12_Q1}}*{{row10_Q1}})",
        disabled: true,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row13_Q2',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row12_Q2}}*{{row10_Q2}})",
        disabled: true,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row13_Q3',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row12_Q3}}*{{row10_Q3}})",
        disabled: true,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row13_Q4',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row12_Q4}}*{{row10_Q4}})",
        disabled: true,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row13_TotalFY21',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row13_Q1}}+{{row13_Q2}}+{{row13_Q3}}+{{row13_Q4}})",
        disabled: true,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row13_TotalFY22',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row12_TotalFY22}}*{{row10_TotalFY22}})",
        disabled: true,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row13_TotalFY23',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row12_TotalFY23}}*{{row10_TotalFY23}})",
        disabled: true,
        mappedToChild: "NewClient"
      },
      {
        fieldName: 'row13_Total3YearValue',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row13_TotalFY21}}+{{row13_TotalFY22}}+{{row13_TotalFY23}})",
        disabled: true,
        mappedToChild: "NewClient"
      },
      /* End: Row 13 */
      /* Added later */
      /* Start: Row 14 */
      {
        fieldName: 'row14_Q1',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row14_Q2',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row14_Q3',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row14_Q4',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row14_TotalFY21',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row14_Q1}} + {{row14_Q2}} + {{row14_Q3}} + {{row14_Q4}})",
        disabled: true,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row14_TotalFY22',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row14_TotalFY23',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row14_Total3YearValue',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row14_TotalFY21}} + {{row14_TotalFY22}} + {{row14_TotalFY23}})",
        disabled: true,
        mappedToChild: "CostSavings"
      },
      /* End: Row 14 */
      /* Start: Row 15 */
      {
        fieldName: 'row15_Q1',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row15_Q2',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row15_Q3',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row15_Q4',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row15_TotalFY21',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row15_Q1}} + {{row15_Q2}} + {{row15_Q3}} + {{row15_Q4}})",
        disabled: true,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row15_TotalFY22',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row15_TotalFY23',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row15_Total3YearValue',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row15_TotalFY21}} + {{row15_TotalFY22}} + {{row15_TotalFY23}})",
        disabled: true,
        mappedToChild: "CostSavings"
      },
      /* End: Row 15 */
      /* Start: Row 16 */
      {
        fieldName: 'row16_Q1',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row16_Q2',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row16_Q3',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row16_Q4',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row16_TotalFY21',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row16_Q1}} + {{row16_Q2}} + {{row16_Q3}} + {{row16_Q4}})",
        disabled: true,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row16_TotalFY22',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row16_TotalFY23',
        isMandatory: true,
        type: 'Integer',
        value: "",
        disabled: false,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row16_Total3YearValue',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row16_TotalFY21}} + {{row16_TotalFY22}} + {{row16_TotalFY23}})",
        disabled: true,
        mappedToChild: "CostSavings"
      },
      /* End: Row 16 */
      /* Start: Row 17 */
      {
        fieldName: 'row17_Q1',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row15_Q1}} + {{row16_Q1}})",
        disabled: true,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row17_Q2',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row15_Q2}} + {{row16_Q2}})",
        disabled: true,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row17_Q3',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row15_Q3}} + {{row16_Q3}})",
        disabled: true,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row17_Q4',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row15_Q4}} + {{row16_Q4}})",
        disabled: true,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row17_TotalFY21',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row15_TotalFY21}} + {{row16_TotalFY21}})",
        disabled: true,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row17_TotalFY22',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row15_TotalFY22}} + {{row16_TotalFY22}})",
        disabled: true,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row17_TotalFY23',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row15_TotalFY23}} + {{row16_TotalFY23}})",
        disabled: true,
        mappedToChild: "CostSavings"
      },
      {
        fieldName: 'row17_Total3YearValue',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row14_Total3YearValue}} + {{row15_Total3YearValue}} + {{row16_Total3YearValue}})",
        disabled: true,
        mappedToChild: "CostSavings"
      },
      /* End: Row 17 */
      /* Start: Row 18 */
      {
        fieldName: 'row18_Q1',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row4_Q1}} + {{row10_Q1}})",
        disabled: true,
        mappedToChild: "Total"
      },
      {
        fieldName: 'row18_Q2',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row4_Q2}} + {{row10_Q2}})",
        disabled: true,
        mappedToChild: "Total"
      },
      {
        fieldName: 'row18_Q3',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row4_Q3}} + {{row10_Q3}})",
        disabled: true,
        mappedToChild: "Total"
      },
      {
        fieldName: 'row18_Q4',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row4_Q4}} + {{row10_Q4}})",
        disabled: true,
        mappedToChild: "Total"
      },
      {
        fieldName: 'row18_TotalFY21',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row4_TotalFY21}} + {{row10_TotalFY21}})",
        disabled: true,
        mappedToChild: "Total"
      },
      {
        fieldName: 'row18_TotalFY22',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row4_TotalFY22}} + {{row10_TotalFY22}})",
        disabled: true,
        mappedToChild: "Total"
      },
      {
        fieldName: 'row18_TotalFY23',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row4_TotalFY23}} + {{row10_TotalFY23}})",
        disabled: true,
        mappedToChild: "Total"
      },
      /* End: Row 18 */
      /* Start: Row 19 */
      {
        fieldName: 'row19_Q1',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row7_Q1}} + {{row13_Q1}})",
        disabled: true,
        mappedToChild: "Total"
      },
      {
        fieldName: 'row19_Q2',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row7_Q2}} + {{row13_Q2}})",
        disabled: true,
        mappedToChild: "Total"
      },
      {
        fieldName: 'row19_Q3',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row7_Q3}} + {{row13_Q3}})",
        disabled: true,
        mappedToChild: "Total"
      },
      {
        fieldName: 'row19_Q4',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row7_Q4}} + {{row13_Q4}})",
        disabled: true,
        mappedToChild: "Total"
      },
      {
        fieldName: 'row19_TotalFY21',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row7_TotalFY21}} + {{row13_TotalFY21}})",
        disabled: true,
        mappedToChild: "Total"
      },
      {
        fieldName: 'row19_TotalFY22',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row7_TotalFY22}} + {{row13_TotalFY22}})",
        disabled: true,
        mappedToChild: "Total"
      },
      {
        fieldName: 'row19_TotalFY23',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row7_TotalFY23}} + {{row13_TotalFY23}})",
        disabled: true,
        mappedToChild: "Total"
      },
      {
        fieldName: 'row19_Total3YearValue',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row7_Total3YearValue}} + {{row13_Total3YearValue}})",
        disabled: true,
        mappedToChild: "Total"
      },
      /* End: Row 19 */
      /* Start: Row 20 */
      {
        fieldName: 'row20_Q1',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row17_Q1}} + {{row19_Q1}})",
        disabled: true,
        mappedToChild: "Total"
      },
      {
        fieldName: 'row20_Q2',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row17_Q2}} + {{row19_Q2}})",
        disabled: true,
        mappedToChild: "Total"
      },
      {
        fieldName: 'row20_Q3',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row17_Q3}} + {{row19_Q3}})",
        disabled: true,
        mappedToChild: "Total"
      },
      {
        fieldName: 'row20_Q4',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row17_Q4}} + {{row19_Q4}})",
        disabled: true,
        mappedToChild: "Total"
      },
      {
        fieldName: 'row20_TotalFY21',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row17_TotalFY21}} + {{row19_TotalFY21}})",
        disabled: true,
        mappedToChild: "Total"
      },
      {
        fieldName: 'row20_TotalFY22',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row17_TotalFY22}} + {{row19_TotalFY22}})",
        disabled: true,
        mappedToChild: "Total"
      },
      {
        fieldName: 'row20_TotalFY23',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row17_TotalFY23}} + {{row19_TotalFY23}})",
        disabled: true,
        mappedToChild: "Total"
      },
      {
        fieldName: 'row20_Total3YearValue',
        isMandatory: true,
        type: 'Integer',
        value: "",
        formula: "({{row17_Total3YearValue}} + {{row19_Total3YearValue}})",
        disabled: true,
        mappedToChild: "Total"
      }
      /* End: Row 20 */
    ]
    }
  ]
};