export class User{
    id : any;
    displayName : any;
    emailId : any;
    userphotosrc : any;

    constructor(){
        this.id = "";
        this.displayName = "";
        this.emailId = "";
        this.userphotosrc = "";
    }
}