export class Jurisdiction {
    priorityJurisdictionName: string;
    launchDate: Date;
    validName:boolean;
    validDate:boolean;
}