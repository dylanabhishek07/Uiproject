export const _FORM_NAMES = {
    form2: 'Form2',
    form3: 'Form3',
    form4: 'Form4',
    form5: 'Form5',
    form6: 'Form6',
    form7: 'Form7'
};