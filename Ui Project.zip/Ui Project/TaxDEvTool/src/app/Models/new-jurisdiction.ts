export class NewJurisdiction{
    jurisdictionName: string;
    launchDate: Date;
    validDate: boolean;
    validName : boolean;
}