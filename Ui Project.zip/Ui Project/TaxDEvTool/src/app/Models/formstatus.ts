export const _FORM_STATUS = {
    inProgress: "In Progress",
    submitted: "Submitted",
    parked: "Parked",
    approved: "Approved",
    techTeamInput: "Tech Team Input",
    completed: "Completed",
    rejected: "Rejected",
    handoff: "Handoff",
    triage: "Triage"    
};

export const _FORM_STAGES = {
    stage1: "Stage 1",
    stage2: "Stage 2",
    completed: "Completed"
}