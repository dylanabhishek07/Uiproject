export class Form7Columns{
    
    Q1: string;
    Q2: string;
    Q3: string;
    Q4: string;
    TotalFY21: string;
    TotalFY22: string;
    TotalFY23: string;
    Total3YearValue : string;
}

export class Form7Model{
    Title: string;
    NumberOfExistingClients: string;
    NumberOfExistingClientsInfused: string;
    PenetrationOnExistingClients: string;
    TargetNumberOfExistingClients: string;
    TargetPenetrationOfExistingClien: string;
    TargetGTERperEngagementOfNewClie : string;
    TargetGTERperEngagement : string;
    TargetGTERValueOfExistingClients: string;
    NewClientsTargetGrowthRate: string;
    TargetNumberOfNewClients: string;
    TargetNumberOfNewClientsInfused: string;
    TargetPenetrationNewClients: string;
    GTERTargetValueOfNewClients: string;
    TargetTotalValueClientsInfused: string;
    CompletionStatus: string;
    TotalGTERValueByAlwin: string;
    FTECostSavings: string;
    QualityImprovementCostSavings: string;
    RiskMitigationCostSavings: string;
}