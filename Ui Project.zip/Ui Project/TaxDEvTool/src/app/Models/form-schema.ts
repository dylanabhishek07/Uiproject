import {_FORM_NAMES} from './form-names';
export const _DEFAULT_FORM = {
    stage1 : [{
    formName: 'Form 1',
    mappedToDemandTypes: ["New use case / product", "Integration / globalisation of existing product"],
    sectionHeader: "Form 1: Use case description",
    formId: _FORM_NAMES.form2,
    formDescription: 'Use case description',
    isFormTabSelected: true,
    childFormDetails: [{
        childId: 'ProblemDescription',
        childFormName: 'Problem Description',
        isChildFormComplete: false,
        childFormStatus: 'notstarted'
    },
    {
        childId: 'Clients',
        childFormName: 'Clients',
        isChildFormComplete: false,
        childFormStatus: 'notstarted'
    },
    {
        childId: 'MarketDeployment',
        childFormName: 'Market Deployment',
        isChildFormComplete: false,
        childFormStatus: 'notstarted'
    }]
},
{
    formName: 'Form 2',
    sectionHeader: "Form 2: Ownership",
    mappedToDemandTypes: ["New use case / product", "Integration / globalisation of existing product"],
    formId: _FORM_NAMES.form3,
    formDescription: 'Ownership',
    isFormTabSelected: false,
    childFormDetails: [{
        childId: 'SSLOwnership',
        childFormName: 'SSL Ownership',
        childFormStatus: 'notstarted'
    },
    {
        childId: 'SSLSponsorship',
        childFormName: 'SSL Sponsorship',
        childFormStatus: 'notstarted'
    },
    {
        childId: 'SSLMainPOC',
        childFormName: 'SSL Main point of contact',
        childFormStatus: 'notstarted'
    },
    {
        childId: 'SSLDeputyPOC',
        childFormName: 'SSL Deputy point of contact',
        childFormStatus: 'notstarted'
    },
    {
        childId: 'MarketOwnership',
        childFormName: 'Market Ownership',
        childFormStatus: 'notstarted'
    },
    {
        childId: 'FundingRequirement',
        childFormName: 'Funding Requirement',
        childFormStatus: 'notstarted'
    }]
},
{
    formName: 'Form 3',
    sectionHeader: "Form 3: Use case description",
    mappedToDemandTypes: ["New Geography for existing use case / product"],
    formId: _FORM_NAMES.form4,
    formDescription: 'Use case description',
    isFormTabSelected: false,
    childFormDetails: [{
        childId: 'ProblemDescription',
        childFormName: 'Problem Description',
        childFormStatus: 'notstarted'
    },
    {
        childId: 'Clients',
        childFormName: 'Clients',
        childFormStatus: 'notstarted'
    },
    {
        childId: 'MarketDeployment',
        childFormName: 'Market Deployment',
        childFormStatus: 'notstarted'
    },
    {
        childId: 'MarketOwnership',
        childFormName: 'Market Ownership',
        childFormStatus: 'notstarted'
    }]
    
},
{
    formName: 'Form 4',
    sectionHeader: "Form 4: Value Model",
    mappedToDemandTypes: ["New use case / product", "Integration / globalisation of existing product", "New Geography for existing use case / product"],
    formId: _FORM_NAMES.form5,
    formDescription: 'Value Model',
    isFormTabSelected: false,
    childFormDetails: [{
        childId: 'ValueFramework',
        childFormName: 'Value Framework',
        childFormStatus: 'notstarted'
    },
    {
        childId: 'OtherMarketValue',
        childFormName: 'Other Market Value',
        childFormStatus: 'notstarted'
    },
    {
        childId: 'TimeSavingsAndOptCosts',
        childFormName: 'Time Savings & Operational Costs',
        childFormStatus: 'notstarted'
    }]
},
{
    formName: 'Form 5',
    sectionHeader: "Form 5: Data",
    mappedToDemandTypes: ["New use case / product", "Integration / globalisation of existing product", "New Geography for existing use case / product"],
    formId: _FORM_NAMES.form6,
    formDescription: 'Data',
    isFormTabSelected: false,
    childFormDetails: [{
        childId: 'Data',
        childFormName: 'Data',
        childFormStatus: 'notstarted'
    },
    {
        childId: 'SubmissionOfData',
        childFormName: 'Submission of Data',
        childFormStatus: 'notstarted'
    },
    {
        childId: 'AdditionalInfo',
        childFormName: 'Additional Info',
        childFormStatus: 'notstarted'
    }]
}],
stage2: [{
    formName: 'Form 7',
    sectionHeader: "Form 7: Detailed Value Pipeline",
    formId: _FORM_NAMES.form7,
    formDescription: 'Detailed Value Pipeline',
    isFormTabSelected: true,
    childFormDetails: [{
        childId: 'ExistingClient',
        childFormName: 'Existing Client',
        childFormStatus: 'notstarted'
    },
    {
        childId: 'NewClient',
        childFormName: 'New Client',
        childFormStatus: 'notstarted'
    },
    {
        childId: 'CostSavings',
        childFormName: 'Cost Savings',
        childFormStatus: 'notstarted'
    },
    {
        childId: 'Total',
        childFormName: 'Total',
        childFormStatus: 'notstarted'
    }]
}]
};