export class Form5Model {
    Title : string;
    BusinessType: string;
    otherBusinessType : string;
    EstimatedAnnualGTER: string;
    Estimated3YearGTER: string;
    Client : string;
    Geographies: string;
    EngagementPenetration : string;
    USDperEngagement: string;
    RegulationResons : string;
    RegulationDetails: string;
    ImprovingMarket : string;
    NewNovelOffered : string;
    NewNovelOfferedDetails : string;
    ImprovingMarketDetails : string;
    CompletionStatus: string;
    CalculatedData: string;

}