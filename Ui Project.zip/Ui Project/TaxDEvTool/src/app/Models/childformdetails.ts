export class ChildFormDetails{
    childFormName: string;
    childFormStatus: 'notstarted'|'inprogress'|'completed' = 'notstarted';
    childFormStatusDisplay: 'Not Started'|'In Progress'|'Completed';
} 