export class TechnicalEstimatesModel{
    EffortEstimates: string;
    CostEstimates: string;
    ApproximateTimeline: string;
    // Columns
    ProductDevelopmentCost: string;
    MiscDevelopmentCost: string;
    IntegrationCost: string;
    DataCost: string;
    CostToIndustrialise: string;
    ProductMaintainCost: string;
    OperationalRunCost: string;
    OtherServiceDeliveryCost: string;
    TotalTechCost: string;
    InfrastructureCostDevelopment : string;
    CTServiceModelOperationalCost : string;
    OperationalInfrastructureCost : string;
}

export class EstimationColumns{
    FY21: string;
    FY22: string;
    FY23: string;
    Total3Year: string;
}