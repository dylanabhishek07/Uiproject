export class ExcelDataModel{
    sheetName: string;
    sheetData: any[];
    columnInfo: ExcelColumnInfo[];
}

export class ExcelColumnInfo{
    columnHeader: string;
    columnFieldName: string;
}