import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule , NO_ERRORS_SCHEMA } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MasterpageComponent } from './masterpage/masterpage.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NavigationComponent } from './navigation/navigation.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HomeComponent } from './home/home.component';
import { HttpClientModule } from '@angular/common/http';
import { GridModule,ExcelModule } from '@progress/kendo-angular-grid';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { CustomKendoMultiselectFilterComponent } from './Common/custom-kendo-multiselect-filter/custom-kendo-multiselect-filter.component';
import { CustomKendoDaterangeFilterComponent } from './Common/custom-kendo-daterange-filter/custom-kendo-daterange-filter.component';
import { NgxSpinnerModule } from "ngx-spinner";
import { ExcelExportModule } from '@progress/kendo-angular-excel-export';
import { NewDemandComponent } from './new-demand/new-demand.component';
import { DemandFormLandingModule } from './demand-forms/demand-form-landing/demand-form-landing.module';
import { AppHomeComponent } from './app-home/app-home.component';
import { HandoffModule } from './hand-off/handoff.module';
import { DashboardComponent } from './dashboard/dashboard.component';
import { PeoplePickerComponent } from './people-picker/people-picker.component';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';

@NgModule({
  declarations: [
    AppComponent,
    MasterpageComponent,
    NavigationComponent,
    HomeComponent,
    CustomKendoMultiselectFilterComponent,
    CustomKendoDaterangeFilterComponent,
    NewDemandComponent,
    AppHomeComponent,
    DashboardComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    NgbModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    GridModule,
    ExcelModule,
    DropDownsModule,
    BrowserAnimationsModule,
    NgxSpinnerModule,
    ExcelExportModule,  
    BrowserAnimationsModule,
    DemandFormLandingModule,
    HandoffModule,
    NgMultiSelectDropDownModule.forRoot() 
  ],
   
  schemas: [ NO_ERRORS_SCHEMA ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }