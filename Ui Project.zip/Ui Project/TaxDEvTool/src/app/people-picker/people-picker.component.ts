import { Component, OnInit,Output,EventEmitter,Input,AfterViewInit,OnChanges } from '@angular/core';
import { Observable } from 'rxjs';
import { ApplicationConfigurationsService } from 'src/Services/applicationConfigurations.service';
import { CommonService } from 'src/Services/common.service';

@Component({
  selector: 'app-people-picker',
  templateUrl: './people-picker.component.html',
  styleUrls: ['./people-picker.component.css']
})
export class PeoplePickerComponent implements OnInit,OnChanges {

  peoplePickerOptions: Observable<any[]>;
  @Output() setEvent =new EventEmitter<any>();
  @Input() valueToSet: Array<{ name: string, email: string }>=[];
  @Input() isDisabled:boolean;
  @Input() maxSelectionsAllowed:number;

  //SPformDigest:string;

  constructor(private commonSer: CommonService, private appConfigService : ApplicationConfigurationsService) {
    //this.SPformDigest = appConfigService.getSPformDigest();
  }

  ngOnInit() {
  }

  ngOnChanges(){

  }

  peopleFilterChange(value: any): void {
    if (value && value.length >= 3) {
      this.commonSer.getFormDigest().toPromise().then((res: any) => {
        this.appConfigService.setSPformDigest(res.FormDigestValue)
        let formDigest = res.FormDigestValue;
        this.peoplePickerOptions = this.getUsersAsObservable(value, formDigest);
      }).catch(err => {
        console.log(err);
      });
    }
  }

  getUsersAsObservable(name: string, formDigest: any): Observable<any> {
    return new Observable<any>((observer) => {
      this.commonSer.searchUser(name, formDigest).subscribe((results: any) => {
        let temp=JSON.parse(results.d.ClientPeoplePickerSearchUser);
        observer.next(temp.map(user => ({ email: user.Description, name: user.DisplayText, key : user.Key})));
      },(error=>console.log(error)));
    });
  }

  valueChange(event: any) {
    try {
      if (event.length <= (+(this.maxSelectionsAllowed))) {
        this.setEvent.emit({ selectedValue: event, reset: true });
      } else {
        this.setEvent.emit({ selectedValue: event, reset: false });
      }
    }
    catch (err) {
      console.log(err);
    }
  }

}
