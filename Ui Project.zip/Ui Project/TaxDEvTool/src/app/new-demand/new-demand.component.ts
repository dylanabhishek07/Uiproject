import { Component, ElementRef, OnInit, Renderer2, ViewChild } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-new-demand',
  templateUrl: './new-demand.component.html',
  styleUrls: ['./new-demand.component.css'],  
})
export class NewDemandComponent implements OnInit {
  more: boolean;
  dropdownVal: string;

  @ViewChild('dropdownDivSSL',{static:false}) dropdownDivSSL: ElementRef;
  dropdownValGTER: string;
  dropdownVal3YearGTER: string;
  //@ViewChild('dropdownDivSSL',{static:false}) dropdownDivSSL: ElementRef;
  @ViewChild('dropdownDivGTER',{static:false}) dropdownDivGTER: ElementRef;
  @ViewChild('dropdownDiv3YearGTER',{static:false}) dropdownDiv3YearGTER: ElementRef;
  showText: boolean;
  checkedList: any;
  checkedListUnchek: any[];
  istrue: boolean;
  moreGTER: boolean;
  more3YearGTER: boolean;
  
  constructor(private renderer: Renderer2) {
    this.renderer.listen('window', 'click',(e:Event)=>{
      /**
       * Only run when toggleButton is not clicked
       * If we don't check this, all clicks (even on the toggle button) gets into this
       * section which in the result we might never see the menu open!
       * And the menu itself is checked here, and it's where we check just outside of
       * the menu and button the condition abbove must close the menu
       */
      if(!this.dropdownDivSSL.nativeElement.contains(e.target)) {
          this.more=false;
      }
      if(!this.dropdownDivGTER.nativeElement.contains(e.target)) {
        this.moreGTER=false;
      }
      if(!this.dropdownDiv3YearGTER.nativeElement.contains(e.target)) {
        this.more3YearGTER=false;
        
      }
  });
   }

  owningSslList: any = ['BTS','Private','GCR/TFO','Indirect','ITTS','Law','PAS','TTT'];
  options: any = ["Yes","No"];
  
  businessType = [
    { id: 1, name: 'Margin improvement' },
    { id: 2, name: 'cost saving' },
    { id: 3, name: 'new client revenue' },
    { id: 4, name: 'other' }
  ];
//businessType: any = ['Margin improvement' , 'cost saving','new client revenue',' other'];
estimatedGTERList : any= ['Less than $1m ','$1 - $5m','$6 - $10m','$11m - $20m','$21m - $30m','Above $30m'];
estimated3YearGTERList : any= ['Less than $1m ','$1 - $5m','$6 - $10m','$11m - $20m','$21m - $30m','Above $30m'];

form5 = new FormGroup({
businessTypeVal: new FormControl('', Validators.required),
  estimatedGTER: new FormControl('', Validators.required),
  estimated3YearGTER: new FormControl('', Validators.required),
  totalFTEassigned: new FormControl('', Validators.required),
  totalFTEhours: new FormControl('', Validators.required), 
  totalFrequency: new FormControl('', Validators.required),
  totalSavedHours: new FormControl('', Validators.required),
  radioGeographie : new FormControl('', Validators.required),
  radioEngagement : new FormControl('', Validators.required),
  radioUSD : new FormControl('', Validators.required),
  radioClient : new FormControl('', Validators.required),
  form5AdditionalDetailsbusinessType : new FormControl('', Validators.required),
  radioRegulation : new FormControl('', Validators.required),
  radioImproving : new FormControl('', Validators.required),
  radioNewNovel : new FormControl('', Validators.required),
  form5AdditionalDetailsradioNewNovel : new FormControl('', Validators.required),
  form5AdditionalDetailsImproving : new FormControl('', Validators.required),
  form5AdditionalDetailsRegulation : new FormControl('', Validators.required),
  details: new FormControl('', Validators.required)
});

  form3 = new FormGroup({
    owningSSL: new FormControl('', Validators.required),
    sslCompetency: new FormControl('', Validators.required),
    sslSponsoringName: new FormControl('', Validators.required),
    sslSponsoringEmail: new FormControl('', Validators.required),
    sslSponsoringRole: new FormControl('', Validators.required),
    sslSolutionOwnerName: new FormControl('', Validators.required),
    sslSolutionOwnerEmail: new FormControl('', Validators.required),
    sslSolutionOwnerRole: new FormControl('', Validators.required), 
    sslSolutionDeputyName: new FormControl('', Validators.required),
    sslSolutionDeputyEmail: new FormControl('', Validators.required),
    sslSolutionDeputyRole: new FormControl('', Validators.required),
    marketOwner: new FormControl('', Validators.required),
    radioQuesA: new FormControl('', Validators.required),   
    radioQuesB: new FormControl('', Validators.required), 
    details: new FormControl('', Validators.required)
  });

  ngOnInit() {
    this.more=false;
    this.dropdownVal = ""; 
    this.moreGTER=false;
    this.more3YearGTER=false;
    this.dropdownValGTER = "";
    this.dropdownVal3YearGTER="";
  }
  
  isEmpty(controlName)
  {
    var formValue = this.form3.value[controlName];
    console.log(formValue);
    if(formValue.length <=0)
      return true;
      else
      return false;
  }
  onCheckChange(value, event) {
    this.checkedList = [];
    this.checkedListUnchek=[];
    if(event.target.checked) {
      this.checkedList.push(value.id);
    } 
    else {
      this.checkedListUnchek.push(value.id)
 }
 console.log(this.checkedList);
    for(var i=0;i<this.checkedList.length; i++)
    {
        if(this.checkedList[i]==4)
        {
          this.showText= true
        }
      }
      for(var i=0;i<this.checkedListUnchek.length; i++)
      {
          if(this.checkedListUnchek[i]==4)
          {
            this.showText= false;
          }
        }
  }
 }
 
 
  // if(event.target.checked){
  //   // Add a new control in the arrayForm
  //   formArray.push(new FormControl(event.target.value));
  // }
  // /* unselected */
  // else{
  //   // find the unselected element
  //   let i: number = 0;

  //   formArray.controls.forEach((ctrl: FormControl) => {
  //     if(ctrl.value == event.target.value) {
  //       // Remove the unselected element from the arrayForm
  //       formArray.removeAt(i);
  //       return;
  //     }

  //     i++;
  //   });
  // }



