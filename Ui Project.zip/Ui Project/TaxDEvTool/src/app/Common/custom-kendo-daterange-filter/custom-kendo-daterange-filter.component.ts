import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custom-kendo-daterange-filter',
  templateUrl: './custom-kendo-daterange-filter.component.html',
  styleUrls: ['./custom-kendo-daterange-filter.component.css']
})
export class CustomKendoDaterangeFilterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
