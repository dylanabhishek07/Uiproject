import { Component, OnInit, Input, Output, EventEmitter, Renderer2, ViewChild, ElementRef } from '@angular/core';
import { AutocompleteInterface } from './autocomplete.interface';

@Component({
  selector: 'ey-autocomplete-input',
  templateUrl: './ey-autocomplete-input.component.html',
  styleUrls: ['./ey-autocomplete-input.component.css']
})

export class AutoCompleteInputComponent implements OnInit {
  @Input()
  isMandatory = false;
  @Input()
  error = false;
  @Input()
  label = '';
  @Input()
  shortDescription = '';
  @Input()
  suggestions: any;
  @Input()
  inputModel = '';
  @Input()
  disabled = false;
  @Input()
  shadowInput = false;
  @Input()
  styles: {} = null;
  @Input()
  overlayDescription = null;
  @Input()
  showSpinner = false;
  @Input()
  class = '';

  @Output()
  inputModelChange: EventEmitter<any> = new EventEmitter<any>();
  @Output()
  keyUpChange: EventEmitter<any> = new EventEmitter<any>();
  @Output()
  keyDownChange: EventEmitter<any> = new EventEmitter<any>();
  @Output()
  keyPressChange: EventEmitter<any> = new EventEmitter<any>();
  @Output()
  valueChange: EventEmitter<any> = new EventEmitter<any>();
  @Output()
  optionClicked: EventEmitter<any> = new EventEmitter<any>();

  itemList: AutocompleteInterface[];

  showOptionsDisplay: boolean = false;

  isInputFocused: boolean = false;

  @ViewChild('toggleButton', { static: false }) toggleButton: ElementRef;
  @ViewChild('menu', { static: false }) menu: ElementRef;
  @ViewChild('inputElement', null) inputElement;
  constructor(private renderer: Renderer2) {
    /* This check added to find a click event on windows except the menu items */
    // this.renderer.listen('window', 'click', (e: Event) => {
    //   /* Adding check for toggleButton and menu undefined */
    //   if (e && this.toggleButton && this.menu) {
    //     /* If the menu toggle button or the menu items itself are not clicked then close set menu to be closed */
    //     if (e.target !== this.toggleButton.nativeElement && e.target !== this.menu.nativeElement) {
    //       this.isInputFocused = false;
    //       this.showOptionsDisplay = false;
    //     }
    //   }
    // });
  }

  ngOnInit() {
    if (this.suggestions) {
      this.suggestions.subscribe(
        data => {
          this.itemList = data;
          /* if (data && data.length < 7) {
            if (this.menu && this.menu.nativeElement) {
              let tbHeight: any = 45;
              if (this.toggleButton && this.toggleButton.nativeElement && this.toggleButton.nativeElement.offsetHeight) {
                tbHeight = this.toggleButton.nativeElement.offsetHeight;
              }
              if (this.label && this.label.length > 0) {
                tbHeight = tbHeight + 32;
              }
              this.menu.nativeElement.style.transform = 'translate3d(0px, ' + tbHeight.toString() + 'px, 0px)';
            }
          } */
        }
      );
    }
  }

  setValue(item: any) {
    // this.inputModel = item.description;
    // this.valueChange.emit(item.id);
    // this.inputModelChange.emit(item.description);
    this.showOptionsDisplay = false;
    this.optionClicked.emit(item);
  }

  isBlock() {
    return this.hasDescription() ? '' : 'block';
  }

  hasDescription() {
    return this.shortDescription && this.shortDescription.length > 0;
  }

  hasError() {
    return this.error ? 'error' : '';
  }

  toggleOptions() {
    if (!this.showOptionsDisplay) {
      this.isInputFocused = true;
      this.showOptionsDisplay = true;
    }
    else {
      this.showOptionsDisplay = false;
      this.isInputFocused = false;
    }
    // this.inputElement.nativeElement.select();
  }
}