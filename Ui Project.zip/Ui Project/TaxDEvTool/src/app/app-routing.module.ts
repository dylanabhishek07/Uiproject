import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppHomeComponent } from './app-home/app-home.component';
import { HomeComponent } from './home/home.component';
import { NewDemandComponent } from './new-demand/new-demand.component';
import { DemandFormLandingS1Component } from './demand-forms/demand-form-landing/demand-form-landing-s1.component';
import { DemandFormLandingS2Component } from './demand-forms/demand-form-landing/demand-form-landing-s2.component';
import { HandoffComponent } from './hand-off/handoff.component';
import { DashboardComponent } from './dashboard/dashboard.component';

const routes: Routes = [
  { path: '', redirectTo: 'appHome', pathMatch: 'full' },
  { path: 'appHome', component: AppHomeComponent },
  { path: 'home', component: HomeComponent },
  { path: 'NewDemand', component: DemandFormLandingS1Component },
  { path: 'NewDemandS2', component: DemandFormLandingS2Component },
  { path: 'handOverS1', component: HandoffComponent },
  { path: 'dashboard', component: DashboardComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule { }
