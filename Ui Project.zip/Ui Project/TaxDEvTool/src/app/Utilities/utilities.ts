import { HttpHeaders } from '@angular/common/http';

export const httpOptions = {
  headers: new HttpHeaders({
    'Content-Type': 'application/json;odata=verbose',
    'Accept': 'application/json;odata=verbose'
  })
};
// export const httpPostOptions = {
//   headers: new HttpHeaders({
//     'Content-Type': 'application/json;odata=verbose;charset=utf-8',
//     'Accept': 'application/json;odata=verbose;charset=utf-8',
//     'X-RequestDigest': (<any>document.getElementById('__REQUESTDIGEST')).value,
//     "IF-MATCH": "*",
//     "X-HTTP-Method": "MERGE",
//   })
//};

// export const httpPostOptions = {
//   headers: new HttpHeaders({
//     'Content-Type': 'application/json;odata=verbose;charset=utf-8',
//     'Accept': 'application/json;odata=verbose;charset=utf-8',
//     'X-RequestDigest': (<any>document.getElementById('__REQUESTDIGEST')).value,
//     "IF-MATCH": "*",
//     "X-HTTP-Method": "MERGE",
//   })
// };

export const httpPostOptions = {
  // headers: new HttpHeaders({
  //   'Content-Type': 'application/json;odata=verbose;charset=utf-8',
  //   'Accept': 'application/json;odata=verbose;charset=utf-8',
  //   'X-RequestDigest': (<any>document.getElementById('__REQUESTDIGEST')).value,    
  //   "X-HTTP-Method": "POST",
  // })
};