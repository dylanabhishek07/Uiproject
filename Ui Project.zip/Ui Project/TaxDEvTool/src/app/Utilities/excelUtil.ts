import { Workbook } from "exceljs";
import { ceil, number } from "mathjs";
import { ExcelDataModel } from "../Models/excelDataModel";
import * as fs from 'file-saver';
import { HttpClient } from "@angular/common/http";
import * as XLSX from 'xlsx';
import { environment } from '../../environments/environment';

export class ExcelUtil{
    static writeToExcelFile(excelDataCollection: ExcelDataModel[], http: HttpClient){
        if(excelDataCollection && excelDataCollection.length>0){
            http.get(environment.report_template_url, {
            responseType: 'arraybuffer',
            headers: { 'content-type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' }
            }).subscribe((response)=>{
                debugger;
                var workBook = XLSX.read(response, {type: 'buffer', bookVBA: true});                
                excelDataCollection.forEach(excelData=>{
                    // Adding data to sheets
                    let dataRowCollection: string[][] = [];
                    for(let i=-1;i<excelData.sheetData.length;i++){
                        let rowDataCollection: string[] = [];
                        excelData.columnInfo.forEach(col=>{
                            if(i===-1){
                                rowDataCollection.push(col.columnHeader);
                            }
                            else{
                                if(excelData.sheetData[i] && excelData.sheetData[i][col.columnFieldName]){
                                    rowDataCollection.push(excelData.sheetData[i][col.columnFieldName]);
                                }
                                else{
                                    rowDataCollection.push("");
                                }
                            }
                        });
                        dataRowCollection.push(rowDataCollection);
                    }
                    // Writing to sheet
                    XLSX.utils.sheet_add_aoa(workBook.Sheets[excelData.sheetName], dataRowCollection, {origin:'A1'});
                    workBook.Sheets[excelData.sheetName]["!cols"] = this.fitToColumn(dataRowCollection);
                    debugger;
                    let newRange = XLSX.utils.encode_range({
                        s: {c: 0, r: 0},
                        e: {c:excelData.columnInfo.length, r: excelData.sheetData.length}
                    });
                    let rangeStart: string = newRange.split(':')[0];
                    let rangeEnd: string = newRange.split(':')[1];

                    let rangeStartColIndex: string = "";
                    let rangeStartRowIndex: string = "";

                    for(let i=0;i<rangeStart.length;i++){
                        if(isNaN(Number(rangeStart[i]))){
                            rangeStartColIndex = rangeStartColIndex+rangeStart[i];
                        }
                        else{
                            rangeStartRowIndex = rangeStartRowIndex+rangeStart[i].toString();
                        }
                    }

                    let rangeEndColIndex: string = "";
                    let rangeEndRowIndex: string = "";

                    for(let i=0;i<rangeEnd.length;i++){
                        if(isNaN(Number(rangeEnd[i]))){
                            rangeEndColIndex = rangeEndColIndex+rangeEnd[i];
                        }
                        else{
                            rangeEndRowIndex = rangeEndRowIndex+rangeEnd[i].toString();
                        }
                    }

                    let namedObjectRange: string = excelData.sheetName+"!$"+rangeStartColIndex+"$"+rangeStartRowIndex+":$"+rangeEndColIndex+"$"+rangeEndRowIndex;
                    let namedObjectName: string = "";
                    switch(excelData.sheetName){
                        case "Dashboard": 
                            namedObjectName = "Table0";
                            break;
                        case "Form1":
                            namedObjectName = "Table1";
                            break;
                        case "Form2":
                            namedObjectName = "Table2";
                            break;
                        case "Form3":
                            namedObjectName = "Table3";
                            break;
                        case "Form4":
                            namedObjectName = "Table4";
                            break;
                        case "Form5":
                            namedObjectName = "Table49";
                            break;
                        case "Form6":
                            namedObjectName = "Table410";       
                            break;
                        case "Form7":
                            namedObjectName = "Table411";       
                            break;
                        case "Form8":
                            namedObjectName = "Table412";       
                            break;
                    }
                    workBook.Workbook.Names.push({
                        Name: namedObjectName,
                        Ref: namedObjectRange
                    });
                });

                

                XLSX.writeFile(workBook, 'out.xlsm', {bookSST: true});
                /* workbook.xlsx.load(response).then(() => {
                    debugger;
                    excelDataCollection.forEach(excelData=>{
                        // Add details to sheet here
                        let worksheet = workbook.getWorksheet(excelData.sheetName);
                        for(let i=-1;i<excelData.sheetData.length;i++){
                            let rowData: string[] = [];
                            excelData.columnInfo.forEach(col=>{
                                if(i===-1){
                                    rowData.push(col.columnHeader);
                                }
                                else{
                                    if(excelData.sheetData[i] && excelData.sheetData[i][col.columnFieldName]){
                                        rowData.push(excelData.sheetData[i][col.columnFieldName]);
                                    }
                                    else{
                                        rowData.push("");
                                    }
                                }
                            });
                            let row = worksheet.addRow(rowData);
                            
                            row.eachCell(cell=>{
                                if(i===-1){
                                    cell.fill = {
                                        type: 'pattern',
                                        pattern: 'solid',
                                        fgColor: {argb: 'C6FA35'}
                                    };
                                    cell.font = {
                                        bold: true
                                    }
                                }
                                cell.border = {
                                    top: {style: 'thin'},
                                    bottom: {style: 'thin'},
                                    left: {style: 'thin'},
                                    right: {style: 'thin'}
                                }
                            })
                        }
                        worksheet.columns.forEach(function (column, i) {
                            var maxLength = 0;
                            column["eachCell"]({ includeEmpty: true }, function (cell) {
                                var columnLength = cell.value ? cell.value.toString().length : 10;
                                if (columnLength > maxLength ) {
                                    maxLength = columnLength;
                                }
                            });
                            column.width = maxLength < 10 ? 10 : maxLength;
                        });
                    });

                    if(workbook.worksheets.length>0){
                        let fileName="summary";
                        workbook.xlsx.writeBuffer().then((data) => {
                            let blob = new Blob([data], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                            fs.saveAs(blob, fileName + '.xlsm');
                        });
                    }
                }); */
            });
        }
    }

    static fitToColumn(arrayOfArray) {
        // get maximum character of each column
        return arrayOfArray[0].map((a, i) => ({ wch: Math.max(...arrayOfArray.map(a2 => a2[i]?a2[i].toString().length: 10)) }));
    }
}