import { evaluate } from "mathjs";

export class Calculations {
    static populateFormula(formula: string, formFields: any[]): string{
        while(formula.indexOf("{{")>-1 || formula.indexOf("}}")>-1){
            let fIndex = formula.indexOf("{{")+2;
            let lIndex = formula.indexOf("}}");
            let fieldName = formula.substring(fIndex, lIndex);
            let fieldValue = formFields.filter(f=>f.fieldName===fieldName)[0].value;
            let fieldValueNumber = 0;
            if(!isNaN(Number(fieldValue))){
              fieldValueNumber = Number(fieldValue);
            }
            formula = formula.replace("{{"+fieldName+"}}", fieldValueNumber.toString());
        }
        return formula;
    }

    static evaluateExpression(expression: string): any {
        let evaluatedNumber = evaluate(expression);
        if(isNaN(evaluatedNumber)){
            return 0;
        }
        return Math.ceil(evaluatedNumber);
    }
}