import { Router } from '@angular/router';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError as observableThrowError, Subject } from 'rxjs';
import { tap, catchError } from 'rxjs/operators';
import { httpOptions,httpPostOptions} from "../Utilities/utilities";

import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})

export class SpapiservicesService {
  group: string;
  arrmail: any[];
  loggeduserEmail: any;
  url: string;
  MiddlemanService: any;

  constructor(private http: HttpClient) { }
  
  public getCurrentUserInfo(): Observable<any> {
    let url = environment.sp_apiBaseUrl + 'web/currentUser';
    return this.http.get(url, httpOptions).pipe(
      tap(() => { }), catchError(this.handleError));
  }

  public checkUserExistsInGroup(): Observable<any> {
    let url = environment.sp_apiBaseUrl + 'web/currentuser/groups';
    return this.http.get(url, httpOptions).pipe(
      tap(() => { }), catchError(this.handleError));
  }

  public getGrouptUserInfo(): Observable<any> {
    this.group='PMDP'
    let url = environment.sp_apiBaseUrl + "web/SiteGroups/GetByName('"+this.group+"')/users";
    return this.http.get(url, httpOptions).pipe(
      tap(() => { }), catchError(this.handleError));
  }

 
  //gets all data for current FY
  public getUtilizationQualityData(listName,router:Router,userEmail?: string): Observable<any> {
    
  //**if url is home or tracker_professionals, filter data by current FY. If counsellor, 
  //**take all data of logged in counsellor and filter by year based on selection on the page.**//
  
    if (router.url.indexOf('counsellors') > -1) {

      this.loggeduserEmail = userEmail;
      this.url = environment.sp_apiBaseUrl + "web/Lists/GetByTitle('"+listName+"')/Items?$select=*,Counsellor/ID,Counsellor/Title,Counsellor/EMail,Employee_x0020_Name/ID,Employee_x0020_Name/Title,Employee_x0020_Name/EMail&$expand=Counsellor,Employee_x0020_Name&$filter=Counsellor/EMail eq '"+this.loggeduserEmail+"'&$top=50000";
      console.log("counsellor url :" + this.url);
      return this.http.get(this.url, httpOptions).pipe(
        tap(() => { }), catchError(this.handleError));
  
  }
  else if(router.url.indexOf('professionals') > -1)
  {
    this.loggeduserEmail = userEmail;
    this.url = environment.sp_apiBaseUrl + "web/Lists/GetByTitle('"+listName+"')/Items?$select=*,Counsellor/ID,Counsellor/Title,Counsellor/EMail,Employee_x0020_Name/ID,Employee_x0020_Name/Title,Employee_x0020_Name/EMail&$expand=Counsellor,Employee_x0020_Name&$filter=Employee_x0020_Name/EMail eq '"+this.loggeduserEmail+"'&$top=50000";
    console.log("counsellor url :" + this.url);
    return this.http.get(this.url, httpOptions).pipe(
      tap(() => { }), catchError(this.handleError));
  }
  else 
  {    
        //calculate FY based on current year and month
   
    var currentYear = new Date().getFullYear();
    var currentMonth = new Date().getMonth();
    if(currentMonth<4)
    {
      var startDate = (Number((new Date()).getFullYear())-1).toString()+'-04-01T00:00:00.000Z';
      var endDate = new Date().toISOString();
    }
    else
    {
      var startDate = (new Date()).getFullYear()+'-04-01T00:00:00.000Z';
      var endDate = new Date().toISOString();
    }
    this.url = environment.sp_apiBaseUrl + "web/Lists/GetByTitle('"+listName+"')/Items?$select=*,Counsellor/ID,Counsellor/Title,Counsellor/EMail,Employee_x0020_Name/ID,Employee_x0020_Name/Title,Employee_x0020_Name/EMail&$expand=Counsellor,Employee_x0020_Name&$filter=(Data_x0020_Uploded_x0020_for_x00 ge datetime'"+startDate+"')and(Data_x0020_Uploded_x0020_for_x00 le datetime'"+endDate+"')&$top=50000";
    console.log("Home Data : "+ this.url);
    return this.http.get(this.url, httpOptions).pipe(
      tap(() => { }), catchError(this.handleError));      
  }
    // let url = environment.sp_apiBaseUrl + "/web/Lists/GetByTitle('"+listName+"')/Items?$select=*,Professional_x0020_Name/ID,Professional_x0020_Name/Title,Manager/ID,Manager/Title,Lead/ID,Lead/Title&$expand=Professional_x0020_Name,Manager,Lead&$top=10000";
    //let url = environment.sp_apiBaseUrl + "/web/Lists/GetByTitle('"+listName+"')/Items?$select=*&$top=10000";
   
  }

  private handleError(error: Response) {
    console.error(error);
    return observableThrowError('Server error');
  }

  
  sendMail(from, to, body, subject):Observable<any>{
    
    let baseUrl= "https://sites.ey.com/sites/IndirectTaxInnovativeIdeas/_api/SP.Utilities.Utility.SendEmail"
    let data= {
      'properties': {
          '__metadata': {
              'type': 'SP.Utilities.EmailProperties'
          },
          'From': from,
          'To': {
              'results': [to]
          },
          'Body': body,
          'Subject': subject
      }
  }
  return this.http.post(baseUrl, data, httpPostOptions);

  }
}




// return this.http.post(baseUrl, data, this.httpOptPost);
