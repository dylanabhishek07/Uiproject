import { spPnpAPIService } from '../Implementations/spPnPAPIService';
import { Injectable } from '@angular/core';
import { Form7Model } from '../../Models/form7model';
import { Observable } from 'rxjs';

@Injectable()
export class Form7SPService {

    constructor(private _spSvc: spPnpAPIService) {

    }

    saveData(form7Data: Form7Model): Observable<any> {
        return this._spSvc.insertListData('Form7DemandList', form7Data);
    }

    updateData(form7Data: Form7Model, id: number): Observable<any> {
        return this._spSvc.updateListData('Form7DemandList', id, form7Data);
    }

    getSavedRecord(id: number): Observable<Form7Model> {
        return this._spSvc.getSingleDataById('Form7DemandList', id);
    }

    getAllListData(): Observable<Form7Model[]> {
        return this._spSvc.getAllListData('Form7DemandList');
    }
}