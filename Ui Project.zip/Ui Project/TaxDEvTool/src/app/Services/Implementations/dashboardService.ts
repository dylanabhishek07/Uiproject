import { spPnpAPIService } from '../Implementations/spPnPAPIService';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { MasterListModel } from 'src/app/Models/masterListModel';
import { _FORM_STAGES, _FORM_STATUS } from 'src/app/Models/formstatus';
import { Form7Model } from 'src/app/Models/form7model';

@Injectable()
export class DashboardSPService{

    constructor(private _spSvc: spPnpAPIService){
      
    }

    getDashboardData(filterType: string = null, filterValue: string = null, stage: string = null): Observable<MasterListModel[]>{
        let filterString = "";
        if(filterType && filterType.length>0 && filterValue && filterValue.length>0){
            if(filterType==="DemandType"){
                filterString = "(DemandType eq '"+filterValue.toString()+"')";
            }
            else if(filterType==="FormStatus"){
                if(stage && stage.length>0){
                    filterString = "((FormStatus eq '"+filterValue.toString()+"') and (Stage eq '"+stage.toString()+"'))";
                }
                else{
                    filterString = "(FormStatus eq '"+filterValue.toString()+"')";
                }
            }
        }

        return this._spSvc.getDataWithExpansion('MasterList',
            ['Form2DemandListLookup', 'Form3DemandListLookup', 'Form4DemandListLookup', 'Form5DemandListLookup', 'Form6DemandListLookup','Form7DemandListLookup', 'TechnicalEstimatesLookup'], 
            ['ID', 'DemandType', 'FormStatus', 'Stage', 'TechnicalEstimatesLookupId', 'FastTrackStatus', 'Form2DemandListLookup/UseCaseName', 'Form2DemandListLookup/CompletionStatus',
             'Form3DemandListLookup/CompletionStatus', 'Form4DemandListLookup/CompletionStatus', 'Form4DemandListLookup/Form4UseCaseName',
             'Form5DemandListLookup/CompletionStatus', 'Form6DemandListLookup/CompletionStatus','Form7DemandListLookup/CompletionStatus', 
             'Created', 'Modified',
             'Form2DemandListLookup/Modified', 'Form3DemandListLookup/Modified',
             'Form4DemandListLookup/Modified', 'Form5DemandListLookup/Modified', 
             'Form6DemandListLookup/Modified', 'TechnicalEstimatesLookup/EffortEstimates', 
             'TechnicalEstimatesLookup/CostEstimates', 'TechnicalEstimatesLookup/ApproximateTimeline',
             'Form7DemandListLookupId'], filterString);
    }

    getPersonalDashboardData(userId: number , userEmail: string): Observable<MasterListModel[]>{
        return this._spSvc.getDataWithExpansion('MasterList',
            ['Form2DemandListLookup', 'Form3DemandListLookup', 'Form4DemandListLookup', 'Form5DemandListLookup', 'Form6DemandListLookup'], 
            ['ID', 'DemandType', 'FormStatus', 'Stage', 'Form2DemandListLookup/UseCaseName', 'Form2DemandListLookup/CompletionStatus',
             'Form3DemandListLookup/CompletionStatus', 'Form4DemandListLookup/CompletionStatus', 'Form4DemandListLookup/Form4UseCaseName',
             'Form5DemandListLookup/CompletionStatus', 'Form6DemandListLookup/CompletionStatus', 
             'Created', 'Modified',
             'Form2DemandListLookup/Modified', 'Form3DemandListLookup/Modified',
             'Form4DemandListLookup/Modified', 'Form5DemandListLookup/Modified', 
             'Form6DemandListLookup/Modified'], "((AuthorId eq '"+userId.toString()+"') or (AssignedToId eq '"+userId.toString()+"') or (Form3SSLsolutionOwnerEmail eq '"+userEmail+"') or (Form3SSLsolutionDeputyEmail eq '"+userEmail+"') or (Form3SSLSponsoringPartnerEmail eq '"+userEmail+"'))");
    }

    getStage1GoNoGoData(): Observable<MasterListModel[]>{
        return this._spSvc.getDataWithExpansion('MasterList',
            ['Form2DemandListLookup', 'AssignedTo'], 
            ['ID', 'DemandType', 'FormStatus', 
             'Form2DemandListLookup/UseCaseName', 
             'AssignedTo/Title', 
             'Created', 'Modified'], "((FormStatus eq '"+_FORM_STATUS.submitted.toString()+"') and (Stage eq '"+_FORM_STAGES.stage1.toString()+"'))");
    }

    getTotalRecordCount(): Observable<number>{
        return this._spSvc.getListItemCount('MasterList');
    }

    getForm7DataForEstimates(masterRowId: Number): Observable<any[]>{
        return this._spSvc.getDataWithExpansion('MasterList',
            ['Form7DemandListLookup'], 
            ['ID', 
            'Form7DemandListLookup/TotalGTERValueByAlwin', 
            'Form7DemandListLookup/FTECostSavings', 
            'Form7DemandListLookup/QualityImprovementCostSavings',
            'Form7DemandListLookup/RiskMitigationCostSavings'], "(ID eq '"+masterRowId+"')");
    }

    getReportData(filterType: string = null, filterValue: string = null, stage: string = null): Observable<MasterListModel[]>{
        let filterString = "";
        if(filterType && filterType.length>0 && filterValue && filterValue.length>0){
            if(filterType==="DemandType"){
                filterString = "(DemandType eq '"+filterValue.toString()+"')";
            }
            else if(filterType==="FormStatus"){
                if(stage && stage.length>0){
                    filterString = "((FormStatus eq '"+filterValue.toString()+"') and (Stage eq '"+stage.toString()+"'))";
                }
                else{
                    filterString = "(FormStatus eq '"+filterValue.toString()+"')";
                }
            }
        }

        return this._spSvc.getDataWithExpansion('MasterList',
            ['Form2DemandListLookup', 'Form3DemandListLookup', 'Form4DemandListLookup', 'Form5DemandListLookup', 'Form6DemandListLookup', 'TechnicalEstimatesLookup'], 
            ['ID', 'DemandType', 'FormStatus', 'Stage', 'TechnicalEstimatesLookupId', 'FastTrackStatus', 'Form2DemandListLookup/UseCaseName', 'Form2DemandListLookup/CompletionStatus',
             'Form3DemandListLookup/CompletionStatus', 'Form4DemandListLookup/CompletionStatus', 'Form4DemandListLookup/Form4UseCaseName',
             'Form5DemandListLookup/CompletionStatus', 'Form6DemandListLookup/CompletionStatus', 
             'Form6DemandListLookup/CompletionStatus',
             'Created', 'Modified',
             'Form2DemandListLookup/Modified', 'Form3DemandListLookup/Modified',
             'Form4DemandListLookup/Modified', 'Form5DemandListLookup/Modified', 
             'Form6DemandListLookup/Modified', 'TechnicalEstimatesLookup/EffortEstimates', 
             'TechnicalEstimatesLookup/CostEstimates', 'TechnicalEstimatesLookup/ApproximateTimeline',
             'Form7DemandListLookupId','Form2DemandListLookupId','Form3DemandListLookupId','Form4DemandListLookupId',
             'Form5DemandListLookupId','Form6DemandListLookupId'], filterString);
    }
}