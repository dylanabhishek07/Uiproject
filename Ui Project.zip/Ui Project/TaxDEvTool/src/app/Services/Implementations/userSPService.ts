import * as pnp from 'sp-pnp-js';
import { environment } from '../../../environments/environment'
import { Injectable } from '@angular/core';
import { Observable} from 'rxjs';
import { from } from 'rxjs';

@Injectable()
export class UserSPService {
    getUserByEmail(keyword: string): Observable<any[]>{
        return from(new pnp.Web(environment.sp_url).siteUsers
            .select('Id', 'LoginName', 'Title', 'Email')
            .filter('startswith(Title, '+keyword+')').get().then(data=>{
                return data;
        }));
    }

    getAllUsers(): Observable<any[]>{
        return from(new pnp.Web(environment.sp_url).siteUsers
            .select('Id', 'LoginName', 'Title', 'Email').get().then(data=>{
                return data;
        }));
    }
}