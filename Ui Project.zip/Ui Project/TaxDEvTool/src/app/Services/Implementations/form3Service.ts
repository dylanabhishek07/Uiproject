import { spPnpAPIService } from '../Implementations/spPnPAPIService';
import { Injectable } from '@angular/core';
import { Form3Model } from '../../Models/form3model';
import { Observable } from 'rxjs';

@Injectable()
export class Form3SPService{

    constructor(private _spSvc: spPnpAPIService){
      
    }

    saveData(form3Data: Form3Model): Observable<any>{
        return this._spSvc.insertListData('Form3DemandList', form3Data);
    }

    updateData(form3Data: Form3Model, id:number): Observable<any>{
        return this._spSvc.updateListData('Form3DemandList', id, form3Data);
    }
    getSavedRecord(id: number): Observable<Form3Model>{
        return this._spSvc.getSingleDataById('Form3DemandList', id);
    }

//     getSavedRecord(id: number): Observable<Form3Model>{
//         return this._spSvc.getSingleDataByIdWithExpansion('Form3DemandList', id, 
//         ['SSLSponsoringPartnerName','SSLsolutionOwnerName', 'SSLsolutionDeputyName'],
//         ['*', 'SSLSponsoringPartnerName/Title', 'SSLsolutionOwnerName/Title', 'SSLsolutionDeputyName/Title']);
//     }

    getAllListData(): Observable<Form3Model[]>{
        return this._spSvc.getAllListData('Form3DemandList');
    }
}