import { Injectable } from '@angular/core';
import { Observable, of} from 'rxjs';

@Injectable()
export class UserMockSPService {
    getUserByEmail(keyword: string): Observable<any[]>{
        return of([{
            Id: '1',
            Title: 'Supratim Gupta',
            Email: 'Supratim.Gupta@gds.ey.com'
        }]);
    }

    getAllUsers(): Observable<any[]>{
        return of([{
            Id: '1',
            Title: 'Supratim Gupta',
            Email: 'Supratim.Gupta@gds.ey.com'
        }]);
    }
}