import { spPnpAPIService } from '../Implementations/spPnPAPIService';
import { Injectable } from '@angular/core';
import { Form6Model } from '../../Models/form6model';
import { Observable } from 'rxjs';

@Injectable()
export class Form6SPService{

    constructor(private _spSvc: spPnpAPIService){
      
    }

    saveData(form3Data: Form6Model): Observable<any>{
        return this._spSvc.insertListData('Form6DemandList', form3Data);
    }

    updateData(form3Data: Form6Model, id:number): Observable<any>{
        return this._spSvc.updateListData('Form6DemandList', id, form3Data);
    }

    getSavedRecord(id: number): Observable<Form6Model>{
        return this._spSvc.getSingleDataById('Form6DemandList', id);
    }

    getAllListData(): Observable<Form6Model[]>{
        return this._spSvc.getAllListData('Form6DemandList');
    }
}