import { Form4Component } from '../../demand-forms/forms/form4.component';
import { spPnpAPIService } from './spPnPAPIService';
import { Injectable } from '@angular/core';
import { Form5Model } from '../../Models/form5model';
import { Observable } from 'rxjs';

@Injectable()
export class Form5SPService{

    constructor(private _spSvc: spPnpAPIService){
      
    }
    saveData(form5Data: Form5Model): Observable<any>{
        return this._spSvc.insertListData('Form5DemandList', form5Data);
    }

    updateData(form5Data: Form5Model, id:number): Observable<any>{
        return this._spSvc.updateListData('Form5DemandList', id, form5Data);
    }

    getSavedRecord(id: number): Observable<Form5Model>{
        return this._spSvc.getSingleDataById('Form5DemandList', id);
    }

    getAllListData(): Observable<Form5Model[]>{
        return this._spSvc.getAllListData('Form5DemandList');
    }
}