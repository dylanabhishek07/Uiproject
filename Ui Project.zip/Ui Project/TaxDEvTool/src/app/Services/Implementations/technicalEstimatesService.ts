import { spPnpAPIService } from '../Implementations/spPnPAPIService';
import { Injectable } from '@angular/core';
import { TechnicalEstimatesModel } from '../../Models/technicalEstimatesModel';
import { Observable } from 'rxjs';

@Injectable()
export class TechnicalEstimatesSPService{

    constructor(private _spSvc: spPnpAPIService){
      
    }

    saveData(estimates: TechnicalEstimatesModel): Observable<any>{
        return this._spSvc.insertListData('TechnicalEstimates', estimates);
    }

    updateData(estimates: TechnicalEstimatesModel, id:number): Observable<any>{
        return this._spSvc.updateListData('TechnicalEstimates', id, estimates);
    }

    getSavedRecord(id: number): Observable<TechnicalEstimatesModel>{
        return this._spSvc.getSingleDataById('TechnicalEstimates', id);
    }
}