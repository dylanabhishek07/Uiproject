import { iSPApiServiceContract } from '../Contracts/iSPApiServiceConract';
import * as pnp from 'sp-pnp-js';
import { environment } from '../../../environments/environment'
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { from } from 'rxjs';

@Injectable()
export class spPnpAPIService implements iSPApiServiceContract {
    getAllListData(listName: string): Observable<any> {
        return from(new pnp.Web(environment.sp_url).lists.getByTitle(listName).items.getAll().then(data => {
            return data;
        }));
    }
    updateListData(listName: string, id: number, updatedData: any): Observable<any> {
        return from(new pnp.Web(environment.sp_url).lists.getByTitle(listName)
            .items.getById(id).update(updatedData).then(data => {
                return data;
            }));
    }
    getSingleDataById(listName: string, id: number): Observable<any> {
        return from(new pnp.Web(environment.sp_url).lists.getByTitle(listName)
            .items.getById(id).get().then(data => {
                return data;
            }));
    }
    insertListData(listName: string, data: any): Observable<any> {
        return from(new pnp.Web(environment.sp_url).lists.getByTitle(listName)
            .items.add(data).then(data => {
                return data;
            }));
    }
    getSingleDataByIdWithExpansion(listName: string, id: number, expandList: string[], selectList: string[]): Observable<any> {
        return from(new pnp.Web(environment.sp_url).lists.getByTitle(listName)
            .items.getById(id).expand(...expandList).select(...selectList).get().then(data => {
                return data;
            }));
    }

    uploadFileToDocumentLibrary(docLibraryName: string, fileName: string,
        fileBuffer: Blob, saveInRoot: boolean = true, folderName: string = ""): Observable<any> {
        if (saveInRoot) {
            return from(new pnp.Web(environment.sp_url).lists.getByTitle(docLibraryName).rootFolder
                .files.add(fileName, fileBuffer, true)
                .then(data => {
                    return data;
                }));
        }
        else {
            return from(new pnp.Web(environment.sp_url).lists.getByTitle(docLibraryName).rootFolder
                .folders.getByName(folderName).files.add(fileName, fileBuffer, true)
                .then(data => {
                    return data;
                }));
        }

    }

    deleteFileToDocumentLibrary(fileRelativeUrl: string)
        : Observable<any> {
        return from(new pnp.Web(environment.sp_url).getFileByServerRelativeUrl(fileRelativeUrl).delete().then(data => {
            return data;
        }));
    }


    getDataWithExpansion(listName: string, expandList: string[], selectList: string[], filter: string = ""): Observable<any[]> {
        if (filter === "") {
            return from(new pnp.Web(environment.sp_url).lists.getByTitle(listName)
                .items.expand(...expandList).select(...selectList).get().then(data => {
                    return data;
                }));
        }
        else {
            return from(new pnp.Web(environment.sp_url).lists.getByTitle(listName)
                .items.expand(...expandList).select(...selectList).filter(filter).get().then(data => {
                    return data;
                }));
        }
    }

    getCurrentUserGroups(): Observable<any> {
        return from(new pnp.Web(environment.sp_url).currentUser.expand('groups').get().then(data => {
            return data;
        }));
    }

    getListItemCount(listName: string): Observable<number> {
        return from(new pnp.Web(environment.sp_url).lists.getByTitle(listName)
            .get().then(result => {
                return result.ItemCount;
            }));
    }

    getItemVersions(listName: string, id: number): Observable<any> {
        return from(new pnp.Web(environment.sp_url).lists.getByTitle(listName)
            .items.getById(id).versions.get().then(data => {
                return data;
            }));
    }
}