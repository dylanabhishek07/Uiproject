import { spPnpAPIService } from '../Implementations/spPnPAPIService';
import { Injectable } from '@angular/core';
import { MasterListModel } from '../../Models/masterListModel';
import { Observable } from 'rxjs';

@Injectable()
export class MasterListService{

    constructor(private _spSvc: spPnpAPIService){

    }

    saveData(masterListData: MasterListModel): Observable<any>{
        return this._spSvc.insertListData('MasterList', masterListData);
    }

    updateData(masterListData: MasterListModel, id:number): Observable<any>{
        return this._spSvc.updateListData('MasterList', id, masterListData);
    }

    getSavedRecord(id: number): Observable<MasterListModel>{
        return this._spSvc.getSingleDataById('MasterList', id);
    }

    getFormsCompletionStatus(masterId: number): Observable<MasterListModel>{
        return this._spSvc.getSingleDataByIdWithExpansion('MasterList', masterId,
            ['Form2DemandListLookup', 'Form3DemandListLookup', 'Form4DemandListLookup', 'Form5DemandListLookup', 'Form6DemandListLookup'], 
            ['Form2DemandListLookup/CompletionStatus',
             'Form3DemandListLookup/CompletionStatus', 'Form4DemandListLookup/CompletionStatus',
             'Form5DemandListLookup/CompletionStatus', 'Form6DemandListLookup/CompletionStatus']);
    }

    getVersionHistory(masterId: number): Observable<MasterListModel[]>{
        return this._spSvc.getItemVersions('MasterList', masterId);
    }
}