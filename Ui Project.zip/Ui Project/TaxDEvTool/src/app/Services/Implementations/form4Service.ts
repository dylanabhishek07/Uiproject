import { Form4Component } from './../../demand-forms/forms/form4.component';
import { spPnpAPIService } from '../Implementations/spPnPAPIService';
import { Injectable } from '@angular/core';
import { Form4Model } from '../../Models/form4model';
import { Observable } from 'rxjs';

@Injectable()
export class Form4SPService{

    constructor(private _spSvc: spPnpAPIService){
      
    }
    saveData(form4Data: Form4Model): Observable<any>{
        return this._spSvc.insertListData('Form4DemandList', form4Data);
    }

    updateData(form4Data: Form4Model, id:number): Observable<any>{
        return this._spSvc.updateListData('Form4DemandList', id, form4Data);
    }

    getSavedRecord(id: number): Observable<Form4Model>{
        return this._spSvc.getSingleDataById('Form4DemandList', id);
    }

    getAllListData(): Observable<Form4Model[]>{
        return this._spSvc.getAllListData('Form4DemandList');
    }
}