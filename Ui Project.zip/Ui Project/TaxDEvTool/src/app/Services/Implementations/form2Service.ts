import { spPnpAPIService } from '../Implementations/spPnPAPIService';
import { Injectable } from '@angular/core';
import { Form2Model } from '../../Models/form2model';
import { Observable } from 'rxjs';

@Injectable()
export class Form2SPService{

    constructor(private _spSvc: spPnpAPIService){
      
    }

    saveData(form2Data: Form2Model): Observable<any>{
        return this._spSvc.insertListData('Form2DemandList', form2Data);
    }

    updateData(form2Data: Form2Model, id:number): Observable<any>{
        return this._spSvc.updateListData('Form2DemandList', id, form2Data);
    }

    getSavedRecord(id: number): Observable<Form2Model>{
        return this._spSvc.getSingleDataById('Form2DemandList', id);
    }

    getAllListData(): Observable<Form2Model[]>{
        return this._spSvc.getAllListData('Form2DemandList');
    }
}