import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DatastorageService {

  public dataLMU: any = [];
  public dataLME: any = [];
  public dataLMA: any = [];

  public dataLTMU: any = [];
  public dataLTME: any = [];
  public dataLTMQ: any = [];
  public dataLTMA: any = [];

  public dataLTTMU: any = [];
  public dataLTTME: any = [];
  public dataLTTMQ: any = [];
  public dataLTTMA: any = [];

  public dataYTDU: any = [];
  public dataYTDE: any = [];
  public dataYTDA: any = [];

  dataLMTQ: any = [];
  dataLMNQ: any = [];
  dataLMWQ: any = [];
  //dataYTDQ: any = [];
  dataLTMTRQ: any = [];
  dataLTMNRQ: any = [];
  dataLTMWGQ: any = [];

  dataLTTMTR: any = [];
  dataLTTMNR: any = [];
  dataLTTMWG: any = [];
  //
  dataYTDTRQ: any = [];
  dataYTDNRQ: any = [];
  dataYTDWGQ: any = [];
  dataLMTAT: any = [];
  dataLTMTAT: any = [];
  dataLTTTAT: any = [];
  
  dataYTDTAT: any = [];

  
  
 
  setdata(value,Valueid){
    if (Valueid == "LMU"){
      this.dataLMU = value;
    }
    else if (Valueid == "LME"){
      this.dataLME = value;
    }
    else if (Valueid == "LMA"){
      this.dataLMA = value;
    }
    //
    else if (Valueid == "LTMU"){
      this.dataLTMU = value;
    }
    else if (Valueid == "LTME"){
      this.dataLTME = value;
    }
    else if (Valueid == "LTMA"){
      this.dataLTMA = value;
    }
    //
   
    else if (Valueid == "LTTMU"){
      this.dataLTTMU = value;
    }
    else if (Valueid == "LTTME"){
      this.dataLTTME = value;
    }
    else if (Valueid == "LTTMA"){
      this.dataLTTMA = value;
    }
    //
    else if (Valueid == "YTDU"){
      this.dataYTDU = value;
    }
    else if (Valueid == "YTDE"){
      this.dataYTDE = value;
    }
    else if (Valueid == "YTDA"){
      this.dataYTDA = value;
    }
    //
    else if (Valueid == "LMTQ"){
      this.dataLMTQ = value;
    }
    else if (Valueid == "LMNQ"){
      this.dataLMNQ = value;
    }
    else if (Valueid == "LMWQ"){
      this.dataLMWQ = value;
    }
    //
    else if (Valueid == "LTMTRQ"){
      this.dataLTMTRQ = value;
    }
    else if (Valueid == "LTMNRQ"){
      this.dataLTMNRQ = value;
    }
    else if (Valueid == "LTMWGQ"){
      this.dataLTMWGQ = value;
    }
    //
    else if (Valueid == "LTTMTR"){
      this.dataLTTMTR = value;
    }
    else if (Valueid == "LTTMNR"){
      this.dataLTTMNR = value;
    }
    else if (Valueid == "LTTMWG"){
      this.dataLTTMWG = value;
    }
    //
    else if (Valueid == "YTDTRQ"){
      this.dataYTDTRQ = value;
    }
    else if (Valueid == "YTDNRQ"){
      this.dataYTDNRQ = value;
    }
    else if (Valueid == "YTDWGQ"){
      this.dataYTDWGQ = value;
    }
    //
    else if (Valueid == "LMTAT"){
      this.dataLMTAT = value;
    }
    else if (Valueid == "LTMTAT"){
      this.dataLTMTAT= value;
    }
    else if (Valueid == "LTTTAT"){
      this.dataLTTTAT= value;
    }
    //
    else if (Valueid == "YTDTAT"){
      this.dataYTDTAT= value;
    }
    
    
    
    

    
    
  }

  getdata(getvalueid){
    if (getvalueid == "LMU"){
      return this.dataLMU;
    }
    else if (getvalueid == "LME"){
      return this.dataLME;
    }
    else if (getvalueid == "LMA"){
      return this.dataLMA;
    }
    //
    else if (getvalueid == "LTMU"){
      return this.dataLTMU;
    }
    else if (getvalueid == "LTME"){
      return this.dataLTME;
    }
    else if (getvalueid == "LTMA"){
      return this.dataLTMA;
    }
    //
    else if (getvalueid == "LTTMU"){
      return this.dataLTTMU;
    }
    else if (getvalueid == "LTTME"){
      return this.dataLTTME;
    }
    else if (getvalueid == "LTTMA"){
      return this.dataLTTMA;
    }

    else if (getvalueid == "YTDU"){
      return this.dataYTDU;
    }
    else if (getvalueid == "YTDE"){
      return this.dataYTDE;
    }
    else if (getvalueid == "YTDA"){
      return this.dataYTDA;
    }
    //

    else if (getvalueid == "LMTQ"){
      return this.dataLMTQ;
    }
    else if (getvalueid == "LMNQ"){
      return this.dataLMNQ;
    }
    else if (getvalueid == "LMWQ"){
      return this.dataLMWQ;
    }
    //
    else if (getvalueid == "LTMTRQ"){
      return this.dataLTMTRQ;
    }
    else if (getvalueid == "LTMNRQ"){
      return this.dataLTMNRQ;
    }
    else if (getvalueid == "LTMWGQ"){
      return this.dataLTMWGQ;
    }
    //
   
    else if (getvalueid == "LTTMTR"){
      return this.dataLTTMTR;
    }
    else if (getvalueid == "LTTMNR"){
      return this.dataLTTMNR;
    }
    else if (getvalueid == "LTTMWG"){
      return this.dataLTTMWG;
    }
    //
    else if (getvalueid == "YTDTRQ"){
      return this.dataYTDTRQ;
    }
    else if (getvalueid == "YTDNRQ"){
      return this.dataYTDNRQ;
    }
    else if (getvalueid == "YTDWGQ"){
      return this.dataYTDWGQ;
    }
    //
    else if (getvalueid == "LMTAT"){
      return this.dataLMTAT;
    }
    else if (getvalueid == "LTMTAT"){
      return this.dataLTMTAT;
    }
    else if (getvalueid == "LTTTAT"){
      return this.dataLTTTAT;
    }
    //
    else if (getvalueid == "YTDTAT"){
      return this.dataYTDTAT;
    }



    
    
    

  }

  constructor() { }
}



// else if (getvalueid == "LTMQ"){
    //   return this.dataLTMQ;
    // }

    // else if (Valueid == "LTMQ"){
    //   this.dataLTMQ = value;
    // }

