import { Observable} from 'rxjs';

export interface iSPApiServiceContract{
    getAllListData(listName: string): Observable<any>;
    getSingleDataById(listName: string, id: number): Observable<any>;
    updateListData(listName: string, id: number, updatedData: any): Observable<any>;
    insertListData(listName: string, data: any): Observable<any>;
    getSingleDataByIdWithExpansion(listName: string, id: number, expandList: string[], selectList: string[]): Observable<any>;
    uploadFileToDocumentLibrary(docLibraryName: string, fileName: string, fileBuffer: Blob);
    getDataWithExpansion(listName: string, expandList: string[], selectList: string[]): Observable<any[]>;
    getCurrentUserGroups(): Observable<any>;
    getListItemCount(listName: string): Observable<number>;
    getItemVersions(listName: string, id: number): Observable<any>;
    deleteFileToDocumentLibrary(fileRelativeUrl : string) : Observable<any>;
}