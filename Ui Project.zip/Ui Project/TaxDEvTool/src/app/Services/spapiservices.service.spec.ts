import { TestBed } from '@angular/core/testing';

import { SpapiservicesService } from './spapiservices.service';

describe('SpapiservicesService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: SpapiservicesService = TestBed.get(SpapiservicesService);
    expect(service).toBeTruthy();
  });
});
