import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { User } from '../models/user';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  private _userInfo = new BehaviorSubject<User>(null);

  constructor(private http: HttpClient) { }

  setBehaviorView(user: User) { 
    this._userInfo.next(user); 
}

getBehaviorView(): Observable<User> { 
    return this._userInfo.asObservable(); 
}

getUserDetailsByEmail(emailId){
    
}
}