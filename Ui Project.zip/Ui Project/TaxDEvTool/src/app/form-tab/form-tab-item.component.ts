import { Component, OnInit, OnChanges, Input, Output, EventEmitter, Renderer2, ViewChild, ElementRef, ViewEncapsulation, Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import {ChildFormDetails} from '../Models/childformdetails';

@Component({
    selector: 'form-tab-item',
    templateUrl: './form-tab-item.component.html',
    styleUrls: ['./form-tab.css'],
    encapsulation: ViewEncapsulation.None
})



export class FormTabItemComponent implements OnInit {
    
    @Input()
    formName: string = "";

    @Input()
    formDescription: string = "";

    @Input()
    childFormDetails: ChildFormDetails[] = [];

    @Input()
    isFormTabSelected: boolean = false;

    currentProgress: number = 0;

    @Input()
    showChildItems: boolean = false;

    @Input()
    showInProgressBar: boolean = false;
    showForm1: boolean;
    showForm2: boolean;
    showForm3: boolean;
    showForm4: boolean;
    showForm5: boolean;   

    constructor(private route: Router) {
       
    }

    ngOnInit(){
        this.updateProgressIndicator();
    }

    getProgress(){
        this.updateProgressIndicator();
        return this.currentProgress;
    }

    updateProgressIndicator(){
        if(this.childFormDetails && this.childFormDetails.length>0){
            let completedSteps: number = this.childFormDetails.filter(c=>c.childFormStatus==="completed").length;
            if(completedSteps === this.childFormDetails.length){
                this.currentProgress = 100;
            }
            else if(this.showInProgressBar){
                let completedSteps: number = this.childFormDetails.filter(c=>c.childFormStatus==="completed").length;
                let volumePerItem: number = Math.round(100/this.childFormDetails.length);
                this.currentProgress = completedSteps * volumePerItem;
            }

            this.childFormDetails.forEach(f=>{
                switch(f.childFormStatus){
                    case "completed":
                        f.childFormStatusDisplay = "Completed";
                        break;
                    case "inprogress":
                        f.childFormStatusDisplay = "In Progress";
                        break;
                    default:
                        f.childFormStatusDisplay = "Not Started";
                        break;
                }
            });
        }
        else{
            this.currentProgress = 100;
        }
    }
}

