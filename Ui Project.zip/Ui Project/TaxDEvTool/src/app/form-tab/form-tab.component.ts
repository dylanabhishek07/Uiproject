import { Component, OnInit, Input, Output, EventEmitter, Renderer2, ViewChild, ElementRef } from '@angular/core';
import {_DEFAULT_FORM} from '../Models/form-schema';

@Component({
    selector: 'form-tab',
    templateUrl: './form-tab.component.html',
    styleUrls: ['./form-tab.css']
})

export class FormTabComponent implements OnInit {
    @Input()
    forms: any [] = [];
    @Output()
    formTabClick = new EventEmitter<string>();
    ngOnInit(){
        if(!this.forms || this.forms.length===0){
            this.forms = _DEFAULT_FORM.stage1;
        }
    }

    setFormActive(form){
        this.forms.forEach(f=>{
            if(f.formId===form.formId){
                f.isFormTabSelected = true;
            }
            else{
                f.isFormTabSelected = false;
            }
        });
        this.formTabClick.emit(form.formId);
    }

    isFormComplete(form){
        if(form.childFormDetails && form.childFormDetails.length>0){
            let allCompletedChildForms = form.childFormDetails.filter(c=>c.childFormStatus==="completed").length;
            if(allCompletedChildForms === form.childFormDetails.length){
                return true;
            }
            return false;
        }
    }

}

