import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormTabComponent } from './form-tab.component';
import { FormTabItemComponent } from './form-tab-item.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [FormTabComponent, FormTabItemComponent],
  imports: [CommonModule, FormsModule],
  exports: [FormTabComponent, FormTabItemComponent]
})
export class FormTabModule { }
