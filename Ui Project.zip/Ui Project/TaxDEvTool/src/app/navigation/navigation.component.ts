import { Component, OnInit, Input } from '@angular/core';
import { TaxLabNav } from '../../assets/taxLabNav';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.css'] 
})
export class NavigationComponent implements OnInit {

  @Input() navItem: any;
  

  public navigation_Data: any;
  
  NavigationHeaders = Object.keys;

  constructor() { }

  ngOnInit() {
    
    this.navigation_Data = TaxLabNav;
   

  }

  ngOnChanges(){
    
    
  }
  checkIfObject(item) {
    if (typeof item == 'object')
      return true;
    else
      return false;

  }

  clientChange() {
  
  }

}



