import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { SpapiservicesService } from '../Services/spapiservices.service';
import { distinct } from '@progress/kendo-data-query';
import { DatastorageService } from '../Services/datastorage.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { UserServiceService } from 'src/Services/user-service.service';
import { User } from 'src/Models/user';
import { DashboardSPService } from '../Services/Implementations/dashboardService';
import { MasterListModel } from '../Models/masterListModel';
import {_DEFAULT_FIELDS} from '../Models/form-fields';
import {_DEFAULT_FORM} from '../Models/form-schema';
import { spPnpAPIService } from '../Services/Implementations/spPnPAPIService';
import { _FORM_STAGES, _FORM_STATUS } from '../Models/formstatus';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
  providers: [DashboardSPService]
})
    

export class HomeComponent implements OnInit {

 
  _userInfo = new User;
  radio1: string;
  dashboardData: any[] = [];
  // isShowDashboardItemMenu: boolean = false;
  isDemandTypeSelected: boolean = false;

  constructor(private spdata: SpapiservicesService, 
    private homedata: DatastorageService, 
    private SpinnerService: NgxSpinnerService,
    private router:Router,private sp: SpapiservicesService, 
    private _spSvc: spPnpAPIService,
    private UserService: UserServiceService, private _dashboardSvc: DashboardSPService) { 
    
  }

 onChange()
 {
  this.isDemandTypeSelected = true;
 }

  ngOnInit() {

    // setTimeout(()=>{
    //   this.routeTo_Url();
    // })

    if (window.location.href.indexOf("localhost") == -1) {
      this.sp.getCurrentUserInfo().subscribe({
        next: currentUserinfo => {
          this._userInfo.id = currentUserinfo.d.Id;
          this._userInfo.displayName = currentUserinfo.d.Title;
          this._userInfo.userphotosrc = environment.sp_url + "_layouts/15/userphoto.aspx?size=S&accountname=" + currentUserinfo.Email;
          this._userInfo.emailId = currentUserinfo.d.Email;
          this.UserService.setBehaviorView(this._userInfo);
          this.getPersonalizedDashboardView();
        }
      });
    }
    else {
      this._userInfo.id = '17';
      this._userInfo.displayName = 'Anjana Sudev';
      this._userInfo.userphotosrc = '';
      this._userInfo.emailId = 'Anjana.Sudev@gds.ey.com';
      this.UserService.setBehaviorView(this._userInfo);
      this.getPersonalizedDashboardView();
    }

}

getPersonalizedDashboardView(){
  this._dashboardSvc.getPersonalDashboardData(this._userInfo.id, this._userInfo.emailId).subscribe(data=>{
    if(data && data.length>0){
      data.forEach(item=>{
        let useCaseName: string = "";
        if(item.DemandType==="New Geography for existing use case / product"){
          useCaseName = (item.Form4DemandListLookup && item.Form4DemandListLookup.Form4UseCaseName) ? item.Form4DemandListLookup.Form4UseCaseName: "";
        }
        else{
          useCaseName = (item.Form2DemandListLookup && item.Form2DemandListLookup.UseCaseName) ? item.Form2DemandListLookup.UseCaseName : "";
        }
        this.dashboardData.push({
          isShowDashboardItemMenu: false,
          ID: item["ID"],
          UseCaseName: useCaseName,
          Form2Status: item.Form2DemandListLookup? item.Form2DemandListLookup.CompletionStatus: "Not Started",
          Form3Status: item.Form3DemandListLookup? item.Form3DemandListLookup.CompletionStatus: "Not Started",
          Form4Status: item.Form4DemandListLookup? item.Form4DemandListLookup.CompletionStatus: "Not Started",
          Form5Status: item.Form5DemandListLookup? item.Form5DemandListLookup.CompletionStatus: "Not Started",
          Form6Status: item.Form6DemandListLookup? item.Form6DemandListLookup.CompletionStatus: "Not Started",
          StartDate: item["Created"]? new Date(item["Created"]).toLocaleDateString():"",
          LastEdited: this.calculateLastEdited(item),
          DemandType: item["DemandType"],
          FormStatus: item.FormStatus,
          Stage: item.Stage
        });
      });

      // Changed for view logic of demand forms
      if(this.dashboardData && this.dashboardData.length>0){
        let changedForDTs = ["New use case / product", "Integration / globalisation of existing product"];
        this.dashboardData.forEach(item=>{
          if(item.DemandType && item.DemandType.length>0 && changedForDTs.indexOf(item.DemandType)>-1){
            item.Form4Status = item.Form5Status;
            item.Form5Status = item.Form6Status;
          }
          else{
            item.Form2Status = item.Form4Status;
            item.Form3Status = "N/A";
            item.Form4Status = item.Form5Status;
            item.Form5Status = item.Form6Status;
          }
        });
      }
    }
  });
}

redirect(redirectType, masterId, demandType, formStatus, stage){
  localStorage.setItem('masterRecordId', masterId);
  // clearing all default field values
  this.clearAllFormData();
  let stageString = _FORM_STAGES.stage1;
  if(formStatus===_FORM_STATUS.approved && stage===_FORM_STAGES.stage1){
    stageString = _FORM_STAGES.stage2;
    formStatus = _FORM_STATUS.inProgress;
  }
  else if(stage===_FORM_STAGES.stage2){
    stageString = _FORM_STAGES.stage2;
  }
  this.router.navigate(['./NewDemand'], { 
    state: { selectedVal: demandType, formStatus: formStatus, stage: stageString } 
  });
}

calculateLastEdited(item: MasterListModel): string{
  if(!item){
    return "";
  }
  let dateArray: Date[] = [];
  dateArray.push(item["Modified"]);
  if(item.Form2DemandListLookup && item.Form2DemandListLookup.Modified){
    dateArray.push(new Date(item.Form2DemandListLookup.Modified));
  }
  if(item.Form3DemandListLookup && item.Form3DemandListLookup.Modified){
    dateArray.push(new Date(item.Form3DemandListLookup.Modified));
  }
  if(item.Form4DemandListLookup && item.Form4DemandListLookup.Modified){
    dateArray.push(new Date(item.Form4DemandListLookup.Modified));
  }
  if(item.Form5DemandListLookup && item.Form5DemandListLookup.Modified){
    dateArray.push(new Date(item.Form5DemandListLookup.Modified));
  }
  if(item.Form6DemandListLookup && item.Form6DemandListLookup.Modified){
    dateArray.push(new Date(item.Form6DemandListLookup.Modified));
  }

  var maxDate= dateArray.reduce(function (a, b) { return new Date(a) > new Date(b) ? new Date(a) : new Date(b); });;
  return new Date(maxDate).toLocaleDateString();
}

routeToUrl(selection){
  localStorage.setItem('masterRecordId', '');
  // clearing all default field values
  this.clearAllFormData();
  this.router.navigate(['./NewDemand'], { 
    state: { selectedVal: selection, formStatus: _FORM_STATUS.inProgress, stage: _FORM_STAGES.stage1 } 
  });
}

clearAllFormData(){
  _DEFAULT_FIELDS.stage1.forEach(form=>{
    form.fields.forEach(field=>{
      field.value = "";
    });
  });
  _DEFAULT_FIELDS.stage2.forEach(form=>{
    form.fields.forEach(field=>{
      field.value = "";
    });
  });
  _DEFAULT_FORM.stage1.forEach(form=>{
    form.childFormDetails.forEach(cForm=>{
      cForm.childFormStatus = 'notstarted';
    });
  });
  _DEFAULT_FORM.stage2.forEach(form=>{
    form.childFormDetails.forEach(cForm=>{
      cForm.childFormStatus = 'notstarted';
    });
  });
}

toggleMenu(dataItem){
  this.dashboardData.forEach(item=>{
    item.isShowDashboardItemMenu = item.isShowDashboardItemMenu ? false : false;
  });
  if(dataItem.isShowDashboardItemMenu){
    dataItem.isShowDashboardItemMenu = false;
  }
  else{
    dataItem.isShowDashboardItemMenu = true;
  }
}

// routeTo_Url(){
//   this._spSvc.getCurrentUserGroups().subscribe(data=>{
//     let taxlab_sp_group = environment.tax_lab_sp_group.toLowerCase();
//     let filteredGroup = data.Groups.filter(g=>g.Title.toLowerCase()===taxlab_sp_group);
//     if(filteredGroup && filteredGroup.length>0){
//       this.router.navigate(['./dashboard']);
//     }
//     else{
//       this.router.navigate(['./home']);
//     }
//   });
// }
}