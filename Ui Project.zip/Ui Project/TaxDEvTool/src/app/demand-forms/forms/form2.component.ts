import { Router } from '@angular/router';
import { AfterViewInit, Component, ElementRef, EventEmitter, Input, OnInit, Output, Renderer2, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { guid } from '@progress/kendo-angular-common';
import { _FORM_NAMES } from 'src/app/Models/form-names';
import { Form2Model } from '../../Models/form2model';
import { MasterListModel } from '../../Models/masterListModel';
import { Form2SPService } from '../../Services/Implementations/form2Service';
import { MasterListService } from '../../Services/Implementations/masterListService';
import { Jurisdiction } from 'src/app/Models/jurisdiction';
import { _FORM_STATUS } from 'src/app/Models/formstatus';
import { _FORM_STAGES } from 'src/app/Models/formstatus';


@Component({
  selector: 'form-2',
  templateUrl: './form2.component.html',
  encapsulation: ViewEncapsulation.None,
  providers: [Form2SPService, MasterListService],
  styleUrls: ['./forms.css']
})
export class Form2Component implements OnInit {

  more: boolean;
  moreA: boolean;
  dropdownVal: string;
  dropdownVal1: string;
  @Output()
  formSaveClick = new EventEmitter<string>();
  form2Validation: any = {};
 

  // @ViewChild('dropdownDivSpriority',{static:false}) dropdownDivSpriority: ElementRef;
  // @ViewChild('dropdownDivService',{static:false}) dropdownDivService: ElementRef;


  constructor(private renderer: Renderer2, private _form2Svc: Form2SPService, private _masterListSvc: MasterListService, private router: Router) {
    //   this.renderer.listen('window', 'click',(e:Event)=>{
    //     /**
    //      * Only run when toggleButton is not clicked
    //      * If we don't check this, all clicks (even on the toggle button) gets into this
    //      * section which in the result we might never see the menu open!
    //      * And the menu itself is checked here, and it's where we check just outside of
    //      * the menu and button the condition abbove must close the menu
    //      */
    //     if(!this.dropdownDivService.nativeElement.contains(e.target)) {
    //         this.more=false;
    //     }
    //     else if(!this.dropdownDivSpriority.nativeElement.contains(e.target)) {
    //       this.moreA=false;
    //   }
    // });
  }

  priorityList: any = ['High', 'Medium', 'Low'];
  servicesList: any = ['new offering', 'existing service'];

  @Output()
  completedChildFormIds = new EventEmitter<any>();

  @Output()
  formSaved = new EventEmitter<string>();

  @Input()
  formFields: any[] = [];

  @Input()
  formStatus: string = "Not Started";

  @Input()
  demandType: string = "";

  @Input()
  isFormSubmitted: boolean = false;

  useCase: string = "";
  versionExist: string = "";
  hasDeployed: string = "";
  geography: string = "";
  describeProduct: string = "";
  successful: string = "";
  currentProcess: string = "";
  changeProcess: string = "";
  requirements: string = "";
  challenges: string = "";
  immediateDemand: string = "";
  provideDetail: string = "";
  listClients: string = "";
  clientDetails: string = "";
  BusinessModel: string = "";
  marketPriority: string = "";
  mJurisdictional: string = "";
  pJurisdictions: string = "";
  targetMarket: string = "";
  // launchDate: Date = null;
  endUser: string = "";
  campaign: string = "";
  exCampaign: string = "";
  newCampaign: string = "";
  serviceOffering: string = "";
  serviceDetails: string = "";
  deployment: string = "";

  jurisdictionArr: Jurisdiction[] = [{ priorityJurisdictionName: "", launchDate: null, validDate: false, validName: false }];


  completedChildIds: string[] = [];

  isDataSaved: boolean = false;
  savedData: Form2Model = null;
  isSavedDataAvailable: boolean = false;
  savedDataId: number = -1;

  isMasterRecordAvailable: boolean = false;
  masterRecordId: number = -1;
  savedMasterRecord: MasterListModel = null;

  ngOnInit() {
    this.useCase = this.formFields.filter(f => f.fieldName === "useCase")[0].value;
    this.versionExist = this.formFields.filter(f => f.fieldName === "versionExist")[0].value;
    this.hasDeployed = this.formFields.filter(f => f.fieldName === "hasDeployed")[0].value;
    this.geography = this.formFields.filter(f => f.fieldName === "geography")[0].value;
    this.describeProduct = this.formFields.filter(f => f.fieldName === "describeProduct")[0].value;
    this.successful = this.formFields.filter(f => f.fieldName === "successful")[0].value;
    this.currentProcess = this.formFields.filter(f => f.fieldName === "currentProcess")[0].value;
    this.changeProcess = this.formFields.filter(f => f.fieldName === "changeProcess")[0].value;
    this.requirements = this.formFields.filter(f => f.fieldName === "requirements")[0].value;
    this.challenges = this.formFields.filter(f => f.fieldName === "challenges")[0].value;
    this.immediateDemand = this.formFields.filter(f => f.fieldName === "immediateDemand")[0].value;
    this.provideDetail = this.formFields.filter(f => f.fieldName === "provideDetail")[0].value;
    this.listClients = this.formFields.filter(f => f.fieldName === "listClients")[0].value;
    this.clientDetails = this.formFields.filter(f => f.fieldName === "clientDetails")[0].value;
    this.BusinessModel = this.formFields.filter(f => f.fieldName === "BusinessModel")[0].value;
    this.marketPriority = this.formFields.filter(f => f.fieldName === "marketPriority")[0].value;
    this.mJurisdictional = this.formFields.filter(f => f.fieldName === "mJurisdictional")[0].value;
    // this.pJurisdictions = this.formFields.filter(f=>f.fieldName==="pJurisdictions")[0].value;
    // this.targetMarket = this.formFields.filter(f=>f.fieldName==="targetMarket")[0].value;
    // if(this.formFields.filter(f=>f.fieldName==="launchDate")[0].value && this.formFields.filter(f=>f.fieldName==="launchDate")[0].value.length>0){
    //   this.launchDate = new Date(this.formFields.filter(f=>f.fieldName==="launchDate")[0].value);
    // }
    this.endUser = this.formFields.filter(f => f.fieldName === "endUser")[0].value;
    this.campaign = this.formFields.filter(f => f.fieldName === "campaign")[0].value;
    this.exCampaign = this.formFields.filter(f => f.fieldName === "exCampaign")[0].value;
    this.newCampaign = this.formFields.filter(f => f.fieldName === "newCampaign")[0].value;
    this.serviceOffering = this.formFields.filter(f => f.fieldName === "serviceOffering")[0].value;
    this.serviceDetails = this.formFields.filter(f => f.fieldName === "serviceDetails")[0].value;
    this.deployment = this.formFields.filter(f => f.fieldName === "deployment")[0].value;

    let jurisdictionArr = this.formFields.filter(f => f.fieldName === "jurisdictionArr")[0].value;
    // let marketArr = this.formFields.filter(f=>f.fieldName==="marketArr")[0].value;

    if (jurisdictionArr && jurisdictionArr.length > 0) {
      this.jurisdictionArr = [];
      let parsedJurisdictionArr = JSON.parse(jurisdictionArr);
      if (parsedJurisdictionArr && parsedJurisdictionArr.length > 0) {
        parsedJurisdictionArr.forEach(j => {
          this.jurisdictionArr.push({
            priorityJurisdictionName: j.PriorityJurisdiction,
            launchDate: new Date(j.LaunchDate),
            validDate: false,
            validName: false

          })
        });
      }
    }
    /* if(marketArr && marketArr.length>0){
      this.marketArr = [];
      marketArr.split(',').forEach(item => {
        this.marketArr.push({
          value: item
        })
      });
    } */

    this.saveOrLoadMasterRecord();
  }

  redirectToHome() {
    this.router.navigateByUrl('/appHome');
  }

  /*
  ngAfterViewInit() {
    if (this.isFormSubmitted) {
      setTimeout(() => {
        let allInputs = document.getElementsByTagName('input');
        // if(allInputs){
        for (let i = 0; i < allInputs.length; i++) {
          allInputs.item(i).disabled = true;
        }
        // }
        let allSelects = document.getElementsByTagName('select');
        if (allSelects) {
          for (let i = 0; i < allSelects.length; i++) {
            // allSelects.item(i).disabled = true;
            allSelects.item(i).style.pointerEvents = "none";
            allSelects.item(i).style.cursor = "not-allowed";
          }
        }
        let allButtons = document.getElementsByTagName('button');
        if (allButtons) {
          for (let i = 0; i < allButtons.length; i++) {
            if (allButtons.item(i).innerText.indexOf("Back to Home") < 0)
              allButtons.item(i).disabled = true;
          }
        }
        let allTextArea = document.getElementsByTagName('textarea');
        if (allTextArea) {
          for (let i = 0; i < allTextArea.length; i++) {
            allTextArea.item(i).disabled = true;
          }
        }
      });
    }
  }
*/
  saveOrLoadMasterRecord() {
    if (localStorage.getItem('masterRecordId') && localStorage.getItem('masterRecordId').length > 0) {
      let masterId: number = Number(localStorage.getItem('masterRecordId'));
      if (masterId > 0) {
        this._masterListSvc.getSavedRecord(masterId).subscribe((masterData: MasterListModel) => {

          this.isMasterRecordAvailable = true;
          this.masterRecordId = masterId;
          this.savedMasterRecord = masterData;
          this.savedMasterRecord.FormStatus = (this.savedMasterRecord.FormStatus===_FORM_STATUS.triage) ? _FORM_STATUS.triage : _FORM_STATUS.inProgress;
          if (this.savedMasterRecord.Form2DemandListLookupId != null) {
            localStorage.setItem('form2SavedId', this.savedMasterRecord.Form2DemandListLookupId.toString());
            this.loadFormDataOnLoad();
          }
        }, (error) => {
          this.isSavedDataAvailable = false;
          this.isMasterRecordAvailable = false;
          localStorage.setItem('form2SavedId', '');
        });
      }
      else {
        this.isSavedDataAvailable = false;
        this.isMasterRecordAvailable = false;
        localStorage.setItem('form2SavedId', '');
      }
    }
    else {
      this.isSavedDataAvailable = false;
      this.isMasterRecordAvailable = false;
      localStorage.setItem('form2SavedId', '');
    }
  }

  loadFormDataOnLoad() {
    this.isSavedDataAvailable = false;
    this.savedData = null;
    this.savedDataId = -1;
    if (localStorage.getItem('form2SavedId') && localStorage.getItem('form2SavedId').length > 0) {
      let savedId: number = Number(localStorage.getItem('form2SavedId'));
      if (savedId > 0) {
        this._form2Svc.getSavedRecord(savedId).subscribe((form2Data: Form2Model) => {
          this.isSavedDataAvailable = true;
          this.savedData = form2Data;
          this.savedDataId = savedId;

          this.useCase = this.formFields.filter(f => f.fieldName === "useCase")[0].value = form2Data.UseCaseName;
          this.versionExist = this.formFields.filter(f => f.fieldName === "versionExist")[0].value = form2Data.UseCaseExist;
          this.hasDeployed = this.formFields.filter(f => f.fieldName === "hasDeployed")[0].value = form2Data.IsDeployedClients;
          this.geography = this.formFields.filter(f => f.fieldName === "geography")[0].value = form2Data.ClientList;
          this.describeProduct = this.formFields.filter(f => f.fieldName === "describeProduct")[0].value = form2Data.DescribeUseCase;
          this.successful = this.formFields.filter(f => f.fieldName === "successful")[0].value = form2Data.ResultUseCase;
          this.currentProcess = this.formFields.filter(f => f.fieldName === "currentProcess")[0].value = form2Data.DescribeCurrentProcessWorks;
          this.changeProcess = this.formFields.filter(f => f.fieldName === "changeProcess")[0].value = form2Data.ReasonChangeCurrentProcess;
          this.requirements = this.formFields.filter(f => f.fieldName === "requirements")[0].value = form2Data.OtherRequirementUseCaseProduct;
          this.challenges = this.formFields.filter(f => f.fieldName === "challenges")[0].value = form2Data.BarriersImpactSuccessfulRollout;
          this.immediateDemand = this.formFields.filter(f => f.fieldName === "immediateDemand")[0].value = form2Data.ImmediateClientDemand;
          this.provideDetail = this.formFields.filter(f => f.fieldName === "provideDetail")[0].value = form2Data.ImmediateClientDemandDetails;
          this.listClients = this.formFields.filter(f => f.fieldName === "listClients")[0].value = form2Data.ClientListTarget;
          this.clientDetails = this.formFields.filter(f => f.fieldName === "clientDetails")[0].value = form2Data.ClientServiceDetails;
          this.BusinessModel = this.formFields.filter(f => f.fieldName === "BusinessModel")[0].value = form2Data.BusinessModel;
          this.marketPriority = this.formFields.filter(f => f.fieldName === "marketPriority")[0].value = form2Data.MarketPriority;
          this.mJurisdictional = this.formFields.filter(f => f.fieldName === "mJurisdictional")[0].value = form2Data.MultiJurisdictional;
          //  this.pJurisdictions = this.formFields.filter(f=>f.fieldName==="pJurisdictions")[0].value;
          //   this.targetMarket = this.formFields.filter(f=>f.fieldName==="targetMarket")[0].value;
          /* this.formFields.filter(f=>f.fieldName==="launchDate")[0].value = form2Data.TargetMarketLaunchDate && form2Data.TargetMarketLaunchDate.length>0?new Date(form2Data.TargetMarketLaunchDate).toLocaleDateString(): "";
          if(this.formFields.filter(f=>f.fieldName==="launchDate")[0].value && this.formFields.filter(f=>f.fieldName==="launchDate")[0].value.length>0){
            this.launchDate = new Date(this.formFields.filter(f=>f.fieldName==="launchDate")[0].value);
          } */
          this.endUser = this.formFields.filter(f => f.fieldName === "endUser")[0].value = form2Data.EndUserClientService_x002f_produ;
          this.campaign = this.formFields.filter(f => f.fieldName === "campaign")[0].value = form2Data.InfusionExistingCampaign;
          this.exCampaign = this.formFields.filter(f => f.fieldName === "exCampaign")[0].value = form2Data.ExistingCampaignDetails;
          this.newCampaign = this.formFields.filter(f => f.fieldName === "newCampaign")[0].value = form2Data.NewCampaignLaunchDate;
          this.serviceOffering = this.formFields.filter(f => f.fieldName === "serviceOffering")[0].value = form2Data.InfusionExistingNewClientService;
          this.serviceDetails = this.formFields.filter(f => f.fieldName === "serviceDetails")[0].value = form2Data.InfusionExistingNewClientService0;
          this.deployment = this.formFields.filter(f => f.fieldName === "deployment")[0].value = form2Data.DeploymentConditionsBarriers;
          this.formFields.filter(f => f.fieldName === "jurisdictionArr")[0].value = form2Data.PriorityJurisdictions;
          // this.formFields.filter(f=>f.fieldName==="marketArr")[0].value = form2Data.TargetMarkets;

          let priorityJurisdiction = form2Data.PriorityJurisdictions;

          if (priorityJurisdiction && priorityJurisdiction.length > 0) {
            this.jurisdictionArr = [];
            let parsedJurisdictionArr = JSON.parse(priorityJurisdiction);
            if (parsedJurisdictionArr && parsedJurisdictionArr.length > 0) {
              parsedJurisdictionArr.forEach(j => {
                this.jurisdictionArr.push({
                  priorityJurisdictionName: j.PriorityJurisdiction,
                  launchDate: new Date(j.LaunchDate),
                  validDate: false,
                  validName: false

                })
              });
            }
          }

          /* let targetMarkets = form2Data.TargetMarkets;
          if(targetMarkets && targetMarkets.length>0){
            this.marketArr = [];
            targetMarkets.split(',').forEach(item => {
              this.marketArr.push({
                value: item
              });
            })
          } */

          this.completedChildFormIds.emit(this.formFields);
        });
      }
    }
  }
  onBlurChange(event) {
    this.onTextChange();
  }

  onDate(event, jurisdiction: Jurisdiction) {
    jurisdiction.launchDate = new Date(event.value);
    this.onTextChange();
  }

  onTextChange() {
    this.isDataSaved = false;
    this.formFields.forEach(field => {
      
      if (field.fieldName === "useCase") {
        field.value = this.useCase;
        
      }
      else if (field.fieldName === "versionExist") {
        field.value = this.versionExist;

        
      }
      else if (field.fieldName === "hasDeployed") {
        field.value = this.hasDeployed;
      }
      else if (field.fieldName === "geography") {
        field.value = this.geography;
      }
      else if (field.fieldName === "describeProduct") {
        field.value = this.describeProduct;
        
      }
      else if (field.fieldName === "successful") {
        field.value = this.successful;
        
      }
      else if (field.fieldName === "currentProcess") {
        field.value = this.currentProcess;
        
      }
      else if (field.fieldName === "changeProcess") {
        field.value = this.changeProcess;
        
      }
      else if (field.fieldName === "requirements") {
        field.value = this.requirements;
        
      }
      else if (field.fieldName === "challenges") {
        field.value = this.challenges;
        
      }
      else if (field.fieldName === "immediateDemand") {
        field.value = this.immediateDemand;

       
      }
      else if (field.fieldName === "provideDetail") {
        field.value = this.provideDetail;
      }
      else if (field.fieldName === "listClients") {
        field.value = this.listClients;
       
      }
      else if (field.fieldName === "clientDetails") {
        field.value = this.clientDetails;
       
      }
      else if (field.fieldName === "BusinessModel") {
        field.value = this.BusinessModel;
        
      }
      else if (field.fieldName === "marketPriority") {
        field.value = this.marketPriority;
        
      }
      else if (field.fieldName === "mJurisdictional") {
        field.value = this.mJurisdictional;
      
      }

      else if (field.fieldName === "targetMarket") {
        field.value = this.targetMarket;
      }
      /* else if(field.fieldName==="launchDate"){
       field.value = new Date(this.launchDate).toLocaleDateString();
      } */
      else if (field.fieldName === "endUser") {
        field.value = this.endUser;

        
      }
      else if (field.fieldName === "campaign") {
        field.value = this.campaign;

        
      }
      else if (field.fieldName === "exCampaign") {
        field.value = this.exCampaign;
        

      }
      else if (field.fieldName === "newCampaign") {
        field.value = this.newCampaign;
        // if (!event) {
        //   event = { "target": {} };
        //   event.target.id = field.fieldName;
        // }
        // if (field.isMandatory && !field.value && event.target.id === field.fieldName && this.campaign == "No") {

        //   this.form2Validation[field.fieldName] = true;
        //   this.form2Validation.isForminValid = true;

        // }
        // else if (field.isMandatory && !field.value && this.form2Validation[field.fieldName] && this.campaign == "No") {
        //   this.form2Validation[field.fieldName] = true;
        //   this.form2Validation.isForminValid = true;
        // }
        // else {
        //   this.form2Validation[field.fieldName] = false;
        //   this.form2Validation.isForminValid = false;
        // }

      }
      else if (field.fieldName === "serviceOffering") {
        field.value = this.serviceOffering;
        
      }
      else if (field.fieldName === "serviceDetails") {
        field.value = this.serviceDetails;
        
      }
      else if (field.fieldName === "deployment") {
        field.value = this.deployment;
        
      }
      else if (field.fieldName === "jurisdictionArr") {
        field.value = "";
       
        if (this.jurisdictionArr.length > 0) {
          let jurisdictionData: any[] = [];
          for (let i = 0; i < this.jurisdictionArr.length; i++) {
            if (this.jurisdictionArr[i].priorityJurisdictionName
              && this.jurisdictionArr[i].priorityJurisdictionName.length > 0
              && this.jurisdictionArr[i].launchDate) {
              jurisdictionData.push({
                PriorityJurisdiction: this.jurisdictionArr[i].priorityJurisdictionName,
                LaunchDate: this.jurisdictionArr[i].launchDate.toLocaleDateString()
              });
            }
            else {
              field.value = "";
              break;
            }
            // if (!this.jurisdictionArr[i].priorityJurisdictionName || !this.jurisdictionArr[i].launchDate) {
            //   if (field.isMandatory && !this.jurisdictionArr[i].priorityJurisdictionName && event.target.id === "jurisdiction.priorityJurisdictionName") {
            //     this.jurisdictionArr[i].validName = true;
            //     this.form2Validation.isForminValid = true;
            //   }
            //   if (field.isMandatory && !this.jurisdictionArr[i].launchDate && (event.target.id === "jurisdiction.launchDate" ||  event.target.id ==="jurisdiction.priorityJurisdictionName")) {
            //     this.jurisdictionArr[i].validDate = true;
            //     this.form2Validation.isForminValid = true;
            //   }
            //   if (field.isMandatory && !this.jurisdictionArr[i].launchDate && this.jurisdictionArr[i].validDate) {

            //     this.jurisdictionArr[i].validDate = true;
            //     this.form2Validation.isForminValid = true;

            //   }
            //   if (field.isMandatory && !this.jurisdictionArr[i].priorityJurisdictionName && this.jurisdictionArr[i].validName) {

            //     this.jurisdictionArr[i].validName = true;
            //     this.form2Validation.isForminValid = true;

            //   }
            //   if (field.isMandatory && this.jurisdictionArr[i].priorityJurisdictionName) {

            //     this.jurisdictionArr[i].validName = false;
            //     if(!this.jurisdictionArr[i].launchDate)
            //     {
            //       this.form2Validation.isForminValid = true;
            //     }
            //     else{
            //       this.form2Validation.isForminValid = false;
            //     }
                

            //   }
            //   if (field.isMandatory && this.jurisdictionArr[i].launchDate) {

            //     this.jurisdictionArr[i].validDate = false;
            //     if(!this.jurisdictionArr[i].priorityJurisdictionName)
            //     {
            //       this.form2Validation.isForminValid = true;
            //     }
            //     else{
            //       this.form2Validation.isForminValid = false;
            //     }

            //   }
            // }
            // else {
            //   this.jurisdictionArr[i].validDate = false;
            //   this.jurisdictionArr[i].validName = false;
            //   this.form2Validation.isForminValid = false;
            // }
          }

          if (jurisdictionData && jurisdictionData.length > 0) {
            field.value = JSON.stringify(jurisdictionData).toString();
          }

        }
      }

      /* else if(field.fieldName==="marketArr"){
       field.value = "";
       if (!event) {
         event = { "target": {} };
         event.target.id = "market.value"
       }
       if (this.marketArr.length > 0) {
         for (let i = 0; i < this.marketArr.length; i++) {
           if (this.marketArr[i].value && this.marketArr[i].value.length > 0) {
             if (field.value && field.value.length > 0) {
               field.value = field.value + "," + this.marketArr[i].value;
             }
             else {
               field.value = this.marketArr[i].value;
             }
           }
           else {
             field.value = "";

           }
           if (field.isMandatory && !field.value && event.target.id === "market.value") {
             this.marketArr[i].valid = true;
             this.form2Validation.isForminValid = true;
           }
           else if (field.isMandatory && !field.value && this.marketArr[i].valid) {
             this.marketArr[i].valid = true;
             this.form2Validation.isForminValid = true;
           }
           else {
             this.marketArr[i].valid = false;
             this.form2Validation.isForminValid = false;
           }
         }
       }
     } */
    })
    this.completedChildFormIds.emit(this.formFields);
  }

  addNew(controlName) {
    if (controlName == 'jurisdictionArr') {
      this.jurisdictionArr.push({ priorityJurisdictionName: "", launchDate: null, validName: false, validDate: false });
    }
    /* else if(controlName=='marketArr')
    {
      this.marketArr.push({value: ""});
    } */
  }

  //remove element at position i
  remove(controlName, i) {
    if (controlName == 'jurisdictionArr') {
      if (i != 0)
        this.jurisdictionArr.splice(i, 1);
    }
    /* else if(controlName=='marketArr')
    {
      if(i!=0)
      this.marketArr.splice(i,1);
    } */
  }

  isEmpty(controlName) {
    var formValue = controlName;
    console.log(formValue);
    if (formValue.length <= 0)
      return true;
    else
      return false;
  }

  saveFormData() {
   
    let form2Data = new Form2Model();
    if (!this.isSavedDataAvailable) {
      form2Data.Title = guid();
    }
    else {
      form2Data.Title = this.savedData.Title;
    }
    form2Data.UseCaseName = this.useCase;
    form2Data.UseCaseExist = this.versionExist;
    form2Data.IsDeployedClients = this.hasDeployed;
    form2Data.ClientList = this.geography;
    form2Data.DescribeUseCase = this.describeProduct;
    form2Data.ResultUseCase = this.successful;
    form2Data.DescribeCurrentProcessWorks = this.currentProcess;
    form2Data.ReasonChangeCurrentProcess = this.changeProcess;
    form2Data.OtherRequirementUseCaseProduct = this.requirements;
    form2Data.BarriersImpactSuccessfulRollout = this.challenges;
    form2Data.ImmediateClientDemand = this.immediateDemand;
    form2Data.ImmediateClientDemandDetails = this.provideDetail;
    form2Data.ClientListTarget = this.listClients;
    form2Data.ClientServiceDetails = this.clientDetails;
    form2Data.BusinessModel = this.BusinessModel;
    form2Data.MarketPriority = this.marketPriority;
    form2Data.MultiJurisdictional = this.mJurisdictional;
    form2Data.PriorityJurisdictions = "";
    if (this.jurisdictionArr && this.jurisdictionArr.length > 0) {
      let jurisdictionData: any[] = [];
      this.jurisdictionArr.forEach(item => {
        if (item.priorityJurisdictionName && item.priorityJurisdictionName.length > 0 && item.launchDate) {
          jurisdictionData.push({
            PriorityJurisdiction: item.priorityJurisdictionName,
            LaunchDate: item.launchDate.toLocaleDateString()
          });
        }
      });
      if (jurisdictionData && jurisdictionData.length > 0) {
        form2Data.PriorityJurisdictions = JSON.stringify(jurisdictionData).toString();
      }
    }

    /* form2Data.TargetMarkets = "";
    this.marketArr.forEach(item=>{
      if(form2Data.TargetMarkets===""){
        form2Data.TargetMarkets = item.value;
      }
      else {
        form2Data.TargetMarkets = form2Data.TargetMarkets + "," + item.value;
      }
    });
    form2Data.TargetMarketLaunchDate = this.launchDate?this.launchDate.toLocaleDateString():null; */
    form2Data.EndUserClientService_x002f_produ = this.endUser;
    form2Data.InfusionExistingCampaign = this.campaign;
    form2Data.ExistingCampaignDetails = this.exCampaign;
    form2Data.NewCampaignLaunchDate = this.newCampaign && this.newCampaign.length > 0 ? this.newCampaign : null;
    form2Data.InfusionExistingNewClientService = this.serviceOffering.toLowerCase();
    form2Data.InfusionExistingNewClientService0 = this.serviceDetails;
    form2Data.DeploymentConditionsBarriers = this.deployment;
    form2Data.CompletionStatus = this.formStatus;

    if (!this.isSavedDataAvailable) {
      if (!this.isMasterRecordAvailable) {
        let newMasterRecord: MasterListModel = new MasterListModel();
        newMasterRecord.Form2DemandListLookupId = null;
        newMasterRecord.Form3DemandListLookupId = null;
        newMasterRecord.Form4DemandListLookupId = null;
        newMasterRecord.Form5DemandListLookupId = null;
        newMasterRecord.Form6DemandListLookupId = null;
        newMasterRecord.DemandType = this.demandType;
        newMasterRecord.FormStatus= _FORM_STATUS.inProgress;
        newMasterRecord.Stage= _FORM_STAGES.stage1
        this._masterListSvc.saveData(newMasterRecord).subscribe(mdata => {
          // Handle Success
          this.isMasterRecordAvailable = true;
          this.masterRecordId = Number(mdata.data.Id);
          this.savedMasterRecord = newMasterRecord;

          localStorage.setItem('masterRecordId', mdata.data.Id);
          this._form2Svc.saveData(form2Data).subscribe(data => {
            // Handle Success
            // Update master record with Id
            this.savedMasterRecord.Form2DemandListLookupId = Number(data.data.Id);
            this._masterListSvc.updateData(this.savedMasterRecord, this.masterRecordId).subscribe((data) => {
              this.isDataSaved = true;
              localStorage.setItem('form2SavedId', this.savedMasterRecord.Form2DemandListLookupId.toString());
              this.formSaved.emit(_FORM_NAMES.form2);
              this.setFormActive(_FORM_NAMES.form3);
            });
          }, (error) => {
            // Handle Error
            this.isDataSaved = false;
          });
        }, (error) => {
          // Handle Error
          this.isMasterRecordAvailable = false;
          this.isDataSaved = false;
        });
      }
      else {
        this._form2Svc.saveData(form2Data).subscribe(data => {
          // Handle Success
          // Update master record with Id
          this.savedMasterRecord.Form2DemandListLookupId = Number(data.data.Id);
          this._masterListSvc.updateData(this.savedMasterRecord, this.masterRecordId).subscribe((data) => {
            this.isDataSaved = true;
            localStorage.setItem('form2SavedId', this.savedMasterRecord.Form2DemandListLookupId.toString());
            this.formSaved.emit(_FORM_NAMES.form2);
            this.setFormActive(_FORM_NAMES.form3);
          });
        }, (error) => {
          // Handle Error
          this.isDataSaved = false;
        });
      }
    }
    else {
      this._form2Svc.updateData(form2Data, this.savedDataId).subscribe(data => {
        // Handle Success
        this.isDataSaved = true;
        this.formSaved.emit(_FORM_NAMES.form2);
        this.setFormActive(_FORM_NAMES.form3);
      }, (error) => {
        // Handle Error
        this.isDataSaved = false;
      });
    }
  }
  setFormActive(form) {
    this.formSaveClick.emit(form);
  }
}

