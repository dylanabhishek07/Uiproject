import * as pnp from 'sp-pnp-js';
import { environment } from '../../../environments/environment'
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { from } from 'rxjs';
import { MasterListService } from 'src/app/Services/Implementations/masterListService';
import { Form2SPService } from 'src/app/Services/Implementations/form2Service';
import { MasterListModel } from 'src/app/Models/masterListModel';
import { Form2Model } from 'src/app/Models/form2model';
import { guid } from '@progress/kendo-angular-common';
import { Form3SPService } from 'src/app/Services/Implementations/form3Service';
import { Form3Model } from 'src/app/Models/form3model';
import { Form4SPService } from 'src/app/Services/Implementations/form4Service';
import { Form4Model } from 'src/app/Models/form4model';
import { Form6SPService } from 'src/app/Services/Implementations/form6Service';
import { Form6Model } from 'src/app/Models/form6model';
import { Form5SPService } from 'src/app/Services/Implementations/form5Service';
import { Form5Model } from 'src/app/Models/form5model';
import { _FORM_STAGES, _FORM_STATUS } from 'src/app/Models/formstatus';
import { Form7SPService } from 'src/app/Services/Implementations/form7Service';
import { Form7Model } from 'src/app/Models/form7model';

@Injectable()
export class FormSaveService {
    /* Region form 2 save */
    saveForm2DataExternal(formFields: any[], masterListSvc: MasterListService,
        form2Svc: Form2SPService, demandType: string) {
        let isSavedDataAvailable = false;
        let isMasterRecordAvailable = false;
        if (localStorage.getItem('masterRecordId') && localStorage.getItem('masterRecordId').length > 0) {
            let masterId: number = Number(localStorage.getItem('masterRecordId'));
            if (masterId > 0) {
                masterListSvc.getSavedRecord(masterId).subscribe((masterData: MasterListModel) => {
                    isMasterRecordAvailable = true;
                    if (masterData.Form2DemandListLookupId && masterData.Form2DemandListLookupId.toString().length > 0) {
                        localStorage.setItem('form2SavedId', masterData.Form2DemandListLookupId.toString());
                        isSavedDataAvailable = true;
                    }
                    this.saveForm2Data(isSavedDataAvailable, isMasterRecordAvailable,
                        Number(masterData.Form2DemandListLookupId), masterData, masterId, formFields, masterListSvc, form2Svc, demandType);
                    // Save form 2 data

                }, (error) => {
                    this.saveForm2Data(isSavedDataAvailable, isMasterRecordAvailable,
                        null, null, null, formFields, masterListSvc, form2Svc, demandType);
                });
            }
            else {
                this.saveForm2Data(isSavedDataAvailable, isMasterRecordAvailable,
                    null, null, null, formFields, masterListSvc, form2Svc, demandType);
            }
        }
        else {
            this.saveForm2Data(isSavedDataAvailable, isMasterRecordAvailable,
                null, null, null, formFields, masterListSvc, form2Svc, demandType);
        }
    }

    saveForm2Data(isSavedDataAvailable: boolean,
        isMasterRecordAvailable: boolean, savedDataId: number,
        savedMasterRecord: MasterListModel, masterRecordId: number, formFields: any[],
        masterListSvc: MasterListService, form2Svc: Form2SPService, demandType: string) {
        let form2Data = new Form2Model();
        form2Data.Title = guid();
        form2Data.UseCaseName = formFields.filter(f => f.fieldName === "useCase")[0].value;
        form2Data.UseCaseExist = formFields.filter(f => f.fieldName === "versionExist")[0].value;
        form2Data.IsDeployedClients = formFields.filter(f => f.fieldName === "hasDeployed")[0].value;
        form2Data.ClientList = formFields.filter(f => f.fieldName === "geography")[0].value;
        form2Data.DescribeUseCase = formFields.filter(f => f.fieldName === "describeProduct")[0].value;
        form2Data.ResultUseCase = formFields.filter(f => f.fieldName === "successful")[0].value;
        form2Data.DescribeCurrentProcessWorks = formFields.filter(f => f.fieldName === "currentProcess")[0].value;
        form2Data.ReasonChangeCurrentProcess = formFields.filter(f => f.fieldName === "changeProcess")[0].value;
        form2Data.OtherRequirementUseCaseProduct = formFields.filter(f => f.fieldName === "requirements")[0].value;
        form2Data.BarriersImpactSuccessfulRollout = formFields.filter(f => f.fieldName === "challenges")[0].value;
        form2Data.ImmediateClientDemand = formFields.filter(f => f.fieldName === "immediateDemand")[0].value;
        form2Data.ImmediateClientDemandDetails = formFields.filter(f => f.fieldName === "provideDetail")[0].value;
        form2Data.ClientListTarget = formFields.filter(f => f.fieldName === "listClients")[0].value;
        form2Data.ClientServiceDetails = formFields.filter(f => f.fieldName === "clientDetails")[0].value;
        form2Data.BusinessModel = formFields.filter(f => f.fieldName === "BusinessModel")[0].value;
        form2Data.MarketPriority = formFields.filter(f => f.fieldName === "marketPriority")[0].value;
        form2Data.MultiJurisdictional = formFields.filter(f => f.fieldName === "mJurisdictional")[0].value;
        form2Data.PriorityJurisdictions = formFields.filter(f => f.fieldName === "jurisdictionArr")[0].value;
        // form2Data.TargetMarkets = formFields.filter(f=>f.fieldName==="marketArr")[0].value;
        // let launchDate = formFields.filter(f=>f.fieldName==="launchDate")[0].value;
        // form2Data.TargetMarketLaunchDate = launchDate && launchDate.length>0?launchDate:null;
        form2Data.EndUserClientService_x002f_produ = formFields.filter(f => f.fieldName === "endUser")[0].value;
        form2Data.InfusionExistingCampaign = formFields.filter(f => f.fieldName === "campaign")[0].value;
        form2Data.ExistingCampaignDetails = formFields.filter(f => f.fieldName === "exCampaign")[0].value;
        let newCampaign = formFields.filter(f => f.fieldName === "newCampaign")[0].value;
        form2Data.NewCampaignLaunchDate = newCampaign && newCampaign.length > 0 ? newCampaign : null;
        form2Data.InfusionExistingNewClientService = formFields.filter(f => f.fieldName === "serviceOffering")[0].value;
        form2Data.InfusionExistingNewClientService0 = formFields.filter(f => f.fieldName === "serviceDetails")[0].value;
        form2Data.DeploymentConditionsBarriers = formFields.filter(f => f.fieldName === "deployment")[0].value;
        form2Data.CompletionStatus = "Completed";

        if (!isSavedDataAvailable) {
            if (!isMasterRecordAvailable) {
                let newMasterRecord: MasterListModel = new MasterListModel();
                newMasterRecord.Form2DemandListLookupId = null;
                newMasterRecord.Form3DemandListLookupId = null;
                newMasterRecord.Form4DemandListLookupId = null;
                newMasterRecord.Form5DemandListLookupId = null;
                newMasterRecord.Form6DemandListLookupId = null;
                newMasterRecord.DemandType = demandType;
                newMasterRecord.Stage = _FORM_STAGES.stage1;
                newMasterRecord.FormStatus = _FORM_STATUS.inProgress;

                masterListSvc.saveData(newMasterRecord).subscribe(mdata => {
                    // Handle Success
                    localStorage.setItem('masterRecordId', mdata.data.Id);
                    form2Svc.saveData(form2Data).subscribe(data => {
                        // Handle Success
                        mdata.data.Form2DemandListLookupId = Number(data.data.Id);
                        masterListSvc.updateData(mdata.data, mdata.data.Id).subscribe((result) => {
                            localStorage.setItem('form2SavedId', mdata.data.Form2DemandListLookupId.toString());
                        });
                    }, (error) => {
                        // Handle Error
                    });
                }, (error) => {
                    // Handle Error
                });
            }
            else {
                form2Svc.saveData(form2Data).subscribe(data => {
                    // Handle Success
                    // Update master record with Id
                    savedMasterRecord.Form2DemandListLookupId = Number(data.data.Id);
                    masterListSvc.updateData(savedMasterRecord, masterRecordId).subscribe((result) => {
                        localStorage.setItem('form2SavedId', savedMasterRecord.Form2DemandListLookupId.toString());
                    });
                }, (error) => {
                    // Handle Error
                });
            }
        }
        else {
            form2Svc.updateData(form2Data, savedDataId).subscribe(data => {
                // Handle Success
            }, (error) => {
                // Handle Error
            });
        }
    }
    /* End-Region form 2 save */

    /* Region form 3 save */
    saveForm3DataExternal(formFields: any[], masterListSvc: MasterListService,
        form3Svc: Form3SPService, demandType: string) {
        let isSavedDataAvailable = false;
        let isMasterRecordAvailable = false;
        if (localStorage.getItem('masterRecordId') && localStorage.getItem('masterRecordId').length > 0) {
            let masterId: number = Number(localStorage.getItem('masterRecordId'));
            if (masterId > 0) {
                masterListSvc.getSavedRecord(masterId).subscribe((masterData: MasterListModel) => {
                    isMasterRecordAvailable = true;
                    if (masterData.Form3DemandListLookupId && masterData.Form3DemandListLookupId.toString().length > 0) {
                        localStorage.setItem('form3SavedId', masterData.Form3DemandListLookupId.toString());
                        isSavedDataAvailable = true;
                    }
                    this.saveForm3Data(isSavedDataAvailable, isMasterRecordAvailable,
                        Number(masterData.Form3DemandListLookupId), masterData, masterId, formFields, masterListSvc, form3Svc, demandType);
                    // Save form 3 data

                }, (error) => {
                    this.saveForm3Data(isSavedDataAvailable, isMasterRecordAvailable,
                        null, null, null, formFields, masterListSvc, form3Svc, demandType);
                });
            }
            else {
                this.saveForm3Data(isSavedDataAvailable, isMasterRecordAvailable,
                    null, null, null, formFields, masterListSvc, form3Svc, demandType);
            }
        }
        else {
            this.saveForm3Data(isSavedDataAvailable, isMasterRecordAvailable,
                null, null, null, formFields, masterListSvc, form3Svc, demandType);
        }
    }

    saveForm3Data(isSavedDataAvailable: boolean,
        isMasterRecordAvailable: boolean, savedDataId: number,
        savedMasterRecord: MasterListModel, masterRecordId: number, formFields: any[],
        masterListSvc: MasterListService, form3Svc: Form3SPService, demandType: string) {
        let form3Data = new Form3Model();
        form3Data.Title = guid();
        form3Data.OwningSSL = formFields.filter(f => f.fieldName === "owningSSL")[0].value;
        form3Data.SSLCompetencyService = formFields.filter(f => f.fieldName === "sslCompetency")[0].value;
        form3Data.SSLSponsoringPartnerEmail = formFields.filter(f => f.fieldName === "sslSponsoringEmail")[0].value;
        form3Data.SSLSponsoringPartnerRole = formFields.filter(f => f.fieldName === "sslSponsoringRole")[0].value;
        form3Data.SSLsolutionOwnerName = formFields.filter(f => f.fieldName === "sslSolutionOwnerName")[0].value;
        form3Data.SSLsolutionDeputyName = formFields.filter(f => f.fieldName === "sslSolutionDeputyName")[0].value;
        form3Data.SSLSponsoringPartnerName = formFields.filter(f => f.fieldName === "sslSponsoringName")[0].value;

        // form3Data.SSLsolutionOwnerNameStringId = formFields.filter(f => f.fieldName === "sslSolutionOwnerNameId")[0].value.toString();
        // form3Data.SSLsolutionOwnerNameId = Number(formFields.filter(f => f.fieldName === "sslSolutionOwnerNameId")[0].value);
        form3Data.SSLsolutionOwnerEmail = formFields.filter(f => f.fieldName === "sslSolutionOwnerEmail")[0].value;
        form3Data.SSLsolutionOwnerRole = formFields.filter(f => f.fieldName === "sslSolutionOwnerRole")[0].value;
        // form3Data.SSLsolutionDeputyNameStringId = formFields.filter(f => f.fieldName === "sslSolutionDeputyNameId")[0].value.toString();
        // form3Data.SSLsolutionDeputyNameId = Number(formFields.filter(f => f.fieldName === "sslSolutionDeputyNameId")[0].value);
        form3Data.SSLsolutionDeputyEmail = formFields.filter(f => f.fieldName === "sslSolutionDeputyEmail")[0].value;
        form3Data.SSLsolutionDeputyRole = formFields.filter(f => f.fieldName === "sslSolutionDeputyRole")[0].value;
        // form3Data.MarketOwnerJurisdictionSpecification = this.marketOwners;
        form3Data.LocalFunding = formFields.filter(f => f.fieldName === "radioQuesA")[0].value;
        form3Data.LocalGlobalFundingApproved = formFields.filter(f => f.fieldName === "radioQuesB")[0].value;
        form3Data.LocalGlobalFundingDetails = formFields.filter(f => f.fieldName === "form3AdditionalDetails")[0].value;
        // form3Data.SSLSponsoringPartnerNameStringId = formFields.filter(f => f.fieldName === "sslSponsoringNameId")[0].value.toString();
        // form3Data.SSLSponsoringPartnerNameId = Number(formFields.filter(f => f.fieldName === "sslSponsoringNameId")[0].value);
        form3Data.MarketOwnerJurisdictionSpecifica = formFields.filter(f => f.fieldName === "marketOwners")[0].value;
        form3Data.CompletionStatus = "Completed";

        if (!isSavedDataAvailable) {
            if (!isMasterRecordAvailable) {
                let newMasterRecord: MasterListModel = new MasterListModel();
                newMasterRecord.Form2DemandListLookupId = null;
                newMasterRecord.Form3DemandListLookupId = null;
                newMasterRecord.Form4DemandListLookupId = null;
                newMasterRecord.Form5DemandListLookupId = null;
                newMasterRecord.Form6DemandListLookupId = null;
                newMasterRecord.DemandType = demandType;
                newMasterRecord.Stage = _FORM_STAGES.stage1;
                newMasterRecord.FormStatus = _FORM_STATUS.inProgress;

                newMasterRecord.Form3SSLsolutionOwnerEmail = (!form3Data.SSLsolutionOwnerName) ? "" : JSON.parse(form3Data.SSLsolutionOwnerName).Id;
                newMasterRecord.Form3SSLsolutionDeputyEmail = (!form3Data.SSLsolutionDeputyName) ? "" : JSON.parse(form3Data.SSLsolutionDeputyName).Id;
                newMasterRecord.Form3SSLSponsoringPartnerEmail = (!form3Data.SSLSponsoringPartnerName) ? "" : JSON.parse(form3Data.SSLSponsoringPartnerName).Id;

                masterListSvc.saveData(newMasterRecord).subscribe(mdata => {
                    // Handle Success
                    localStorage.setItem('masterRecordId', mdata.data.Id);
                    form3Svc.saveData(form3Data).subscribe(data => {
                        // Handle Success
                        mdata.data.Form3DemandListLookupId = Number(data.data.Id);
                        masterListSvc.updateData(mdata.data, mdata.data.Id).subscribe((result) => {
                            localStorage.setItem('form3SavedId', mdata.data.Form3DemandListLookupId.toString());
                        });
                    }, (error) => {
                        // Handle Error
                    });
                }, (error) => {
                    // Handle Error
                });
            }
            else {
                form3Svc.saveData(form3Data).subscribe(data => {
                    // Handle Success
                    // Update master record with Id
                    savedMasterRecord.Form3DemandListLookupId = Number(data.data.Id);
                    savedMasterRecord.Form3SSLsolutionOwnerEmail = (!form3Data.SSLsolutionOwnerName) ? "" : JSON.parse(form3Data.SSLsolutionOwnerName).Id;
                    savedMasterRecord.Form3SSLsolutionDeputyEmail = (!form3Data.SSLsolutionDeputyName) ? "" : JSON.parse(form3Data.SSLsolutionDeputyName).Id;
                    savedMasterRecord.Form3SSLSponsoringPartnerEmail = (!form3Data.SSLSponsoringPartnerName) ? "" : JSON.parse(form3Data.SSLSponsoringPartnerName).Id;
                    masterListSvc.updateData(savedMasterRecord, masterRecordId).subscribe((result) => {
                        localStorage.setItem('form3SavedId', savedMasterRecord.Form3DemandListLookupId.toString());
                    });
                }, (error) => {
                    // Handle Error
                });
            }
        }
        else {
            form3Svc.updateData(form3Data, savedDataId).subscribe(data => {
                // Handle Success
            }, (error) => {
                // Handle Error
            });
        }
    }
    /* End-Region form 3 save */

    /* Region form 4 save */
    saveForm4DataExternal(formFields: any[], masterListSvc: MasterListService,
        form4Svc: Form4SPService, demandType: string) {
        let isSavedDataAvailable = false;
        let isMasterRecordAvailable = false;
        if (localStorage.getItem('masterRecordId') && localStorage.getItem('masterRecordId').length > 0) {
            let masterId: number = Number(localStorage.getItem('masterRecordId'));
            if (masterId > 0) {
                masterListSvc.getSavedRecord(masterId).subscribe((masterData: MasterListModel) => {
                    isMasterRecordAvailable = true;
                    if (masterData.Form4DemandListLookupId && masterData.Form4DemandListLookupId.toString().length > 0) {
                        localStorage.setItem('form4SavedId', masterData.Form4DemandListLookupId.toString());
                        isSavedDataAvailable = true;
                    }
                    this.saveForm4Data(isSavedDataAvailable, isMasterRecordAvailable,
                        Number(masterData.Form4DemandListLookupId), masterData, masterId, formFields, masterListSvc, form4Svc, demandType);
                    // Save form 3 data

                }, (error) => {
                    this.saveForm4Data(isSavedDataAvailable, isMasterRecordAvailable,
                        null, null, null, formFields, masterListSvc, form4Svc, demandType);
                });
            }
            else {
                this.saveForm4Data(isSavedDataAvailable, isMasterRecordAvailable,
                    null, null, null, formFields, masterListSvc, form4Svc, demandType);
            }
        }
        else {
            this.saveForm4Data(isSavedDataAvailable, isMasterRecordAvailable,
                null, null, null, formFields, masterListSvc, form4Svc, demandType);
        }
    }

    saveForm4Data(isSavedDataAvailable: boolean,
        isMasterRecordAvailable: boolean, savedDataId: number,
        savedMasterRecord: MasterListModel, masterRecordId: number, formFields: any[],
        masterListSvc: MasterListService, form4Svc: Form4SPService, demandType: string) {
        let form4Data = new Form4Model();
        form4Data.Title = guid();
        form4Data.Form4UseCaseName = formFields.filter(f => f.fieldName === "useCaseForm4")[0].value;
        form4Data.Technology = formFields.filter(f => f.fieldName === "technology")[0].value;
        form4Data.DescriptionUseCase = formFields.filter(f => f.fieldName === "description")[0].value;
        form4Data.OtherSystemIntegrationUseCase = formFields.filter(f => f.fieldName === "systemIntegration")[0].value;
        form4Data.BarrierChallengesImpact = formFields.filter(f => f.fieldName === "barriers")[0].value;
        form4Data.Form4ClientImmediateDemand = formFields.filter(f => f.fieldName === "IsImmediate")[0].value;
        form4Data.Form4ClientImmediateDemandDetail = formFields.filter(f => f.fieldName === "form4AdditionalDetailsIsImmediate")[0].value;
        form4Data.Form4ListClientTarget = formFields.filter(f => f.fieldName === "listOfClients")[0].value;
        form4Data.NewJurisdictionRequired = formFields.filter(f => f.fieldName === "newJurisdictionArr")[0].value;
        // let launchDate = formFields.filter(f=>f.fieldName==="launchDate")[0].value;
        // form4Data.Form4TargetLaunchDate = launchDate && launchDate.length>0?launchDate:null;
        form4Data.Form4DeploymentConditionsBarrier = formFields.filter(f => f.fieldName === "deploymentConditions")[0].value;
        form4Data.Form4MarketOwnerJurisdictionSpec = formFields.filter(f => f.fieldName === "marketOwner")[0].value;
        form4Data.CompletionStatus = "Completed";

        if (!isSavedDataAvailable) {
            if (!isMasterRecordAvailable) {
                let newMasterRecord: MasterListModel = new MasterListModel();
                newMasterRecord.Form2DemandListLookupId = null;
                newMasterRecord.Form3DemandListLookupId = null;
                newMasterRecord.Form4DemandListLookupId = null;
                newMasterRecord.Form5DemandListLookupId = null;
                newMasterRecord.Form6DemandListLookupId = null;
                newMasterRecord.DemandType = demandType;
                newMasterRecord.Stage = _FORM_STAGES.stage1;
                newMasterRecord.FormStatus = _FORM_STATUS.inProgress;

                masterListSvc.saveData(newMasterRecord).subscribe(mdata => {
                    // Handle Success
                    localStorage.setItem('masterRecordId', mdata.data.Id);
                    form4Svc.saveData(form4Data).subscribe(data => {
                        // Handle Success
                        mdata.data.Form4DemandListLookupId = Number(data.data.Id);
                        masterListSvc.updateData(mdata.data, mdata.data.Id).subscribe((result) => {
                            localStorage.setItem('form4SavedId', mdata.data.Form4DemandListLookupId.toString());
                        });
                    }, (error) => {
                        // Handle Error
                    });
                }, (error) => {
                    // Handle Error
                });
            }
            else {
                form4Svc.saveData(form4Data).subscribe(data => {
                    // Handle Success
                    // Update master record with Id
                    savedMasterRecord.Form4DemandListLookupId = Number(data.data.Id);
                    masterListSvc.updateData(savedMasterRecord, masterRecordId).subscribe((result) => {
                        localStorage.setItem('form4SavedId', savedMasterRecord.Form4DemandListLookupId.toString());
                    });
                }, (error) => {
                    // Handle Error
                });
            }
        }
        else {
            form4Svc.updateData(form4Data, savedDataId).subscribe(data => {
                // Handle Success
            }, (error) => {
                // Handle Error
            });
        }
    }
    /* End-Region form 4 save */

    /* Region form 6 save */
    saveForm6DataExternal(formFields: any[], masterListSvc: MasterListService,
        form6Svc: Form6SPService, demandType: string) {
        let isSavedDataAvailable = false;
        let isMasterRecordAvailable = false;
        if (localStorage.getItem('masterRecordId') && localStorage.getItem('masterRecordId').length > 0) {
            let masterId: number = Number(localStorage.getItem('masterRecordId'));
            if (masterId > 0) {
                masterListSvc.getSavedRecord(masterId).subscribe((masterData: MasterListModel) => {
                    isMasterRecordAvailable = true;
                    if (masterData.Form6DemandListLookupId && masterData.Form6DemandListLookupId.toString().length > 0) {
                        localStorage.setItem('form6SavedId', masterData.Form6DemandListLookupId.toString());
                        isSavedDataAvailable = true;
                    }
                    this.saveForm6Data(isSavedDataAvailable, isMasterRecordAvailable,
                        Number(masterData.Form6DemandListLookupId), masterData, masterId, formFields, masterListSvc, form6Svc, demandType);
                    // Save form 3 data

                }, (error) => {
                    this.saveForm6Data(isSavedDataAvailable, isMasterRecordAvailable,
                        null, null, null, formFields, masterListSvc, form6Svc, demandType);
                });
            }
            else {
                this.saveForm6Data(isSavedDataAvailable, isMasterRecordAvailable,
                    null, null, null, formFields, masterListSvc, form6Svc, demandType);
            }
        }
        else {
            this.saveForm6Data(isSavedDataAvailable, isMasterRecordAvailable,
                null, null, null, formFields, masterListSvc, form6Svc, demandType);
        }
    }

    saveForm6Data(isSavedDataAvailable: boolean,
        isMasterRecordAvailable: boolean, savedDataId: number,
        savedMasterRecord: MasterListModel, masterRecordId: number, formFields: any[],
        masterListSvc: MasterListService, form6Svc: Form6SPService, demandType: string) {
        let form6Data = new Form6Model();
        form6Data.Title = guid();
        form6Data.OverViewInputDataRequirements = formFields.filter(f => f.fieldName === "dataRequirement")[0].value;
        form6Data.DataTranscationVolumes = formFields.filter(f => f.fieldName === "dataVolume")[0].value;
        form6Data.DataAccuracyRequiredProduct = formFields.filter(f => f.fieldName === "dataAccuracy")[0].value;
        form6Data.ClientDataSubmitted = formFields.filter(f => f.fieldName === "submitClientData")[0].value;
        form6Data.DataBelongsToClient = formFields.filter(f => f.fieldName === "dataBelong")[0].value;
        form6Data.AdditionalInfo = formFields.filter(f => f.fieldName === "otherInfo")[0].value;
        form6Data.FileDetailsJson = formFields.filter(f => f.fieldName === "fileInfoJson")[0].value;
        form6Data.CompletionStatus = "Completed";

        if (!isSavedDataAvailable) {
            if (!isMasterRecordAvailable) {
                let newMasterRecord: MasterListModel = new MasterListModel();
                newMasterRecord.Form2DemandListLookupId = null;
                newMasterRecord.Form3DemandListLookupId = null;
                newMasterRecord.Form4DemandListLookupId = null;
                newMasterRecord.Form5DemandListLookupId = null;
                newMasterRecord.Form6DemandListLookupId = null;
                newMasterRecord.DemandType = demandType;
                newMasterRecord.Stage = _FORM_STAGES.stage1;
                newMasterRecord.FormStatus = _FORM_STATUS.inProgress;

                masterListSvc.saveData(newMasterRecord).subscribe(mdata => {
                    // Handle Success
                    localStorage.setItem('masterRecordId', mdata.data.Id);
                    form6Svc.saveData(form6Data).subscribe(data => {
                        // Handle Success
                        mdata.data.Form6DemandListLookupId = Number(data.data.Id);
                        masterListSvc.updateData(mdata.data, mdata.data.Id).subscribe((result) => {
                            localStorage.setItem('form6SavedId', mdata.data.Form6DemandListLookupId.toString());
                        });
                    }, (error) => {
                        // Handle Error
                    });
                }, (error) => {
                    // Handle Error
                });
            }
            else {
                form6Svc.saveData(form6Data).subscribe(data => {
                    // Handle Success
                    // Update master record with Id
                    savedMasterRecord.Form6DemandListLookupId = Number(data.data.Id);
                    masterListSvc.updateData(savedMasterRecord, masterRecordId).subscribe((result) => {
                        localStorage.setItem('form6SavedId', savedMasterRecord.Form6DemandListLookupId.toString());
                    });
                }, (error) => {
                    // Handle Error
                });
            }
        }
        else {
            form6Svc.updateData(form6Data, savedDataId).subscribe(data => {
                // Handle Success
            }, (error) => {
                // Handle Error
            });
        }
    }
    /* End-Region form 6 save */

    /* Region form 5 save */
    saveForm5DataExternal(formFields: any[], masterListSvc: MasterListService,
        form5Svc: Form5SPService, demandType: string) {
        let isSavedDataAvailable = false;
        let isMasterRecordAvailable = false;
        if (localStorage.getItem('masterRecordId') && localStorage.getItem('masterRecordId').length > 0) {
            let masterId: number = Number(localStorage.getItem('masterRecordId'));
            if (masterId > 0) {
                masterListSvc.getSavedRecord(masterId).subscribe((masterData: MasterListModel) => {
                    isMasterRecordAvailable = true;
                    if (masterData.Form5DemandListLookupId && masterData.Form5DemandListLookupId.toString().length > 0) {
                        localStorage.setItem('form5SavedId', masterData.Form5DemandListLookupId.toString());
                        isSavedDataAvailable = true;
                    }
                    this.saveForm5Data(isSavedDataAvailable, isMasterRecordAvailable,
                        Number(masterData.Form5DemandListLookupId), masterData, masterId, formFields, masterListSvc, form5Svc, demandType);
                    // Save form 3 data

                }, (error) => {
                    this.saveForm5Data(isSavedDataAvailable, isMasterRecordAvailable,
                        null, null, null, formFields, masterListSvc, form5Svc, demandType);
                });
            }
            else {
                this.saveForm5Data(isSavedDataAvailable, isMasterRecordAvailable,
                    null, null, null, formFields, masterListSvc, form5Svc, demandType);
            }
        }
        else {
            this.saveForm5Data(isSavedDataAvailable, isMasterRecordAvailable,
                null, null, null, formFields, masterListSvc, form5Svc, demandType);
        }
    }

    saveForm5Data(isSavedDataAvailable: boolean,
        isMasterRecordAvailable: boolean, savedDataId: number,
        savedMasterRecord: MasterListModel, masterRecordId: number, formFields: any[],
        masterListSvc: MasterListService, form5Svc: Form5SPService, demandType: string) {

        let form5Data = new Form5Model();
        form5Data.Title = guid();

        form5Data.BusinessType = formFields.filter(f => f.fieldName === "businessTypeVal")[0].value;
        var rawData = JSON.stringify({
            "Task": formFields.filter(f => f.fieldName === "Task")[0].value,
            "Frequency": formFields.filter(f => f.fieldName === "Frequency")[0].value,
            "FTEassignedPerTask": formFields.filter(f => f.fieldName === "FTEassignedPerTask")[0].value,
            "ApproxFTEassignedHourly": formFields.filter(f => f.fieldName === "ApproxFTEassignedHourly")[0].value,
            "HoursFTE": formFields.filter(f => f.fieldName === "HoursFTE")[0].value,
            "TotalHoursPA": formFields.filter(f => f.fieldName === "TotalHoursPA")[0].value,
            "TotalCostPAapprox": formFields.filter(f => f.fieldName === "TotalCostPAapprox")[0].value,
            "TargetNumberHours": formFields.filter(f => f.fieldName === "TargetNumberHours")[0].value,
            "ExpectedTotalGrowth": formFields.filter(f => f.fieldName === "ExpectedTotalGrowth")[0].value,
            "TargetTotalCost": formFields.filter(f => f.fieldName === "TargetTotalCost")[0].value,
            "CostSavingPA": formFields.filter(f => f.fieldName === "CostSavingPA")[0].value,
            "Task1": formFields.filter(f => f.fieldName === "Task1")[0].value,
            "Frequency1": formFields.filter(f => f.fieldName === "Frequency1")[0].value,
            "FTEassignedPerTask1": formFields.filter(f => f.fieldName === "FTEassignedPerTask1")[0].value,
            "ApproxFTEassignedHourly1": formFields.filter(f => f.fieldName === "ApproxFTEassignedHourly1")[0].value,
            "HoursFTE1": formFields.filter(f => f.fieldName === "HoursFTE1")[0].value,
            "TotalHoursPA1": formFields.filter(f => f.fieldName === "TotalHoursPA1")[0].value,
            "TotalCostPAapprox1": formFields.filter(f => f.fieldName === "TotalCostPAapprox1")[0].value,
            "TargetNumberHours1": formFields.filter(f => f.fieldName === "TargetNumberHours1")[0].value,
            "ExpectedTotalGrowth1": formFields.filter(f => f.fieldName === "ExpectedTotalGrowth1")[0].value,
            "TargetTotalCost1": formFields.filter(f => f.fieldName === "TargetTotalCost1")[0].value,
            "CostSavingPA1": formFields.filter(f => f.fieldName === "CostSavingPA1")[0].value,
            "TotalFTEassignedPerTask": formFields.filter(f => f.fieldName === "TotalFTEassignedPerTask")[0].value,
            "TotalHoursFTE": formFields.filter(f => f.fieldName === "TotalHoursFTE")[0].value,
            "TotalHoursPATotal": formFields.filter(f => f.fieldName === "TotalHoursPATotal")[0].value,
            "TotalCostPAapproxTotal": formFields.filter(f => f.fieldName === "TotalCostPAapproxTotal")[0].value,
            "TotalTargetNumberHours": formFields.filter(f => f.fieldName === "TotalTargetNumberHours")[0].value,
            "TotalTargetTotalCost": formFields.filter(f => f.fieldName === "TotalTargetTotalCost")[0].value,
            "TotalCostSavingPA": formFields.filter(f => f.fieldName === "TotalCostSavingPA")[0].value
        });
        form5Data.CalculatedData = rawData;
        form5Data.otherBusinessType = formFields.filter(f => f.fieldName === "form5AdditionalDetailsbusinessType")[0].value;
        form5Data.EstimatedAnnualGTER = formFields.filter(f => f.fieldName === "estimatedGTER")[0].value;
        form5Data.Estimated3YearGTER = formFields.filter(f => f.fieldName === "estimated3YearGTER")[0].value;
        form5Data.Client = formFields.filter(f => f.fieldName === "radioClient")[0].value;
        form5Data.Geographies = formFields.filter(f => f.fieldName === "radioGeographie")[0].value;
        form5Data.EngagementPenetration = formFields.filter(f => f.fieldName === "radioEngagement")[0].value;
        form5Data.USDperEngagement = formFields.filter(f => f.fieldName === "radioUSD")[0].value;

        form5Data.RegulationResons = formFields.filter(f => f.fieldName === "radioRegulation")[0].value;
        form5Data.ImprovingMarket = formFields.filter(f => f.fieldName === "radioImproving")[0].value;
        form5Data.NewNovelOffered = formFields.filter(f => f.fieldName === "radioNewNovel")[0].value;
        form5Data.ImprovingMarketDetails = formFields.filter(f => f.fieldName === "form5AdditionalDetailsImproving")[0].value;
        form5Data.RegulationDetails = formFields.filter(f => f.fieldName === "form5AdditionalDetailsRegulation")[0].value;
        form5Data.NewNovelOfferedDetails = formFields.filter(f => f.fieldName === "form5AdditionalDetailsNewNovel")[0].value;

        form5Data.CompletionStatus = "Completed";

        if (!isSavedDataAvailable) {
            if (!isMasterRecordAvailable) {
                let newMasterRecord: MasterListModel = new MasterListModel();
                newMasterRecord.Form2DemandListLookupId = null;
                newMasterRecord.Form3DemandListLookupId = null;
                newMasterRecord.Form4DemandListLookupId = null;
                newMasterRecord.Form5DemandListLookupId = null;
                newMasterRecord.Form6DemandListLookupId = null;
                newMasterRecord.DemandType = demandType;
                newMasterRecord.Stage = _FORM_STAGES.stage1;
                newMasterRecord.FormStatus = _FORM_STATUS.inProgress;

                masterListSvc.saveData(newMasterRecord).subscribe(mdata => {
                    // Handle Success
                    localStorage.setItem('masterRecordId', mdata.data.Id);
                    form5Svc.saveData(form5Data).subscribe(data => {
                        // Handle Success
                        mdata.data.Form5DemandListLookupId = Number(data.data.Id);
                        masterListSvc.updateData(mdata.data, mdata.data.Id).subscribe((result) => {
                            localStorage.setItem('form5SavedId', mdata.data.Form5DemandListLookupId.toString());
                        });
                    }, (error) => {
                        // Handle Error
                    });
                }, (error) => {
                    // Handle Error
                });
            }
            else {
                form5Svc.saveData(form5Data).subscribe(data => {
                    // Handle Success
                    // Update master record with Id
                    savedMasterRecord.Form5DemandListLookupId = Number(data.data.Id);
                    masterListSvc.updateData(savedMasterRecord, masterRecordId).subscribe((result) => {
                        localStorage.setItem('form5SavedId', savedMasterRecord.Form5DemandListLookupId.toString());
                    });
                }, (error) => {
                    // Handle Error
                });
            }
        }
        else {
            form5Svc.updateData(form5Data, savedDataId).subscribe(data => {
                // Handle Success
            }, (error) => {
                // Handle Error
            });
        }
    }
    /* End-Region form 5 save */

    /* Region form 7 save */
    saveForm7DataExternal(formFields: any[], masterListSvc: MasterListService,
        form7Svc: Form7SPService, demandType: string) {
        let isSavedDataAvailable = false;
        let isMasterRecordAvailable = false;
        if (localStorage.getItem('masterRecordId') && localStorage.getItem('masterRecordId').length > 0) {
            let masterId: number = Number(localStorage.getItem('masterRecordId'));
            if (masterId > 0) {
                masterListSvc.getSavedRecord(masterId).subscribe((masterData: MasterListModel) => {
                    isMasterRecordAvailable = true;
                    if (masterData.Form7DemandListLookupId && masterData.Form7DemandListLookupId.toString().length > 0) {
                        localStorage.setItem('form7SavedId', masterData.Form7DemandListLookupId.toString());
                        isSavedDataAvailable = true;
                    }
                    this.saveForm7Data(isSavedDataAvailable, isMasterRecordAvailable,
                        Number(masterData.Form7DemandListLookupId), masterData, masterId, formFields, masterListSvc, form7Svc, demandType);
                    // Save form 7 data

                }, (error) => {
                    this.saveForm7Data(isSavedDataAvailable, isMasterRecordAvailable,
                        null, null, null, formFields, masterListSvc, form7Svc, demandType);
                });
            }
            else {
                this.saveForm7Data(isSavedDataAvailable, isMasterRecordAvailable,
                    null, null, null, formFields, masterListSvc, form7Svc, demandType);
            }
        }
        else {
            this.saveForm7Data(isSavedDataAvailable, isMasterRecordAvailable,
                null, null, null, formFields, masterListSvc, form7Svc, demandType);
        }
    }

    getForm7ColumnName(rowName: string): string {
        switch (rowName) {
            case "row1_": return "NumberOfExistingClients";
            case "row2_": return "NumberOfExistingClientsInfused";
            case "row3_": return "PenetrationOnExistingClients";
            case "row4_": return "TargetNumberOfExistingClients";
            case "row5_": return "TargetPenetrationOfExistingClien";
            case "row6_": return "TargetGTERperEngagement";
            case "row7_": return "TargetGTERValueOfExistingClients";
            case "row8_": return "NewClientsTargetGrowthRate";
            case "row9_": return "TargetNumberOfNewClients";
            case "row10_": return "TargetNumberOfNewClientsInfused";
            case "row11_": return "TargetPenetrationNewClients";
            case "row12_": return "TargetGTERperEngagementOfNewClie";
            case "row13_": return "GTERTargetValueOfNewClients";
            case "row14_": return "TargetTotalNumberClientsInfused";
            case "row15_": return "TargetTotalValueClientsInfused";
            default: return "";
        }
    }

    saveForm7Data(isSavedDataAvailable: boolean,
        isMasterRecordAvailable: boolean, savedDataId: number,
        savedMasterRecord: MasterListModel, masterRecordId: number, formFields: any[],
        masterListSvc: MasterListService, form7Svc: Form7SPService, demandType: string) {

        let form7Data = new Form7Model();
        form7Data.Title = guid();

        let rowIds = ["row1_", "row2_", "row3_", "row4_", "row5_", "row6_", "row7_", "row8_",
            "row9_", "row10_", "row11_", "row12_", "row13_", "row14_", "row15_"];
        rowIds.forEach(rowId => {
            let fieldValues = formFields.filter(field => field.fieldName.indexOf(rowId) === 0);
            let form7Cols = {};
            fieldValues.forEach(fieldValue => {
                let fieldName = fieldValue.fieldName.split('_')[1];
                form7Cols[fieldName] = fieldValue.value;
            });
            let spColName = this.getForm7ColumnName(rowId);
            form7Data[spColName] = JSON.stringify(form7Cols).toString();
        });

        if (!isSavedDataAvailable) {
            if (!isMasterRecordAvailable) {
                let newMasterRecord: MasterListModel = new MasterListModel();
                newMasterRecord.Form2DemandListLookupId = null;
                newMasterRecord.Form3DemandListLookupId = null;
                newMasterRecord.Form4DemandListLookupId = null;
                newMasterRecord.Form5DemandListLookupId = null;
                newMasterRecord.Form6DemandListLookupId = null;
                newMasterRecord.Form7DemandListLookupId = null;
                newMasterRecord.DemandType = demandType;
                newMasterRecord.Stage = _FORM_STAGES.stage1;
                newMasterRecord.FormStatus = _FORM_STATUS.inProgress;

                masterListSvc.saveData(newMasterRecord).subscribe(mdata => {
                    // Handle Success
                    localStorage.setItem('masterRecordId', mdata.data.Id);
                    form7Svc.saveData(form7Data).subscribe(data => {
                        // Handle Success
                        mdata.data.Form7DemandListLookupId = Number(data.data.Id);
                        masterListSvc.updateData(mdata.data, mdata.data.Id).subscribe((result) => {
                            localStorage.setItem('form7SavedId', mdata.data.Form7DemandListLookupId.toString());
                        });
                    }, (error) => {
                        // Handle Error
                    });
                }, (error) => {
                    // Handle Error
                });
            }
            else {
                form7Svc.saveData(form7Data).subscribe(data => {
                    // Handle Success
                    // Update master record with Id
                    savedMasterRecord.Form7DemandListLookupId = Number(data.data.Id);
                    masterListSvc.updateData(savedMasterRecord, masterRecordId).subscribe((result) => {
                        localStorage.setItem('form7SavedId', savedMasterRecord.Form7DemandListLookupId.toString());
                    });
                }, (error) => {
                    // Handle Error
                });
            }
        }
        else {
            form7Svc.updateData(form7Data, savedDataId).subscribe(data => {
                // Handle Success
            }, (error) => {
                // Handle Error
            });
        }
    }
    /* End-Region form 7 save */
}