import { NotifierModule, NotifierService } from 'angular-notifier';
import { CommonService } from 'src/Services/common.service';
import { ApplicationConfigurationsService } from 'src/Services/applicationConfigurations.service';
import { utilitySettings } from './../../../Services/utilitySettings';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { PeoplePickerComponent } from './../../people-picker/people-picker.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Form5Component } from './form5.component';
import { Form2Component } from './form2.component';
import { Form3Component } from './form3.component';
import { Form4Component } from './form4.component';
import { Form7Component } from './form7.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Form6Component } from './form6.component';
import { spPnpAPIService } from '../../Services/Implementations/spPnPAPIService';
import { AutocompleteInputModule } from '../../Common/ey-autocomplete-input/ey-autocomplete-input.module';
import { MatDatepickerModule, MatInputModule, MatNativeDateModule } from '@angular/material';

@NgModule({
  declarations: [
    Form5Component,
    Form2Component,
    Form3Component,
    Form4Component,
    Form7Component,
    Form6Component, 
    PeoplePickerComponent 
  ],
  imports: [
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    AutocompleteInputModule, 
    DropDownsModule,
    MatDatepickerModule, MatInputModule, MatNativeDateModule,NotifierModule
  ],
  exports: [Form5Component, Form2Component, Form3Component, Form4Component, Form7Component,Form6Component],
  providers: [spPnpAPIService,utilitySettings,ApplicationConfigurationsService,CommonService,NotifierService]
})
export class FormModule { }
