import { AfterViewInit, Component, ElementRef, EventEmitter, Input, OnInit, Output, Renderer2, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { guid } from '@progress/kendo-angular-common';
import { _FORM_NAMES } from 'src/app/Models/form-names';
import { NewJurisdiction } from 'src/app/Models/new-jurisdiction';
import { Form4Model } from '../../Models/form4model';
import { MasterListModel } from '../../Models/masterListModel';
import { Form4SPService } from '../../Services/Implementations/form4Service';
import { MasterListService } from '../../Services/Implementations/masterListService';
import { _FORM_STATUS } from 'src/app/Models/formstatus';
import { _FORM_STAGES } from 'src/app/Models/formstatus';

@Component({
  selector: 'form-4',
  templateUrl: './form4.component.html',
  encapsulation: ViewEncapsulation.None,
  providers: [Form4SPService, MasterListService],
  styleUrls: ['./forms.css']
})
export class Form4Component implements OnInit {
  @Output()
  completedChildFormIds = new EventEmitter<any>();

  @Output()
  formSaved = new EventEmitter<string>();

  @Input()
  formFields: any[] = [];

  @Input()
  formStatus: string = "Not Started";

  @Input()
  demandType: string = "";

  @Input()
  isFormSubmitted: boolean = false;

  @Output()
  formSaveClick = new EventEmitter<string>();
  form4Validation: any = {};
  marketOwners: any[] = [];
  marketOwnersText: any;
  // @ViewChild('dropdownTechnology',{static:false}) dropdownTechnology: ElementRef;

  //   constructor(private renderer: Renderer2) {
  //     this.renderer.listen('window', 'click',(e:Event)=>{

  //       if(!this.dropdownTechnology.nativeElement.contains(e.target)) {
  //         this.moreTechnology=false;
  //       }

  //   });
  //  }

  //   });
  //  }

  constructor(private renderer: Renderer2, private _form4Svc: Form4SPService, private _masterListSvc: MasterListService, private router: Router) {

  }


  useCaseForm4: string = "";
  technology: string = "";
  description: string = "";
  systemIntegration: string = "";
  barriers: string = "";
  IsImmediate: string = "";
  form4AdditionalDetailsIsImmediate: string = "";
  listOfClients: string = "";
  deploymentConditions: string = "";

  arrJurisdiction: any[] = [];
  newJurisdictionArr: NewJurisdiction[] = [{ jurisdictionName: "", launchDate: null, validDate: false, validName: false }];

  isMasterRecordAvailable: boolean = false;
  masterRecordId: number = -1;
  savedMasterRecord: MasterListModel = null;

  isDataSaved: boolean = false;
  savedData: Form4Model = null;
  isSavedDataAvailable: boolean = false;
  savedDataId: number = -1;

  technologies: any = ['Predictive Intelligence', 'Document Intelligence', 'Organisational Intelligence', 'Web Scraping', 'Other'];
  // launchDate: any;

  ngOnInit() {

    this.useCaseForm4 = this.formFields.filter(f => f.fieldName === "useCaseForm4")[0].value;
    this.technology = this.formFields.filter(f => f.fieldName === "technology")[0].value;
    this.description = this.formFields.filter(f => f.fieldName === "description")[0].value;
    this.systemIntegration = this.formFields.filter(f => f.fieldName === "systemIntegration")[0].value;
    this.barriers = this.formFields.filter(f => f.fieldName === "barriers")[0].value;
    this.IsImmediate = this.formFields.filter(f => f.fieldName === "IsImmediate")[0].value;
    this.form4AdditionalDetailsIsImmediate = this.formFields.filter(f => f.fieldName === "form4AdditionalDetailsIsImmediate")[0].value;
    this.listOfClients = this.formFields.filter(f => f.fieldName === "listOfClients")[0].value;

    let newJurisdiction = this.formFields.filter(f => f.fieldName === "newJurisdictionArr")[0].value;
    // this.launchDate = this.formFields.filter(f=>f.fieldName==="launchDate")[0].value;
    this.deploymentConditions = this.formFields.filter(f => f.fieldName === "deploymentConditions")[0].value;

    if (newJurisdiction && newJurisdiction.length > 0) {
      this.newJurisdictionArr = [];
      let parsedJurisdictionArr = JSON.parse(newJurisdiction);
      if (parsedJurisdictionArr && parsedJurisdictionArr.length > 0) {
        parsedJurisdictionArr.forEach(j => {
          this.newJurisdictionArr.push({
            jurisdictionName: j.NewJurisdiction,
            launchDate: new Date(j.LaunchDate),
            validDate: false,
            validName: false
          })
        });
      }
    }
    if (this.newJurisdictionArr && this.newJurisdictionArr.length > 0) {
      this.newJurisdictionArr.forEach(item => {
        if (!item.jurisdictionName == false) {
          this.marketOwners.push({ value: "" });
          this.arrJurisdiction.push(item.jurisdictionName);
        }
      });
    }
    let marketOwnersText = this.formFields.filter(f => f.fieldName === "marketOwners")[0].value;
    if (marketOwnersText && marketOwnersText.length > 0) {
      let arrMarketOwnerText = marketOwnersText.split(',');
      if (arrMarketOwnerText && arrMarketOwnerText.length > 0) {
        for (let i = 0; i < arrMarketOwnerText.length; i++) {
          if (i < this.marketOwners.length) {
            this.marketOwners[i].value = arrMarketOwnerText[i];
          }
        }
      }
    }

    this.saveOrLoadMasterRecord();
  }

  redirectToHome() {
    this.router.navigateByUrl('/appHome');
  }

  // ngAfterViewInit() {
  //   if (this.isFormSubmitted) {
  //     setTimeout(() => {
  //       let allInputs = document.getElementsByTagName('input');
  //       if (allInputs) {
  //         for (let i = 0; i < allInputs.length; i++) {
  //           allInputs.item(i).disabled = true;
  //         }
  //       }
  //       let allSelects = document.getElementsByTagName('select');
  //       if (allSelects) {
  //         for (let i = 0; i < allSelects.length; i++) {
  //           // allSelects.item(i).disabled = true;
  //           allSelects.item(i).style.pointerEvents = "none";
  //           allSelects.item(i).style.cursor = "not-allowed";
  //         }
  //       }
  //       let allButtons = document.getElementsByTagName('button');
  //       if (allButtons) {
  //         for (let i = 0; i < allButtons.length; i++) {
  //           if (allButtons.item(i).innerText.indexOf("Back to Home") < 0)
  //             allButtons.item(i).disabled = true;
  //         }
  //       }
  //       let allTextArea = document.getElementsByTagName('textarea');
  //       if (allTextArea) {
  //         for (let i = 0; i < allTextArea.length; i++) {
  //           allTextArea.item(i).disabled = true;
  //         }
  //       }
  //     });
  //   }
  // }

  saveOrLoadMasterRecord() {
    if (localStorage.getItem('masterRecordId') && localStorage.getItem('masterRecordId').length > 0) {
      let masterId: number = Number(localStorage.getItem('masterRecordId'));
      if (masterId > 0) {
        this._masterListSvc.getSavedRecord(masterId).subscribe((masterData: MasterListModel) => {

          this.isMasterRecordAvailable = true;
          this.masterRecordId = masterId;
          this.savedMasterRecord = masterData;
          this.savedMasterRecord.FormStatus = (this.savedMasterRecord.FormStatus===_FORM_STATUS.triage) ? _FORM_STATUS.triage : _FORM_STATUS.inProgress;
          
          if (this.savedMasterRecord.Form4DemandListLookupId != null) {
            localStorage.setItem('form4SavedId', this.savedMasterRecord.Form4DemandListLookupId.toString());
            this.loadFormDataOnLoad();
          }
        }, (error) => {
          localStorage.setItem('form4SavedId', '');
          this.isSavedDataAvailable = false;
          this.isMasterRecordAvailable = false;
        });
      }
      else {
        localStorage.setItem('form4SavedId', '');
        this.isSavedDataAvailable = false;
        this.isMasterRecordAvailable = false;
      }
    }
    else {
      localStorage.setItem('form4SavedId', '');
      this.isSavedDataAvailable = false;
      this.isMasterRecordAvailable = false;
    }
  }

  loadFormDataOnLoad() {
    this.isSavedDataAvailable = false;
    this.savedData = null;
    this.savedDataId = -1;
    if (localStorage.getItem('form4SavedId') && localStorage.getItem('form4SavedId').length > 0) {
      let savedId: number = Number(localStorage.getItem('form4SavedId'));
      if (savedId > 0) {
        this._form4Svc.getSavedRecord(savedId).subscribe((form4Data: Form4Model) => {
          this.isSavedDataAvailable = true;
          this.savedData = form4Data;
          this.savedDataId = savedId;

          this.useCaseForm4 = this.formFields.filter(f => f.fieldName === "useCaseForm4")[0].value = form4Data.Form4UseCaseName;
          this.technology = this.formFields.filter(f => f.fieldName === "technology")[0].value = form4Data.Technology;
          this.description = this.formFields.filter(f => f.fieldName === "description")[0].value = form4Data.DescriptionUseCase;
          this.systemIntegration = this.formFields.filter(f => f.fieldName === "systemIntegration")[0].value = form4Data.OtherSystemIntegrationUseCase;
          this.barriers = this.formFields.filter(f => f.fieldName === "barriers")[0].value = form4Data.BarrierChallengesImpact;
          this.IsImmediate = this.formFields.filter(f => f.fieldName === "IsImmediate")[0].value = form4Data.Form4ClientImmediateDemand;
          this.form4AdditionalDetailsIsImmediate = this.formFields.filter(f => f.fieldName === "form4AdditionalDetailsIsImmediate")[0].value = form4Data.Form4ClientImmediateDemandDetail;
          this.listOfClients = this.formFields.filter(f => f.fieldName === "listOfClients")[0].value = form4Data.Form4ListClientTarget;
          this.formFields.filter(f => f.fieldName === "newJurisdictionArr")[0].value = form4Data.NewJurisdictionRequired;

          this.newJurisdictionArr = [];
          let priorityNewJurisdiction = form4Data.NewJurisdictionRequired;

          if (priorityNewJurisdiction && priorityNewJurisdiction.length > 0) {
            let parsedNewJurisdictionArr = JSON.parse(priorityNewJurisdiction);
            if (parsedNewJurisdictionArr && parsedNewJurisdictionArr.length > 0) {
              parsedNewJurisdictionArr.forEach(j => {
                this.newJurisdictionArr.push({
                  jurisdictionName: j.NewJurisdiction,
                  launchDate: new Date(j.LaunchDate),
                  validDate: false,
                  validName: false
                })
              });
            }
          }
          // this.launchDate = this.formFields.filter(f=>f.fieldName==="launchDate")[0].value=form4Data.Form4TargetLaunchDate;
          this.deploymentConditions = this.formFields.filter(f => f.fieldName === "deploymentConditions")[0].value = form4Data.Form4DeploymentConditionsBarrier;
          let marketOwnersText = this.formFields.filter(f => f.fieldName === "marketOwners")[0].value = form4Data.Form4MarketOwnerJurisdictionSpec;
          if (this.newJurisdictionArr && this.newJurisdictionArr.length > 0) {
            this.newJurisdictionArr.forEach(item => {
              if (!item.jurisdictionName == false) {
                this.marketOwners.push({ value: "" });
                this.arrJurisdiction.push(item.jurisdictionName);
              }
            });
          }
          if (marketOwnersText && marketOwnersText.length > 0) {
            let arrMarketOwnerText = marketOwnersText.split(',');
            if (arrMarketOwnerText && arrMarketOwnerText.length > 0) {
              for (let i = 0; i < arrMarketOwnerText.length; i++) {
                if (i < this.marketOwners.length) {
                  this.marketOwners[i].value = arrMarketOwnerText[i];
                }
              }
            }
          }
          this.completedChildFormIds.emit(this.formFields);
        });
      }
    }
  }
 
  onTextChange( index = null) {
   
    this.formFields.forEach(field => {
      if (field.fieldName === "useCaseForm4") {
        field.value = this.useCaseForm4;
      }
      else if (field.fieldName === "technology") {
        field.value = this.technology;
      }
      else if (field.fieldName === "description") {
        field.value = this.description;
      }
      else if (field.fieldName === "systemIntegration") {
        field.value = this.systemIntegration;
      }
      else if (field.fieldName === "barriers") {
        field.value = this.barriers;
      }
      else if (field.fieldName === "IsImmediate") {
        field.value = this.IsImmediate;
      }
      else if (field.fieldName === "form4AdditionalDetailsIsImmediate") {
        field.value = this.form4AdditionalDetailsIsImmediate;
      }
      else if (field.fieldName === "listOfClients") {
        field.value = this.listOfClients;
      }
      else if (field.fieldName === "newJurisdictionArr") {
        field.value = "";
        
        if (this.newJurisdictionArr.length > 0) {
          let jurisdictionData: any[] = [];
          for (let i = 0; i < this.newJurisdictionArr.length; i++) {
            if (this.newJurisdictionArr[i].jurisdictionName
              && this.newJurisdictionArr[i].jurisdictionName.length > 0
              && this.newJurisdictionArr[i].launchDate) {
              jurisdictionData.push({
                NewJurisdiction: this.newJurisdictionArr[i].jurisdictionName,
                LaunchDate: this.newJurisdictionArr[i].launchDate.toLocaleDateString()
              });
            }
            else {
              field.value = "";
              break;
            }
          }
          if (jurisdictionData && jurisdictionData.length > 0) {
            field.value = JSON.stringify(jurisdictionData).toString();
          }
        }
      }
      /* else if(field.fieldName==="launchDate"){
          field.value = this.launchDate;
        } */

      else if (field.fieldName === "deploymentConditions") {
        field.value = this.deploymentConditions;
      }
      else if (field.fieldName === "marketOwners") {
        field.value = "";
       
        //change market owner name on text change 
        if (this.arrJurisdiction.length - 1 >= index && index != null) {
          this.arrJurisdiction[index] = this.newJurisdictionArr[index].jurisdictionName;
        }

        if (this.marketOwners.length > 0) {
          for (let i = 0; i < this.marketOwners.length; i++) {
            if (this.marketOwners[i] && this.marketOwners[i].value && this.marketOwners[i].value.length > 0) {
              if (field.value && field.value.length > 0) {
                field.value = field.value + "," + this.marketOwners[i].value;
              }
              else {
                field.value = this.marketOwners[i].value;
              }
            }
            else {
              field.value = "";
              break;
            }
          }
        }
      }
  
    })
    this.completedChildFormIds.emit(this.formFields);
  }

  saveFormData() {
    let form4Data = new Form4Model();
    if (!this.isSavedDataAvailable) {
      form4Data.Title = guid();
    }
    else {
      form4Data.Title = this.savedData.Title;
    }
    form4Data.Form4UseCaseName = this.useCaseForm4;
    form4Data.Technology = this.technology;
    form4Data.DescriptionUseCase = this.description
    form4Data.OtherSystemIntegrationUseCase = this.systemIntegration;
    form4Data.BarrierChallengesImpact = this.barriers;
    form4Data.Form4ClientImmediateDemand = this.IsImmediate;
    form4Data.Form4ClientImmediateDemandDetail = this.form4AdditionalDetailsIsImmediate;
    form4Data.Form4ListClientTarget = this.listOfClients;
    form4Data.NewJurisdictionRequired = "";
    if (this.newJurisdictionArr && this.newJurisdictionArr.length > 0) {
      let jurisdictionData: any[] = [];
      this.newJurisdictionArr.forEach(item => {
        if (item.jurisdictionName && item.jurisdictionName.length > 0 && item.launchDate) {
          jurisdictionData.push({
            NewJurisdiction: item.jurisdictionName,
            LaunchDate: item.launchDate.toLocaleDateString()
          });
        }
      });
      if (jurisdictionData && jurisdictionData.length > 0) {
        form4Data.NewJurisdictionRequired = JSON.stringify(jurisdictionData).toString();
      }
    }
    // form4Data.Form4TargetLaunchDate = this.launchDate;
    form4Data.Form4DeploymentConditionsBarrier = this.deploymentConditions;

    form4Data.Form4MarketOwnerJurisdictionSpec = "";
    if (this.marketOwners && this.marketOwners.length > 0) {
      this.marketOwners.forEach(marketOwner => {
        if (form4Data.Form4MarketOwnerJurisdictionSpec === "") {
          form4Data.Form4MarketOwnerJurisdictionSpec = marketOwner.value;
        }
        else {
          form4Data.Form4MarketOwnerJurisdictionSpec = form4Data.Form4MarketOwnerJurisdictionSpec + "," + marketOwner.value;
        }
      });
    }
    form4Data.CompletionStatus = this.formStatus;

    if (!this.isSavedDataAvailable) {
      if (!this.isMasterRecordAvailable) {
        let newMasterRecord: MasterListModel = new MasterListModel();
        newMasterRecord.Form2DemandListLookupId = null;
        newMasterRecord.Form3DemandListLookupId = null;
        newMasterRecord.Form4DemandListLookupId = null;
        newMasterRecord.Form5DemandListLookupId = null;
        newMasterRecord.Form6DemandListLookupId = null;
        newMasterRecord.DemandType = this.demandType;
        newMasterRecord.FormStatus = _FORM_STATUS.inProgress;
        newMasterRecord.Stage = _FORM_STAGES.stage1

        this._masterListSvc.saveData(newMasterRecord).subscribe(mdata => {
          // Handle Success
          this.isMasterRecordAvailable = true;
          this.masterRecordId = Number(mdata.data.Id);
          this.savedMasterRecord = newMasterRecord;

          localStorage.setItem('masterRecordId', mdata.data.Id);
          this._form4Svc.saveData(form4Data).subscribe(data => {
            // Handle Success
            // Update master record with Id
            this.savedMasterRecord.Form4DemandListLookupId = Number(data.data.Id);
            this._masterListSvc.updateData(this.savedMasterRecord, this.masterRecordId).subscribe((data) => {
              this.isDataSaved = true;
              localStorage.setItem('form4SavedId', this.savedMasterRecord.Form4DemandListLookupId.toString());
              this.formSaved.emit(_FORM_NAMES.form4);
              this.setFormActive(_FORM_NAMES.form5);
            });
          }, (error) => {
            // Handle Error
            this.isDataSaved = false;
          });
        }, (error) => {
          // Handle Error
          this.isMasterRecordAvailable = false;
          this.isDataSaved = false;
        });
      }
      else {
        this._form4Svc.saveData(form4Data).subscribe(data => {
          // Handle Success
          // Update master record with Id
          this.savedMasterRecord.Form4DemandListLookupId = Number(data.data.Id);
          this._masterListSvc.updateData(this.savedMasterRecord, this.masterRecordId).subscribe((data) => {
            this.isDataSaved = true;
            localStorage.setItem('form4SavedId', this.savedMasterRecord.Form4DemandListLookupId.toString());
            this.formSaved.emit(_FORM_NAMES.form4);
            this.setFormActive(_FORM_NAMES.form5);
          });
        }, (error) => {
          // Handle Error
          this.isDataSaved = false;
        });
      }
    }
    else {
      this._form4Svc.updateData(form4Data, this.savedDataId).subscribe(data => {
        // Handle Success
        this.isDataSaved = true;
        this.formSaved.emit(_FORM_NAMES.form4);
        this.setFormActive(_FORM_NAMES.form5);
      }, (error) => {
        // Handle Error
        this.isDataSaved = false;
      });
    }
  }

  onDate(event, jurisdiction: NewJurisdiction) {
    jurisdiction.launchDate = new Date(event.value);
    this.onTextChange();
  }

  addNew(controlName) {

    if (controlName == 'newJurisdictionArr') {

      let item = this.newJurisdictionArr.length - 1;
      if (this.newJurisdictionArr && this.newJurisdictionArr.length > 0 && this.marketOwners.length != this.newJurisdictionArr.length) {

        if (!this.newJurisdictionArr[item].jurisdictionName == false && !this.newJurisdictionArr[item].launchDate == false) {
          this.marketOwners.push({ value: "" });
          this.arrJurisdiction.push(this.newJurisdictionArr[item].jurisdictionName);

        };
      }

      if (!this.newJurisdictionArr[item].jurisdictionName || !this.newJurisdictionArr[item].launchDate) {

        this.newJurisdictionArr[item].validName = !this.newJurisdictionArr[item].jurisdictionName ? true : false;
        this.newJurisdictionArr[item].validDate = !this.newJurisdictionArr[item].validDate ? true : false;

        this.form4Validation.isForminValid = true;
        return;
      }
      else {
        this.newJurisdictionArr.push({ jurisdictionName: "", launchDate: null, validDate: false, validName: false });

      }


    }
  }



  //remove element at position i
  remove(controlName, i) {
    if (controlName == 'newJurisdictionArr') {
      if (i != 0)
        this.newJurisdictionArr.splice(i, 1);

      this.marketOwners.splice(i, 1);
      this.arrJurisdiction.splice(i, 1);


    }
  }

  isEmpty(controlName) {
    var formValue = controlName;
    console.log(formValue);
    if (formValue.length <= 0)
      return true;
    else
      return false;
  }

  setFormActive(form) {
    this.formSaveClick.emit(form);
  }
}

