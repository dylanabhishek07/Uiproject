import { AfterViewInit, Component, EventEmitter, Input, OnInit, Output, ViewEncapsulation } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { guid } from '@progress/kendo-angular-common';
import { _FORM_NAMES } from 'src/app/Models/form-names';
import { Form7Columns, Form7Model } from 'src/app/Models/form7model';
import { _FORM_STAGES, _FORM_STATUS } from 'src/app/Models/formstatus';
import { MasterListModel } from 'src/app/Models/masterListModel';
import { Form7SPService } from 'src/app/Services/Implementations/form7Service';
import { MasterListService } from 'src/app/Services/Implementations/masterListService';
import { Calculations } from 'src/app/Utilities/calculationUtil';

@Component({
  selector: 'form-7',
  templateUrl: './form7.component.html',
  styleUrls: ['./forms.css'],
  encapsulation: ViewEncapsulation.None,
  providers: [MasterListService, Form7SPService]
})
export class Form7Component implements OnInit {
  @Output()
  completedChildFormIds = new EventEmitter<any>();

  @Output()
  formSaved = new EventEmitter<string>();

  @Input()
  formFields: any[] = [];

  @Input()
  formStatus: string = "Not Started";

  @Input()
  demandType: string = "";

  @Input()
  isFormSubmitted: boolean = false;

  @Output()
  formSaveClick = new EventEmitter<string>();

  formValues: any = {
    existingClientRows: [],
    newClientRows: [],
    costSavingsRows: [],
    totalRows: []
  };

  existingClintRowsIndex = ['row1_', 'row2_', 'row3_', 'row4_', 'row5_', 'row6_', 'row7_'];
  newClientRowsIndex = ['row8_', 'row9_', 'row10_', 'row11_', 'row12_', 'row13_'];
  costSavingsRowsIndex = ['row14_', 'row15_', 'row16_', 'row17_'];
  totalRowsIndex = ['row18_', 'row19_', 'row20_'];

  isDataSaved: boolean = false;
  savedData: Form7Model = null;
  isSavedDataAvailable: boolean = false;
  savedDataId: number = -1;

  isMasterRecordAvailable: boolean = false;
  masterRecordId: number = -1;
  savedMasterRecord: MasterListModel = null;

  constructor(private _masterListSvc: MasterListService,
    private _form7Svc: Form7SPService, private router: Router) {

  }

  ngOnInit() {
    this.existingClintRowsIndex.forEach(idx => {
      let rowCells = this.formFields.filter(field => field.fieldName.indexOf(idx) === 0);
      let rowObj: any = {};
      rowObj.title = "";
      switch (idx) {
        case "row1_":
          rowObj.title = "Number of Existing Clients that EY provides this service";
          rowObj.spColName = "NumberOfExistingClients";
          break;
        case "row2_":
          rowObj.title = "Number of these existing Clients already infused by Alwin";
          rowObj.spColName = "NumberOfExistingClientsInfused";
          break;
        case "row3_":
          rowObj.title = "Actual % Alwin penetration on existing clients";
          rowObj.spColName = "PenetrationOnExistingClients";
          break;
        case "row4_":
          rowObj.title = "Target Number of existing clients to be infused with Alwin";
          rowObj.spColName = "TargetNumberOfExistingClients";
          break;
        case "row5_":
          rowObj.title = "Target % Alwin penetration of Existing Clients";
          rowObj.spColName = "TargetPenetrationOfExistingClien";
          break;
        case "row6_":
          rowObj.title = "Target GTER per engagement,infused by Alwin($USD)";

          rowObj.spColName = "TargetGTERperEngagement";
          break;
        case "row7_":
          rowObj.title = "GTER Target Value of Existing Clients Infused by Alwin";
          rowObj.spColName = "TargetGTERValueOfExistingClients";
          break;
      }
      rowObj.cells = rowCells;
      this.formValues.existingClientRows.push(rowObj);
    });

    this.newClientRowsIndex.forEach(idx => {
      let rowCells = this.formFields.filter(field => field.fieldName.indexOf(idx) === 0);
      let rowObj: any = {};
      rowObj.title = "";
      switch (idx) {
        case "row8_":
          rowObj.title = "New clients target growth rate";
          rowObj.spColName = "NewClientsTargetGrowthRate";
          break;
        case "row9_":
          rowObj.title = "Target number of new clients ";
          rowObj.spColName = "TargetNumberOfNewClients";
          break;
        case "row10_":
          rowObj.title = "Target Number of New Clients infused by Alwin";
          rowObj.spColName = "TargetNumberOfNewClientsInfused";
          break;
        case "row11_":
          rowObj.title = "Target % Alwin penetration in new clients ";
          rowObj.spColName = "TargetPenetrationNewClients";
          break;
        case "row12_":
          rowObj.title = "Target GTER per engagement,infused by Alwin($USD)";

          rowObj.spColName = "TargetGTERperEngagementOfNewClie";
          break;
        case "row13_":
          rowObj.title = "GTER Target Value of New Clients Infused by Alwin";
          rowObj.spColName = "GTERTargetValueOfNewClients";
          break;
      }
      rowObj.cells = rowCells;
      this.formValues.newClientRows.push(rowObj);
    });

    this.costSavingsRowsIndex.forEach(idx => {
      let rowCells = this.formFields.filter(field => field.fieldName.indexOf(idx) === 0);
      let rowObj: any = {};
      rowObj.title = "";
      switch (idx) {
        case "row14_":
          rowObj.title = "FTE Cost Savings total GTER ($USD / 000)";
          rowObj.spColName = "FTECostSavings";
          break;
        case "row15_":
          rowObj.title = "Quality Improvement cost savings total GTER ($USD / 000)";
          rowObj.spColName = "QualityImprovementCostSavings";
          break;
        case "row16_":
          rowObj.title = "Risk Mitigation cost savings (avoiding penalities etc) total GTER ($USD / 000)";
          rowObj.spColName = "RiskMitigationCostSavings";
          break;
        case "row17_":
          rowObj.title = "Total Cost savings GTER ($USD / 000)";
          rowObj.spColName = "TotalCostSavings";
          break;
      }
      rowObj.cells = rowCells;
      this.formValues.costSavingsRows.push(rowObj);
    });

    this.totalRowsIndex.forEach(idx => {
      let rowCells = this.formFields.filter(field => field.fieldName.indexOf(idx) === 0);
      let rowObj: any = {};
      rowObj.title = "";
      switch (idx) {
        case "row18_":
          rowObj.title = "Target total Number of Clients Infused by Alwin";
          rowObj.spColName = "TotalClientByAlwin";
          break;
        case "row19_":
          rowObj.title = "Target GTER total Value of Clients Infused by Alwin ($USD / 000)";
          rowObj.spColName = "TotalGTERValueByAlwin";
          break;
        case "row20_":
          rowObj.title = "Target GTER total Business Value of Alwin ($USD / 000)";
          rowObj.spColName = "TotalBusinessValueOfAlwin";
          break;
      }
      rowObj.cells = rowCells;
      this.formValues.totalRows.push(rowObj);
    });

    this.saveOrLoadMasterRecord();
  }

  // ngAfterViewInit() {
  //   if (this.isFormSubmitted) {
  //     setTimeout(() => {
  //       let allInputs = document.getElementsByTagName('input');
  //       if (allInputs) {
  //         for (let i = 0; i < allInputs.length; i++) {
  //           allInputs.item(i).disabled = true;
  //         }
  //       }
  //       let allSelects = document.getElementsByTagName('select');
  //       if (allSelects) {
  //         for (let i = 0; i < allSelects.length; i++) {
  //           allSelects.item(i).disabled = true;
  //         }
  //       }
  //       let allButtons = document.getElementsByTagName('button');
  //       if (allButtons) {
  //         for (let i = 0; i < allButtons.length; i++) {
  //           if (allButtons.item(i).innerText.indexOf("Back to Home") < 0)
  //             allButtons.item(i).disabled = true;
  //         }
  //       }
  //       let allTextArea = document.getElementsByTagName('textarea');
  //       if (allTextArea) {
  //         for (let i = 0; i < allTextArea.length; i++) {
  //           allTextArea.item(i).disabled = true;
  //         }
  //       }
  //     });
  //   }
  // }

  saveOrLoadMasterRecord() {
    if (localStorage.getItem('masterRecordId') && localStorage.getItem('masterRecordId').length > 0) {
      let masterId: number = Number(localStorage.getItem('masterRecordId'));
      if (masterId > 0) {
        this._masterListSvc.getSavedRecord(masterId).subscribe((masterData: MasterListModel) => {

          this.isMasterRecordAvailable = true;
          this.masterRecordId = masterId;
          this.savedMasterRecord = masterData;
          if (this.savedMasterRecord.Form7DemandListLookupId != null) {
            localStorage.setItem('form7SavedId', this.savedMasterRecord.Form7DemandListLookupId.toString());
            this.loadFormDataOnLoad();
          }
        }, (error) => {
          this.isSavedDataAvailable = false;
          this.isMasterRecordAvailable = false;
          localStorage.setItem('form7SavedId', '');
        });
      }
      else {
        this.isSavedDataAvailable = false;
        this.isMasterRecordAvailable = false;
        localStorage.setItem('form7SavedId', '');
      }
    }
    else {
      this.isSavedDataAvailable = false;
      this.isMasterRecordAvailable = false;
      localStorage.setItem('form7SavedId', '');
    }
  }

  loadFormDataOnLoad() {
    this.isSavedDataAvailable = false;
    this.savedData = null;
    this.savedDataId = -1;
    if (localStorage.getItem('form7SavedId') && localStorage.getItem('form7SavedId').length > 0) {
      let savedId: number = Number(localStorage.getItem('form7SavedId'));
      if (savedId > 0) {
        this._form7Svc.getSavedRecord(savedId).subscribe((form7Data: Form7Model) => {
          this.savedData = form7Data;
          this.savedDataId = savedId;
          this.isSavedDataAvailable = true;

          // Populating saved fields
          Object.keys(this.formValues).forEach(key => {
            let valueArray: any[] = this.formValues[key];
            if (valueArray && valueArray.length > 0) {
              valueArray.forEach(value => {
                let spColData = form7Data[value.spColName];
                let parsedColData = JSON.parse(spColData);
                if (value.cells && value.cells.length > 0) {
                  value.cells.forEach(cell => {
                    let fieldName = cell.fieldName;
                    let fieldNameKey = fieldName.split('_')[1];
                    cell.value = parsedColData[fieldNameKey];
                    this.formFields.filter(field => field.fieldName === fieldName)[0].value = parsedColData[fieldNameKey];
                  });
                }
              });
            }
          });

          this.completedChildFormIds.emit(this.formFields);
        });
      }
    }
  }

  onTextChange(cell) {
    let fieldName = cell.fieldName;
    let value = cell.value;
    if (cell.type === "Integer") {
      if (isNaN(Number(value))) {
        value = "";
      }
      if (value.indexOf(".") > -1) {
        value = "";
      }
    }

    this.formFields.forEach(field => {
      if (field.fieldName === fieldName) {
        field.value = value;
      }
      // Adding new calculations
      if (field.formula && field.formula.length > 0) {
        let stringExpression = Calculations.populateFormula(field.formula, this.formFields);
        let fieldValue = Calculations.evaluateExpression(stringExpression);
        field.value = fieldValue;
      }
    })


    this.completedChildFormIds.emit(this.formFields);
  }

  redirectToHome() {
    this.router.navigateByUrl('/appHome');
  }

  saveFormData() {
    let form7Data = new Form7Model();
    if (!this.isSavedDataAvailable) {
      form7Data.Title = guid();
    }
    else {
      form7Data.Title = this.savedData.Title;
    }
    let rowIds = ["row1_", "row2_", "row3_", "row4_", "row5_", "row6_", "row7_", "row8_",
      "row9_", "row10_", "row11_", "row12_", "row13_", "row14_", "row15_", "row16_", "row17_",
      "row18_", "row19_", "row20_"];
    rowIds.forEach(rowId => {
      let fieldValues = this.formFields.filter(field => field.fieldName.indexOf(rowId) === 0);
      let form7Cols = {};
      fieldValues.forEach(fieldValue => {
        let fieldName = fieldValue.fieldName.split('_')[1];
        form7Cols[fieldName] = fieldValue.value;
      });
      let spColName = this.getForm7ColumnName(rowId);
      form7Data[spColName] = JSON.stringify(form7Cols).toString();
    });
    form7Data.CompletionStatus = this.formStatus;
    if (!this.isSavedDataAvailable) {
      if (!this.isMasterRecordAvailable) {
        let newMasterRecord: MasterListModel = new MasterListModel();
        newMasterRecord.Form2DemandListLookupId = null;
        newMasterRecord.Form3DemandListLookupId = null;
        newMasterRecord.Form4DemandListLookupId = null;
        newMasterRecord.Form5DemandListLookupId = null;
        newMasterRecord.Form6DemandListLookupId = null;
        newMasterRecord.DemandType = this.demandType;
        newMasterRecord.FormStatus = _FORM_STATUS.inProgress;
        newMasterRecord.Stage = _FORM_STAGES.stage2;

        this._masterListSvc.saveData(newMasterRecord).subscribe(mdata => {
          // Handle Success
          this.isMasterRecordAvailable = true;
          this.masterRecordId = Number(mdata.data.Id);
          this.savedMasterRecord = newMasterRecord;

          localStorage.setItem('masterRecordId', mdata.data.Id);
          this._form7Svc.saveData(form7Data).subscribe(data => {
            // Handle Success
            // Update master record with Id
            this.savedMasterRecord.Form7DemandListLookupId = Number(data.data.Id);
            this.savedMasterRecord.FormStatus = _FORM_STATUS.inProgress;
            this.savedMasterRecord.Stage = _FORM_STAGES.stage2;
            this._masterListSvc.updateData(this.savedMasterRecord, this.masterRecordId).subscribe((data) => {
              this.isDataSaved = true;
              localStorage.setItem('form7SavedId', this.savedMasterRecord.Form7DemandListLookupId.toString());
              this.formSaved.emit(_FORM_NAMES.form7);
              this.setFormActive(_FORM_NAMES.form7);
            });
          }, (error) => {
            // Handle Error
            this.isDataSaved = false;
          });
        }, (error) => {
          // Handle Error
          this.isMasterRecordAvailable = false;
          this.isDataSaved = false;
        });
      }
      else {
        this._form7Svc.saveData(form7Data).subscribe(data => {
          // Handle Success
          // Update master record with Id
          this.savedMasterRecord.Form7DemandListLookupId = Number(data.data.Id);
          this.savedMasterRecord.FormStatus = _FORM_STATUS.inProgress;
          this.savedMasterRecord.Stage = _FORM_STAGES.stage2;
          this._masterListSvc.updateData(this.savedMasterRecord, this.masterRecordId).subscribe((data) => {
            this.isDataSaved = true;
            localStorage.setItem('form7SavedId', this.savedMasterRecord.Form7DemandListLookupId.toString());
            this.formSaved.emit(_FORM_NAMES.form7);
            this.setFormActive(_FORM_NAMES.form7);
          });
        }, (error) => {
          // Handle Error
          this.isDataSaved = false;
        });
      }
    }
    else {
      this._form7Svc.updateData(form7Data, this.savedDataId).subscribe(data => {
        // Handle Success
        this.isDataSaved = true;
        this.formSaved.emit(_FORM_NAMES.form7);
        this.setFormActive(_FORM_NAMES.form7);
      }, (error) => {
        // Handle Error
        this.isDataSaved = false;
      });
    }
  }

  getForm7ColumnName(rowName: string): string {
    switch (rowName) {
      case "row1_": return "NumberOfExistingClients";
      case "row2_": return "NumberOfExistingClientsInfused";
      case "row3_": return "PenetrationOnExistingClients";
      case "row4_": return "TargetNumberOfExistingClients";
      case "row5_": return "TargetPenetrationOfExistingClien";
      case "row6_": return "TargetGTERperEngagement";
      case "row7_": return "TargetGTERValueOfExistingClients";
      case "row8_": return "NewClientsTargetGrowthRate";
      case "row9_": return "TargetNumberOfNewClients";
      case "row10_": return "TargetNumberOfNewClientsInfused";
      case "row11_": return "TargetPenetrationNewClients";
      case "row12_": return "TargetGTERperEngagementOfNewClie";
      case "row13_": return "GTERTargetValueOfNewClients";
      case "row14_": return "FTECostSavings";
      case "row15_": return "QualityImprovementCostSavings";
      case "row16_": return "RiskMitigationCostSavings";
      case "row17_": return "TotalCostSavings";
      case "row18_": return "TotalClientByAlwin";
      case "row19_": return "TotalGTERValueByAlwin";
      case "row20_": return "TotalBusinessValueOfAlwin";
      default: return "";
    }
  }



  setFormActive(form) {
    this.formSaveClick.emit(form);
  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }
}
