import { ApplicationConfigurationsService } from 'src/Services/applicationConfigurations.service';
import { CommonService } from 'src/Services/common.service';
import { AfterViewInit, Component, ElementRef, EventEmitter, Input, OnInit, Output, Renderer2, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Form3Model } from '../../Models/form3model';
import { MasterListModel } from '../../Models/masterListModel';
import { MasterListService } from '../../Services/Implementations/masterListService';
import { Form3SPService } from '../../Services/Implementations/form3Service';
import { guid } from '@progress/kendo-angular-common';
import { Observable, Subject } from 'rxjs';
import { AutocompleteInterface } from 'src/app/Common/ey-autocomplete-input/autocomplete.interface';
import { UserSPService } from 'src/app/Services/Implementations/userSPService';
import { DoesNotContainFilterOperatorComponent } from '@progress/kendo-angular-grid';
import { _FORM_NAMES } from 'src/app/Models/form-names';
import { Router } from '@angular/router';
import { _FORM_STATUS } from 'src/app/Models/formstatus';
import { _FORM_STAGES } from 'src/app/Models/formstatus';
import { JsonPipe } from '@angular/common';

@Component({
  selector: 'form-3',
  templateUrl: './form3.component.html',
  encapsulation: ViewEncapsulation.None,
  providers: [Form3SPService, MasterListService, UserSPService],
  styleUrls: ['./forms.css']
})
export class Form3Component implements OnInit {    //AfterViewInit {
  @Output()
  completedChildFormIds = new EventEmitter<any>();

  @Output()
  formSaved = new EventEmitter<string>();

  @Input()
  formFields: any[] = [];

  @Input()
  formStatus: string = "Not Started";

  @Input()
  jurisdictionArr: any[] = [];

  @Input()
  demandType: string = "";

  @Input()
  isFormSubmitted: boolean = false;

  more: boolean;
  dropdownVal: string;
  @Output()
  formSaveClick = new EventEmitter<string>();
  peoplePickerOptionsSSLOwner: Subject<AutocompleteInterface[]> = new Subject();
  peoplePickerOptionsSSLSponser: Subject<AutocompleteInterface[]> = new Subject();
  peoplePickerOptionsSSLDeputy: Subject<AutocompleteInterface[]> = new Subject();





  // @ViewChild('dropdownDivSSL',{static:false}) dropdownDivSSL: ElementRef;

  constructor(private _form3Svc: Form3SPService,
    private _masterListSvc: MasterListService,
    private _userSvc: UserSPService, private router: Router, private commonService: CommonService, private appConfigService: ApplicationConfigurationsService) {

  }

  // constructor(private renderer: Renderer2) {
  //   this.renderer.listen('window', 'click',(e:Event)=>{
  //     /**
  //      * Only run when toggleButton is not clicked
  //      * If we don't check this, all clicks (even on the toggle button) gets into this
  //      * section which in the result we might never see the menu open!
  //      * And the menu itself is checked here, and it's where we check just outside of
  //      * the menu and button the condition abbove must close the menu
  //      */
  //     // if(!this.dropdownDivSSL.nativeElement.contains(e.target)) {
  //     //     this.more=false;
  //     // }
  // });
  //  }

  owningSslList: any = ['BTS', 'Private', 'GCR/TFO', 'Indirect', 'ITTS', 'Law', 'PAS', 'TTT'];
  options: any = ["Yes", "No"];
  sslSolutionOwnerDisplayName: string;
  sslSponsoringDisplayName: string;
  sslSolutionDeputyDisplayName: string;
  owningSSL: string = "";
  sslCompetency: string = "";
  sslSponsoringName: string = "";
  sslSponsoringNameId: string = "";
  sslSponsoringEmail: string = "";
  sslSponsoringRole: string = "";
  sslSolutionOwnerName: string = "";
  sslSolutionOwnerNameId: string = "";
  sslSolutionOwnerEmail: string = "";
  sslSolutionOwnerRole: string = "";
  sslSolutionDeputyName: string = "";
  sslSolutionDeputyNameId: string = "";
  sslSolutionDeputyEmail: string = "";
  sslSolutionDeputyRole: string = "";
  // marketOwner: string = "";
  radioQuesA: string = "";
  radioQuesB: string = "";
  form3AdditionalDetails: string = "";
  marketOwners: any[] = [];
  arrJurisdiction: any;

  isDataSaved: boolean = false;
  savedData: Form3Model = null;
  isSavedDataAvailable: boolean = false;
  savedDataId: number = -1;

  isMasterRecordAvailable: boolean = false;
  masterRecordId: number = -1;
  savedMasterRecord: MasterListModel = null;
  isLoadingUserList: boolean = true;
  ownerAutocompletionSubject: Subject<AutocompleteInterface[]> = new Subject();
  sponsorPartnerAutocompletionSubject: Subject<AutocompleteInterface[]> = new Subject();
  deputyAutocompleteSubject: Subject<AutocompleteInterface[]> = new Subject();
  userList: AutocompleteInterface[] = [];

  form3Validation: any = {};


  ngOnInit() {

    this.more = false;
    this.dropdownVal = "";
    console.log(this.jurisdictionArr);
    this.arrJurisdiction = this.jurisdictionArr;
    if (this.arrJurisdiction && this.arrJurisdiction.length > 0) {
      this.arrJurisdiction.forEach(item => {
        this.marketOwners.push({ value: "" });
      });
    }

    this.owningSSL = this.formFields.filter(f => f.fieldName === "owningSSL")[0].value;
    this.sslCompetency = this.formFields.filter(f => f.fieldName === "sslCompetency")[0].value;
    this.sslSponsoringName = this.formFields.filter(f => f.fieldName === "sslSponsoringName")[0].value;
    this.sslSponsoringDisplayName = this.formFields.filter(f => f.fieldName === "sslSponsoringDisplayName")[0].value;
    this.sslSponsoringEmail = this.formFields.filter(f => f.fieldName === "sslSponsoringEmail")[0].value;
    this.sslSponsoringRole = this.formFields.filter(f => f.fieldName === "sslSponsoringRole")[0].value;
    this.sslSolutionOwnerName = this.formFields.filter(f => f.fieldName === "sslSolutionOwnerName")[0].value;
    this.sslSolutionOwnerDisplayName = this.formFields.filter(f => f.fieldName === "sslSolutionOwnerDisplayName")[0].value;
    this.sslSolutionOwnerEmail = this.formFields.filter(f => f.fieldName === "sslSolutionOwnerEmail")[0].value;
    this.sslSolutionOwnerRole = this.formFields.filter(f => f.fieldName === "sslSolutionOwnerRole")[0].value;
    this.sslSolutionDeputyName = this.formFields.filter(f => f.fieldName === "sslSolutionDeputyName")[0].value;
    this.sslSolutionDeputyDisplayName = this.formFields.filter(f => f.fieldName === "sslSolutionDeputyDisplayName")[0].value;
    this.sslSolutionDeputyEmail = this.formFields.filter(f => f.fieldName === "sslSolutionDeputyEmail")[0].value;
    this.sslSolutionDeputyRole = this.formFields.filter(f => f.fieldName === "sslSolutionDeputyRole")[0].value;
    this.radioQuesA = this.formFields.filter(f => f.fieldName === "radioQuesA")[0].value;
    this.radioQuesB = this.formFields.filter(f => f.fieldName === "radioQuesB")[0].value;
    this.form3AdditionalDetails = this.formFields.filter(f => f.fieldName === "form3AdditionalDetails")[0].value;

    let marketOwnersText = this.formFields.filter(f => f.fieldName === "marketOwners")[0].value;
    if (marketOwnersText && marketOwnersText.length > 0) {
      let arrMarketOwnerText = marketOwnersText.split(',');
      if (arrMarketOwnerText && arrMarketOwnerText.length > 0) {
        for (let i = 0; i < arrMarketOwnerText.length; i++) {
          if (i < this.marketOwners.length) {
            this.marketOwners[i].value = arrMarketOwnerText[i];
          }
        }
      }
    }

    this.saveOrLoadMasterRecord();
    this.ownerAutocompletionSubject.next([]);
    this.sponsorPartnerAutocompletionSubject.next([]);
    this.deputyAutocompleteSubject.next([]);
    setTimeout(() => {
      this.populateUserList();
    }, 500);
  }

  // ngAfterViewInit() {
  //   if (this.isFormSubmitted) {
  //     setTimeout(() => {
  //       let allInputs = document.getElementsByTagName('input');
  //       if (allInputs) {
  //         for (let i = 0; i < allInputs.length; i++) {
  //           allInputs.item(i).disabled = true;
  //         }
  //       }
  //       let allSelects = document.getElementsByTagName('select');
  //       if (allSelects) {
  //         for (let i = 0; i < allSelects.length; i++) {
  //           //allSelects.item(i).disabled = true;
  //           allSelects.item(i).style.pointerEvents = "none";
  //           allSelects.item(i).style.cursor = "not-allowed";
  //         }
  //       }
  //       let allButtons = document.getElementsByTagName('button');
  //       if (allButtons) {
  //         for (let i = 0; i < allButtons.length; i++) {
  //           if (allButtons.item(i).innerText.indexOf("Back to Home") < 0)
  //             allButtons.item(i).disabled = true;
  //         }
  //       }
  //       let allTextArea = document.getElementsByTagName('textarea');
  //       if (allTextArea) {
  //         for (let i = 0; i < allTextArea.length; i++) {
  //           allTextArea.item(i).disabled = true;
  //         }
  //       }
  //     });
  //   }
  // }

  populateUserList() {
    this.peoplePickerOptionsSSLOwner.next([]);
    this.peoplePickerOptionsSSLSponser.next([]);
    this.peoplePickerOptionsSSLDeputy.next([]);
    // this._userSvc.getAllUsers().subscribe(data=>{
    //   this.isLoadingUserList = false;
    //   if(data!=null && data.length>0){
    //     this.userList = [];
    //     data.forEach(item=>{
    //       this.userList.push({
    //         id: item.Id,
    //         description: item.Title
    //       })
    //     });
    //this.ownerAutocompletionSubject.next(this.userList);        
    // this.deputyAutocompleteSubject.next(this.userList);
    //   }
    // });
  }

  searchSSLOwner(value: any) {
    this.peopleFilterChange(value, this.peoplePickerOptionsSSLOwner);
    // if (value.length >= 0) {
    //   const filterData = this.userList.filter(a =>
    //     a.description.toLowerCase().includes(value.toLowerCase())
    //   );
    //   this.ownerAutocompletionSubject.next(filterData || this.userList);
    // }
  }


  setSSLOwner(value: any) {

    //this.sslSolutionOwnerNameId = value.id;
    this.sslSolutionOwnerName = JSON.stringify({ "Id": value.id, "Name": value.description }); //value.description;
    this.sslSolutionOwnerDisplayName = value.description;


    this.formFields.filter(f => f.fieldName === "sslSolutionOwnerName")[0].value = this.sslSolutionOwnerName
    this.formFields.filter(f => f.fieldName === "sslSolutionOwnerDisplayName")[0].value = this.sslSolutionOwnerDisplayName;

  }


  searchSSLSponser(value: any) {
    this.peopleFilterChange(value, this.peoplePickerOptionsSSLSponser);
  }

  peopleFilterChange(value: any, peoplePickerOptions: any): void {
    if (value && value.length >= 3) {
      this.commonService.getFormDigest().toPromise().then((res: any) => {
        this.appConfigService.setSPformDigest(res.FormDigestValue)
        let formDigest = res.FormDigestValue;
        this.getUsersAsObservable(value, formDigest).subscribe((data) => {
          this.userList = [];
          data.forEach(val => {
            // debugger;
            this.userList.push({ id: val.email, description: val.name })
          });
          //debugger;      
          peoplePickerOptions.next(this.userList);
        });
        //  console.log(this.peoplePickerOptions);      
      }).catch(err => {
        console.log(err);
      });
    }
  }

  getUsersAsObservable(name: string, formDigest: any): Observable<any> {
    return new Observable<any>((observer) => {
      this.commonService.searchUser(name, formDigest).subscribe((results: any) => {
        let temp = JSON.parse(results.d.ClientPeoplePickerSearchUser);
        observer.next(
          temp.map(user =>
          ({ email: user.Description, name: user.DisplayText, key: user.Key }
          )));
      }, (error =>
        console.log(error)
      ));
    });
  }

  setSSLSponser(value: any) {
    // this.sslSponsoringNameId = value.id;
    this.sslSponsoringName = JSON.stringify({ "Id": value.id, "Name": value.description }); //value.description;
    this.sslSponsoringDisplayName = value.description
    this.formFields.filter(f => f.fieldName === "sslSponsoringName")[0].value = this.sslSponsoringName;
    this.formFields.filter(f => f.fieldName === "sslSponsoringDisplayName")[0].value = this.sslSponsoringDisplayName

    // var final = { "target": { id: "" } }

    // final.target.id = "sslSponsoringName";

    // this.onTextChange(final);
  }

  searchSSLDeputy(value: any) {
    this.peopleFilterChange(value, this.peoplePickerOptionsSSLDeputy);
    // if (value.length >= 0) {
    //   const filterData = this.userList.filter(a =>
    //     a.description.toLowerCase().includes(value.toLowerCase())
    //   );
    //   this.deputyAutocompleteSubject.next(filterData || this.userList);
    // }
  }

  setSSLDeputy(value: any) {
    // this.sslSolutionDeputyNameId = value.id;
    this.sslSolutionDeputyName = JSON.stringify({ "Id": value.id, "Name": value.description });//value.description;
    this.sslSolutionDeputyDisplayName = value.description;
    this.formFields.filter(f => f.fieldName === "sslSolutionDeputyName")[0].value = this.sslSolutionDeputyName;
    this.formFields.filter(f => f.fieldName === "sslSolutionDeputyDisplayName")[0].value = this.sslSolutionDeputyDisplayName;

  }

  saveOrLoadMasterRecord() {
    if (localStorage.getItem('masterRecordId') && localStorage.getItem('masterRecordId').length > 0) {
      let masterId: number = Number(localStorage.getItem('masterRecordId'));
      if (masterId > 0) {
        this._masterListSvc.getSavedRecord(masterId).subscribe((masterData: MasterListModel) => {

          this.isMasterRecordAvailable = true;
          this.masterRecordId = masterId;
          this.savedMasterRecord = masterData;
          if (this.savedMasterRecord.Form3DemandListLookupId != null) {
            localStorage.setItem('form3SavedId', this.savedMasterRecord.Form3DemandListLookupId.toString());
            this.loadFormDataOnLoad();
          }
        }, (error) => {
          this.isSavedDataAvailable = false;
          this.isMasterRecordAvailable = false;
          localStorage.setItem('form3SavedId', '');
        });
      }
      else {
        this.isSavedDataAvailable = false;
        this.isMasterRecordAvailable = false;
        localStorage.setItem('form3SavedId', '');
      }
    }
    else {
      this.isSavedDataAvailable = false;
      this.isMasterRecordAvailable = false;
      localStorage.setItem('form3SavedId', '');
    }
  }

  redirectToHome() {
    this.router.navigateByUrl('/appHome');
  }

  loadFormDataOnLoad() {
    this.isSavedDataAvailable = false;
    this.savedData = null;
    this.savedDataId = -1;
    if (localStorage.getItem('form3SavedId') && localStorage.getItem('form3SavedId').length > 0) {
      let savedId: number = Number(localStorage.getItem('form3SavedId'));
      if (savedId > 0) {
        this._form3Svc.getSavedRecord(savedId).subscribe((form3Data: Form3Model) => {
          this.isSavedDataAvailable = true;
          this.savedData = form3Data;
          this.savedDataId = savedId;

          this.owningSSL = this.formFields.filter(f => f.fieldName === "owningSSL")[0].value = form3Data.OwningSSL;
          this.sslCompetency = this.formFields.filter(f => f.fieldName === "sslCompetency")[0].value = form3Data.SSLCompetencyService;

          this.sslSponsoringName = this.formFields.filter(f => f.fieldName === "sslSponsoringName")[0].value = form3Data.SSLSponsoringPartnerName;
          this.sslSponsoringDisplayName = this.formFields.filter(f => f.fieldName === "sslSponsoringDisplayName")[0].value = (!form3Data.SSLSponsoringPartnerName) ? "" : JSON.parse(form3Data.SSLSponsoringPartnerName).Name;
          this.sslSponsoringEmail = this.formFields.filter(f => f.fieldName === "sslSponsoringEmail")[0].value = form3Data.SSLSponsoringPartnerEmail;
          this.sslSponsoringRole = this.formFields.filter(f => f.fieldName === "sslSponsoringRole")[0].value = form3Data.SSLSponsoringPartnerRole;

          this.sslSolutionOwnerName = this.formFields.filter(f => f.fieldName === "sslSolutionOwnerName")[0].value = form3Data.SSLsolutionOwnerName;
          this.sslSolutionOwnerDisplayName = this.formFields.filter(f => f.fieldName === "sslSolutionOwnerDisplayName")[0].value = (!form3Data.SSLsolutionOwnerName) ? "" : JSON.parse(form3Data.SSLsolutionOwnerName).Name;
          this.sslSolutionOwnerEmail = this.formFields.filter(f => f.fieldName === "sslSolutionOwnerEmail")[0].value = form3Data.SSLsolutionOwnerEmail;
          this.sslSolutionOwnerRole = this.formFields.filter(f => f.fieldName === "sslSolutionOwnerRole")[0].value = form3Data.SSLsolutionOwnerRole;

          this.sslSolutionDeputyName = this.formFields.filter(f => f.fieldName === "sslSolutionDeputyName")[0].value = form3Data.SSLsolutionDeputyName;
          this.sslSolutionDeputyDisplayName = this.formFields.filter(f => f.fieldName === "sslSolutionDeputyDisplayName")[0].value = (!form3Data.SSLsolutionDeputyName) ? "" : JSON.parse(form3Data.SSLsolutionDeputyName).Name;
          this.sslSolutionDeputyEmail = this.formFields.filter(f => f.fieldName === "sslSolutionDeputyEmail")[0].value = form3Data.SSLsolutionDeputyEmail;
          this.sslSolutionDeputyRole = this.formFields.filter(f => f.fieldName === "sslSolutionDeputyRole")[0].value = form3Data.SSLsolutionDeputyRole;

          this.radioQuesA = this.formFields.filter(f => f.fieldName === "radioQuesA")[0].value = form3Data.LocalFunding;
          this.radioQuesB = this.formFields.filter(f => f.fieldName === "radioQuesB")[0].value = form3Data.LocalGlobalFundingApproved;
          this.form3AdditionalDetails = this.formFields.filter(f => f.fieldName === "form3AdditionalDetails")[0].value = form3Data.LocalGlobalFundingDetails;
          let marketOwnersText = this.formFields.filter(f => f.fieldName === "marketOwners")[0].value = form3Data.MarketOwnerJurisdictionSpecifica;
          if (marketOwnersText && marketOwnersText.length > 0) {
            let arrMarketOwnerText = marketOwnersText.split(',');
            if (arrMarketOwnerText && arrMarketOwnerText.length > 0) {
              for (let i = 0; i < arrMarketOwnerText.length; i++) {
                if (i < this.marketOwners.length) {
                  this.marketOwners[i].value = arrMarketOwnerText[i];
                }
              }
            }
          }
          this.completedChildFormIds.emit(this.formFields);
        });
      }
    }
  }
  onBlurChange(event) {
    this.onTextChange();
  }
  onTextChange() {

    this.formFields.forEach(field => {

      if (field.fieldName === "owningSSL") {
        field.value = this.owningSSL;
      }
      else if (field.fieldName === "sslCompetency") {
        field.value = this.sslCompetency;
      }
      else if (field.fieldName === "sslSponsoringName") {
        field.value = this.sslSponsoringName;
      }
      // else if (field.fieldName === "sslSponsoringNameId") {
      //   field.value = this.sslSponsoringNameId;
      //   
      // }

      else if (field.fieldName === "sslSponsoringRole") {
        field.value = this.sslSponsoringRole;
      }
      else if (field.fieldName === "sslSolutionOwnerName") {
        field.value = this.sslSolutionOwnerName;
      }
      else if (field.fieldName === "sslSolutionDeputyName") {
        field.value = this.sslSolutionDeputyName;
      }
      // else if (field.fieldName === "sslSolutionOwnerNameId") {
      //   field.value = this.sslSolutionOwnerNameId;
      //   
      // }
      /*
      else if (field.fieldName === "sslSolutionOwnerEmail") {
        field.value = this.sslSolutionOwnerEmail;
        let chekEmail = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
        if (!chekEmail.test(field.value)) {
          this.form3Validation[field.fieldName] = true;
        }
        else {
          this.form3Validation[field.fieldName] = false;
        }
      }
      else if (field.fieldName === "sslSolutionDeputyEmail") {
        field.value = this.sslSolutionDeputyEmail;
        let chekEmail = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
        if (!chekEmail.test(field.value)) {
          this.form3Validation[field.fieldName] = true;
        }
        else {
          this.form3Validation[field.fieldName] = false;
        }
      }
      else if (field.fieldName === "sslSponsoringEmail") {
        field.value = this.sslSponsoringEmail;
        let chekEmail = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
        if (!chekEmail.test(field.value)) {
          this.form3Validation[field.fieldName] = true;
        }
        else {
          this.form3Validation[field.fieldName] = false;
        }

      }
      else if (field.fieldName === "sslSolutionOwnerRole") {
        field.value = this.sslSolutionOwnerRole;
      }
      else if (field.fieldName === "sslSolutionDeputyRole") {
        field.value = this.sslSolutionDeputyRole;
      }
      
      // else if (field.fieldName === "sslSolutionDeputyNameId") {
      //   field.value = this.sslSolutionDeputyNameId;
      //   
      // }
    */

      else if (field.fieldName === "marketOwners") {
        field.value = "";
        if (this.marketOwners.length > 0) {
          for (let i = 0; i < this.marketOwners.length; i++) {
            if (this.marketOwners[i] && this.marketOwners[i].value && this.marketOwners[i].value.length > 0) {
              if (field.value && field.value.length > 0) {
                field.value = field.value + "," + this.marketOwners[i].value;
              }
              else {
                field.value = this.marketOwners[i].value;
              }
            }
            else {
              field.value = "";
              break;
            }
          }
        }
      }
      else if (field.fieldName === "radioQuesA") {
        field.value = this.radioQuesA;
      }
      else if (field.fieldName === "radioQuesB") {
        field.value = this.radioQuesB;
      }
      else if (field.fieldName === "form3AdditionalDetails") {
        field.value = this.form3AdditionalDetails;
      }
    })
    this.completedChildFormIds.emit(this.formFields);
  }


  isEmpty(controlName) {
    var formValue = controlName;
    console.log(formValue);
    if (formValue.length <= 0)
      return true;
    else
      return false;
  }

  // valitaionCheck(event, field) {

  //   if (!event) {
  //     event = { "target": {} };
  //     event.target.id = field.fieldName;
  //     event.target.name = field.fieldName;
  //   }
  //   if (field.isMandatory && !field.value && (event.target.name === field.fieldName || event.target.id === field.fieldName)) {

  //     this.form3Validation[field.fieldName] = true;
  //     this.form3Validation.isForminValid = true;

  //   }
  //   else if (field.isMandatory && !field.value && this.form3Validation[field.fieldName]) {
  //     this.form3Validation[field.fieldName] = true;
  //     this.form3Validation.isForminValid = true;
  //   }
  //   else {
  //     this.form3Validation[field.fieldName] = false;
  //     this.form3Validation.isForminValid = false;
  //   }
  // }

  saveFormData() {
    let form3Data = new Form3Model();
    if (!this.isSavedDataAvailable) {
      form3Data.Title = guid();
    }
    else {
      form3Data.Title = this.savedData.Title;
    }

    form3Data.OwningSSL = this.owningSSL;
    form3Data.SSLCompetencyService = this.sslCompetency;
    form3Data.SSLSponsoringPartnerEmail = this.sslSponsoringEmail;
    form3Data.SSLSponsoringPartnerRole = this.sslSponsoringRole;
    form3Data.SSLsolutionOwnerName = this.sslSolutionOwnerName
    form3Data.SSLSponsoringPartnerName = this.sslSponsoringName;
    form3Data.SSLsolutionDeputyName = this.sslSolutionDeputyName;
    //form3Data.SSLsolutionDeputyName = this.sslSolutionDeputyName;
    //form3Data.SSLsolutionOwnerNameStringId = this.sslSolutionOwnerNameId.toString();
    // form3Data.SSLsolutionOwnerNameId = Number(this.sslSolutionOwnerNameId);
    form3Data.SSLsolutionOwnerEmail = this.sslSolutionOwnerEmail;
    form3Data.SSLsolutionOwnerRole = this.sslSolutionOwnerRole;
    // form3Data.SSLsolutionDeputyNameStringId = this.sslSolutionDeputyNameId.toString();
    // form3Data.SSLsolutionDeputyNameId = Number(this.sslSolutionDeputyNameId);
    form3Data.SSLsolutionDeputyEmail = this.sslSolutionDeputyEmail;
    form3Data.SSLsolutionDeputyRole = this.sslSolutionDeputyRole;
    // form3Data.MarketOwnerJurisdictionSpecification = this.marketOwners;
    form3Data.LocalFunding = this.radioQuesA;
    form3Data.LocalGlobalFundingApproved = this.radioQuesB;
    form3Data.LocalGlobalFundingDetails = this.form3AdditionalDetails;
    //form3Data.SSLSponsoringPartnerNameStringId = this.sslSponsoringNameId.toString();
    // form3Data.SSLSponsoringPartnerNameId = Number(this.sslSponsoringNameId);
    form3Data.MarketOwnerJurisdictionSpecifica = "";
    if (this.marketOwners && this.marketOwners.length > 0) {
      this.marketOwners.forEach(marketOwner => {
        if (form3Data.MarketOwnerJurisdictionSpecifica === "") {
          form3Data.MarketOwnerJurisdictionSpecifica = marketOwner.value;
        }
        else {
          form3Data.MarketOwnerJurisdictionSpecifica = form3Data.MarketOwnerJurisdictionSpecifica + "," + marketOwner.value;
        }
      });
    }

    form3Data.CompletionStatus = this.formStatus;


    if (!this.isSavedDataAvailable) {
      if (!this.isMasterRecordAvailable) {
        let newMasterRecord: MasterListModel = new MasterListModel();
        newMasterRecord.Form2DemandListLookupId = null;
        newMasterRecord.Form3DemandListLookupId = null;
        newMasterRecord.Form4DemandListLookupId = null;
        newMasterRecord.Form5DemandListLookupId = null;
        newMasterRecord.Form6DemandListLookupId = null;
        newMasterRecord.DemandType = this.demandType;
        if (!this.sslSponsoringName && !this.sslSolutionOwnerName && !this.sslSolutionDeputyName) {
          newMasterRecord.FormStatus = _FORM_STATUS.triage;
        }
        else {
          newMasterRecord.FormStatus = _FORM_STATUS.inProgress;
        }
        // newMasterRecord.FormStatus = _FORM_STATUS.inProgress;
        newMasterRecord.Stage = _FORM_STAGES.stage1;
        newMasterRecord.Form3SSLsolutionOwnerEmail = (!this.sslSolutionOwnerName) ? "" : JSON.parse(this.sslSolutionOwnerName).Id;
        newMasterRecord.Form3SSLsolutionDeputyEmail = (!this.sslSolutionDeputyName) ? "" : JSON.parse(this.sslSolutionDeputyName).Id;
        newMasterRecord.Form3SSLSponsoringPartnerEmail = (!this.sslSponsoringName) ? "" : JSON.parse(this.sslSponsoringName).Id;

        this._masterListSvc.saveData(newMasterRecord).subscribe(mdata => {
          // Handle Success
          this.isMasterRecordAvailable = true;
          this.masterRecordId = Number(mdata.data.Id);
          this.savedMasterRecord = newMasterRecord;

          localStorage.setItem('masterRecordId', mdata.data.Id);
          this._form3Svc.saveData(form3Data).subscribe(data => {
            // Handle Success
            // Update master record with Id
            this.savedMasterRecord.Form3DemandListLookupId = Number(data.data.Id);

            this._masterListSvc.updateData(this.savedMasterRecord, this.masterRecordId).subscribe((data) => {
              this.isDataSaved = true;
              localStorage.setItem('form3SavedId', this.savedMasterRecord.Form3DemandListLookupId.toString());
              this.formSaved.emit(_FORM_NAMES.form3);
              this.setFormActive(_FORM_NAMES.form5);
            });
          }, (error) => {
            // Handle Error
            this.isDataSaved = false;
          });
        }, (error) => {
          // Handle Error
          this.isMasterRecordAvailable = false;
          this.isDataSaved = false;
        });
      }
      else {
        this._form3Svc.saveData(form3Data).subscribe(data => {
          // Handle Success
          // Update master record with Id
          this.savedMasterRecord.Form3DemandListLookupId = Number(data.data.Id);
          this.savedMasterRecord.Form3SSLsolutionOwnerEmail = (!this.sslSolutionOwnerName) ? "" : JSON.parse(this.sslSolutionOwnerName).Id;
          this.savedMasterRecord.Form3SSLsolutionDeputyEmail = (!this.sslSolutionDeputyName) ? "" : JSON.parse(this.sslSolutionDeputyName).Id;
          this.savedMasterRecord.Form3SSLSponsoringPartnerEmail = (!this.sslSponsoringName) ? "" : JSON.parse(this.sslSponsoringName).Id;
          //update master record as triage status
          if (!this.sslSponsoringName && !this.sslSolutionOwnerName && !this.sslSolutionDeputyName) {
            this.savedMasterRecord.FormStatus = _FORM_STATUS.triage;
          }
          else {
            this.savedMasterRecord.FormStatus = _FORM_STATUS.inProgress;
          }
          this._masterListSvc.updateData(this.savedMasterRecord, this.masterRecordId).subscribe((data) => {
            this.isDataSaved = true;
            localStorage.setItem('form3SavedId', this.savedMasterRecord.Form3DemandListLookupId.toString());
            this.formSaved.emit(_FORM_NAMES.form3);
            this.setFormActive(_FORM_NAMES.form5);
          });
        }, (error) => {
          // Handle Error
          this.isDataSaved = false;
        });
      }
    }
    else {
      this._form3Svc.updateData(form3Data, this.savedDataId).subscribe(data => {
        // Handle Success
        this.savedMasterRecord.Form3SSLsolutionOwnerEmail = (!this.sslSolutionOwnerName) ? "" : JSON.parse(this.sslSolutionOwnerName).Id;
        this.savedMasterRecord.Form3SSLsolutionDeputyEmail = (!this.sslSolutionDeputyName) ? "" : JSON.parse(this.sslSolutionDeputyName).Id;
        this.savedMasterRecord.Form3SSLSponsoringPartnerEmail = (!this.sslSponsoringName) ? "" : JSON.parse(this.sslSponsoringName).Id;

        //update master record as triage status
        if (!this.sslSponsoringName && !this.sslSolutionOwnerName && !this.sslSolutionDeputyName) {
          this.savedMasterRecord.FormStatus = _FORM_STATUS.triage;
        }
        else {
          this.savedMasterRecord.FormStatus = _FORM_STATUS.inProgress;
        }
        this._masterListSvc.updateData(this.savedMasterRecord, this.masterRecordId).subscribe((data) => {
          this.isDataSaved = true;
          //localStorage.setItem('form3SavedId', this.savedMasterRecord.Form3DemandListLookupId.toString());
          this.formSaved.emit(_FORM_NAMES.form3);
          this.setFormActive(_FORM_NAMES.form5);
        });


      }, (error) => {
        // Handle Error
        this.isDataSaved = false;
      });
    }
  }

  setFormActive(form) {
    this.formSaveClick.emit(form);
  }

}
