import { Component, Output, ViewEncapsulation, EventEmitter, Input, OnInit, ViewChild, Renderer2, ElementRef, AfterViewInit } from '@angular/core';
import { Router } from '@angular/router';
import { guid } from '@progress/kendo-angular-common';
import { _FORM_NAMES } from 'src/app/Models/form-names';
import { Form5Model } from '../../Models/form5model';
import { MasterListModel } from '../../Models/masterListModel';
import { Form5SPService } from '../../Services/Implementations/form5Service';
import { MasterListService } from '../../Services/Implementations/masterListService';
import { _FORM_STATUS } from 'src/app/Models/formstatus';
import { _FORM_STAGES } from 'src/app/Models/formstatus';
@Component({
  selector: 'form-5',
  templateUrl: './form5.component.html',
  encapsulation: ViewEncapsulation.None,
  providers: [Form5SPService, MasterListService],
  styleUrls: ['./forms.css']
})
export class Form5Component implements OnInit {
  @Output()
  completedChildFormIds = new EventEmitter<any>();

  @Output()
  formSaved = new EventEmitter<string>();

  @Input()
  formFields: any[] = [];



  @Input()
  formStatus: string = "Not Started";

  @Input()
  demandType: string = "";

  @Input()
  isFormSubmitted: boolean = false;

  // @ViewChild('dropdownDivGTER', { static: false }) dropdownDivGTER: ElementRef;
  // @ViewChild('dropdownDiv3YearGTER', { static: false }) dropdownDiv3YearGTER: ElementRef;

  // @ViewChild('dropdownDivGTER', { static: false }) dropdownDivGTER: ElementRef;
  // @ViewChild('dropdownDiv3YearGTER', { static: false }) dropdownDiv3YearGTER: ElementRef;
  // selectedBusinessType: string[];
  @Output()
  formSaveClick = new EventEmitter<string>();
 
  form5Validation: any= {};

  constructor(private renderer: Renderer2, private _form5Svc: Form5SPService, private _masterListSvc: MasterListService, private router:Router) {
    // this.renderer.listen('window', 'click', (e: Event) => {

    //   if (!this.dropdownDivGTER.nativeElement.contains(e.target)) {
    //     this.moreGTER = false;
    //   }
    //   if (!this.dropdownDiv3YearGTER.nativeElement.contains(e.target)) {
    //     this.more3YearGTER = false;

    //   }

    // });
  }

  businessType = [
    { id: 1, name: 'Margin improvement', selected: false },
    { id: 2, name: 'Cost saving', selected: false },
    { id: 3, name: 'New client revenue', selected: false },
    { id: 4, name: 'Other', selected: false }
  ];

  estimatedGTERList: string[] = ['Less than $1m', '$1 - $5m', '$6 - $10m', '$11m - $20m', '$21m - $30m', 'Above $30m'];
  estimated3YearGTERList: any = ['Less than $1m', '$1 - $5m', '$6 - $10m', '$11m - $20m', '$21m - $30m', 'Above $30m'];
  checkedList: any[];

  showText: boolean;
  checkedListUnchek: any;

  form5AdditionalDetailsbusinessType: string = "";
  estimatedGTER: string = "";
  estimated3YearGTER: string = "";
  radioClient: string = "";
  radioGeographie: string = "";
  radioEngagement: string = "";
  radioUSD: string = "";
  radioRegulation: string = "";
  radioImproving: string = "";
  radioNewNovel: string = "";
  form5AdditionalDetailsImproving: string = "";
  form5AdditionalDetailsRegulation: string = "";
  form5AdditionalDetailsNewNovel: string = "";
  TotalFTEassignedPerTask: number;
  TotalHoursFTE: number;
  TotalHoursPATotal: number;
  TotalCostPAapproxTotal: number;

  TotalTargetNumberHours: number;
  TotalTargetTotalCost: number;
  TotalCostSavingPA: number;

  Task: string = "";
  Frequency: string;
  FTEassignedPerTask: string;
  ApproxFTEassignedHourly: string;
  HoursFTE: string;
  TotalHoursPA: string;
  TotalCostPAapprox: string;
  TargetNumberHours: string;
  ExpectedTotalGrowth: string = "";
  TargetTotalCost: string;
  CostSavingPA: string;

  Task1: string = "";
  Frequency1: string;
  FTEassignedPerTask1: string;
  ApproxFTEassignedHourly1: string;
  HoursFTE1: string;
  TotalHoursPA1: string;
  TotalCostPAapprox1: string;
  TargetNumberHours1: string;
  ExpectedTotalGrowth1: string = "";
  TargetTotalCost1: string;
  CostSavingPA1: string;

  isMasterRecordAvailable: boolean = false;
  masterRecordId: number = -1;
  savedMasterRecord: MasterListModel = null;

  isDataSaved: boolean = false;
  savedData: Form5Model = null;
  isSavedDataAvailable: boolean = false;
  savedDataId: number = -1;
  businessTypeVal: string = "";
  businessTypeCheckListSelected: string[] = [];
  selectedBusinessType: string[];

  ngOnInit() {

    this.estimatedGTER = this.formFields.filter(f => f.fieldName === "estimatedGTER")[0].value;
    this.estimated3YearGTER = this.formFields.filter(f => f.fieldName === "estimated3YearGTER")[0].value;
    this.businessTypeVal = this.formFields.filter(f => f.fieldName === "businessTypeVal")[0].value;
    if (!this.businessTypeVal == false) {
      this.selectedBusinessType = this.businessTypeVal.split(',');
      if (this.selectedBusinessType.length > 0) {
        this.selectedBusinessType.forEach(item => {
          if (item === "Other") {
            this.showText = true;
          }
          for (var i = 0; i < this.businessType.length; i++) {
            if (this.businessType[i].name === item) {
              this.businessType[i].selected = true;

            }

          }
        })
      }

    }

    this.form5AdditionalDetailsbusinessType = this.formFields.filter(f => f.fieldName === "form5AdditionalDetailsbusinessType")[0].value;

    this.radioClient = this.formFields.filter(f => f.fieldName === "radioClient")[0].value;
    this.radioEngagement = this.formFields.filter(f => f.fieldName === "radioEngagement")[0].value;
    this.radioGeographie = this.formFields.filter(f => f.fieldName === "radioGeographie")[0].value;
    this.radioUSD = this.formFields.filter(f => f.fieldName === "radioUSD")[0].value;
    this.radioRegulation = this.formFields.filter(f => f.fieldName === "radioRegulation")[0].value;
    this.radioImproving = this.formFields.filter(f => f.fieldName === "radioImproving")[0].value;
    this.radioNewNovel = this.formFields.filter(f => f.fieldName === "radioNewNovel")[0].value;
    this.form5AdditionalDetailsImproving = this.formFields.filter(f => f.fieldName === "form5AdditionalDetailsImproving")[0].value;
    this.form5AdditionalDetailsRegulation = this.formFields.filter(f => f.fieldName === "form5AdditionalDetailsRegulation")[0].value;
    this.form5AdditionalDetailsNewNovel = this.formFields.filter(f => f.fieldName === "form5AdditionalDetailsNewNovel")[0].value;
    this.TotalFTEassignedPerTask = this.formFields.filter(f => f.fieldName === "TotalFTEassignedPerTask")[0].value;
    this.TotalHoursFTE = this.formFields.filter(f => f.fieldName === "TotalHoursFTE")[0].value;
    this.TotalHoursPATotal = this.formFields.filter(f => f.fieldName === "TotalHoursPATotal")[0].value;
    this.TotalCostPAapproxTotal = this.formFields.filter(f => f.fieldName === "TotalCostPAapproxTotal")[0].value;
    this.TotalTargetNumberHours = this.formFields.filter(f => f.fieldName === "TotalTargetNumberHours")[0].value;
    this.TotalTargetTotalCost = this.formFields.filter(f => f.fieldName === "TotalTargetTotalCost")[0].value;
    this.TotalCostSavingPA = this.formFields.filter(f => f.fieldName === "TotalCostSavingPA")[0].value;
    this.Task = this.formFields.filter(f => f.fieldName === "Task")[0].value;
    this.Frequency = this.formFields.filter(f => f.fieldName === "Frequency")[0].value;
    this.FTEassignedPerTask = this.formFields.filter(f => f.fieldName === "FTEassignedPerTask")[0].value;
    this.ApproxFTEassignedHourly = this.formFields.filter(f => f.fieldName === "ApproxFTEassignedHourly")[0].value;
    this.HoursFTE = this.formFields.filter(f => f.fieldName === "HoursFTE")[0].value;
    this.TotalHoursPA = this.formFields.filter(f => f.fieldName === "TotalHoursPA")[0].value;
    this.TotalCostPAapprox = this.formFields.filter(f => f.fieldName === "TotalCostPAapprox")[0].value;
    this.TargetNumberHours = this.formFields.filter(f => f.fieldName === "TargetNumberHours")[0].value;
    this.ExpectedTotalGrowth = this.formFields.filter(f => f.fieldName === "ExpectedTotalGrowth")[0].value;
    this.TargetTotalCost = this.formFields.filter(f => f.fieldName === "TargetTotalCost")[0].value;
    this.CostSavingPA = this.formFields.filter(f => f.fieldName === "CostSavingPA")[0].value;
    this.Task1 = this.formFields.filter(f => f.fieldName === "Task1")[0].value;
    this.Frequency1 = this.formFields.filter(f => f.fieldName === "Frequency1")[0].value;
    this.FTEassignedPerTask1 = this.formFields.filter(f => f.fieldName === "FTEassignedPerTask1")[0].value;
    this.ApproxFTEassignedHourly1 = this.formFields.filter(f => f.fieldName === "ApproxFTEassignedHourly1")[0].value;
    this.HoursFTE1 = this.formFields.filter(f => f.fieldName === "HoursFTE1")[0].value;
    this.TotalHoursPA1 = this.formFields.filter(f => f.fieldName === "TotalHoursPA1")[0].value;
    this.TotalCostPAapprox1 = this.formFields.filter(f => f.fieldName === "TotalCostPAapprox1")[0].value;
    this.TargetNumberHours1 = this.formFields.filter(f => f.fieldName === "TargetNumberHours1")[0].value;
    this.ExpectedTotalGrowth1 = this.formFields.filter(f => f.fieldName === "ExpectedTotalGrowth1")[0].value;
    this.TargetTotalCost1 = this.formFields.filter(f => f.fieldName === "TargetTotalCost1")[0].value;
    this.CostSavingPA1 = this.formFields.filter(f => f.fieldName === "CostSavingPA1")[0].value;

    this.saveOrLoadMasterRecord();

  }

  // ngAfterViewInit() {
  //   if (this.isFormSubmitted) {
  //     setTimeout(() => {
  //       let allInputs = document.getElementsByTagName('input');
  //       if (allInputs) {
  //         for (let i = 0; i < allInputs.length; i++) {
  //           allInputs.item(i).disabled = true;
  //         }
  //       }
  //       let allSelects = document.getElementsByTagName('select');
  //       if (allSelects) {
  //         for (let i = 0; i < allSelects.length; i++) {
  //          // allSelects.item(i).disabled = true;
  //          allSelects.item(i).style.pointerEvents = "none";
  //          allSelects.item(i).style.cursor = "not-allowed";
  //         }
  //       }
  //       let allButtons = document.getElementsByTagName('button');
  //       if(allButtons){
  //         for(let i=0;i<allButtons.length;i++){
  //           if(allButtons.item(i).innerText.indexOf("Back to Home")<0)
  //             allButtons.item(i).disabled = true;
  //         }
  //       }
  //       let allTextArea = document.getElementsByTagName('textarea');
  //       if (allTextArea) {
  //         for (let i = 0; i < allTextArea.length; i++) {
  //           allTextArea.item(i).disabled = true;
  //         }
  //       }
  //     });
  //   }
  // }

  onTextChange() {
    this.formFields.forEach(field => {
      if (field.fieldName === "form5AdditionalDetailsbusinessType") {
        field.value = this.form5AdditionalDetailsbusinessType
      }
      else if (field.fieldName === "businessTypeVal") {
        field.value = this.businessTypeVal;
      }
      else if (field.fieldName === "estimatedGTER") {
        field.value = this.estimatedGTER;
      }
      else if (field.fieldName === "estimated3YearGTER") {
        field.value = this.estimated3YearGTER;

      }
      else if (field.fieldName === "radioClient") {
        field.value = this.radioClient;
      }

      else if (field.fieldName === "radioGeographie") {
        field.value = this.radioGeographie;
      }
      else if (field.fieldName === "radioEngagement") {
        field.value = this.radioEngagement;
      }
      else if (field.fieldName === "radioRegulation") {
        field.value = this.radioRegulation;
      }
      else if (field.fieldName === "radioImproving") {
        field.value = this.radioImproving;
      }
      else if (field.fieldName === "radioNewNovel") {
        field.value = this.radioNewNovel;
      }
      else if (field.fieldName === "radioUSD") {
        field.value = this.radioUSD;
      }
      else if (field.fieldName === "form5AdditionalDetailsImproving") {
        field.value = this.form5AdditionalDetailsImproving;
      }
      else if (field.fieldName === "form5AdditionalDetailsRegulation") {
        field.value = this.form5AdditionalDetailsRegulation;
      }
      else if (field.fieldName === "form5AdditionalDetailsNewNovel") {
        field.value = this.form5AdditionalDetailsNewNovel;
      }
      else if (field.fieldName === "TotalFTEassignedPerTask") {
        field.value = this.TotalFTEassignedPerTask;
      }
      else if (field.fieldName === "TotalHoursFTE") {
        field.value = this.TotalHoursFTE;
      }
      else if (field.fieldName === "TotalHoursPATotal") {
        field.value = this.TotalHoursPATotal;
      }
      else if (field.fieldName === "TotalCostPAapproxTotal") {
        field.value = this.TotalCostPAapproxTotal;
      }
      else if (field.fieldName === "TotalTargetNumberHours") {
        field.value = this.TotalTargetNumberHours;
      }
      else if (field.fieldName === "TotalTargetTotalCost") {
        field.value = this.TotalTargetTotalCost;
      }
      else if (field.fieldName === "TotalCostSavingPA") {
        field.value = this.TotalCostSavingPA;
      }
      else if (field.fieldName === "Task") {
        field.value = this.Task;
      }
      else if (field.fieldName === "Frequency") {
        field.value = this.Frequency;
      }
      else if (field.fieldName === "FTEassignedPerTask") {
        field.value = this.FTEassignedPerTask;
        this.onInsertValue();
      }
      else if (field.fieldName === "ApproxFTEassignedHourly") {
        field.value = this.ApproxFTEassignedHourly;
      }
      else if (field.fieldName === "HoursFTE") {
        field.value = this.HoursFTE;
        this.onInsertValue();
      }
      else if (field.fieldName === "TotalHoursPA") {
        field.value = this.TotalHoursPA;
        this.onInsertValue();
      }
      else if (field.fieldName === "TotalCostPAapprox") {
        field.value = this.TotalCostPAapprox;
        this.onInsertValue();
      }
      else if (field.fieldName === "TargetNumberHours") {
        field.value = this.TargetNumberHours;
        this.onInsertValue();
      }
      else if (field.fieldName === "ExpectedTotalGrowth") {
        field.value = this.ExpectedTotalGrowth;
      }
      else if (field.fieldName === "TargetTotalCost") {
        field.value = this.TargetTotalCost;
        this.onInsertValue();
      }
      else if (field.fieldName === "CostSavingPA") {
        field.value = this.CostSavingPA;
        this.onInsertValue();
      }
      else if (field.fieldName === "Task1") {
        field.value = this.Task1;
      }
      else if (field.fieldName === "Frequency1") {
        field.value = this.Frequency1;
      }
      else if (field.fieldName === "FTEassignedPerTask1") {
        field.value = this.FTEassignedPerTask1;

        this.onInsertValue();
      }
      else if (field.fieldName === "ApproxFTEassignedHourly1") {
        field.value = this.ApproxFTEassignedHourly1;
      }
      else if (field.fieldName === "HoursFTE1") {
        field.value = this.HoursFTE1;
        this.onInsertValue();
      }
      else if (field.fieldName === "TotalHoursPA1") {
        field.value = this.TotalHoursPA1;
        this.onInsertValue();
      }
      else if (field.fieldName === "TotalCostPAapprox1") {
        field.value = this.TotalCostPAapprox1;
        this.onInsertValue();
      }
      else if (field.fieldName === "TargetNumberHours1") {
        field.value = this.TargetNumberHours1;
        this.onInsertValue();
      }
      else if (field.fieldName === "ExpectedTotalGrowth1") {
        field.value = this.ExpectedTotalGrowth1;
      }
      else if (field.fieldName === "TargetTotalCost1") {
        field.value = this.TargetTotalCost1;
        this.onInsertValue();
      }
      else if (field.fieldName === "CostSavingPA1") {
        field.value = this.CostSavingPA1;
        this.onInsertValue();

      }

    })
    this.completedChildFormIds.emit(this.formFields);
  }
  saveOrLoadMasterRecord() {
    if (localStorage.getItem('masterRecordId') && localStorage.getItem('masterRecordId').length > 0) {
      let masterId: number = Number(localStorage.getItem('masterRecordId'));
      if (masterId > 0) {
        this._masterListSvc.getSavedRecord(masterId).subscribe((masterData: MasterListModel) => {

          this.isMasterRecordAvailable = true;
          this.masterRecordId = masterId;
          this.savedMasterRecord = masterData;
          this.savedMasterRecord.FormStatus = (this.savedMasterRecord.FormStatus===_FORM_STATUS.triage) ? _FORM_STATUS.triage : _FORM_STATUS.inProgress;
          if(this.savedMasterRecord.Form5DemandListLookupId!=null)
          {
          localStorage.setItem('form5SavedId', this.savedMasterRecord.Form5DemandListLookupId.toString());
          this.loadFormDataOnLoad();
          }
        }, (error) => {
          this.isSavedDataAvailable = false;
          this.isMasterRecordAvailable = false;
          localStorage.setItem('form5SavedId', '');
        });
      }
      else {
        this.isSavedDataAvailable = false;
        this.isMasterRecordAvailable = false;
        localStorage.setItem('form5SavedId', '');
      }
    }
    else {
      this.isSavedDataAvailable = false;
      this.isMasterRecordAvailable = false;
      localStorage.setItem('form5SavedId', '');
    }
  }

  loadFormDataOnLoad() {
    this.isSavedDataAvailable = false;
    this.savedData = null;
    this.savedDataId = -1;
    if (localStorage.getItem('form5SavedId') && localStorage.getItem('form5SavedId').length > 0) {
      let savedId: number = Number(localStorage.getItem('form5SavedId'));
      if (savedId > 0) {
        this._form5Svc.getSavedRecord(savedId).subscribe((form5Data: Form5Model) => {
          this.isSavedDataAvailable = true;
          this.savedData = form5Data;
          this.savedDataId = savedId;
          //let form5Data = new Form5Model();

          this.businessTypeVal = this.formFields.filter(f => f.fieldName === "businessTypeVal")[0].value = form5Data.BusinessType;

          if (!this.businessTypeVal == false) {
            this.selectedBusinessType = this.businessTypeVal.split(',');
            if (this.selectedBusinessType.length > 0) {
              this.selectedBusinessType.forEach(item => {
                if (item === "Other") {
                  this.showText = true;
                }
                for (var i = 0; i < this.businessType.length; i++) {
                  if (this.businessType[i].name === item) {
                    this.businessType[i].selected = true;
                    this.businessTypeCheckListSelected.push(item);
                  }

                }
              })
            }
          }
          var getRawData = JSON.parse(form5Data.CalculatedData);
          if (!getRawData == false) {

            this.Task = (getRawData.Task) ? getRawData.Task : "";
            this.Frequency = (getRawData.Frequency) ? getRawData.Frequency : "";
            this.FTEassignedPerTask = (getRawData.FTEassignedPerTask) ? getRawData.FTEassignedPerTask : "";
            this.ApproxFTEassignedHourly = (getRawData.ApproxFTEassignedHourly) ? getRawData.ApproxFTEassignedHourly : "";
            this.HoursFTE = (getRawData.HoursFTE) ? getRawData.HoursFTE : "";
            this.TotalHoursPA = (getRawData.TotalHoursPA) ? getRawData.TotalHoursPA : "";
            this.TotalCostPAapprox = (getRawData.TotalCostPAapprox) ? getRawData.TotalCostPAapprox : "";
            this.TargetNumberHours = (getRawData.TargetNumberHours) ? getRawData.TargetNumberHours : "";
            this.ExpectedTotalGrowth = (getRawData.ExpectedTotalGrowth) ? getRawData.ExpectedTotalGrowth : "";
            this.TargetTotalCost = (getRawData.TargetTotalCost) ? getRawData.TargetTotalCost : "";
            this.CostSavingPA = (getRawData.CostSavingPA) ? getRawData.CostSavingPA : "";

            this.Task1 = (getRawData.Task1) ? getRawData.Task1 : "";
            this.Frequency1 = (getRawData.Frequency1) ? getRawData.Frequency1 : "";
            this.FTEassignedPerTask1 = (getRawData.FTEassignedPerTask1) ? getRawData.FTEassignedPerTask1 : "";
            this.ApproxFTEassignedHourly1 = (getRawData.ApproxFTEassignedHourly1) ? getRawData.ApproxFTEassignedHourly1 : "";
            this.HoursFTE1 = (getRawData.HoursFTE1) ? getRawData.HoursFTE1 : "";
            this.TotalHoursPA1 = (getRawData.TotalHoursPA1) ? getRawData.TotalHoursPA1 : "";
            this.TotalCostPAapprox1 = (getRawData.TotalCostPAapprox1) ? getRawData.TotalCostPAapprox1 : "";
            this.TargetNumberHours1 = (getRawData.TargetNumberHours1) ? getRawData.TargetNumberHours1 : "";
            this.ExpectedTotalGrowth1 = (getRawData.ExpectedTotalGrowth1) ? getRawData.ExpectedTotalGrowth1 : "";
            this.TargetTotalCost1 = (getRawData.TargetTotalCost1) ? getRawData.TargetTotalCost1 : "";
            this.CostSavingPA1 = (getRawData.CostSavingPA1) ? getRawData.CostSavingPA1 : "";

            this.TotalFTEassignedPerTask = (getRawData.TotalFTEassignedPerTask) ? getRawData.TotalFTEassignedPerTask : "";
            this.TotalHoursFTE = (getRawData.TotalHoursFTE) ? getRawData.TotalHoursFTE : "";
            this.TotalHoursPATotal = (getRawData.TotalHoursPATotal) ? getRawData.TotalHoursPATotal : "";
            this.TotalCostPAapproxTotal = (getRawData.TotalCostPAapproxTotal) ? getRawData.TotalCostPAapproxTotal : "";

            this.TotalTargetNumberHours = (getRawData.TotalTargetNumberHours) ? getRawData.TotalTargetNumberHours : "";
            this.TotalTargetTotalCost = (getRawData.TotalTargetTotalCost) ? getRawData.TotalTargetTotalCost : "";
            this.TotalCostSavingPA = (getRawData.TotalCostSavingPA) ? getRawData.TotalCostSavingPA : "";
          }



          this.form5AdditionalDetailsbusinessType = this.formFields.filter(f => f.fieldName === "form5AdditionalDetailsbusinessType")[0].value = form5Data.otherBusinessType;
          this.estimatedGTER = this.formFields.filter(f => f.fieldName === "estimatedGTER")[0].value = form5Data.EstimatedAnnualGTER;
          this.estimated3YearGTER = this.formFields.filter(f => f.fieldName === "estimated3YearGTER")[0].value = form5Data.Estimated3YearGTER;
          this.radioClient = this.formFields.filter(f => f.fieldName === "radioClient")[0].value = form5Data.Client;
          this.radioGeographie = this.formFields.filter(f => f.fieldName === "radioGeographie")[0].value = form5Data.Geographies;
          this.radioEngagement = this.formFields.filter(f => f.fieldName === "radioEngagement")[0].value = form5Data.EngagementPenetration;
          this.radioUSD = this.formFields.filter(f => f.fieldName === "radioUSD")[0].value = form5Data.USDperEngagement;
          this.form5AdditionalDetailsImproving = this.formFields.filter(f => f.fieldName === "form5AdditionalDetailsImproving")[0].value = form5Data.ImprovingMarketDetails;
          this.form5AdditionalDetailsRegulation = this.formFields.filter(f => f.fieldName === "form5AdditionalDetailsRegulation")[0].value = form5Data.RegulationDetails;
          this.form5AdditionalDetailsNewNovel = this.formFields.filter(f => f.fieldName === "form5AdditionalDetailsNewNovel")[0].value = form5Data.NewNovelOfferedDetails;

          this.radioRegulation = this.formFields.filter(f => f.fieldName === "radioRegulation")[0].value = form5Data.RegulationResons;
          this.radioImproving = this.formFields.filter(f => f.fieldName === "radioImproving")[0].value = form5Data.RegulationResons;
          this.radioNewNovel = this.formFields.filter(f => f.fieldName === "radioNewNovel")[0].value = form5Data.NewNovelOffered;
          this.completedChildFormIds.emit(this.formFields);
        });
      }
    }
  }

  redirectToHome()
  {
  this.router.navigateByUrl('/appHome');
  }

  numberOnly(event): boolean {
    const charCode = (event.which) ? event.which : event.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;

  }

  saveFormData() {
    let form5Data = new Form5Model();
    if (!this.isSavedDataAvailable) {
      form5Data.Title = guid();
    }
    else {
      form5Data.Title = this.savedData.Title;
    }
    form5Data.BusinessType = "";
    this.businessTypeCheckListSelected.forEach(item => {
      if (form5Data.BusinessType === "") {
        form5Data.BusinessType = item;
      }
      else {
        form5Data.BusinessType = form5Data.BusinessType + "," + item;
      }
    })
    var rawData = JSON.stringify({
      "Task": this.Task, "Frequency": this.Frequency, "FTEassignedPerTask": this.FTEassignedPerTask, "ApproxFTEassignedHourly": this.ApproxFTEassignedHourly,
      "HoursFTE": this.HoursFTE, "TotalHoursPA": this.TotalHoursPA, "TotalCostPAapprox": this.TotalCostPAapprox, "TargetNumberHours": this.TargetNumberHours,
      "ExpectedTotalGrowth": this.ExpectedTotalGrowth, "TargetTotalCost": this.TargetTotalCost, "CostSavingPA": this.CostSavingPA,
      "Task1": this.Task1, "Frequency1": this.Frequency1, "FTEassignedPerTask1": this.FTEassignedPerTask1, "ApproxFTEassignedHourly1": this.ApproxFTEassignedHourly1,
      "HoursFTE1": this.HoursFTE1, "TotalHoursPA1": this.TotalHoursPA1, "TotalCostPAapprox1": this.TotalCostPAapprox1, "TargetNumberHours1": this.TargetNumberHours1,
      "ExpectedTotalGrowth1": this.ExpectedTotalGrowth1, "TargetTotalCost1": this.TargetTotalCost1, "CostSavingPA1": this.CostSavingPA1,
      "TotalFTEassignedPerTask": this.TotalFTEassignedPerTask, "TotalHoursFTE": this.TotalHoursFTE, "TotalHoursPATotal": this.TotalHoursPATotal,
      "TotalCostPAapproxTotal": this.TotalCostPAapproxTotal, "TotalTargetNumberHours": this.TotalTargetNumberHours, "TotalTargetTotalCost": this.TotalTargetTotalCost,
      "TotalCostSavingPA": this.TotalCostSavingPA
    });
    form5Data.CalculatedData = rawData;
    form5Data.otherBusinessType = this.form5AdditionalDetailsbusinessType;
    form5Data.EstimatedAnnualGTER = this.estimatedGTER
    form5Data.Estimated3YearGTER = this.estimated3YearGTER;
    form5Data.Client = this.radioClient;
    form5Data.Geographies = this.radioGeographie;
    form5Data.EngagementPenetration = this.radioEngagement;
    form5Data.USDperEngagement = this.radioUSD;

    form5Data.RegulationResons = this.radioRegulation;
    form5Data.ImprovingMarket = this.radioImproving;
    form5Data.NewNovelOffered = this.radioNewNovel;
    form5Data.ImprovingMarketDetails = this.form5AdditionalDetailsImproving;
    form5Data.RegulationDetails = this.form5AdditionalDetailsRegulation;
    form5Data.NewNovelOfferedDetails = this.form5AdditionalDetailsNewNovel;
    form5Data.CompletionStatus = this.formStatus;

    if (!this.isSavedDataAvailable) {
      if (!this.isMasterRecordAvailable) {
        let newMasterRecord: MasterListModel = new MasterListModel();
        newMasterRecord.Form2DemandListLookupId = null;
        newMasterRecord.Form3DemandListLookupId = null;
        newMasterRecord.Form4DemandListLookupId = null;
        newMasterRecord.Form5DemandListLookupId = null;
        newMasterRecord.Form6DemandListLookupId = null;
        newMasterRecord.DemandType = this.demandType;
        newMasterRecord.FormStatus= _FORM_STATUS.inProgress;
        newMasterRecord.Stage= _FORM_STAGES.stage1

        this._masterListSvc.saveData(newMasterRecord).subscribe(mdata => {
          // Handle Success
          this.isMasterRecordAvailable = true;
          this.masterRecordId = Number(mdata.data.Id);
          this.savedMasterRecord = newMasterRecord;

          localStorage.setItem('masterRecordId', mdata.data.Id);
          this._form5Svc.saveData(form5Data).subscribe(data => {
            // Handle Success
            // Update master record with Id
            this.savedMasterRecord.Form5DemandListLookupId = Number(data.data.Id);
            this._masterListSvc.updateData(this.savedMasterRecord, this.masterRecordId).subscribe((data) => {
              this.isDataSaved = true;
              localStorage.setItem('form5SavedId', this.savedMasterRecord.Form5DemandListLookupId.toString());
              this.formSaved.emit(_FORM_NAMES.form5);
              this.setFormActive(_FORM_NAMES.form6);
            });
          }, (error) => {
            // Handle Error
            this.isDataSaved = false;
          });
        }, (error) => {
          // Handle Error
          this.isMasterRecordAvailable = false;
          this.isDataSaved = false;
        });
      }
      else {
        this._form5Svc.saveData(form5Data).subscribe(data => {
          // Handle Success
          // Update master record with Id
          this.savedMasterRecord.Form5DemandListLookupId = Number(data.data.Id);
          this._masterListSvc.updateData(this.savedMasterRecord, this.masterRecordId).subscribe((data) => {
            this.isDataSaved = true;
            localStorage.setItem('form5SavedId', this.savedMasterRecord.Form5DemandListLookupId.toString());
            this.formSaved.emit(_FORM_NAMES.form5);
            this.setFormActive(_FORM_NAMES.form6);
          });
        }, (error) => {
          // Handle Error
          this.isDataSaved = false;
        });
      }
    }
    else {
      this._form5Svc.updateData(form5Data, this.savedDataId).subscribe(data => {
        // Handle Success
        this.isDataSaved = true;
        this.formSaved.emit(_FORM_NAMES.form5);
        this.setFormActive(_FORM_NAMES.form6);
      }, (error) => {
        // Handle Error
        this.isDataSaved = false;
      });
    }
  }


  onCheckChange(value, event) {
    this.checkedList = [];
    this.checkedListUnchek = [];

    if (event.target.checked) {
      this.checkedList.push(value.id);
      this.businessTypeCheckListSelected.push(value.name); // pushing selected value in checkList array
    }
    else {
      this.checkedListUnchek.push(value.id)
      const index = this.businessTypeCheckListSelected.indexOf(value.name);
      if (index > -1) {
        this.businessTypeCheckListSelected.splice(index, 1);
      }
    }
    for (var i = 0; i < this.checkedList.length; i++) {
      if (this.checkedList[i] == 4) {
        this.showText = true
      }
    }
    for (var i = 0; i < this.checkedListUnchek.length; i++) {
      if (this.checkedListUnchek[i] == 4) {
        this.showText = false;
      }
    }


    this.businessTypeVal = "";
    this.businessTypeCheckListSelected.forEach(item => {
      if (this.businessTypeVal === "") {
        this.businessTypeVal = item;
      }
      else {
        this.businessTypeVal = this.businessTypeVal + "," + item;
      }
    })
    this.onTextChange();
  }

  onInsertValue() {

    if (this.FTEassignedPerTask1 != null && this.FTEassignedPerTask != null) {

      var result = parseFloat(this.FTEassignedPerTask1) + parseFloat(this.FTEassignedPerTask);

      if (Number.isNaN(result)) {
        this.TotalFTEassignedPerTask = null;
      }
      else {
        this.TotalFTEassignedPerTask = parseFloat(this.FTEassignedPerTask1) + parseFloat(this.FTEassignedPerTask);
      }

    }

    if (this.HoursFTE1 != null && this.HoursFTE != null) {
      var result = parseFloat(this.HoursFTE) + parseFloat(this.HoursFTE1);

      if (Number.isNaN(result)) {
        this.TotalHoursFTE = null;
      }
      else {
        this.TotalHoursFTE = parseFloat(this.HoursFTE) + parseFloat(this.HoursFTE1);
      }

    }
    if (this.TotalHoursPA != null && this.TotalHoursPA1 != null) {


      var result = parseFloat(this.TotalHoursPA) + parseFloat(this.TotalHoursPA1);
      if (Number.isNaN(result)) {
        this.TotalHoursPATotal = null;
      }
      else {
        this.TotalHoursPATotal = parseFloat(this.TotalHoursPA) + parseFloat(this.TotalHoursPA1);
      }
    }
    if (this.TotalCostPAapprox != null && this.TotalCostPAapprox1 != null) {
      var result = parseFloat(this.TotalCostPAapprox1) + parseFloat(this.TotalCostPAapprox);

      if (Number.isNaN(result)) {
        this.TotalCostPAapproxTotal = null;
      }
      else {
        this.TotalCostPAapproxTotal = parseFloat(this.TotalCostPAapprox1) + parseFloat(this.TotalCostPAapprox);
      }

    }
    if (this.TargetNumberHours1 != null && this.TargetNumberHours != null) {
      var result = parseFloat(this.TargetNumberHours1) + parseFloat(this.TargetNumberHours);
      if (Number.isNaN(result)) {
        this.TotalTargetNumberHours = null;
      }
      else {
        this.TotalTargetNumberHours = parseFloat(this.TargetNumberHours1) + parseFloat(this.TargetNumberHours);
      }

    }
    if (this.TargetTotalCost != null && this.TargetTotalCost1 != null) {
      var result = parseFloat(this.TargetTotalCost) + parseFloat(this.TargetTotalCost1);
      if (Number.isNaN(result)) {
        this.TotalTargetTotalCost = null;
      }
      else {
        this.TotalTargetTotalCost = parseFloat(this.TargetTotalCost1) + parseFloat(this.TargetTotalCost);
      }
    }
    if (this.CostSavingPA1 != null && this.CostSavingPA != null) {
      var result = parseFloat(this.CostSavingPA) + parseFloat(this.CostSavingPA1);
      if (Number.isNaN(result)) {
        this.TotalCostSavingPA = null;
      }
      else {
        this.TotalCostSavingPA = parseFloat(this.CostSavingPA1) + parseFloat(this.CostSavingPA);
      }

    }

  }
  isEmpty(controlName) {
    var formValue = controlName;
    console.log(formValue);
    if (formValue.length <= 0)
      return true;
    else
      return false;
  }
  setFormActive(form) {
    this.formSaveClick.emit(form);
  }
}
