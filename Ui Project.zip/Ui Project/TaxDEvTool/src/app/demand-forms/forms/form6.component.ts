import { Router } from '@angular/router';
import { Component, Output, ViewEncapsulation, EventEmitter, Input, OnInit, AfterViewInit } from '@angular/core';
import { spPnpAPIService } from '../../Services/Implementations/spPnPAPIService';
import { MasterListService } from '../../Services/Implementations/masterListService';
import { MasterListModel } from '../../Models/masterListModel';
import { Form6Model } from '../../Models/form6model';
import { Form6SPService } from '../../Services/Implementations/form6Service';
import { guid } from '@progress/kendo-angular-common';
import { _FORM_NAMES } from 'src/app/Models/form-names';
import { _FORM_STATUS } from 'src/app/Models/formstatus';
import { _FORM_STAGES } from 'src/app/Models/formstatus';
import { environment } from '../../../environments/environment'

@Component({
  selector: 'form-6',
  templateUrl: './form6.component.html',
  encapsulation: ViewEncapsulation.None,
  providers: [spPnpAPIService, MasterListService, Form6SPService],
  styleUrls: ['./forms.css']
})
export class Form6Component implements OnInit {
  @Output()
  completedChildFormIds = new EventEmitter<any>();
  @Output()
  formSaved = new EventEmitter<string>();
  @Output() error: EventEmitter<string> = new EventEmitter<string>();
  @Output() change: EventEmitter<File | FileList> = new EventEmitter<File | FileList>();
  @Input()
  formFields: any[] = [];
  @Input() disabled: boolean;
  @Input() maxSize: number; // in MB
  @Input()
  formStatus: string = "Not Started";
  @Input()
  demandType: string = "";
  @Input()
  isFormSubmitted: boolean = false;
  dataRequirement: string = "";
  dataVolume: string = "";
  dataAccuracy: string = "";
  submitClientData: string = "";
  dataBelong: string = "";
  otherInfo: string = "";
  fileInfoJson: string = "";
  fileInfoObjs: any[] = [];

  allowMultiple: boolean = true;
  value: any = {};
  showFile: boolean;
  isMultipleUpload: boolean = false;

  isDataSaved: boolean = false;
  savedData: Form6Model = null;
  isSavedDataAvailable: boolean = false;
  savedDataId: number = -1;

  isMasterRecordAvailable: boolean = false;
  masterRecordId: number = -1;
  savedMasterRecord: MasterListModel = null;
  form6Data = new Form6Model;
  form6Validation: any = {};
  _uploadedFiles: any[] = [];
  sameFilePresent: boolean = false;
  _fileToUpload: any[] = [];
  _uploadFile: boolean = false;
  _uploadedFile: boolean = false;
  uploadButton: boolean;

  currentProgress: number = 0;
  volumeAllItem: number=0;
  showProgress: boolean = false;


  constructor(private _spSvc: spPnpAPIService,
    private _masterListSvc: MasterListService,
    private _form6Svc: Form6SPService, private router: Router) {

  }

  ngOnInit() {
    this.dataRequirement = this.formFields.filter(f => f.fieldName === "dataRequirement")[0].value;
    this.dataVolume = this.formFields.filter(f => f.fieldName === "dataVolume")[0].value;
    this.dataAccuracy = this.formFields.filter(f => f.fieldName === "dataAccuracy")[0].value;
    this.fileInfoJson = this.formFields.filter(f => f.fieldName === "fileInfoJson")[0].value;
    this.submitClientData = this.formFields.filter(f => f.fieldName === "submitClientData")[0].value;
    this.dataBelong = this.formFields.filter(f => f.fieldName === "dataBelong")[0].value;
    this.otherInfo = this.formFields.filter(f => f.fieldName === "otherInfo")[0].value;

    // if (this.fileInfoJson && this.fileInfoJson.length > 0) {
    //   this.fileInfoObjs = JSON.parse(this.fileInfoJson);
    //   this.value = {};
    //   this.value.name = this.fileInfoObjs[0].name;
    //   this.value.size = this.fileInfoObjs[0].size;
    //   this.showFile = true;
    // }
    if (this.fileInfoJson && this.fileInfoJson.length > 0) {
      this._uploadedFiles = [];
      this.fileInfoObjs = JSON.parse(this.fileInfoJson);
      this.fileInfoObjs.forEach(item => {

        this.value = {};
        this.value.name = item.name;
        this.value.url = item.url;
        this.value.uniqueId = item.uniqueId;
        this.value.size = item.size;
        this.value.linkUrl = environment.sp_url + "/FormDocuments/FormDocuments/" + item.name;

        this.showFile = true;
        this._uploadedFiles.push(this.value);

      });

    }

    this.saveOrLoadMasterRecord();
  }

  // ngAfterViewInit() {
  //   if(this.isFormSubmitted){
  //     setTimeout(()=>{
  //       let allInputs = document.getElementsByTagName('input');
  //       if(allInputs){
  //         for(let i=0;i<allInputs.length;i++){
  //           allInputs.item(i).disabled = true;
  //         }
  //       }
  //       let allSelects = document.getElementsByTagName('select');
  //       if(allSelects){
  //         for(let i=0;i<allSelects.length;i++){
  //          // allSelects.item(i).disabled = true;
  //          allSelects.item(i).style.pointerEvents = "none";
  //          allSelects.item(i).style.cursor = "not-allowed";
  //         }
  //       }
  //       let allButtons = document.getElementsByTagName('button');
  //       if(allButtons){
  //         for(let i=0;i<allButtons.length;i++){
  //           if(allButtons.item(i).innerText.indexOf("Back to Home")<0)
  //             allButtons.item(i).disabled = true;
  //         }
  //       }
  //       let allTextArea = document.getElementsByTagName('textarea');
  //       if(allTextArea){
  //         for(let i=0;i<allTextArea.length;i++){
  //           allTextArea.item(i).disabled = true;
  //         }
  //       }
  //     });
  //   }
  // }

  saveOrLoadMasterRecord() {
    if (localStorage.getItem('masterRecordId') && localStorage.getItem('masterRecordId').length > 0) {
      let masterId: number = Number(localStorage.getItem('masterRecordId'));
      if (masterId > 0) {
        this._masterListSvc.getSavedRecord(masterId).subscribe((masterData: MasterListModel) => {

          this.isMasterRecordAvailable = true;
          this.masterRecordId = masterId;
          this.savedMasterRecord = masterData;
          this.savedMasterRecord.FormStatus = (this.savedMasterRecord.FormStatus === _FORM_STATUS.triage) ? _FORM_STATUS.triage : _FORM_STATUS.inProgress;
          if (this.savedMasterRecord.Form6DemandListLookupId != null) {
            localStorage.setItem('form6SavedId', this.savedMasterRecord.Form6DemandListLookupId.toString());
            this.loadFormDataOnLoad();
          }
        }, (error) => {
          this.isSavedDataAvailable = false;
          this.isMasterRecordAvailable = false;
          localStorage.setItem('form6SavedId', '');
        });
      }
      else {
        this.isSavedDataAvailable = false;
        this.isMasterRecordAvailable = false;
        localStorage.setItem('form6SavedId', '');
      }
    }
    else {
      this.isSavedDataAvailable = false;
      this.isMasterRecordAvailable = false;
      localStorage.setItem('form6SavedId', '');
    }
  }

  loadFormDataOnLoad() {
    this.isSavedDataAvailable = false;
    this.savedData = null;
    this.savedDataId = -1;
    if (localStorage.getItem('form6SavedId') && localStorage.getItem('form6SavedId').length > 0) {
      let savedId: number = Number(localStorage.getItem('form6SavedId'));
      if (savedId > 0) {
        this._form6Svc.getSavedRecord(savedId).subscribe((form6Data: Form6Model) => {
          this.form6Data = form6Data;
          this.isSavedDataAvailable = true;
          this.savedData = form6Data;
          this.savedDataId = savedId;
          this.dataRequirement = this.formFields.filter(f => f.fieldName === "dataRequirement")[0].value = form6Data.OverViewInputDataRequirements;
          this.dataVolume = this.formFields.filter(f => f.fieldName === "dataVolume")[0].value = form6Data.DataTranscationVolumes;
          this.dataAccuracy = this.formFields.filter(f => f.fieldName === "dataAccuracy")[0].value = form6Data.DataAccuracyRequiredProduct;
          this.fileInfoJson = this.formFields.filter(f => f.fieldName === "fileInfoJson")[0].value = form6Data.FileDetailsJson;
          this.submitClientData = this.formFields.filter(f => f.fieldName === "submitClientData")[0].value = form6Data.ClientDataSubmitted;
          this.dataBelong = this.formFields.filter(f => f.fieldName === "dataBelong")[0].value = form6Data.DataBelongsToClient;
          this.otherInfo = this.formFields.filter(f => f.fieldName === "otherInfo")[0].value = form6Data.AdditionalInfo;
          this._uploadedFiles = [];

          if (this.fileInfoJson && this.fileInfoJson.length > 0) {

            this.fileInfoObjs = JSON.parse(this.fileInfoJson);
            this.fileInfoObjs.forEach(item => {

              this.value = {};
              this.value.name = item.name;
              this.value.url = item.url;
              this.value.uniqueId = item.uniqueId;
              this.value.size = item.size;
              this.value.linkUrl = environment.sp_url + "/FormDocuments/FormDocuments/" + item.name;

              this.showFile = true;

              this._uploadedFiles.push(this.value);
              this._uploadedFile = true;

            });

          }

          this.completedChildFormIds.emit(this.formFields);
        });
      }
    }
  }



  onTextChange() {
    // if (typeof (event) === 'string') {
    //   this.clearEvent = true;
    // }
    // this.formValidCheck = false;

    this.formFields.forEach(field => {
      // event = (event) ? event : "";
      if (field.fieldName === "dataRequirement") {
        field.value = this.dataRequirement;

      }
      else if (field.fieldName === "dataVolume") {
        field.value = this.dataVolume;

      }
      else if (field.fieldName === "dataAccuracy") {
        field.value = this.dataAccuracy;

      }
      else if (field.fieldName === "submitClientData") {
        field.value = this.submitClientData;

      }
      else if (field.fieldName === "dataBelong") {
        field.value = this.dataBelong;

      }
      else if (field.fieldName === "otherInfo") {
        field.value = this.otherInfo;

      }
      // if (this.clearEvent) {
      //   event = "";
      // }
      // if (this.form6Validation.isForminValid) {
      //   this.formValidCheck = true;
      // }
    })
    this.completedChildFormIds.emit(this.formFields);
  }
  get isFile() {
    return this.value instanceof File;
  }

  get isFileList() {
    return this.value instanceof FileList;
  }


  onChange(event: any, input: HTMLInputElement): void {
    event.stopPropagation();

    this.updateFile(input.files);
  }

  resetFile(input?: HTMLInputElement): void {
    this.value = {};
    this.showFile = false;
    if (input) {
      input.value = '';
    }
  }

  onDrop(evt: any, wrapper: HTMLElement, input: HTMLInputElement): void {
    evt.preventDefault();
    if (this.disabled) { return; }
    this.updateFile(evt.dataTransfer.files);
    this.stopDragging(wrapper);
    input.value = '';
  }

  onDragover(evt: any): void {
    evt.preventDefault();
  }

  startDragging(wrapper: HTMLElement): void {
    wrapper.classList.add('dragging');
  }

  stopDragging(wrapper: HTMLElement): void {
    wrapper.classList.remove('dragging');
  }

  private updateFile(files: FileList): void {

    //if (files.length > 1 && !this.allowMultiple) { return this.throwError('Please upload a single file'); }

    //   if (this.allowMultiple && files.length > 1) {
    //     this.isMultipleUpload = true;
    //     file = files;

    //     Array.from(files).map(f => {
    //       //this.value= f;
    //       this._fileToUpload.push(f);
    //       this._uploadFile= true;
    //       if (!this.runValidations(f)) return;
    //     });
    //   } else {
    //     this.isMultipleUpload = false;
    //     file = files[0];
    //     this._fileToUpload.push(file.name)
    //       this._uploadFile= true;
    //     if (!this.runValidations(file)) return;
    //   }
    // } else {
    //   return;
    // }
    //this.updateValue(file);
    let file: File | FileList;
    this.sameFilePresent = false;
    if (files.length > 0) {
      file = files;
      Array.from(files).map(f => {
        if (!this.runValidations(f)) {
          return false;
        }
        else {
          this._fileToUpload.push(f);
          this._uploadFile = true;
          this.uploadButton = true;
          this.sameFilePresent = false;
        }
      });
    }
  }

  private throwError(message: string): void {
    //this.alertService.error(message);
    this.error.emit(message);
  }

  private updateValue(file?: File | FileList): void {
    this.value = file;
    this.showFile = true;
    // this.change.emit(file);
    this.uploadFile(file);
  }

  private runValidations(file: File): boolean {
    if (file.size / (1024 * 1024) > this.maxSize) {
      this.throwError(`File upload has failed due to file size. It is limited to ${this.maxSize} MB`);
      return false;
    }

    else if (true) {

      for (var i = 0; i < this._uploadedFiles.length; i++) {
        if (file.name === this._uploadedFiles[i].name) {
          this.sameFilePresent = true;
          break;
        }
      }
      for (var i = 0; i < this._fileToUpload.length; i++) {
        if (file.name === this._fileToUpload[i].name) {
          this.sameFilePresent = true;
          break;
        }
      }

      if (this.sameFilePresent === true) {
        return false;
      }

    }
    return true;

  }

  _uploadFiles() {

    this.fileInfoObjs = [];
    this.showProgress= true;
    this.currentProgress = 0;
    for (let i = 0; i < this._fileToUpload.length; i++) {
      this.volumeAllItem=this._fileToUpload.length;
      let uploadedFile: File = this._fileToUpload[i];
      let fileName: string = uploadedFile.name;
      this._spSvc.uploadFileToDocumentLibrary('FormDocuments', fileName, uploadedFile, false, 'FormDocuments').subscribe(data => {
        this.fileInfoObjs.push({
          name: fileName,
          url: data.file._url,
          uniqueId: data.data.UniqueId,
          size: data.data.Length
        });
        this.fileInfoJson = JSON.stringify(this.fileInfoObjs).toString();
        this._uploadedFiles.push({
          name: fileName,
          url: data.file._url,
          uniqueId: data.data.UniqueId,
          size: data.data.Length,
          linkUrl: environment.sp_url + "/FormDocuments/FormDocuments/" + fileName

        });
        let index = this._fileToUpload.indexOf(uploadedFile);
        this._fileToUpload.splice(index, 1);
        this._uploadedFile = true;
        //this._fileToUpload=[];
        this.getProgress();
        if (this._fileToUpload.length === 0) {
          this._uploadFile = false;
          this.showProgress= false;
          this.uploadButton = false;

        }

        

      });
    }
    this.formFields.filter(f => f.fieldName === "fileInfoJson")[0].value = JSON.stringify(this._uploadedFiles).toString();
    this.onTextChange();
  }

  getProgress() {
    this.updateProgressIndicator();
    return this.currentProgress;
  }

  updateProgressIndicator() {
    let completedSteps: number = this.fileInfoObjs.length;
    let volumePerItem: number = Math.round(100 / this.volumeAllItem);
    this.currentProgress = completedSteps * volumePerItem;
  }



  uploadFile(file: File | FileList): void {
    if (!this.isMultipleUpload) {
      // Single file upload
      let uploadedFile: File = file as File;
      let fileName: string = uploadedFile.name;
      this._spSvc.uploadFileToDocumentLibrary('FormDocuments', fileName, uploadedFile, false, 'FormDocuments').subscribe(data => {
        // Add file info to file info obj
        this.fileInfoObjs = [];
        this.fileInfoObjs.push({
          name: fileName,
          url: data.file._url,
          uniqueId: data.data.UniqueId,
          size: data.data.Length
        });
        this.fileInfoJson = JSON.stringify(this.fileInfoObjs).toString();
        this._uploadedFiles.push({
          name: fileName,
          url: data.file._url,
          uniqueId: data.data.UniqueId,
          size: data.data.Length,
          linkUrl: environment.sp_url + "/FormDocuments/FormDocuments/" + fileName

        });
        this.formFields.filter(f => f.fieldName === "fileInfoJson")[0].value = JSON.stringify(this._uploadedFiles).toString();
        this._uploadedFile = true;
        this.onTextChange();
      });
    }
    else {
      // multiple file upload
      let uploadedFiles: FileList = file as FileList;
      this.fileInfoObjs = [];
      for (let i = 0; i < uploadedFiles.length; i++) {
        let uploadedFile: File = uploadedFiles.item(i);
        let fileName: string = uploadedFile.name;
        this._spSvc.uploadFileToDocumentLibrary('FormDocuments', fileName, uploadedFile, false, 'FormDocuments').subscribe(data => {
          this.fileInfoObjs.push({
            name: fileName,
            url: data.file._url,
            uniqueId: data.data.UniqueId,
            size: data.data.Length
          });
          this.fileInfoJson = JSON.stringify(this.fileInfoObjs).toString();
          this._uploadedFiles.push({
            name: fileName,
            url: data.file._url,
            uniqueId: data.data.UniqueId,
            size: data.data.Length,
            linkUrl: environment.sp_url + "/FormDocuments/FormDocuments/" + fileName

          });
          this._uploadedFile = true;
        });
      }
      this.formFields.filter(f => f.fieldName === "fileInfoJson")[0].value = JSON.stringify(this._uploadedFiles).toString();
      this.onTextChange();
    }
  }

  redirectToHome() {
    this.router.navigateByUrl('/appHome');
  }

  deleteFile(file) {

    if (this._uploadedFiles.length > 0) {
      let relativePath = environment.fileRelativeUrl + "/FormDocuments/FormDocuments/" + file.name;
      if (!this.form6Data.FileDetailsJson == false) {

        this._spSvc.deleteFileToDocumentLibrary(relativePath).subscribe(data => {
          let index = this._uploadedFiles.indexOf(file);
          this._uploadedFiles.splice(index, 1);
          if (this._uploadedFiles.length > 0) {
            this.form6Data.FileDetailsJson = JSON.stringify(this._uploadedFiles);
          }
          else {
            this.form6Data.FileDetailsJson = "";
          }

          this._form6Svc.updateData(this.form6Data, this.savedDataId).subscribe(data => {
            this.form6Data = data;
          })
        })
      }
      else {
        this._spSvc.deleteFileToDocumentLibrary(relativePath).subscribe(data => {
          let index = this._uploadedFiles.indexOf(file);
          this._uploadedFiles.splice(index, 1);

        });
      }
    }
    if (this._fileToUpload.length > 0) {
      let index = this._fileToUpload.indexOf(file);
      this._fileToUpload.splice(index, 1);

    }
    if (this._fileToUpload.length === 0) {
      this.uploadButton = false;
      this._uploadFile = false;

    }

  }
  // else {
  //   let index = this._uploadedFiles.indexOf(file.uniqueId);
  //   this._uploadedFiles.splice(index, 1);
  //   this._spSvc.deleteFileToDocumentLibrary(relativePath).subscribe(data => {

  //   })
  // }





  // valitaionCheck(event, field) {

  //   if (!event) {
  //     event = { "target": {} };
  //     event.target.id = field.fieldName;
  //     event.target.name = field.fieldName;
  //   }
  //   if (field.isMandatory && !field.value && (event.target.name === field.fieldName || event.target.id === field.fieldName)) {

  //     this.form6Validation[field.fieldName] = true;
  //     this.form6Validation.isForminValid = true;

  //   }
  //   else if (field.isMandatory && !field.value && this.form6Validation[field.fieldName]) {
  //     this.form6Validation[field.fieldName] = true;
  //     this.form6Validation.isForminValid = true;
  //   }
  //   else {
  //     this.form6Validation[field.fieldName] = false;
  //     this.form6Validation.isForminValid = false;
  //   }
  // }
  saveFormData() {
    // this.onTextChange("");
    // if (this.formValidCheck) {
    //   return;
    // }

    if (!this.isSavedDataAvailable) {
      this.form6Data.Title = guid();
    }
    else {
      this.form6Data.Title = this.savedData.Title;
    }

    this.form6Data.OverViewInputDataRequirements = this.dataRequirement;
    this.form6Data.DataTranscationVolumes = this.dataVolume;
    this.form6Data.DataAccuracyRequiredProduct = this.dataAccuracy;
    this.form6Data.ClientDataSubmitted = this.submitClientData;
    this.form6Data.DataBelongsToClient = this.dataBelong;
    this.form6Data.AdditionalInfo = this.otherInfo;
    if (this._uploadedFiles.length > 0) {
      this.form6Data.FileDetailsJson = JSON.stringify(this._uploadedFiles);
    }
    else {
      this.form6Data.FileDetailsJson = "";
    }

    this.form6Data.CompletionStatus = this.formStatus;

    if (!this.isSavedDataAvailable) {
      if (!this.isMasterRecordAvailable) {
        let newMasterRecord: MasterListModel = new MasterListModel();
        newMasterRecord.Form2DemandListLookupId = null;
        newMasterRecord.Form3DemandListLookupId = null;
        newMasterRecord.Form4DemandListLookupId = null;
        newMasterRecord.Form5DemandListLookupId = null;
        newMasterRecord.Form6DemandListLookupId = null;
        newMasterRecord.DemandType = this.demandType;
        newMasterRecord.FormStatus = _FORM_STATUS.inProgress;
        newMasterRecord.Stage = _FORM_STAGES.stage1

        this._masterListSvc.saveData(newMasterRecord).subscribe(mdata => {
          // Handle Success
          this.isMasterRecordAvailable = true;
          this.masterRecordId = Number(mdata.data.Id);
          this.savedMasterRecord = newMasterRecord;

          localStorage.setItem('masterRecordId', mdata.data.Id);
          this._form6Svc.saveData(this.form6Data).subscribe(data => {
            // Handle Success
            // Update master record with Id
            this.savedMasterRecord.Form6DemandListLookupId = Number(data.data.Id);
            this._masterListSvc.updateData(this.savedMasterRecord, this.masterRecordId).subscribe((data) => {
              this.isDataSaved = true;
              localStorage.setItem('form6SavedId', this.savedMasterRecord.Form6DemandListLookupId.toString());
              this.formSaved.emit(_FORM_NAMES.form6);
            });
          }, (error) => {
            // Handle Error
            this.isDataSaved = false;
          });
        }, (error) => {
          // Handle Error
          this.isMasterRecordAvailable = false;
          this.isDataSaved = false;
        });
      }
      else {
        this._form6Svc.saveData(this.form6Data).subscribe(data => {
          // Handle Success
          // Update master record with Id
          this.savedMasterRecord.Form6DemandListLookupId = Number(data.data.Id);
          this._masterListSvc.updateData(this.savedMasterRecord, this.masterRecordId).subscribe((data) => {
            this.isDataSaved = true;
            localStorage.setItem('form6SavedId', this.savedMasterRecord.Form6DemandListLookupId.toString());
            this.formSaved.emit(_FORM_NAMES.form6);
          });
        }, (error) => {
          // Handle Error
          this.isDataSaved = false;
        });
      }
    }
    else {
      this._form6Svc.updateData(this.form6Data, this.savedDataId).subscribe(data => {
        // Handle Success
        this.isDataSaved = true;
        this.formSaved.emit(_FORM_NAMES.form6);
      }, (error) => {
        // Handle Error
        this.isDataSaved = false;
      });
    }
  }
}
