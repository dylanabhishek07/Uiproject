import { ChangeDetectorRef, Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { from, Subject } from 'rxjs';
import { _DEFAULT_FORM } from '../../Models/form-schema';
import { _DEFAULT_FIELDS } from '../../Models/form-fields';
import { _FORM_NAMES } from '../../Models/form-names';
import { Router } from '@angular/router';
import { MasterListService } from '../../Services/Implementations/masterListService';
import { MasterListModel } from 'src/app/Models/masterListModel';
import { Form2SPService } from 'src/app/Services/Implementations/form2Service';
import { Form3SPService } from 'src/app/Services/Implementations/form3Service';
import { Form4SPService } from 'src/app/Services/Implementations/form4Service';
import { Form5SPService } from 'src/app/Services/Implementations/form5Service';
import { Form6SPService } from 'src/app/Services/Implementations/form6Service';
import { FormSaveService } from '../forms/formsave.service';
import { AutocompleteInterface } from 'src/app/Common/ey-autocomplete-input/autocomplete.interface';
import { UserSPService } from 'src/app/Services/Implementations/userSPService';
import { _FORM_STAGES, _FORM_STATUS } from 'src/app/Models/formstatus';
import { Form7SPService } from 'src/app/Services/Implementations/form7Service';
import { Form2Component } from '../forms/form2.component';
import { Form3Component } from '../forms/form3.component';
import { Form4Component } from '../forms/form4.component';
import { Form5Component } from '../forms/form5.component';
import { Form6Component } from '../forms/form6.component';
import { Form7Component } from '../forms/form7.component';


@Component({
  selector: 'demand-form-landing-s1',
  templateUrl: './demand-form-landing-s1.component.html',
  encapsulation: ViewEncapsulation.None,
  providers: [MasterListService, Form2SPService,
    Form3SPService, Form4SPService, Form5SPService,
    Form6SPService, Form7SPService, FormSaveService, UserSPService]


})
export class DemandFormLandingS1Component implements OnInit {
  selectedFormId: string = _FORM_NAMES.form2;
  @ViewChild() form2Instance: Form2Component;
  @ViewChild('form3Instance', { static: false }) form3Instance: Form3Component;
  @ViewChild('form4Instance', { static: false }) form4Instance: Form4Component;
  @ViewChild('form5Instance', { static: false }) form5Instance: Form5Component;
  @ViewChild('form6Instance', { static: false }) form6Instance: Form6Component;
  @ViewChild('form7Instance', { static: false }) form7Instance: Form7Component;
  forms: any[] = [];
  formFields: any[] = [];
  form2Fields: any[] = [];
  form3Fields: any[] = [];
  form4Fields: any[] = [];
  form5Fields: any[] = [];
  form6Fields: any[] = [];
  form7Fields: any[] = [];
  formNames: any = _FORM_NAMES;
  sectionHeader: string;
  formStatus: any = {};
  demandType: string = "";
  isFormSubmitted: boolean = false;
  showFormSubmitMsg: boolean = false;
  formIsDirty: any = {};
  jurisdictionArr: any[] = [];

  isLoadingUserList: boolean = true;
  assignedToAutocompletionSubject: Subject<AutocompleteInterface[]> = new Subject();
  userList: AutocompleteInterface[] = [];

  assignedToUserName: string = "";
  assignedToUserId: string = "";
  isAssignedToSuccess: boolean = false;
  currentStage: string = "";
  isDataSaved: boolean = false;

  constructor(private router: Router, private changeDetector: ChangeDetectorRef,
    private _masterListSvc: MasterListService, private _form2Svc: Form2SPService,
    private _form3Svc: Form3SPService, private _form4Svc: Form4SPService,
    private _form5Svc: Form5SPService,
    private _form6Svc: Form6SPService,
    private _form7Svc: Form7SPService,
    private _formSaveSvc: FormSaveService,
    private _userSvc: UserSPService) {
    this.formStatus = {
      [_FORM_NAMES.form2]: "Not Started",
      [_FORM_NAMES.form3]: "Not Started",
      [_FORM_NAMES.form4]: "Not Started",
      [_FORM_NAMES.form5]: "Not Started",
      [_FORM_NAMES.form6]: "Not Started",
      [_FORM_NAMES.form7]: "Not Started"
    }

    this.formIsDirty = {
      [_FORM_NAMES.form2]: false,
      [_FORM_NAMES.form3]: false,
      [_FORM_NAMES.form4]: false,
      [_FORM_NAMES.form5]: false,
      [_FORM_NAMES.form6]: false,
      [_FORM_NAMES.form7]: false
    }

    this.demandType = window.history.state.selectedVal;

    if (window.history.state.formStatus
      && window.history.state.formStatus.length > 0
      && window.history.state.formStatus.toLowerCase() !== _FORM_STATUS.inProgress.toLowerCase()) {
      this.isFormSubmitted = true;
    }
    if (window.history.state.formStatus
      && window.history.state.formStatus.length > 0
      && window.history.state.formStatus.toLowerCase() === _FORM_STATUS.approved.toLowerCase()
      && window.history.state.stage.toLowerCase() === _FORM_STAGES.stage1.toLowerCase()) {
      this.isFormSubmitted = false;
    }

    this.setupFormsAndFields(window.history.state.selectedVal,
      window.history.state.formStatus, window.history.state.stage);
  }

  setupFormsAndFields(demandType, formStatus, currentStage) {
    // Setup Forms data
    this.demandType = demandType;

    if (formStatus
      && formStatus.length > 0
      && formStatus.toLowerCase() !== _FORM_STATUS.inProgress.toLowerCase()) {
      this.isFormSubmitted = true;
    }
    if (formStatus
      && formStatus.length > 0
      && formStatus.toLowerCase() === _FORM_STATUS.approved.toLowerCase()
      && currentStage.toLowerCase() === _FORM_STAGES.stage1.toLowerCase()) {
      this.isFormSubmitted = false;
    }
    // Setup Forms
    this.currentStage = currentStage;

    if (!this.currentStage || this.currentStage === _FORM_STAGES.stage1) {
      this.forms = _DEFAULT_FORM.stage1.filter(form => form.mappedToDemandTypes.includes(this.demandType));
    }
    else {
      this.forms = _DEFAULT_FORM.stage2;
    }
    for (let i = 0; i < this.forms.length; i++) {
      this.forms[i].formName = "Form " + (i + 1).toString();
      this.forms[i].isFormTabSelected = false;
    }
    this.forms[0].isFormTabSelected = true;
    this.selectedFormId = this.forms[0].formId;
    this.sectionHeader = this.forms[0].formName + ": " + this.forms[0].sectionHeader.split(':')[1];

    // Setup Fields
    if (!this.currentStage || this.currentStage === _FORM_STAGES.stage1) {
      this.formFields = _DEFAULT_FIELDS.stage1;
      this.form2Fields = this.formFields.filter(f => f.formName === _FORM_NAMES.form2)[0].fields;
      this.form3Fields = this.formFields.filter(f => f.formName === _FORM_NAMES.form3)[0].fields;
      this.form4Fields = this.formFields.filter(f => f.formName === _FORM_NAMES.form4)[0].fields;
      this.form5Fields = this.formFields.filter(f => f.formName === _FORM_NAMES.form5)[0].fields;
      this.form6Fields = this.formFields.filter(f => f.formName === _FORM_NAMES.form6)[0].fields;
    }
    else {
      this.formFields = _DEFAULT_FIELDS.stage2;
      this.form7Fields = this.formFields.filter(f => f.formName === _FORM_NAMES.form7)[0].fields;
    }
  }

  showSuccessMessage(){
    this.isDataSaved = true;
  }

  ngOnInit() {
    setTimeout(() => {
      this.checkIfFormSubmitted();
    });

    setTimeout(() => {
      this.setAllSavedFormsStatus();
    });

    setTimeout(() => {
      this.populateUserList();
    }, 500);
  }

  populateUserList() {
    this._userSvc.getAllUsers().subscribe(data => {
      this.isLoadingUserList = false;
      if (data != null && data.length > 0) {
        this.userList = [];
        data.forEach(item => {
          this.userList.push({
            id: item.Id,
            description: item.Title
          })
        });
        this.assignedToAutocompletionSubject.next(this.userList);
      }
    });
  }

  searchAssignedTo(value: any) {
    if (value.length >= 0) {
      const filterData = this.userList.filter(a =>
        a.description.toLowerCase().includes(value.toLowerCase())
      );
      this.assignedToAutocompletionSubject.next(filterData || this.userList);
    }
  }

  setAssignedTo(value: any) {
    this.assignedToUserId = value.id;
    this.assignedToUserName = value.description;
  }

  onFormSelectChanged(formId) {
    this.selectedFormId = formId;
    let formName = this.forms.filter(f => f.formId === formId)[0].formName;
    if (formId == 'Form2')
      this.sectionHeader = formName + ": Use case description";
    if (formId == 'Form3')
      this.sectionHeader = formName + ": Ownership";
    if (formId == 'Form4')
      this.sectionHeader = formName + ": Use case description";
    if (formId == 'Form5')
      this.sectionHeader = formName + ": Value Model";
    if (formId == 'Form6')
      this.sectionHeader = formName + ": Data";
    if (formId == _FORM_NAMES.form7)
      this.sectionHeader = formName + ": Detailed Value Pipeline";
    
    this.isDataSaved = false;
    this.changeDetector.detectChanges();
  }

  setForm(value) {
    let formName = this.forms.filter(f => f.formId === value)[0].formName;
    this.forms.forEach(function (item) {
      if (item.formId === value) {
        item.isFormTabSelected = true;
      }
      else {
        item.isFormTabSelected = false;
      }
    });
    if (value == "Form3") {
      this.selectedFormId = "Form3";
      this.sectionHeader = formName + ": Ownership";
      window.scrollTo(0, 0);
    }
    if (value == "Form5") {
      this.selectedFormId = "Form5";
      this.sectionHeader = formName + ": Value Model";
      window.scrollTo(0, 0);
    }
    if (value == "Form6") {
      this.selectedFormId = "Form6";
      this.sectionHeader = formName + ": Data";
      window.scrollTo(0, 0);
    }
  }

  onFormValueChanges(fieldsInfo: any[], formId: string) {
    this.showFormSubmitMsg = false;
    if (fieldsInfo.length > 0) {
      this.formIsDirty[formId] = true;
      let currentForm = this.formFields.filter(form => form.formName === formId);

      //getting jusrisdictions from form 2 for rest of the application
      this.jurisdictionArr = [];
      if (this.form2Fields && this.form2Fields.length > 0 && this.form2Fields[24].value && this.form2Fields[24].value.length > 0) {
        let parsedJurisdictions: any[] = JSON.parse(this.form2Fields[24].value);
        if (parsedJurisdictions && parsedJurisdictions.length > 0) {
          parsedJurisdictions.forEach(j => {
            this.jurisdictionArr.push(j.PriorityJurisdiction);
          })
        }
      }


      let currentFormSchema = this.forms.filter(form => form.formId === formId);
      if (currentForm != null && currentForm.length > 0 && currentFormSchema != null && currentFormSchema.length > 0) {
        currentForm[0]["fields"] = [...fieldsInfo];

        currentFormSchema[0].childFormDetails.forEach(c => {
          c.childFormStatus = "notstarted";
          let formSetupValue = currentForm[0]["fields"].filter(f => f.mappedToChild === c.childId);
          let allFields = [...formSetupValue];
          let mandatoryFields = formSetupValue.filter(f => this.isMandatory(f, allFields));
          let mandatoryFieldsWithValue = mandatoryFields.filter(f => f.value && f.value.toString().length > 0);

          let validValues = formSetupValue.filter(f => (f.value && f.value.length > 0)).length;
          let blankValues = formSetupValue.filter(f => f.isMandatory && (!f.value || f.value.length === 0)).length;

          if (mandatoryFieldsWithValue && mandatoryFields.length === mandatoryFieldsWithValue.length) {
            c.childFormStatus = "completed";
          }
          else if (validValues > 0 && blankValues > 0) {
            c.childFormStatus = "inprogress";
          }
        });

        let completedForms = currentFormSchema[0].childFormDetails.filter(c => c.childFormStatus === "completed");
        let notStartedForms = currentFormSchema[0].childFormDetails.filter(c => c.childFormStatus === "notstarted");
        if (completedForms.length === currentFormSchema[0].childFormDetails.length) {
          this.formStatus[formId] = "Completed";
        }
        else if (notStartedForms.length === currentFormSchema[0].childFormDetails.length) {
          this.formStatus[formId] = "Not Started";
        }
        else {
          this.formStatus[formId] = "In Progress";
        }
      }
    }

    this.changeDetector.detectChanges();
  }

  setAllSavedFormsStatus() {
    let masterId = localStorage.getItem('masterRecordId');
    if (masterId && masterId.length > 0) {
      let masterIdInt = Number(masterId);
      this._masterListSvc.getFormsCompletionStatus(masterIdInt).subscribe((mdata: MasterListModel) => {
        if (mdata.Form2DemandListLookup &&
          mdata.Form2DemandListLookup.CompletionStatus &&
          mdata.Form2DemandListLookup.CompletionStatus.toLowerCase() === "completed") {
          // Set form 2 complete
          this.setFormStatusCompleted(_FORM_NAMES.form2);
        }
        if (mdata.Form3DemandListLookup &&
          mdata.Form3DemandListLookup.CompletionStatus &&
          mdata.Form3DemandListLookup.CompletionStatus.toLowerCase() === "completed") {
          // Set form 3 complete
          this.setFormStatusCompleted(_FORM_NAMES.form3);
        }
        if (mdata.Form4DemandListLookup &&
          mdata.Form4DemandListLookup.CompletionStatus &&
          mdata.Form4DemandListLookup.CompletionStatus.toLowerCase() === "completed") {
          // Set form 4 complete
          this.setFormStatusCompleted(_FORM_NAMES.form4);
        }
        if (mdata.Form5DemandListLookup &&
          mdata.Form5DemandListLookup.CompletionStatus &&
          mdata.Form5DemandListLookup.CompletionStatus.toLowerCase() === "completed") {
          // Set form 5 complete
          this.setFormStatusCompleted(_FORM_NAMES.form5);
        }
        if (mdata.Form6DemandListLookup &&
          mdata.Form6DemandListLookup.CompletionStatus &&
          mdata.Form6DemandListLookup.CompletionStatus.toLowerCase() === "completed") {
          // Set form 6 complete
          this.setFormStatusCompleted(_FORM_NAMES.form6);
        }
        if (mdata.Form7DemandListLookup &&
          mdata.Form7DemandListLookup.CompletionStatus &&
          mdata.Form7DemandListLookup.CompletionStatus.toLowerCase() === "completed") {
          // Set form 7 complete
          this.setFormStatusCompleted(_FORM_NAMES.form7);
        }

        this.changeDetector.detectChanges();
      });
    }
  }

  setFormStatusCompleted(formId) {
    let currentFormSchema = this.forms.filter(form => form.formId === formId);
    if (currentFormSchema && currentFormSchema.length > 0) {
      currentFormSchema[0].childFormDetails.forEach(c => {
        c.childFormStatus = "completed";
      });
      this.formStatus[formId] = "Completed";
    }
  }

  isMandatory(field, allFields): boolean {
    let isMandatory: boolean = false;
    if (field.isMandatory && !field.mandatoryDependency) {
      isMandatory = true;
    }
    else if (field.isMandatory && field.mandatoryDependency) {
      if (field.mandatoryDependency.formId) {
        let currentForm = this.formFields.filter(form => form.formName === field.mandatoryDependency.formId);
        if (currentForm && currentForm.length > 0) {
          allFields = currentForm[0]["fields"];
          let arrDependsOnField: any = allFields.filter(f => f.fieldName === field.mandatoryDependency.dependentOn);
          if (arrDependsOnField && arrDependsOnField.length > 0) {
            if (field.mandatoryDependency.dependencyType === "Value"
              && arrDependsOnField[0].value === field.mandatoryDependency.dependsOnValue) {
              isMandatory = true;
            }
            if (field.mandatoryDependency.dependencyType === "ValueLength"
              && arrDependsOnField[0].value.length >= field.mandatoryDependency.dependsOnValue) {
              isMandatory = true;
            }
          }
        }
      }
      else {
        let arrDependsOnField: any = allFields.filter(f => f.fieldName === field.mandatoryDependency.dependentOn);
        if (arrDependsOnField && arrDependsOnField.length > 0) {
          if (field.mandatoryDependency.dependencyType === "Value"
            && arrDependsOnField[0].value === field.mandatoryDependency.dependsOnValue) {
            isMandatory = true;
          }
          if (field.mandatoryDependency.dependencyType === "ValueLength"
            && arrDependsOnField[0].value.length >= field.mandatoryDependency.dependsOnValue) {
            isMandatory = true;
          }
        }
      }
    }
    return isMandatory;
  }

  canContinue() {
    let inCompltedForms = this.forms.filter(f => f.childFormDetails.filter(c => c.childFormStatus === "inprogress" || c.childFormStatus === "notstarted").length > 0);
    if (inCompltedForms && inCompltedForms.length > 0) {
      return false;
    }
    return true;
  }

  saveStage1DirtyForms(masterId, status) {
    let formFields: any[] = [];
    let masterIdInt = Number(masterId);
    // Saving master status
    this._masterListSvc.getSavedRecord(masterIdInt).subscribe((mdata: MasterListModel) => {
      mdata.FormStatus = status;
      // Saving stage also
      mdata.Stage = this.currentStage;
      this._masterListSvc.updateData(mdata, masterIdInt).subscribe(data => {
        // Show success message
        this.isFormSubmitted = true;
        this.showFormSubmitMsg = true;
        // Saving all dirty forms
        if (this.formIsDirty[_FORM_NAMES.form2]) {
          formFields = this.formFields.filter(f => f.formName === _FORM_NAMES.form2)[0].fields;
          this._formSaveSvc.saveForm2DataExternal(formFields, this._masterListSvc, this._form2Svc, this.demandType);
        }
        if (this.formIsDirty[_FORM_NAMES.form3]) {
          formFields = this.formFields.filter(f => f.formName === _FORM_NAMES.form3)[0].fields;
          this._formSaveSvc.saveForm3DataExternal(formFields, this._masterListSvc, this._form3Svc, this.demandType);
        }
        if (this.formIsDirty[_FORM_NAMES.form4]) {
          formFields = this.formFields.filter(f => f.formName === _FORM_NAMES.form4)[0].fields;
          this._formSaveSvc.saveForm4DataExternal(formFields, this._masterListSvc, this._form4Svc, this.demandType);
        }
        if (this.formIsDirty[_FORM_NAMES.form5]) {
          formFields = this.formFields.filter(f => f.formName === _FORM_NAMES.form5)[0].fields;
          this._formSaveSvc.saveForm5DataExternal(formFields, this._masterListSvc, this._form5Svc, this.demandType);
        }
        if (this.formIsDirty[_FORM_NAMES.form6]) {
          formFields = this.formFields.filter(f => f.formName === _FORM_NAMES.form6)[0].fields;
          this._formSaveSvc.saveForm6DataExternal(formFields, this._masterListSvc, this._form6Svc, this.demandType);
        }
      });
    });
  }

  saveStage2DirtyForms(masterId, status) {
    let formFields: any[] = [];
    let masterIdInt = Number(masterId);
    // Saving master status
    this._masterListSvc.getSavedRecord(masterIdInt).subscribe((mdata: MasterListModel) => {
      mdata.FormStatus = status;
      // Saving stage also
      mdata.Stage = this.currentStage;
      this._masterListSvc.updateData(mdata, masterIdInt).subscribe(data => {
        // Show success message
        this.isFormSubmitted = true;
        this.showFormSubmitMsg = true;
        // Saving all dirty forms
        if (this.formIsDirty[_FORM_NAMES.form7]) {
          formFields = this.formFields.filter(f => f.formName === _FORM_NAMES.form7)[0].fields;
          this._formSaveSvc.saveForm7DataExternal(formFields, this._masterListSvc, this._form7Svc, this.demandType);
        }
      });
    });
  }

  saveMasterStatus(status: string) {
    let masterId = localStorage.getItem('masterRecordId');

    if (masterId && masterId.length > 0) {
      if (this.currentStage === _FORM_STAGES.stage1) {
        this.saveStage1DirtyForms(masterId, status);
      }
      else if (this.currentStage === _FORM_STAGES.stage2) {
        this.saveStage2DirtyForms(masterId, status);
      }
    }
    else {
      // Save master record first
      let newMasterRecord: MasterListModel = new MasterListModel();
      newMasterRecord.Form2DemandListLookupId = null;
      newMasterRecord.Form3DemandListLookupId = null;
      newMasterRecord.Form4DemandListLookupId = null;
      newMasterRecord.Form5DemandListLookupId = null;
      newMasterRecord.Form6DemandListLookupId = null;
      newMasterRecord.Form7DemandListLookupId = null;
      newMasterRecord.DemandType = this.demandType;
      newMasterRecord.FormStatus = _FORM_STATUS.inProgress;
      newMasterRecord.Stage = this.currentStage;

      this._masterListSvc.saveData(newMasterRecord).subscribe(mdata => {
        localStorage.setItem('masterRecordId', mdata.data.Id);
        if (this.currentStage === _FORM_STAGES.stage1) {
          this.saveStage1DirtyForms(mdata.data.Id, status);
        }
        else if (this.currentStage === _FORM_STAGES.stage2) {
          this.saveStage2DirtyForms(mdata.data.Id, status);
        }
      });
    }
  }

  checkIfFormSubmitted() {
    let masterId = localStorage.getItem('masterRecordId');
    if (masterId && masterId.length > 0) {
      let masterIdInt = Number(masterId);
      this._masterListSvc.getSavedRecord(masterIdInt).subscribe((mdata: MasterListModel) => {
        this.currentStage = _FORM_STAGES.stage1;
        if (mdata.Stage === _FORM_STAGES.stage1 && mdata.FormStatus === _FORM_STATUS.approved) {
          this.currentStage = _FORM_STAGES.stage2;
        }
        else if (mdata.Stage === _FORM_STAGES.stage2) {
          this.currentStage = _FORM_STAGES.stage2;
        }
        this.setupFormsAndFields(mdata.DemandType, mdata.FormStatus, this.currentStage);
        this.changeDetector.detectChanges();
      });
    }
  }

  routeToUrl() {
    this.router.navigate(['./NewDemandS2']);
  }

  redirectToHome() {
    this.router.navigateByUrl('/appHome');
  }

  saveClick() {

    if (this.selectedFormId === "Form2") {
      this.form2Instance.saveFormData();
    }


    else if (this.selectedFormId === "Form3") {
      this.form3Instance.saveFormData();
    }

    else if (this.selectedFormId === "Form4") {
      this.form4Instance.saveFormData();
    }
    else if (this.selectedFormId === "Form5") {
      this.form5Instance.saveFormData();
    }

    else if (this.selectedFormId === "Form6") {
      this.form6Instance.saveFormData();
    }

    else if (this.selectedFormId === "Form7") {
      this.form7Instance.saveFormData();
    }



  }

  formSaved(formId: string) {
    this.formIsDirty[formId] = false;
    this.isDataSaved = true;
  }

  saveMasterRecordAssignedTo() {
    this.isAssignedToSuccess = false;
    if (localStorage.getItem('masterRecordId') && localStorage.getItem('masterRecordId').length > 0) {
      let masterId: number = Number(localStorage.getItem('masterRecordId'));
      if (masterId > 0) {
        this._masterListSvc.getSavedRecord(masterId).subscribe((masterData: MasterListModel) => {
          // Success
          masterData.AssignedToId = Number(this.assignedToUserId);
          masterData.AssignedToStringId = this.assignedToUserId.toString();
          this._masterListSvc.updateData(masterData, masterId).subscribe((result) => {
            // Success
            this.isAssignedToSuccess = true;
          });
        });
      }
      else {
        let newMasterRecord: MasterListModel = new MasterListModel();
        newMasterRecord.Form2DemandListLookupId = null;
        newMasterRecord.Form3DemandListLookupId = null;
        newMasterRecord.Form4DemandListLookupId = null;
        newMasterRecord.Form5DemandListLookupId = null;
        newMasterRecord.Form6DemandListLookupId = null;
        newMasterRecord.DemandType = this.demandType;

        this._masterListSvc.saveData(newMasterRecord).subscribe(mdata => {
          // Handle Success
          localStorage.setItem('masterRecordId', mdata.data.Id);
          // Handle Success
          mdata.data.AssignedToId = Number(this.assignedToUserId);
          mdata.data.AssignedToStringId = this.assignedToUserId.toString();
          this._masterListSvc.updateData(mdata.data, mdata.data.Id).subscribe((result) => {
            // Success
            this.isAssignedToSuccess = true;
          });
        });
      }
    }
    else {
      let newMasterRecord: MasterListModel = new MasterListModel();
      newMasterRecord.Form2DemandListLookupId = null;
      newMasterRecord.Form3DemandListLookupId = null;
      newMasterRecord.Form4DemandListLookupId = null;
      newMasterRecord.Form5DemandListLookupId = null;
      newMasterRecord.Form6DemandListLookupId = null;
      newMasterRecord.DemandType = this.demandType;

      this._masterListSvc.saveData(newMasterRecord).subscribe(mdata => {
        // Handle Success
        localStorage.setItem('masterRecordId', mdata.data.Id);
        // Handle Success
        mdata.data.AssignedToId = Number(this.assignedToUserId);
        mdata.data.AssignedToStringId = this.assignedToUserId.toString();
        this._masterListSvc.updateData(mdata.data, mdata.data.Id).subscribe((result) => {
          // Success
          this.isAssignedToSuccess = true;
        });
      });
    }
  }
}
