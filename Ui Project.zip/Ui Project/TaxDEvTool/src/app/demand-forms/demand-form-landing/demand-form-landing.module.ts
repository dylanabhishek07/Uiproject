import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { FormTabModule } from '../../form-tab/form-tab.module';
import { FormModule } from '../forms/form.module';
import { DemandFormLandingS1Component } from './demand-form-landing-s1.component';
import { DemandFormLandingS2Component } from './demand-form-landing-s2.component';
import { AutocompleteInputModule } from '../../Common/ey-autocomplete-input/ey-autocomplete-input.module';

@NgModule({
  declarations: [
    DemandFormLandingS1Component,
    DemandFormLandingS2Component
  ],
  imports: [
    BrowserModule,
    FormTabModule,
    FormModule,
    AutocompleteInputModule
  ],
  providers: []
})
export class DemandFormLandingModule { }
