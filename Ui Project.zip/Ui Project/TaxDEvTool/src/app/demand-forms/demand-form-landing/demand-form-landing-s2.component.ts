import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { from } from 'rxjs';
import {_DEFAULT_FORM} from '../../Models/form-schema';
import {_DEFAULT_FIELDS} from '../../Models/form-fields';
import {_FORM_NAMES} from '../../Models/form-names';

@Component({
  selector: 'demand-form-landing-s2',
  templateUrl: './demand-form-landing-s2.component.html',
  encapsulation: ViewEncapsulation.None
})
export class DemandFormLandingS2Component implements OnInit {
  selectedFormId: string = _FORM_NAMES.form7;
  forms: any [] = [];
  formFields: any[] = [];  
  form2Fields: any[] = [];
  form3Fields: any[] = [];
  form4Fields: any[] = [];
  form5Fields: any[] = [];
  form7Fields: any[] = [];
  formNames: any = _FORM_NAMES;
  ngOnInit(){
    this.forms = _DEFAULT_FORM.stage1;
    this.formFields = _DEFAULT_FIELDS.stage1;
  
    this.form7Fields = this.formFields.filter(f=>f.formName===_FORM_NAMES.form7)[0].fields;
  }
  
  onFormSelectChanged(formId){
    this.selectedFormId = formId;
  }

  onFormValueChanges(fieldsInfo: any[], formId: string){
    if(fieldsInfo.length>0){
      let currentForm = this.formFields.filter(form=>form.formName===formId);
      let currentFormSchema = this.forms.filter(form=>form.formId===formId);
      if(currentForm!=null && currentForm.length>0 && currentFormSchema!=null && currentFormSchema.length>0){
        currentForm[0]["fields"] = [...fieldsInfo];
        
        currentFormSchema[0].childFormDetails.forEach(c=>{
          c.childFormStatus = "notstarted";
          let formSetupValue = currentForm[0]["fields"].filter(f=>f.mappedToChild===c.childId);
          let mandatoryFields = formSetupValue.filter(f=>f.isMandatory);
          let mandatoryFieldsWithValue = formSetupValue.filter(f=>f.isMandatory && f.value.length>0);

          let validValues = formSetupValue.filter(f=>f.value.length>0).length;
          let blankValues = formSetupValue.filter(f=>f.value.length===0).length;

          if(mandatoryFieldsWithValue && mandatoryFields.length===mandatoryFieldsWithValue.length){
            c.childFormStatus = "completed";
          }
          if(validValues>0 && blankValues>0){
            c.childFormStatus = "inprogress";
          }
        });
      }
    }
  }
}
