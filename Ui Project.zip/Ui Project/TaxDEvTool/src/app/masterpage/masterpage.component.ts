import { Component, OnInit } from '@angular/core';
import { User } from '../Models/user';
import { SpapiservicesService } from '../Services/spapiservices.service';
import { UserServiceService } from '../Services/user-service.service.spec';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-masterpage',
  templateUrl: './masterpage.component.html',
  styleUrls: ['./masterpage.component.css']
})
export class MasterpageComponent implements OnInit {
  
  
  userdisplayname = "";
  userphotosrc = "";
  toggleAppDropdown = false;
  toggleProfileDropdown = false;
  _userInfo = new User;

  public clientName: any;
  
  constructor(private sp: SpapiservicesService, private UserService: UserServiceService ) { }

  ngOnInit() {
    this.clientName = 'TAX LAB Demand Management Tool';

    if (window.location.href.indexOf("localhost") == -1) {
      this.sp.getCurrentUserInfo().subscribe({
        next: currentUserinfo => {
          this._userInfo.id = currentUserinfo.d.Id;
          this._userInfo.displayName = currentUserinfo.d.Title;
          this._userInfo.userphotosrc = environment.sp_url + "_layouts/15/userphoto.aspx?size=S&accountname=" + currentUserinfo.Email;
          this._userInfo.emailId = currentUserinfo.d.Email;
          this.UserService.setBehaviorView(this._userInfo);
        }
      });
    }
    else {
      this._userInfo.id = '17';
      this._userInfo.displayName = 'Anjana Sudev';
      this._userInfo.userphotosrc = '';
      this._userInfo.emailId = 'Anjana.Sudev@gds.ey.com';
      this.UserService.setBehaviorView(this._userInfo);
    }
  }

 

}
