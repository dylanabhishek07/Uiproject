export const TaxLabNav = {
  "Home": "/home",
  "New Demand": "/NewDemand",
}