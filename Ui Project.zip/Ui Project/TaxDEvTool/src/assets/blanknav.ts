export const BLANKNAV = {
  "Home": "/home",
}