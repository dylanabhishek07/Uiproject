import { HttpClient } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MsalGuardConfiguration, MsalService, MSAL_GUARD_CONFIG } from '@azure/msal-angular';
import { AuthenticationResult, PopupRequest } from '@azure/msal-browser';
import { currentUserModel } from 'src/app/models/LandingPageModel/currentUserModel';
import { AppSettings } from 'src/app/services/CommonService/app-settings';
import { workspaceCommonService } from 'src/app/services/CommonService/workspaceCommonService';

@Component({
  selector: 'app-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.scss']
})
export class LoginPageComponent implements OnInit {

  constructor(private commonService: workspaceCommonService, private appSettings: AppSettings, private msalService : MsalService, @Inject(MSAL_GUARD_CONFIG) private msalGuardConfig: MsalGuardConfiguration, private route : Router) {  }

;
  loggedInUserName: string|undefined;
  ngOnInit(): void {
    if (this.msalService.instance.getAllAccounts().length > 0)
    {
      this.appSettings.isUserLoggedIn.next(false);
      this.loggedInUserName='';
        this.msalService.logout();

        setTimeout(() => {
        this.route.navigate(['/login']);
      }, 3000);
      
    }
  }

  login() {
    // this.http.get("https://graph.microsoft.com/v1.0/me")
    // .subscribe(profile => {
    //   console.log(profile);
    // });
    this.msalService.loginPopup({ ...this.msalGuardConfig.authRequest } as PopupRequest).subscribe((response :AuthenticationResult)=>{
      this.msalService.instance.setActiveAccount(response.account);
      this.commonService.currentUser = response.account==null ? new currentUserModel() : response.account;
      console.log(this.msalService.instance.getActiveAccount());
      let userName = this.msalService.instance.getActiveAccount()?.name;      
      //to be removed if we get first name and last name in claims
      //start
      this.appSettings.loggedInUserName = userName != undefined ? userName.replace(/\./g,' ').replace(/\d+/g, '') : undefined;
      //end
      this.appSettings.isUserLoggedIn.next(true);
      this.route.navigate(['/landing']);
    })
  }
}
