import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AnnexePreviewComponent } from './annexe-preview.component';

describe('AnnexePreviewComponent', () => {
  let component: AnnexePreviewComponent;
  let fixture: ComponentFixture<AnnexePreviewComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AnnexePreviewComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AnnexePreviewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
