import { Location } from '@angular/common';
import { AfterViewInit, Component, NgZone, OnDestroy, OnInit, Renderer2, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { RowClassArgs } from '@progress/kendo-angular-grid';
import { process, State } from '@progress/kendo-data-query';
import { NgxSpinnerService } from 'ngx-spinner';
import { fromEvent, Subscription } from 'rxjs';
import { take, tap } from 'rxjs/operators';
import { AnnexePreviewAdditionalColumns } from 'src/app/columnConfiguration/annexePreviewAdditionalColumns';
import { columnConfig } from 'src/app/columnConfiguration/columnInterface';
import { workspaceStatusEnum } from 'src/app/enums/workspaceStatus';
import { AnnexeAdditionalColumnsModel } from 'src/app/models/AnnexePreviewModel/annexeAdditionalColumnsModel';
import { AnnexePreviewDistributionItemsModel } from 'src/app/models/AnnexePreviewModel/annexePreviewDistributionItemsModel';
import { AnnexePreviewDistributionModel } from 'src/app/models/AnnexePreviewModel/annexePreviewDistributionModel';
import { AnnexePreviewModel } from 'src/app/models/AnnexePreviewModel/annexePreviewModel';
import { ModifyWorkspaceStatus } from 'src/app/models/AnnexePreviewModel/modifyWorkspaceStatus';
import { SaveAnnexePreviewDataModel } from 'src/app/models/AnnexePreviewModel/saveAnnexePreviewDataModel';
import { SaveAnnexePreviewDistributionItemsModel } from 'src/app/models/AnnexePreviewModel/saveAnnexePreviewDistributionItemsModel';
import { SaveAnnexePreviewDistributionModel } from 'src/app/models/AnnexePreviewModel/saveAnnexePreviewDistributionModel';
import { SaveAnnexePreviewModel } from 'src/app/models/AnnexePreviewModel/saveAnnexePreviewModel';
import { AnnexePreviewService } from 'src/app/services/AnnexePreview/annexePreviewServices';
import { AppSettings } from 'src/app/services/CommonService/app-settings';
import { workspaceCommonService } from 'src/app/services/CommonService/workspaceCommonService';

const tableRow = (node:any) => node.tagName.toLowerCase() === "tr";

const closest = (node:any, predicate:any) => {
  while (node && !predicate(node)) {
    node = node.parentNode;
  }

  return node;
};
@Component({
  selector: 'app-annexe-preview',
  templateUrl: './annexe-preview.component.html',
  styleUrls: ['./annexe-preview.component.scss'],
  providers: [AnnexePreviewService],
  encapsulation: ViewEncapsulation.None
})
export class AnnexePreviewComponent implements OnInit, AfterViewInit, OnDestroy {

  constructor(private wrkspacecommonservice: workspaceCommonService, private annexePreviewService: AnnexePreviewService, private appSettings: AppSettings, private spinner: NgxSpinnerService, private _location: Location, private renderer: Renderer2, private zone: NgZone, private router: Router) { }

  wrkspaceMasterGuid: string = "";
  annexePreviewData = new AnnexePreviewModel();
  annexPreviewDistributionDataSource: AnnexePreviewDistributionModel[] = [];
  annexPreviewDistributionItemDataSource: AnnexePreviewDistributionItemsModel[] = [];
  saveData: AnnexePreviewDistributionModel[] = [];
  saveAnnexePreviewDataReqModel: SaveAnnexePreviewDataModel[] = [];
  currentRowToUpdate: SaveAnnexePreviewDistributionItemsModel = new SaveAnnexePreviewDistributionItemsModel();
  rowsToUpdate: SaveAnnexePreviewDistributionItemsModel[] = [];
  annexePreviewAdditionalColumns: columnConfig[] = AnnexePreviewAdditionalColumns;
  selection: any = [];
  columns: Array<string> = [];
  defaultColumnKeys: Array<string> = ['workSpaceRowGID','productID','serviceDescription','invoiceFee','feeText','currency'];
  selectedColumnKeys: Array<string> = [];
  columnKeysToSaveData: Array<string> = [];
  additionalColumnList = this.annexePreviewAdditionalColumns;
  updatedDataObj:AnnexePreviewDistributionModel[] = [];
  additionalColumns: AnnexeAdditionalColumnsModel[] = []; 

  saveAnnexePreviewDistributionDataSource: SaveAnnexePreviewDistributionModel[] = [];
  message: string = '';

  public state: any = {};
  processedData: any;
  gridDataSrc: Array<any> = [];
  private currentSubscription!: Subscription;
  gridIndex: number = 0;
  openApprovalConfirmation: boolean = false;

  workspaceStatusId: number = 0;
  isInvoiceReviewed: boolean = false;
  wrkspaceStatusObj = workspaceStatusEnum;
  
  ngOnInit(): void {
    this.wrkspaceMasterGuid = this.wrkspacecommonservice.workspaceMasterGuid;
    this.workspaceStatusId = this.wrkspacecommonservice.workspaceStatusId;
    this.getAnnexePreviewData();
    this.annexePreviewAdditionalColumns.forEach(item => {
      this.columns.push(item.title);
    })
    this.state = {
      skip: 0,
      take: 10,
    };
  }

  public ngAfterViewInit(): void {
    this.currentSubscription = this.handleDragAndDrop();
  }

  public ngOnDestroy(): void {
    this.currentSubscription.unsubscribe();
  }

  public dataStateChange(state: State): void {
    this.state = state;
    this.gridDataSrc[this.gridIndex] = process(this.annexPreviewDistributionDataSource[this.gridIndex].annexPreviewDistributionItems, this.state);
    this.currentSubscription.unsubscribe();
    this.zone.onStable
      .pipe(take(1))
      .subscribe(() => (this.currentSubscription = this.handleDragAndDrop()));
    

  }

  public rowCallback(context: RowClassArgs) {
    return {
      dragging: context.dataItem.dragging,
    };
  }

  getAdditionalColumns() {
    this.annexePreviewService.getAnnexOptionalColumns().subscribe((data: AnnexeAdditionalColumnsModel[]) => {
      this.additionalColumns = data;
      this.additionalColumns.filter(item => this.annexePreviewData.selectedOptionalColumnGIds.includes(item.columnGId)).forEach(el => this.selection.push(el.columnName));
    })
  }
  getAnnexePreviewData () {
    this.message = 'Fetching Annexe Preview Data.Please Wait...';
    this.spinner.show();
     this.annexePreviewService.getAnnexePreviewData(this.wrkspaceMasterGuid).subscribe((data:AnnexePreviewModel) => {
      this.annexePreviewData = data;
      this.annexPreviewDistributionDataSource = this.annexePreviewData.annexPreviewDistribution;
      this.annexPreviewDistributionDataSource.forEach(item => {
      item.annexPreviewDistributionItems.sort((a,b) => a.rowSequenceID - b.rowSequenceID)
        let annexePreviewDistributionItemsModel = new AnnexePreviewDistributionItemsModel();
        annexePreviewDistributionItemsModel.invoiceFee = item.totalFee;
        annexePreviewDistributionItemsModel.serviceDescription = "Total"
        item.annexPreviewDistributionItems.push(annexePreviewDistributionItemsModel);
        this.processedData = process(item.annexPreviewDistributionItems,this.state);
        this.processedData.entityId = item.billingEntityId;
        this.gridDataSrc.push(this.processedData)
      })
      
      this.getAdditionalColumns();
          this.annexPreviewDistributionDataSource.map((item: AnnexePreviewDistributionModel) => {
            let annexeDistributionModel = new SaveAnnexePreviewDistributionModel();
            annexeDistributionModel.billingEntityId = item.billingEntityId;
            annexeDistributionModel.billingEntityName = item.billingEntityName == null? 'NameNotInitialized' : item.billingEntityName;
            annexeDistributionModel.totalFee = item.totalFee;
            item.annexPreviewDistributionItems.forEach((element,index) => {
              let annexeDistributionItemModel = new SaveAnnexePreviewDistributionItemsModel();
                annexeDistributionItemModel.costCenter =  element.costCenter;
                annexeDistributionItemModel.createdBy = element.gId == null ? this.appSettings.loggedInUserName : element.createdBy;
                annexeDistributionItemModel.currency = element.currency;
                annexeDistributionItemModel.employee = element.employee;
                annexeDistributionItemModel.feeText = element.feeText;
                annexeDistributionItemModel.gbtRef = element.gbtRef;
                annexeDistributionItemModel.gbtStatus = element.gbtStatus;
                annexeDistributionItemModel.gid = element.gId;
                annexeDistributionItemModel.hours = element.hours;
                annexeDistributionItemModel.invoiceFee = element.invoiceFee;
                annexeDistributionItemModel.modifiedBy = element.modifiedBy;
                annexeDistributionItemModel.oosnr = element.oosnr;
                annexeDistributionItemModel.product = element.product;
                annexeDistributionItemModel.productID = element.productID;
                annexeDistributionItemModel.rowSequenceID = element.gId == null ? index + 1 : element.rowSequenceID;
                annexeDistributionItemModel.serviceDescription = element.serviceDescription;
                annexeDistributionItemModel.workSpaceRowGID = element.workSpaceRowGID;
              annexeDistributionModel.annexPreviewDistributionItems.push(annexeDistributionItemModel)
            })
            
            this.saveAnnexePreviewDistributionDataSource.push(annexeDistributionModel);
          })
          this.saveAnnexePreviewDistributionDataSource.forEach(item => {
            let index = item.annexPreviewDistributionItems.findIndex(element => element.serviceDescription === 'Total')
            item.annexPreviewDistributionItems.splice(index,1)
          })
          console.log(this.saveAnnexePreviewDistributionDataSource)
          this.dataStateChange(this.state);
          this.spinner.hide();
    }, error => {
      this.spinner.hide();
    }) 
  }

  onFeeTextUpdate(data: any, _event: any, entityIndex: number, rowIndex: number) {
    let updatedFeeTextValue = _event.target.value.trim();
    this.currentRowToUpdate = this.saveAnnexePreviewDistributionDataSource[entityIndex].annexPreviewDistributionItems[rowIndex];

    let saveAnnexeDistributionItemModel = new SaveAnnexePreviewDistributionItemsModel();
    Object.assign(saveAnnexeDistributionItemModel, this.currentRowToUpdate);

    console.log(saveAnnexeDistributionItemModel)
    if(saveAnnexeDistributionItemModel.gid != null) {
      if(saveAnnexeDistributionItemModel.createdBy == '' || saveAnnexeDistributionItemModel.createdBy == null || saveAnnexeDistributionItemModel.createdBy == undefined) {
        saveAnnexeDistributionItemModel.createdBy = this.appSettings.loggedInUserName;
      }
      else {
        saveAnnexeDistributionItemModel.modifiedBy = this.appSettings.loggedInUserName;
      }
    }

    let updateValue = this.validateData(this.currentRowToUpdate.feeText, updatedFeeTextValue);
    saveAnnexeDistributionItemModel.feeText = updatedFeeTextValue == '' ? null : updatedFeeTextValue;

    if(updateValue) {
      if(this.rowsToUpdate.filter(item => item.workSpaceRowGID === this.currentRowToUpdate.workSpaceRowGID).length > 0){
        const index = this.rowsToUpdate.findIndex(obj => {
          return obj.workSpaceRowGID == this.currentRowToUpdate.workSpaceRowGID;
        })
        this.rowsToUpdate[index].feeText = updatedFeeTextValue == '' ? null : updatedFeeTextValue;
      }
      else {
        this.rowsToUpdate.push(saveAnnexeDistributionItemModel);
      }
    }
    else {
      this.rowsToUpdate = this.rowsToUpdate.filter(item => item.workSpaceRowGID != this.currentRowToUpdate.workSpaceRowGID);
    }
    if(this.rowsToUpdate.length > 0) {
      this.gridDataSrc.forEach(item => {
        item.data.forEach((element: any) => {
          this.rowsToUpdate.forEach(obj => {
            if(element.gId == obj.gid) {
              element.feeText = obj.feeText;
            }
          })
        })
      })
    }
    else {
      this.onDrop(true);
    }
    console.log(this.rowsToUpdate)
  } 

  validateData(existingFeeText: string | null, updatedFeeText: string) {
    if(existingFeeText == null && updatedFeeText == '')
      return false;
    if(existingFeeText == updatedFeeText)
      return false
    if(existingFeeText != null && updatedFeeText == '') {
      return true;
    }
    return true;
  }

  saveAnnexePreviewFeeData() {
    this.message = "Saving Annexe Preview Fee Data.Please Wait...";
    this.spinner.show();
    console.log(this.selection)
    let saveAnnexePreviewModel: SaveAnnexePreviewModel = new SaveAnnexePreviewModel();
    saveAnnexePreviewModel.workSpaceMasterGid = this.annexePreviewData.workSpaceMasterGid;
    this.additionalColumns.filter(item => this.selection.includes(item.columnName)).forEach(el => saveAnnexePreviewModel.selectedColumnGIds.push(el.columnGId));
    this.modifySaveDataObject();
    saveAnnexePreviewModel.annexPreviewDistribution = this.saveAnnexePreviewDistributionDataSource;

     this.annexePreviewService.saveAnnexePreviewFeeData(saveAnnexePreviewModel).subscribe(() => {
      this.getAnnexePreviewData();
      this.spinner.hide();
      this.saveAnnexePreviewDistributionDataSource = [];
      this.gridDataSrc = [];
      this.selection = [];
    }, error => {
      this.spinner.hide();
    })
    console.log(saveAnnexePreviewModel)
  }

  
  modifySaveDataObject() {
    this.columnKeysToSaveData = [];
    this.selectedColumnKeys = [];
    this.updatedDataObj = [];

    if(this.rowsToUpdate.length > 0) {
      this.rowsToUpdate.forEach(item => {
        this.saveAnnexePreviewDistributionDataSource.forEach(element => {
          element.annexPreviewDistributionItems.forEach(el => {
            if(el.workSpaceRowGID === item.workSpaceRowGID) {
              Object.assign(el,item);
            }
          })
        })
      })
    }

    this.additionalColumnList = this.annexePreviewAdditionalColumns;
    this.additionalColumnList = this.additionalColumnList.filter(item => !this.selection.includes(item.title))

    this.additionalColumnList.forEach(item => {
        this.saveAnnexePreviewDistributionDataSource.forEach(element => {
          element.annexPreviewDistributionItems.forEach((el:any) => {
            el[item.field] = null;
          })       
        })
    })

    console.log(this.saveAnnexePreviewDistributionDataSource)

/*      const newSaveDataObj = (array:any) => array.map((o:any) => this.columnKeysToSaveData.reduce((acc:any, curr) => {
       console.log(acc, "===>", curr)
      acc[curr] = o[curr];
      return acc;
    }, {}));

    this.saveAnnexePreviewDistributionDataSource.forEach(item => {
      item.annexPreviewDistributionItems = newSaveDataObj(item.annexPreviewDistributionItems);
    }) */


    this.rowsToUpdate = [];
    //console.log(this.saveAnnexePreviewDistributionDataSource)
  }

  backButton() {
    this._location.back();
  }

  isHidden(data:any) {
    if(data.serviceDescription === 'Total')
      return true;
    return false;
  }

  approve(action: string) {
    let modifyWorkspaceModel: ModifyWorkspaceStatus = new ModifyWorkspaceStatus();
    this.message = action === 'review' ? 'Reviewing Annexe Preview Data.Please Wait...' : 'Approving Annexe Preview Data.Please Wait...';
    this.spinner.show();
    modifyWorkspaceModel.workSpaceMasterGId = this.wrkspaceMasterGuid;
    modifyWorkspaceModel.approvedBy = action === 'review' ? null : this.appSettings.loggedInUserName;
    modifyWorkspaceModel.workSpaceStatus = action === 'review'? workspaceStatusEnum.InReview : workspaceStatusEnum.InvoiceInProgress;
    modifyWorkspaceModel.modifiedBy = this.appSettings.loggedInUserName;

    this.annexePreviewService.modifyWorkspaceStatus(modifyWorkspaceModel).subscribe(data => {
      this.isInvoiceReviewed = data;
      this.spinner.hide();
      if(action === 'approve') {
        this.router.navigate(['/landing']);
      }
    }, error => {
      this.spinner.hide();
    })
  }

  private handleDragAndDrop(): Subscription {
    const sub = new Subscription(() => {});
    let draggedItemIndex: any;

    const tableRows = Array.from(document.querySelectorAll(".k-grid tr"));
    tableRows.forEach((item) => {
      this.renderer.setAttribute(item, "draggable", "true");
      const dragStart = fromEvent<DragEvent>(item, "dragstart");
      const dragOver = fromEvent(item, "dragover");
      const dragEnd = fromEvent(item, "dragend");

      sub.add(
        dragStart
          .pipe(
            tap(({ dataTransfer }) => {
              try {
                const dragImgEl = document.createElement("span");
                dragImgEl.setAttribute(
                  "style",
                  "position: absolute; display: block; top: 0; left: 0; width: 0; height: 0;"
                );
                document.body.appendChild(dragImgEl);
                dataTransfer!.setDragImage(dragImgEl, 0, 0);
              } catch (err) {
                // IE doesn't support setDragImage
              }
              try {
                // Firefox won't drag without setting data
                dataTransfer!.setData("application/json", '');
              } catch (err) {
                // IE doesn't support MIME types in setData
              }
            })
          )
          .subscribe(({ target }) => {
            const row: HTMLTableRowElement = <HTMLTableRowElement>target;
            draggedItemIndex = row.rowIndex;
            const dataItem = this.gridDataSrc[this.gridIndex].data[draggedItemIndex];
            console.log(dataItem)
            if(dataItem.serviceDescription != 'Total')
              dataItem.dragging = true;
          })
      );

      sub.add(
        dragOver.subscribe((e: any) => {
          e.preventDefault();
          const dataItem = this.gridDataSrc[this.gridIndex].data.splice(draggedItemIndex, 1)[0];
          const dropIndex = closest(e.target, tableRow).rowIndex;
          const dropItem = this.gridDataSrc[this.gridIndex].data[dropIndex];

          draggedItemIndex = dropIndex;
          this.zone.run(() =>
            this.gridDataSrc[this.gridIndex].data.splice(dropIndex, 0, dataItem)
          );
        })
      );

      sub.add(
        dragEnd.subscribe((e: any) => {
          e.preventDefault();
          const dataItem = this.gridDataSrc[this.gridIndex].data[draggedItemIndex];
          dataItem.dragging = false;
        })
      );
    });
    console.log("updated data ",this.gridDataSrc)
    return sub;
  }
  onDragStart(index: number) {
    this.gridIndex = index;
  }

  onDrop(updateFeeText?: boolean) {
    this.gridDataSrc.forEach((item) => {
      item.data.forEach((element:any,index:number) => {
        element.rowSequenceID = index + 1;
      })
    })

    this.saveAnnexePreviewDistributionDataSource.forEach(item => {
      item.annexPreviewDistributionItems.forEach(element => {
        this.gridDataSrc.forEach(el => {
          el.data.forEach((obj:any) => {
            if(obj.gId == element.gid) {
              if(updateFeeText)
              {
                obj.feeText = element.feeText;
              }
              else {
                element.rowSequenceID = obj.rowSequenceID;
              }
            }
          });
        })
      })
      item.annexPreviewDistributionItems.sort((a,b) => a.rowSequenceID - b.rowSequenceID)
    })
  }
}
