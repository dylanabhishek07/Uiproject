import { Component, OnInit } from '@angular/core';
import { billingPreviewModel } from 'src/app/models/BillingPreviewModel/billingPreviewModel';
import { billingService } from 'src/app/services/BillingPreview/billlingService';
import { billingPreviewColumns } from 'src/app/columnConfiguration/billingPreviewColumn';
import { DataTypeEnum } from 'src/app/enums/DataTypeEnum';
import { workspaceCommonService } from 'src/app/services/CommonService/workspaceCommonService';
import { billingPreviewItem, complexData } from 'src/app/data/billingPreviewItem';
import { Location } from '@angular/common';
import { wrkspaceCommonModal } from 'src/app/models/WorkSpaceModel/wrkspaceCommonModel';
@Component({
  selector: 'app-preview',
  templateUrl: './preview.component.html',
  styleUrls: ['./preview.component.scss'],
  providers: [billingService]
})
export class PreviewComponent implements OnInit {

  public billableColumns = billingPreviewColumns;
  billableItemPreview: billingPreviewModel[] = [];

  additonalBillingItemPreview: billingPreviewModel[] = [];
  nonBillableHoursPreview: billingPreviewModel[] = [];
  adhocPreview: billingPreviewModel[] = [];
  uncodePreview: billingPreviewModel[] = [];
  expensesPreview: billingPreviewModel[] = [];

  constructor(private billingservice: billingService, private globalservice: workspaceCommonService, private _location: Location) { }

  ngOnInit(): void {

    let billpreviewData: wrkspaceCommonModal[] = this.globalservice.AllWorkSpaceCategoryData;
    console.log(this.globalservice.AllWorkSpaceCategoryData);
    // let dataForBilling = complexData;
    this.billableItemPreview = this.populateBillPreviewCategoryWise(billpreviewData, DataTypeEnum.Billable);
    this.additonalBillingItemPreview = this.populateBillPreviewCategoryWise(billpreviewData, DataTypeEnum.AdditionalBillingOppertunity);
    this.nonBillableHoursPreview = this.populateBillPreviewCategoryWise(billpreviewData, DataTypeEnum.NonBillable);
    this.adhocPreview = this.populateBillPreviewCategoryWise(billpreviewData, DataTypeEnum.Adhoc);
    this.uncodePreview = this.populateBillPreviewCategoryWise(billpreviewData, DataTypeEnum.Uncoded);
    this.expensesPreview = this.populateBillPreviewCategoryWise(billpreviewData, DataTypeEnum.Expense);

  }

  populateBillPreviewCategoryWise(wrkspacedata: wrkspaceCommonModal[], dataTypeEnum: DataTypeEnum) {
    
    return wrkspacedata.filter((i: wrkspaceCommonModal) => i.dataType === dataTypeEnum).map((i: wrkspaceCommonModal) =>
    ({
      Fee: (i.adjustedInvoiceFee) != 0  ? i.adjustedInvoiceFee : i.invoiceFee,
      Currency: (i.adjustedCurrency) != "" && (i.adjustedCurrency) != null ? i.adjustedCurrency : i.currency,
      Description: (i.adjustedDescription) != "" && (i.adjustedDescription) != null ? i.adjustedDescription : i.serviceDescription,
      DataType: i.dataType
    })
    );
  }

  backToWorkspace() {
    this._location.back();
  }
}
