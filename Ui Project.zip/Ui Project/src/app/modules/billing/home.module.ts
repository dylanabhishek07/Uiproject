import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InvoicesComponent } from './invoices/invoices/invoices.component';
import { LandingComponent } from './landing/landing/landing.component';
import { PreviewComponent } from './preview/preview/preview.component';
import { SummaryComponent } from './summary/summary/summary.component';
import { WorkspaceComponent } from './workspace/workspace/workspace.component';
import { AppRoutingModule } from 'src/app/app-routing.module';
import { RouterModule } from '@angular/router';
import { TimeDetailsComponent } from './timeDetails/time-details/time-details.component';
import { FormsModule } from '@angular/forms';
import { BrowserModule } from '@angular/platform-browser';
import {SharedModule }  from 'src/app/shared/shared.module'
import { GridModule } from '@progress/kendo-angular-grid';
import { AnnexePreviewComponent } from './annexe-preview/annexe-preview.component';
import { InvoiceDetailsComponent } from './invoice-details/invoice-details/invoice-details.component';
import { EAFCalculationComponent } from './eafcalculation/eafcalculation.component';
import { FeeSharingTypeComponent } from './fee-sharing-type/fee-sharing-type.component';


@NgModule({
  declarations: [
    InvoicesComponent,
    LandingComponent,
    PreviewComponent,
    SummaryComponent,
    WorkspaceComponent,
    AppRoutingModule,
    TimeDetailsComponent,
    RouterModule,
    CommonModule,
    GridModule,
    AnnexePreviewComponent,
    InvoiceDetailsComponent,
    EAFCalculationComponent
    
    
  ],
  imports: [
    SharedModule,
    CommonModule,
    AppRoutingModule,
    RouterModule,
    FormsModule,
    GridModule
    
  ],
  exports:[
    InvoicesComponent,
    LandingComponent,
    PreviewComponent,
    SummaryComponent,
    WorkspaceComponent,
    TimeDetailsComponent,
    AnnexePreviewComponent
  ]
})
export class HomeModule { }
