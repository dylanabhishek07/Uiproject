import { ChangeDetectorRef, Component, OnInit, ViewEncapsulation } from '@angular/core';
import { workspaceService } from 'src/app/services/WorkSpace/workspaceService';
import { workspaceCommonService } from 'src/app/services/CommonService/workspaceCommonService';
import { FormGroup, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { wrkSpaceSpecificTneData } from 'src/app/models/WorkSpaceModel/wrkSpaceSpecificTneData';
import { DataTypeEnum } from 'src/app/enums/DataTypeEnum';
import { NgxSpinnerService } from "ngx-spinner";
import { workspaceAdHoc_Uncoded_Columns, workspaceBillableColumns, workspaceExpenseColumn } from 'src/app/columnConfiguration/workspaceColumns';
import { Location } from '@angular/common';
import { columnConfig } from 'src/app/columnConfiguration/columnInterface';
import { complexData } from 'src/app/data/billingPreviewItem';
import { workspaceTrackingModel } from 'src/app/models/WorkSpaceModel/workspaceTrackingModel';
import { billingTimeTrackerModel } from 'src/app/models/BillingPreviewModel/billingTimeTrackerModel';
import { workspaceAdjustedData } from 'src/app/models/WorkSpaceModel/workspaceAdjustedData';
import { wrkspaceCommonModal } from 'src/app/models/WorkSpaceModel/wrkspaceCommonModel';
import { workSpaceUISessionDetails } from 'src/app/models/WorkSpaceModel/workSpaceUISessionDetails';
import { UIStageEnum } from 'src/app/enums/UIStageEnum';
import { sessionService } from 'src/app/services/CommonService/sessionService';
import { AdjustedBillingAction } from 'src/app/data/adjustedBillingItem';
import { clientService } from 'src/app/services/LandingPage/clientService';
import { AppSettings } from 'src/app/services/CommonService/app-settings';
import { Observable } from 'rxjs';
import { workspaceDatasource } from 'src/app/enums/workspaceDataSource';
import { GridDataResult } from '@progress/kendo-angular-grid';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
@Component({
  selector: 'app-workspace',
  templateUrl: './workspace.component.html',
  styleUrls: ['./workspace.component.scss'],
  providers: [workspaceService, clientService],
  encapsulation: ViewEncapsulation.None
})
export class WorkspaceComponent implements OnInit {

 
  
  public pageSize = 5;
  public skip = 0;
  workspaceColumns: columnConfig[] = [];
  workspaceAdhoc_UncodedColumns: columnConfig[] = [];
  workspaceExpenseColumns: columnConfig[] = [];
  adjustedBillingActionDdl: any[] = [];
  formGroup: FormGroup | undefined;
  billableItems: wrkspaceCommonModal[] = [];
  additionalBillingData: wrkspaceCommonModal[] = [];
  nonBillableData: wrkspaceCommonModal[] = [];
  adhocData: wrkspaceCommonModal[] = [];
  uncodedData: wrkspaceCommonModal[] = [];
  expensesData: wrkspaceCommonModal[] = [];
  private editedRowIndex: any;
  wrkspaceadjustedData: workspaceAdjustedData[] = [];
  enumDataTypeWrkspace = DataTypeEnum;
  workspaceUncategorisedData: wrkspaceCommonModal[] = [];
  wrkSpaceUISessionDetails = new workSpaceUISessionDetails(UIStageEnum.None, '', '', '', '', [], []);
  workspaceTrackerData: workspaceTrackingModel = this.wrkspaceCommonService.WorkSpaceTracker;
  workSpaceMasterID: string = this.workspaceTrackerData.workspaceId;
  workSpaceName: string = this.workspaceTrackerData.workSpaceName;
  selectedEnagagementIDs: string = this.workspaceTrackerData.selectedEngagementIDS;
  selectedClientName: string = this.workspaceTrackerData.clientName;
  wrkspaceCommonData = new wrkspaceCommonModal();
  eventGrid: any;

  copywrkSpaceAdjustedData: wrkspaceCommonModal[] = [];
  adjustedBillingEntities: any[] = [];
  readOnly: boolean = false;

  dataSource: any = {};
  constructor(private sessionservice: sessionService, private changeDetector: ChangeDetectorRef, private wrkspaceCommonService: workspaceCommonService, private workspaceSerive: workspaceService, private clientService: clientService, private route: Router, private spinner: NgxSpinnerService, private _location: Location, private appSettings: AppSettings) { }
  ngOnInit(): void {
    this.wrkspaceCommonService.readonly.subscribe(result => {
      console.log('subjectsummary', result);
      this.readOnly = result;
    })

    console.log('subjectWorkspace', this.readOnly);
    let readonly = localStorage.getItem('readonly');
    this.readOnly = (readonly == 'true' || this.readOnly) ? true : false;

    this.workspaceColumns = this.wrkspaceCommonService.WorkspaceColumns;
    this.workspaceAdhoc_UncodedColumns = this.wrkspaceCommonService.WorkspaceAdhoc_UncodedColumns;
    this.workspaceExpenseColumns = this.wrkspaceCommonService.WorkspaceExpenseColumns;
    this.sessionservice.getWorkspaceUIdetails().subscribe((workSpaceUIDetails: workSpaceUISessionDetails) => {
      //Assign Workspace Header Data from Session Object. 
      console.log(workSpaceUIDetails);
      this.wrkSpaceUISessionDetails = (workSpaceUIDetails) ? workSpaceUIDetails : this.wrkSpaceUISessionDetails;
      this.workSpaceMasterID = workSpaceUIDetails.workspaceMasterGid;//Will Check
      this.workSpaceName = workSpaceUIDetails.workspaceName;
      this.selectedEnagagementIDs = workSpaceUIDetails.engagements.join(',');
      this.selectedClientName = workSpaceUIDetails.clientName;

      if (this.wrkspaceCommonService.AllWorkSpaceCategoryData != null && this.wrkspaceCommonService.AllWorkSpaceCategoryData.length > 0) {
        this.populateDataFromCacheMemory();
      }
      else {
        if (workSpaceUIDetails.workspaceMasterGid && workSpaceUIDetails.workspaceMasterGid != '') {

          this.workspaceSerive.getWorkspaceData(workSpaceUIDetails.workspaceMasterGid).subscribe((workSpaceData: wrkspaceCommonModal[]) => {
            this.wrkspaceCommonService.timeDetailsData = [];
            if (workSpaceData != null && workSpaceData.length > 0) {
              console.log(workSpaceData);
              this.workspaceUncategorisedData = workSpaceData;
              this.wrkspaceCommonService.AllWorkSpaceCategoryData = workSpaceData;
              this.populateIndividualCategoryDataSource(this.workspaceUncategorisedData);
              this.spinner.hide();
            }
          }, (error) => {
            // Handle Error
            this.spinner.hide();
            console.log(error);
          })
        }
      }
      this.getClientDetailsWithBillingEntities(workSpaceUIDetails.clientGId);
    }, (error) => {
      // Handle Error
      console.log(error);
    });


    this.adjustedBillingActionDdl = AdjustedBillingAction.filter((item) => item.isVisible == true);
  }

  getClientDetailsWithBillingEntities(clientId: string) {
    this.clientService.getClientDetailsWithBillingEntity(clientId).subscribe((data) => {
      this.adjustedBillingEntities = data.billingEntities;
      this.adjustedBillingEntities.unshift({ "name": "Select", "id": 0 })

    })
    console.log(this.adjustedBillingEntities)
  }

  findAdjustedBillingArrayIndex(value: any, isAdjustedBillingEntity: boolean): number {
    let arrayindex: number = 0;
    if (!isAdjustedBillingEntity) {
      arrayindex = this.adjustedBillingActionDdl.findIndex(item => item.isVisible == true && item.value == value);
    }
    else {
      if (value == null) return 0;
      else {
        arrayindex = this.adjustedBillingEntities.findIndex((item: any) => item.id == value)
      }
    }
    return arrayindex;
  }
  cellClickHandler(_$event: any) {
    let datatype = (this.eventGrid) ? this.eventGrid.dataItem.dataType : _$event.dataItem.dataType;
    let readOnly = localStorage.getItem('readonly');

    let workspaceReadOnly = this.wrkspaceCommonService.WorkSpaceTracker.readonly;
    if (_$event.isEdited || (this.formGroup && !this.formGroup.valid) || workspaceReadOnly || readOnly == 'true' || this.readOnly) {
      return;
    }
    _$event.dataItem.copyTO = true;
    this.saveAdjustedWorkspaceGrid(datatype, _$event.dataItem);
    this.formGroup = this.createFormGroupWorkspace(_$event.dataItem, _$event.dataItem.dataType);
    this.wrkspaceCommonData = _$event.dataItem;
    this.editedRowIndex = _$event.rowIndex;
    this.eventGrid = _$event;
    _$event.sender.editRow(_$event.rowIndex, this.formGroup);

  }


  populateDataFromCacheMemory() {
    let workSpaceDataResultFromCache: wrkspaceCommonModal[] = this.wrkspaceCommonService.AllWorkSpaceCategoryData;
    let calculatedWorkspaceTimeExpenseModelDataFromCache = this.wrkspaceCommonService.CalculatedWorkspaceTimeExpenseModelData;
    if (calculatedWorkspaceTimeExpenseModelDataFromCache != null && calculatedWorkspaceTimeExpenseModelDataFromCache.length > 0) {
      calculatedWorkspaceTimeExpenseModelDataFromCache.forEach((item: any) => {
        let index = workSpaceDataResultFromCache.findIndex((i: wrkspaceCommonModal) => i.gId == item.gId);
        if (index > -1) {
          workSpaceDataResultFromCache[index].ansr = item.totalANSR;
          workSpaceDataResultFromCache[index].hours = item.totalHours;
          workSpaceDataResultFromCache[index].expenseAmount = item.totalExpenseAmount;
        }
      })
      this.wrkspaceCommonService.AllWorkSpaceCategoryData = workSpaceDataResultFromCache;
      this.wrkspaceCommonService.timeDetailsData = [];
      this.populateIndividualCategoryDataSource(workSpaceDataResultFromCache);
      this.spinner.hide();
    } else {
      this.wrkspaceCommonService.AllWorkSpaceCategoryData = workSpaceDataResultFromCache;
      this.wrkspaceCommonService.timeDetailsData = [];
      this.populateIndividualCategoryDataSource(workSpaceDataResultFromCache);
      this.spinner.hide();
    }
  }
  populateIndividualCategoryDataSource(workSpaceData: wrkspaceCommonModal[]): void {
    this.billableItems = this.getWorkspaceGridData(DataTypeEnum.Billable, workSpaceData);
    this.additionalBillingData = this.getWorkspaceGridData(DataTypeEnum.AdditionalBillingOppertunity, workSpaceData);
    this.nonBillableData = this.getWorkspaceGridData(DataTypeEnum.NonBillable, workSpaceData);
    this.adhocData = this.getWorkspaceGridData(DataTypeEnum.Adhoc, workSpaceData);
    this.uncodedData = this.getWorkspaceGridData(DataTypeEnum.Uncoded, workSpaceData);
    this.expensesData = this.getWorkspaceGridData(DataTypeEnum.Expense, workSpaceData);
    this.dataSource = {
      [workspaceDatasource.billableItems]: this.billableItems,
      [workspaceDatasource.additionalBillingData]: this.additionalBillingData,
      [workspaceDatasource.nonBillableData]: this.nonBillableData,
      [workspaceDatasource.adhocData]: this.adhocData,
      [workspaceDatasource.uncodedData]: this.uncodedData,
      [workspaceDatasource.expensesData]: this.expensesData
    }
  }


  navigetTimeDetails(dataitem: wrkspaceCommonModal) {
    console.log(this.billableItems);
    if (this.formGroup) {
      let dataType = this.eventGrid.dataItem.dataType;
      this.saveAdjustedWorkspaceGrid(dataType, this.eventGrid.dataItem);
    }
    let billingTimeDetailsTrackerData = new billingTimeTrackerModel();
    billingTimeDetailsTrackerData.gid = dataitem.gId;
    billingTimeDetailsTrackerData.itemID = dataitem.billingItemId + '-' + this.getSectionName(dataitem.dataType);
    billingTimeDetailsTrackerData.datatype = dataitem.dataType;
    this.wrkspaceCommonService.BillingTimeDetailsTracker = billingTimeDetailsTrackerData;
    this.wrkSpaceUISessionDetails.modifiedWorkSpaceDetails = this.wrkspaceadjustedData;

    this.sessionservice.saveSessionData(this.wrkSpaceUISessionDetails).subscribe(() => {
      console.log('Data saved in session successfully');
      this.route.navigate(['/timeDetails']);
    }, (error) => {
      // Handle Error
      console.log(error);
    });
  }

  private getSectionName(dataType: DataTypeEnum) {
    let sectionName = "";
    switch (dataType) {
      case DataTypeEnum.Billable:
        sectionName = "Billable Items";
        break;
      case DataTypeEnum.AdditionalBillingOppertunity:
        sectionName = "Additional Billing Opportunity";
        break;
      case DataTypeEnum.NonBillable:
        sectionName = "Non Billable Hours";
        break;
      case DataTypeEnum.Adhoc:
        sectionName = "Adhoc Items";
        break;
      case DataTypeEnum.Uncoded:
        sectionName = "Uncoded Items";
        break;
      case DataTypeEnum.Expense:
        sectionName = "Expenses";
        break;

    }
    return sectionName;

  }
  private getWorkspaceGridData(dataType: DataTypeEnum, data: wrkspaceCommonModal[]) {
    const thisContext = this;
    let sectionName = "";
    switch (dataType) {
      case DataTypeEnum.Billable:
        sectionName = "Billable Items";
        break;
      case DataTypeEnum.AdditionalBillingOppertunity:
        sectionName = "Additional Billing Opportunity";
        break;
      case DataTypeEnum.NonBillable:
        sectionName = "Non Billable Hours";
        break;
      case DataTypeEnum.Adhoc:
        sectionName = "Adhoc Items";
        break;
      case DataTypeEnum.Uncoded:
        sectionName = "Uncoded Items";
        break;
      case DataTypeEnum.Expense:
        sectionName = "Expenses";
        break;
    }
    return data.filter(item => item.dataType == dataType)
      .map(function (item, index) {
        let workSpaceBillingItemId = item.dataType + .1 * (index + 1);
        //item.itemID = workSpaceBillingItemId + '-' + sectionName;
        item.billingItemId = workSpaceBillingItemId.toString();

        if (item.dataType == DataTypeEnum.Adhoc || item.dataType == DataTypeEnum.Expense || item.dataType == DataTypeEnum.Uncoded) {
          item.adjustedBillingAction = (item.adjustedBillingAction == 0) ? 1 : item.adjustedBillingAction;
        }
        item.billingActionName = thisContext.GetBillionActionName(item.billingAction);
        let wrkSpaceSpecificTneDataObj = new wrkSpaceSpecificTneData();
        wrkSpaceSpecificTneDataObj.timeDetailsHeader = workSpaceBillingItemId + '-' + sectionName;
        wrkSpaceSpecificTneDataObj.workSpaceDataType = dataType;
        wrkSpaceSpecificTneDataObj.workSpaceGuid = item.gId;
        thisContext.wrkspaceCommonService.timeDetailsData.push(wrkSpaceSpecificTneDataObj);
        return item;
      })

  }


  GetBillionActionName(billingactionId: number) {
    let billingName: string[] = AdjustedBillingAction.filter(i => i.value == billingactionId).map(j => j.text);
    return billingName[0];

  }

   createFormGroupWorkspace(dataItem: wrkspaceCommonModal, workSpaceDataType: DataTypeEnum) {
    let formgroup: FormGroup | undefined;
    if (workSpaceDataType == DataTypeEnum.Billable || workSpaceDataType == DataTypeEnum.AdditionalBillingOppertunity || workSpaceDataType == DataTypeEnum.NonBillable) {
      formgroup = new FormGroup({
        adjustedBillingAction: new FormControl(dataItem.adjustedBillingAction),
        adjustedInvoiceFee: new FormControl(dataItem.adjustedInvoiceFee),
        adjustedCurrency: new FormControl(dataItem.adjustedCurrency),
        adjustedDescription: new FormControl(dataItem.adjustedDescription),
        adjustedBillingEntityId: new FormControl(dataItem.adjustedBillingEntityId),
        gid: new FormControl(dataItem.gId)
      });
    }
    else if (workSpaceDataType == DataTypeEnum.Adhoc || workSpaceDataType == DataTypeEnum.Uncoded) {

      formgroup = new FormGroup({
        adjustedBillingAction: new FormControl(dataItem.adjustedBillingAction),
        adjustedDescription: new FormControl(dataItem.adjustedDescription),
        adjustedInvoiceFee: new FormControl(dataItem.adjustedInvoiceFee),
        adjustedCurrency: new FormControl(dataItem.adjustedCurrency),
        adjustedBillingEntityId: new FormControl(dataItem.adjustedBillingEntityId),
        adjustedCostCenter: new FormControl(dataItem.adjustedCostCenter),
        adjustedOOSNR: new FormControl(dataItem.adjustedOOSNR),
        adjustedGBTStatus: new FormControl(dataItem.adjustedGBTStatus),
        adjustedGBTRef: new FormControl(dataItem.adjustedGBTRef),
        gid: new FormControl(dataItem.gId)
      });
    }
    else if (workSpaceDataType === DataTypeEnum.Expense) {
      formgroup = new FormGroup({
        adjustedBillingAction: new FormControl(dataItem.adjustedBillingAction),
        adjustedDescription: new FormControl(dataItem.adjustedDescription),
        adjustedInvoiceFee: new FormControl(dataItem.adjustedInvoiceFee),
        adjustedCurrency: new FormControl(dataItem.adjustedCurrency),
        gid: new FormControl(dataItem.gId)
      });
    }
    return formgroup;
  }

  private updateAdjustedWorkspaceDetails(workSpaceDataType: DataTypeEnum, dataItem: wrkspaceCommonModal) {
    let wrkspaceAdjusted = new workspaceAdjustedData();
    if (this.formGroup != undefined && this.formGroup != null) {

      wrkspaceAdjusted.gId = this.formGroup?.controls["gid"].value;
      wrkspaceAdjusted.workSpaceDataType = workSpaceDataType;
      wrkspaceAdjusted.adjustedInvoiceFee = this.formGroup?.controls["adjustedInvoiceFee"].value;
      wrkspaceAdjusted.adjustedCurrency = this.formGroup?.controls["adjustedCurrency"].value;
      wrkspaceAdjusted.adjustedDescription = this.formGroup?.controls["adjustedDescription"].value;
      wrkspaceAdjusted.adjustedBillingAction = this.formGroup?.controls["adjustedBillingAction"].value;
      wrkspaceAdjusted.modifiedDateTime = null;
      wrkspaceAdjusted.productID = (dataItem.productId) ? dataItem.productId : "";
      wrkspaceAdjusted.serviceDescription = (dataItem.serviceDescription) ? dataItem.serviceDescription : "";
      wrkspaceAdjusted.costCenter = (dataItem.costCenter) ? dataItem.costCenter : "";
      wrkspaceAdjusted.GBTRef = (dataItem.gbtRef) ? dataItem.gbtRef : "";

      // wrkspaceAdjusted.currency = (dataItem.currency)? dataItem.currency : "";
      // wrkspaceAdjusted.employee = (dataItem.employee)?dataItem.employee : "";
      // wrkspaceAdjusted.product = (dataItem.product) ? dataItem.product : "";
      // wrkspaceAdjusted.productType= (dataItem.productType) ? dataItem.productType : "";
      // wrkspaceAdjusted.hours = dataItem.hours;
      // wrkspaceAdjusted.gbtStatus= (dataItem.gbtStatus) ? dataItem.gbtStatus : "";
      if (workSpaceDataType !== DataTypeEnum.Expense) {

        wrkspaceAdjusted.adjustedBillingEntityId = this.formGroup?.controls["adjustedBillingEntityId"].value;
        // wrkspaceAdjusted.adjustedBillingEntity = this.adjustedBillingEntities.filter(item => item.id === wrkspaceAdjusted.adjustedBillingEntityId)[0].name;  // aditya work on this part  giving issue 

      }

      if (workSpaceDataType == DataTypeEnum.Adhoc || workSpaceDataType == DataTypeEnum.Uncoded) {
        wrkspaceAdjusted.adjustedCostCenter = this.formGroup?.controls["adjustedCostCenter"].value;
        wrkspaceAdjusted.adjustedOOSNR = this.formGroup?.controls["adjustedOOSNR"].value;
        wrkspaceAdjusted.adjustedGBTStatus = this.formGroup?.controls["adjustedGBTStatus"].value;
        wrkspaceAdjusted.adjustedGBTRef = this.formGroup?.controls["adjustedGBTRef"].value;
      }
    }
    return wrkspaceAdjusted;
  }
   updateIndividualCategoryDataSource(dataItem: wrkspaceCommonModal, copyGridRow?: boolean) {
    if (this.formGroup != undefined && this.formGroup != null || copyGridRow) {
      let gid = (dataItem.gId) ? dataItem.gId :  this.formGroup?.controls["gid"].value;
      this.wrkspaceCommonData.gId = (copyGridRow) ? gid : this.formGroup?.controls["gid"].value;
      this.wrkspaceCommonData.adjustedInvoiceFee = (copyGridRow) ? this.copywrkSpaceAdjustedData[0].adjustedInvoiceFee : this.formGroup?.controls["adjustedInvoiceFee"].value;
      this.wrkspaceCommonData.adjustedCurrency = (copyGridRow) ? this.copywrkSpaceAdjustedData[0].adjustedCurrency : this.formGroup?.controls["adjustedCurrency"].value;
      this.wrkspaceCommonData.adjustedDescription = (copyGridRow) ? this.copywrkSpaceAdjustedData[0].adjustedDescription : this.formGroup?.controls["adjustedDescription"].value;
      this.wrkspaceCommonData.adjustedBillingAction = (copyGridRow) ? this.copywrkSpaceAdjustedData[0].adjustedBillingAction : this.formGroup?.controls["adjustedBillingAction"].value;

      if (dataItem.dataType != DataTypeEnum.Expense) {
        //this.wrkspaceCommonData.adjustedBillingEntityId = (copyGridRow) ? this.copywrkSpaceAdjustedData[0].adjustedBillingEntityId : this.formGroup?.controls["adjustedBillingEntityId"].value; //aditya work here
      }
      if (dataItem.dataType == DataTypeEnum.Adhoc || dataItem.dataType == DataTypeEnum.Uncoded) {
        this.wrkspaceCommonData.adjustedCostCenter = (copyGridRow) ? this.copywrkSpaceAdjustedData[0].adjustedCostCenter : this.formGroup?.controls["adjustedCostCenter"].value;
        this.wrkspaceCommonData.adjustedOOSNR = (copyGridRow) ? this.copywrkSpaceAdjustedData[0].adjustedOOSNR : this.formGroup?.controls["adjustedOOSNR"].value;
        this.wrkspaceCommonData.adjustedGBTStatus = (copyGridRow) ? this.copywrkSpaceAdjustedData[0].adjustedGBTStatus : this.formGroup?.controls["adjustedGBTStatus"].value;
        this.wrkspaceCommonData.adjustedGBTRef = (copyGridRow) ? this.copywrkSpaceAdjustedData[0].adjustedGBTRef : this.formGroup?.controls["adjustedGBTRef"].value;

      }
      if (dataItem.dataType === DataTypeEnum.Billable) {
        let indx = this.billableItems.findIndex((obj: wrkspaceCommonModal) => obj.gId == gid);
        console.log(indx);
        if (indx > -1) {
          this.billableItems[indx] = this.wrkspaceCommonData;
          this.dataSource[workspaceDatasource.billableItems] = this.billableItems;
        }
      }
      else if (dataItem.dataType === DataTypeEnum.AdditionalBillingOppertunity) {
        let indx = this.additionalBillingData.findIndex((obj: wrkspaceCommonModal) => obj.gId == gid);
        console.log(indx);
        if (indx > -1) {
          this.additionalBillingData[indx] = this.wrkspaceCommonData;
          this.dataSource[workspaceDatasource.additionalBillingData] = this.additionalBillingData;
        }
      }
      else if (dataItem.dataType === DataTypeEnum.NonBillable) {
        let indx = this.nonBillableData.findIndex((obj: wrkspaceCommonModal) => obj.gId == gid);
        console.log(indx);
        if (indx > -1) {
          this.dataSource[workspaceDatasource.nonBillableData] = this.nonBillableData;
        }
      }
      else if (dataItem.dataType === DataTypeEnum.Adhoc) {
        let indx = this.adhocData.findIndex((obj: wrkspaceCommonModal) => obj.gId == gid);
        console.log(indx);
        if (indx > -1) {
          this.adhocData[indx] = this.wrkspaceCommonData;
        }
      }
      else if (dataItem.dataType === DataTypeEnum.Uncoded) {
        let indx = this.uncodedData.findIndex((obj: wrkspaceCommonModal) => obj.gId == gid);
        console.log(indx);
        if (indx > -1) {
          this.uncodedData[indx] = this.wrkspaceCommonData;
          this.dataSource[workspaceDatasource.uncodedData] = this.uncodedData;
        }
      }
      else if (dataItem.dataType === DataTypeEnum.Expense) {
        let indx = this.expensesData.findIndex((obj: wrkspaceCommonModal) => obj.gId == gid);
        console.log(indx);
        if (indx > -1) {
          this.expensesData[indx] = this.wrkspaceCommonData;
          this.dataSource[workspaceDatasource.expensesData] = this.expensesData;
        }
      }
      this.changeDetector.detectChanges();
    }
  }

  private saveAdjustedWorkspaceGrid(workSpaceDataType: DataTypeEnum, dataItem: wrkspaceCommonModal) {

    let gid = this.formGroup?.controls["gid"].value;
    let objIndex = this.wrkspaceadjustedData.findIndex((obj: workspaceAdjustedData) => obj.gId == gid);
    let wrkspaceAdjusted: workspaceAdjustedData = this.updateAdjustedWorkspaceDetails(workSpaceDataType, dataItem);
    this.updateIndividualCategoryDataSource(dataItem);

    if (this.formGroup != undefined && this.formGroup != null) {

      if (this.wrkspaceadjustedData.length > 0 && objIndex > -1) {
        this.wrkspaceadjustedData[objIndex] = wrkspaceAdjusted;
      }
      else {
        this.wrkspaceadjustedData.push(wrkspaceAdjusted);
      }
      this.eventGrid.sender.closeRow(this.editedRowIndex);
      this.eventGrid.dataItem.copyTO = false;
      this.editedRowIndex = undefined;
      this.formGroup = undefined;
      console.log('workspace adjusted data');
      console.log(this.wrkspaceadjustedData);

    }
  }

  // private loadItems(): void {
  //   this.gridView = {
  //     data: this.dataSource.slice(this.skip, this.skip + this.pageSize),
  //     total: this.gridTimeDetailsData.length,
  //   };
  // }
  // public pageChange(event: PageChangeEvent): void {
  //   this.skip = event.skip;
  //   this.loadItems();
  // }
  
  copyPreviousEngagementData(dataItem: any) {
    let dataitem: wrkspaceCommonModal = dataItem;
    if (this.copywrkSpaceAdjustedData.length > 0) {
      if (dataitem.gId !== this.copywrkSpaceAdjustedData[0].gId && dataitem.dataType == this.copywrkSpaceAdjustedData[0].dataType) {
        this.spinner.show();
        setTimeout(() => {
          
        }, 5000);
        let createDuplicateData = this.wrkSapceDuplicateDataCreation(dataitem);
        this.updateIndividualCategoryDataSource(dataitem, true);
        let gid = dataitem.gId;
        this.formGroup = this.createFormGroupWorkspace(dataitem, dataitem.dataType);
        let objIndex = this.wrkspaceadjustedData.findIndex((obj: workspaceAdjustedData) => obj.gId == gid);
        if (this.wrkspaceadjustedData.length > 0 && objIndex > -1) {
          this.wrkspaceadjustedData[objIndex] = createDuplicateData;
        }
        else {
          this.wrkspaceadjustedData.push(createDuplicateData);
        }
        this.eventGrid.sender.closeRow(this.editedRowIndex);
        this.eventGrid.dataItem.copyTO = false;
        this.editedRowIndex = undefined;
        this.formGroup = undefined;
      }

      else {
        this.copywrkSpaceAdjustedData[0] = dataitem;
      }
      this.spinner.hide();
    }
    else {
      this.copywrkSpaceAdjustedData.push(dataitem);
    }
   // this.changeDetector.detectChanges();

  }
  
  wrkSapceDuplicateDataCreation(dataItem: wrkspaceCommonModal) {

    let wrkspaceAdjusted = new workspaceAdjustedData();
    wrkspaceAdjusted.gId = dataItem.gId
    wrkspaceAdjusted.workSpaceDataType = dataItem.dataType;
    wrkspaceAdjusted.adjustedInvoiceFee = this.copywrkSpaceAdjustedData[0].adjustedInvoiceFee;
    wrkspaceAdjusted.adjustedCurrency = this.copywrkSpaceAdjustedData[0].adjustedCurrency;
    wrkspaceAdjusted.adjustedDescription = this.copywrkSpaceAdjustedData[0].adjustedDescription;
    wrkspaceAdjusted.adjustedBillingAction = this.copywrkSpaceAdjustedData[0].adjustedBillingAction;
    wrkspaceAdjusted.modifiedDateTime = null;
    wrkspaceAdjusted.productID = (dataItem.productId) ? dataItem.productId : "";
    wrkspaceAdjusted.serviceDescription = (dataItem.serviceDescription) ? dataItem.serviceDescription : "";
    wrkspaceAdjusted.costCenter = (dataItem.costCenter) ? dataItem.costCenter : "";
    wrkspaceAdjusted.GBTRef = (dataItem.gbtRef) ? dataItem.gbtRef : "";

    if (dataItem.dataType !== DataTypeEnum.Expense) {

      wrkspaceAdjusted.adjustedBillingEntityId = this.copywrkSpaceAdjustedData[0].adjustedBillingEntityId;
      //wrkspaceAdjusted.adjustedBillingEntity = this.adjustedBillingEntities.filter(item => item.id === wrkspaceAdjusted.adjustedBillingEntityId)[0].name; //aditya work here 

    }

    if (dataItem.dataType == DataTypeEnum.Adhoc || dataItem.dataType == DataTypeEnum.Uncoded) {
      wrkspaceAdjusted.adjustedCostCenter = this.copywrkSpaceAdjustedData[0].adjustedCostCenter;
      wrkspaceAdjusted.adjustedOOSNR = this.copywrkSpaceAdjustedData[0].adjustedOOSNR;
      wrkspaceAdjusted.adjustedGBTStatus = this.copywrkSpaceAdjustedData[0].adjustedGBTStatus;
      wrkspaceAdjusted.adjustedGBTRef = this.copywrkSpaceAdjustedData[0].adjustedGBTRef;
    }
    return wrkspaceAdjusted;

  }


  saveAllGridData() {
    this.spinner.show();
    console.log(this.formGroup);
    if (this.formGroup) {
      let dataType = this.eventGrid.dataItem.dataType;
      this.saveAdjustedWorkspaceGrid(dataType, this.eventGrid.dataItem);
    }
    //this.wrkspaceCommonService.AllWorkSpaceCategoryData = this.workspaceUncategorisedData;
    this.wrkSpaceUISessionDetails.modifiedWorkSpaceDetails = this.wrkspaceadjustedData;
    this.wrkSpaceUISessionDetails.stage = UIStageEnum.Workspace;

    this.workspaceSerive.saveGridDataAPI(this.wrkSpaceUISessionDetails).subscribe((isDataSaved: boolean) => {
      if (isDataSaved) {
        console.log('Session & DB data saved successfully');

      }
      this.spinner.hide();
    }, (error) => {
      // Handle Error
      console.log(error);
      this.spinner.hide();
    });

  }

  addAdhocRow() {
    let adhocRow = new wrkspaceCommonModal();//this.workSpaceMasterID and createdby to be passed to the service
    this.workspaceSerive.createAdhocRow(this.workSpaceMasterID, this.appSettings.loggedInUserName).subscribe(adhocRowGuid => {
      adhocRow.gId = adhocRowGuid;
      adhocRow.dataType = DataTypeEnum.Adhoc;
      this.wrkspaceCommonService.AllWorkSpaceCategoryData.push(adhocRow);
      this.adhocData = this.getWorkspaceGridData(DataTypeEnum.Adhoc, this.wrkspaceCommonService.AllWorkSpaceCategoryData);
    })
  }

  navigateBillingPreview() {
    if (this.formGroup) {
      let dataType = this.eventGrid.dataItem.dataType;
      this.saveAdjustedWorkspaceGrid(dataType, this.eventGrid.dataItem);
    }
    // this.wrkSpaceUISessionDetails.modifiedWorkSpaceDetails = this.wrkspaceadjustedData;
    //this.wrkSpaceUISessionDetails.stage = UIStageEnum.Workspace;
    console.log(this.wrkSpaceUISessionDetails);
    console.log(this.wrkspaceCommonService.AllWorkSpaceCategoryData);
    this.route.navigate(['/preview']);
  }

  navigateBillingSummary() {
    this.spinner.show();
    if (this.formGroup) {
      let dataType = this.eventGrid.dataItem.dataType;
      this.saveAdjustedWorkspaceGrid(dataType, this.eventGrid.dataItem);
    }

    this.getWrkspaceAdjustedDetails();

    this.wrkSpaceUISessionDetails.modifiedWorkSpaceDetails = this.wrkspaceadjustedData;
    this.wrkSpaceUISessionDetails.stage = UIStageEnum.Workspace;
    this.wrkspaceCommonService.workspaceMasterGuid = this.workSpaceMasterID;
    this.workspaceSerive.saveGridDataAPI(this.wrkSpaceUISessionDetails).subscribe((isDataSaved: Boolean) => {
      if (isDataSaved) {
        console.log('Session & DB data saved successfully');
        //this.spinner.hide();
        this.route.navigate(['/summary']);
      }
      // this.route.navigate(['./workspace']);
    }, (error) => {
      // Handle Error
      this.spinner.hide();
      console.log(error);
    });

  }


  getWrkspaceAdjustedDetails() {
    let adjustedwrkSpaceData: workspaceAdjustedData[] = [];
    adjustedwrkSpaceData = this.wrkspaceCommonService.AllWorkSpaceCategoryData.map((i: wrkspaceCommonModal) =>
    ({
      gId: i.gId, workSpaceDataType: i.dataType, adjustedBillingAction: i.adjustedBillingAction, adjustedInvoiceFee: i.adjustedInvoiceFee,
      adjustedCurrency: i.adjustedCurrency, adjustedDescription: i.activityDescription, adjustedBillingEntity: i.adjustedBillingEntity, adjustedBillingEntityId: i.adjustedBillingEntityId, adjustedCostCenter: i.adjustedCostCenter, adjustedOOSNR: i.adjustedOOSNR, adjustedGBTStatus: i.adjustedGBTStatus, adjustedGBTRef: i.adjustedGBTRef, modifiedBy: i.modifiedBy,
      modifiedDateTime: null, invoiceFee: i.invoiceFee, billingEntityName: i.billingEntity, billingEntityId: "", billingActionId: i.billingAction, productID: (i.productId) ? i.productId : "", serviceDescription: (i.serviceDescription) ? i.serviceDescription : "",
      OOSNR: (i.oosNr) ? i.oosNr : "", costCenter: (i.costCenter) ? i.costCenter : "", GBTRef: (i.gbtRef) ? i.gbtRef : "", currency: (i.currency) ? i.currency : "", employee: (i.employee) ? i.employee : "", product: (i.product) ? i.product : "", productType: (i.productType) ? i.productType : "", hours: (i.hours) ? i.hours : 0, gbtStatus: (i.gbtStatus) ? i.gbtStatus : ""
    })
    );

    if (this.wrkspaceadjustedData.length > 0) {
      adjustedwrkSpaceData.forEach(item => {
        let data: workspaceAdjustedData[] = this.wrkspaceadjustedData.filter(i => i.gId == item.gId);
        if (data.length == 0) {
          this.wrkspaceadjustedData.push(item);
        }
      })
    }
    else {
      this.wrkspaceadjustedData = adjustedwrkSpaceData;
    }
  }

  wrkspaceadjustedChildComponent(dataitem:workspaceAdjustedData[])
  {
    this.wrkspaceadjustedData = dataitem;
  }

  backButton() {
    this.sessionservice.clearSessionData().subscribe(() => {
      console.log("session clear");
    }, (error) => {
      // Handle Error
      console.log(error);
    });
    this._location.back();

  }
}


