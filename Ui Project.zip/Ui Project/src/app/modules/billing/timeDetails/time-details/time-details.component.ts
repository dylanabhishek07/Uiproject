import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { timeDetails } from 'src/app/models/TimeDetailModel/timeDetails';
import { timeDetailsService } from 'src/app/services/TimeDetail/timeDetailsService';
import { Validators, FormBuilder, FormGroup } from '@angular/forms';
import { State, process } from "@progress/kendo-data-query";
import { Location } from '@angular/common';
import { workspaceCommonService } from 'src/app/services/CommonService/workspaceCommonService';
import { timeDataModel } from 'src/app/models/TimeDetailModel/timeData';
import { btTimeDetailsTransferModel } from 'src/app/models/BillingPreviewModel/btTimeDetailTransferModel';
import { NgxSpinnerService } from "ngx-spinner";

import { wrkSpaceSpecificTneData } from 'src/app/models/WorkSpaceModel/wrkSpaceSpecificTneData';
import { calculatedWorkspaceTimeExpenseModel } from 'src/app/models/WorkSpaceModel/calculatedWorkspaceTimeExpenseModel';
import { timeDetailsColumns } from 'src/app/columnConfiguration/timeDetailsColumn';
import { columnConfig } from 'src/app/columnConfiguration/columnInterface';
import { billingTimeTrackerModel } from 'src/app/models/BillingPreviewModel/billingTimeTrackerModel';
import { btTimeDetails } from 'src/app/data/btTimeDetails';
import { GridDataResult, PageChangeEvent } from "@progress/kendo-angular-grid";
import { filterBy, CompositeFilterDescriptor } from "@progress/kendo-data-query";
@Component({
  selector: 'app-time-details',
  templateUrl: './time-details.component.html',
  styleUrls: ['./time-details.component.scss'],
  providers: [timeDetailsService]
})
export class TimeDetailsComponent implements OnInit {
  public gridView: GridDataResult = {
    data: [],
    total: 0
  }
  public pageSize = 5;
  public skip = 0;
  selectedtranferTo = new wrkSpaceSpecificTneData();

  public billintimeDetailsTrackerData: billingTimeTrackerModel = this.globalservice.BillingTimeDetailsTracker;
  itemId = this.billintimeDetailsTrackerData.itemID;
  workSpaceGid = this.billintimeDetailsTrackerData.gid;
  currentdataType = this.billintimeDetailsTrackerData.datatype;

  public timeDetailsColumns: columnConfig[] = timeDetailsColumns;
  dataSourceTransferTo: wrkSpaceSpecificTneData[] = [];
  transferFrom: any;
  allTrnsId: any[] = [];
  movetimeDataIDetails: timeDataModel[] = [];
  readOnly : boolean = false;

  // public pageSize = 5;
  // public skip = 0;
  showGrid = false;

  selectAllCheckbox: boolean = false;
  public gridTimeDetailsData: timeDetails[] = [];
  public gridFilterData: any[] = [];


  public defaultItemTransferTo: { timeDetailsHeader: string; workSpaceGuid: string, workSpaceDataType: number } = {
    timeDetailsHeader: "Select",
    workSpaceGuid: "",
    workSpaceDataType: 0
  };
  calculatedWorkspaceTimeExpenseModelData: calculatedWorkspaceTimeExpenseModel[] = [];

  //isSaveButtonDisabled: boolean = true;
  //isBackButtonDisabled: boolean = false;

  calculatedWorkspaceID: any;

  public tranferToDetails: timeDetails[] = []

  public filter: CompositeFilterDescriptor = { logic: 'or', filters: [] }

  tranferData: btTimeDetailsTransferModel[] = [];

  constructor(private http: timeDetailsService, private formBuilder: FormBuilder, private _location: Location, private globalservice: workspaceCommonService, private spinner: NgxSpinnerService) { }
  ngOnInit(): void {
    this.spinner.show();
    let readonly : string | null  = localStorage.getItem('readonly');
    
    this.globalservice.readonly.subscribe(result=>{
      this.readOnly= result;
      console.log('subjecttimedetails' , result);
     })
     
     this.readOnly =(this.readOnly || readonly=='true' ) ? true : false;
    let items = this.globalservice.timeDetailsData.filter(i => i.timeDetailsHeader !== this.billintimeDetailsTrackerData.itemID);
    this.dataSourceTransferTo = items;
    this.transferFrom = this.globalservice.timeDetailsData;
    console.log(this.dataSourceTransferTo);
    // this.gridTimeDetailsData = btTimeDetails;
    console.log(this.transferFrom);
    this.http.timeDetailsItemsApi(this.workSpaceGid).subscribe(data => {
      data.forEach((item: timeDetails) => {
        let timeDetailsData = new timeDetails();
        timeDetailsData.engagementName = item.engagementName;
        timeDetailsData.transactionDate = item.transactionDate;
        timeDetailsData.employeeName = item.employeeName;
        timeDetailsData.rank = item.rank;
        timeDetailsData.country = item.country;
        timeDetailsData.chargedHours = item.chargedHours;
        timeDetailsData.chargedHoursDescription = item.chargedHoursDescription;
        timeDetailsData.nsr = item.nsr;
        timeDetailsData.nsrRate = item.nsrRate;
        timeDetailsData.ansr = item.ansr;
        timeDetailsData.eaf = item.eaf;
        timeDetailsData.activityName = item.activityName;
        timeDetailsData.accountingDate = item.accountingDate;
        timeDetailsData.expenseAmount = item.expenseAmount;
        timeDetailsData.expensesDescription = item.expensesDescription;
        timeDetailsData.vendorName = item.vendorName;
        timeDetailsData.guid = item.guid;
        this.gridTimeDetailsData.push(timeDetailsData);
      });
      this.loadItems();
      this.showGrid = true;
    }, (error) => {
      // Handle Error
      this.spinner.hide();
      console.log(error);
    });

    this.allTrnsId = this.gridTimeDetailsData.map(item => item.guid);
    this.spinner.hide();
    console.log(this.gridTimeDetailsData);
  }

  selectedDropdownValueTranferTo(item: wrkSpaceSpecificTneData) {
    this.selectedtranferTo = item;

  }
  private loadItems(): void {
    this.gridView = {
      data: this.gridTimeDetailsData.slice(this.skip, this.skip + this.pageSize),
      total: this.gridTimeDetailsData.length,
    };
  }
  public pageChange(event: PageChangeEvent): void {
    this.skip = event.skip;
    this.loadItems();
  }
  SelectALL() {
    this.tranferToDetails = [];
    if (this.selectAllCheckbox) {
      if (this.gridFilterData.length > 0) {
        this.gridFilterData.forEach((item, index) => {
          this.gridFilterData[index]['checked'] = true;
        })
      }
      else {
        this.gridView.data.forEach((item, index) => {
          this.gridView.data[index]['checked'] = true;
        })
      }

      this.tranferToDetails = (this.gridFilterData.length > 0) ? this.gridFilterData : this.gridView.data;
    }
    else {
      this.gridView.data.forEach((item, index) => {
        this.gridView.data[index]['checked'] = false;
      });
      if (this.gridFilterData.length > 0) {
        this.gridFilterData.forEach((item, index) => {
          this.gridFilterData[index]['checked'] = false;
        })

      }
    }
    console.log(this.tranferToDetails);
    console.log('gridFilter', this.gridFilterData);

  }
  public cellClickHandler(_$event: any) {

    if (!_$event.isEdited) {
      _$event.sender.editCell(_$event.rowIndex, _$event.columnIndex, this.createFormGroup(_$event.dataItem));
    }
  }

  public createFormGroup(dataItem: any): FormGroup {
    return this.formBuilder.group({
      engagementName: dataItem.engagementName,
      transactionDate: dataItem.transactionDate,
      employeeName: dataItem.employeeName,
      rank: dataItem.rank,
      country: dataItem.country,
      chargedHours_Quantity: dataItem.chargedHours_Quantity,
      chargedHours_QuantityDescription: dataItem.chargedHours_QuantityDescription,
      nsr: dataItem.nsr,
      nsrRate: dataItem.nsrRate,
      ansr: dataItem.ansr,
      eafReserveAllocation: dataItem.eafReserveAllocation,
      activityCodeDescription: dataItem.activityCodeDescription,
      accountingDate: dataItem.accountingDate,
      expenseAmount: dataItem.expenseAmount,
      expenseDescription: dataItem.expenseDescription,
      vendorName: dataItem.vendorName
    });
  }

  public filterChange(filter: CompositeFilterDescriptor): void {
    if (filter.filters.length > 0) {
      this.filter = filter;
      this.gridFilterData = filterBy(this.gridTimeDetailsData, filter);
      console.log('gridFilter', this.gridFilterData);
    }
    else {
      this.gridFilterData = [];
    }
  }
  /*
    moveTo(timeDetailsRowData: timeDetails, currentWrkSpaceInfo: wrkSpaceSpecificTneData) {
      //let data = timeDetailsRowData;
      if (currentWrkSpaceInfo.workSpaceGuid !== this.workSpaceGid && currentWrkSpaceInfo.workSpaceGuid != "" && currentWrkSpaceInfo.workSpaceGuid != null) {
        //this.isSaveButtonDisabled = false;
        //this.isBackButtonDisabled = true;
        if (!this.tranferToDetails.some(i => i.tneGuid === timeDetailsRowData.guid)) {
          if (this.tranferData.some(i => i.transferToWorkspaceGId === currentWrkSpaceInfo.workSpaceGuid)) {
            let indx = this.tranferData.map(i => i.transferToWorkspaceGId).indexOf(currentWrkSpaceInfo.workSpaceGuid);
            this.tranferData[indx].finalProcessedTnEList.push(timeDetailsRowData.guid);
            this.tranferToDetails.push({ tneGuid: timeDetailsRowData.guid, workspaceId: currentWrkSpaceInfo.workSpaceGuid });
          }
          else {
            let bttimeDataTransferModel = new btTimeDetailsTransferModel();
            bttimeDataTransferModel.finalProcessedTnEList.push(timeDetailsRowData.guid);
            bttimeDataTransferModel.isSourceCategory = false;
            bttimeDataTransferModel.transferToDataCategory = currentWrkSpaceInfo.workSpaceDataType;
            bttimeDataTransferModel.transferToWorkspaceGId = currentWrkSpaceInfo.workSpaceGuid;
            this.tranferData.push(bttimeDataTransferModel);
            this.tranferToDetails.push({ tneGuid: timeDetailsRowData.guid, workspaceId: currentWrkSpaceInfo.workSpaceGuid });
  
          }
  
        }
        else {
          var trnIndex: number = 0;
          var indx: number = 0;
          let allItemguidId = this.tranferData.map(i => i.finalProcessedTnEList);
          allItemguidId.forEach((element, index) => {
            element.map((i, idx) => {
              if (i === timeDetailsRowData.guid) {
                trnIndex = idx;
                indx = index;
              }
            })
          })
          this.tranferData[indx].finalProcessedTnEList.splice(trnIndex, 1);
          if (this.tranferData.some(i => i.transferToWorkspaceGId === currentWrkSpaceInfo.workSpaceGuid)) {
            let indx = this.tranferData.map(i => i.transferToWorkspaceGId).indexOf(currentWrkSpaceInfo.workSpaceGuid);
            this.tranferData[indx].finalProcessedTnEList.push(timeDetailsRowData.guid);
            //this.tranferToDetails.push({trnId: data.guid , workspaceId:transferTo.timeId  });
          }
          else {
            let bttimeDataTransferModel = new btTimeDetailsTransferModel();
            bttimeDataTransferModel.finalProcessedTnEList.push(timeDetailsRowData.guid);
            bttimeDataTransferModel.isSourceCategory = false;
            bttimeDataTransferModel.transferToDataCategory = currentWrkSpaceInfo.workSpaceDataType;
            bttimeDataTransferModel.transferToWorkspaceGId = currentWrkSpaceInfo.workSpaceGuid;
            this.tranferData.push(bttimeDataTransferModel);
            //this.tranferToDetails.push({trnId: data.guid , workspaceId:transferTo.timeId  });
  
          }
        }
      }
      if (currentWrkSpaceInfo.timeDetailsHeader == 'Select') {
        this.tranferToDetails = this.tranferToDetails.filter(item => item.tneGuid != timeDetailsRowData.guid);
      }
    }
    */

  RowItemCheck(dataItem: timeDetails) {
    if (!dataItem.checked) {
      this.tranferToDetails.push(dataItem);

    }
    else {
      let filterTime = this.tranferToDetails.filter(i => i.guid != dataItem.guid);
      this.tranferToDetails = filterTime;
    }

    console.log(this.tranferToDetails);

  }
  saveClick() {
    this.spinner.show();
    let tneIDs: string[] = [];
    this.tranferData = [];
    let bttimeDataTrnIdDestination = new btTimeDetailsTransferModel();
    
    bttimeDataTrnIdDestination.finalProcessedTnEList = this.tranferToDetails.map(i => i.guid);
    bttimeDataTrnIdDestination.isSourceCategory = false;
    bttimeDataTrnIdDestination.transferToDataCategory = this.selectedtranferTo.workSpaceDataType;
    bttimeDataTrnIdDestination.transferToWorkspaceGId = this.selectedtranferTo.workSpaceGuid;
    this.tranferData.push(bttimeDataTrnIdDestination);

    let btTimeDetailsTrnIdSource = new btTimeDetailsTransferModel();
    btTimeDetailsTrnIdSource.finalProcessedTnEList = this.gridTimeDetailsData.filter(i => i.checked == false).map(i => i.guid);
    btTimeDetailsTrnIdSource.isSourceCategory = true;
    btTimeDetailsTrnIdSource.transferToDataCategory = this.currentdataType;
    btTimeDetailsTrnIdSource.transferToWorkspaceGId = this.workSpaceGid;
    this.tranferData.push(btTimeDetailsTrnIdSource);

    this.http.TranferTneDataToOtherCategory(this.tranferData).subscribe((data: btTimeDetailsTransferModel) => {
      this.tranferToDetails = [];
      this.tranferData.forEach(element => {
        let calculatedWorkspaceTimeExpenseModelData = new calculatedWorkspaceTimeExpenseModel();
        calculatedWorkspaceTimeExpenseModelData.GId = element.transferToWorkspaceGId
        calculatedWorkspaceTimeExpenseModelData.TotalANSR = 0;
        calculatedWorkspaceTimeExpenseModelData.TotalExpenseAmount = 0;
        calculatedWorkspaceTimeExpenseModelData.TotalHours = 0;
        this.calculatedWorkspaceTimeExpenseModelData.push(calculatedWorkspaceTimeExpenseModelData);
      });
      
      this.http.timeDetailsItemsApi(this.workSpaceGid).subscribe((data : timeDetails[]) => {
        this.gridTimeDetailsData = data;
        this.spinner.hide();

      }, (error) => {
        // Handle Error
        this.spinner.hide();
        console.log(error);
      });
     
      
    },(error) => {
      // Handle Error
      this.spinner.hide();
      console.log(error);
    });

  }
  backButton() {
    if (this.tranferData.length === 0) {
      this._location.back();
    }
    else {
      this.http.calculateWorkspaceTimeExpenseAPI(this.calculatedWorkspaceTimeExpenseModelData).subscribe((data: calculatedWorkspaceTimeExpenseModel[]) => {
        this.globalservice.CalculatedWorkspaceTimeExpenseModelData = data;
        this._location.back();
      });

    }
  }

  onGridSelectionChange() {
    alert();
  }


}


