import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { EngagementBillSummary } from 'src/app/data/engagementBillSummary';
import { engageMentConsolidatedRevenuesModel } from 'src/app/models/BillingSummaryModel/feeSharing/engageMentConsolidatedRevenuesModel';
import { engagementKendoDataSourceModel } from 'src/app/models/BillingSummaryModel/engagementSummary/engagementKendoDataSourceModel';
import { engagementItemModel } from 'src/app/models/BillingSummaryModel/engagementSummary/engagementItemModel';
import { engagementRevenueModel } from 'src/app/models/BillingSummaryModel/engagementSummary/engagementRevenueModel';
import { engagementSummaryModel } from 'src/app/models/BillingSummaryModel/engagementSummary/engagementSummaryModel';

import { feeSharingModel } from 'src/app/models/BillingSummaryModel/feeSharing/feeSharingDetailModel';
import { billingSummaryService } from 'src/app/services/BillingSummary/billingSummaryService';
import { AppSettings } from 'src/app/services/CommonService/app-settings';
import { workspaceCommonService } from 'src/app/services/CommonService/workspaceCommonService';
import { Location } from '@angular/common';
import { billingEntitySummaryModel } from 'src/app/models/BillingSummaryModel/feeSharing/billingEntitySummaryModel';
import { feeSharingKendoDataSourceModel } from 'src/app/models/BillingSummaryModel/feeSharing/feeSharingKendoDataSourceModel';
import { entityInvoiceDetailsData } from 'src/app/models/BillingSummaryModel/feeSharing/entityInvoiceDetailsData';
import { feeSharingDetailsResponsemodel } from 'src/app/models/BillingSummaryModel/feeSharing/feeSharingDetailsResponsemodel';
import { engagementWiseFeeSharingDetailsModel } from 'src/app/models/BillingSummaryModel/feeSharing/engagementWiseFeeSharingDetailsModel';
import { columnConfig } from 'src/app/columnConfiguration/columnInterface';
import { columnModel } from 'src/app/columnConfiguration/columnModel';
import { BillingActionEnum } from 'src/app/enums/BillingActionEnum';
import { EAFCalculationKendoDataSource } from 'src/app/models/BillingSummaryModel/EAFCalculation/EAFCalculationKendoDataSource';
import { FormControl, FormGroup } from '@angular/forms';
import { EAFCalculationResponse } from 'src/app/models/BillingSummaryModel/EAFCalculation/EAFCalculationResponse';
import { billsummeryEngagmentEAFDeatils } from 'src/app/models/BillingSummaryModel/EAFCalculation/billsummeryEngagmentEAFDeatils';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { feeSharingEnum } from 'src/app/enums/feeSharingEnum';
import { saveCustomFeeSharingTypeDetails } from 'src/app/models/BillingSummaryModel/feeSharing/saveCustomInvoiceAllocationDetails';
import { eitityWiseCustomInvoiceAllocationDetails } from 'src/app/models/BillingSummaryModel/feeSharing/eitityWiseCustomInvoiceAllocationDetails';
import { DomSanitizer, SafeStyle } from "@angular/platform-browser";
import { ItemTemplateDirective } from '@progress/kendo-angular-dropdowns';
import { currentUserModel } from 'src/app/models/LandingPageModel/currentUserModel';
import { FeeSharingTypeComponent } from '../../fee-sharing-type/fee-sharing-type.component';
import { EAFCalculationComponent } from '../../eafcalculation/eafcalculation.component';
@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.scss'],
  providers: [billingSummaryService],
  encapsulation: ViewEncapsulation.None
})



export class SummaryComponent implements OnInit {

  @ViewChild(FeeSharingTypeComponent, { static: true }) FeeSharingTypeChildComponent!: FeeSharingTypeComponent;
  @ViewChild(EAFCalculationComponent, { static: true }) EAFCalculationChildComponent!: EAFCalculationComponent;

  enableEditablefield: boolean = false;
  feeShaingEnumtype: number = 0;
  feesharingTypeAPIresponse = new feeSharingDetailsResponsemodel();
  readOnly: boolean= false;
  constructor(private billingSummaryservice: billingSummaryService, private wrkspacecommonservice: workspaceCommonService, private appSettings: AppSettings, private _location: Location, private route: Router, private spinner: NgxSpinnerService) { }
  engagementSummary = new engagementSummaryModel();
  billingEntitySummary = new billingEntitySummaryModel();
  feeSharing = new feeSharingModel();
  etcToBeProcessedValue = [true, false];
  engagementData = new engagementKendoDataSourceModel();
  engagementDataSource: engagementKendoDataSourceModel[] = [];
  engageMentConsolidatedRevenuesData = new engageMentConsolidatedRevenuesModel();
  engageMentConsolidatedRevenuesDataSource: engageMentConsolidatedRevenuesModel[] = [];
  entityInvoiceDetailsData = new entityInvoiceDetailsData();
  entityInvoiceDetailsDataSource: entityInvoiceDetailsData[] = [];
  feeSharingDetails = new feeSharingModel();
  feeSharingTypes = this.appSettings.feeSharingType;
  currentUser = this.appSettings.loggedInUserName;
  engagementSummaryData: Array<any> = [];
  engagementSummaryTotal: Array<any> = [];
  feeSharingDataModel = new feeSharingKendoDataSourceModel();
  feeSharingDataSource: feeSharingKendoDataSourceModel[] = [];

  totalFeeSharingDataSource: feeSharingKendoDataSourceModel[] = [];
  feeSharingResponseModel = new feeSharingDetailsResponsemodel();

  billingEntityColumnconfig: columnConfig[] = []
  engagementWiseFeeSharingData: engagementWiseFeeSharingDetailsModel[] = [];

  feesharingDynamicKendoDatasource: any = [];

  eafCalculationKendoDataSource: EAFCalculationKendoDataSource[] = [];

  customFeesharingData: saveCustomFeeSharingTypeDetails[] = [];
  exitingEAFDetails: boolean = true;
  entityList: Array<any> = [];
  totalEngagementWiseEntities: Array<any> = [];
  objectKeys = Object.keys;
  eafAPIResponse = new EAFCalculationResponse();
  checkInvoiceAllocation: boolean = false;
  wrkspaceMasterGuid = this.wrkspacecommonservice.workspaceMasterGuid;//'9C38C21D-4783-EC11-8056-502F9B7D84CF';
  ngOnInit(): void {
    this.spinner.hide();
    console.log('summary onInit');
    
    // this.wrkspacecommonservice.readonly.subscribe(result=>{
    //   console.log('subjectsummary' , result);
    //   this.readOnly= result;
    //  })
  
     let readonly = localStorage.getItem('readonly');
     this.readOnly = (readonly=='true' || this.wrkspacecommonservice.WorkSpaceTracker.readonly) ? true: false;

    this.billingSummaryservice.getEAFCalculationAPI(this.wrkspaceMasterGuid).subscribe((eafResponse: EAFCalculationResponse) => {
      this.eafAPIResponse = eafResponse;
      if (eafResponse.workspaceMasterGid === null || eafResponse.workspaceMasterGid === "") {
        // this.BindEAFDetails(eafResponse);
        this.exitingEAFDetails = false;
      }
      else{
        this.exitingEAFDetails = true;
      }
      this.billingSummaryservice.getEngagementSummaryAPI(this.wrkspaceMasterGuid).subscribe((data: engagementSummaryModel) => {
        this.engagementSummary = data;
        this.createEngagementFeeEAFSummaryKendoDatasource(this.engagementSummary);
        this.GetBillingEntitySummary();
        let engagementIds = this.engagementSummary.engagementRevenueList.map(el => el.engagementId);
        engagementIds.forEach(item => {
          this.engagementSummaryData.push(this.engagementDataSource.filter(el => el.Name === item));
        })

        this.engagementSummaryData.forEach(item => {
          item.map((el: any) => {
            if (el.BillingAction != 0) {
              el.Name = "";
            }
          })
        })
        this.engagementData.ANSR = data.totalANSR;
        this.engagementData.NSR = data.totalNSR;
        this.engagementData.EAF = data.totalEAF;
        this.engagementData.Expense = data.totalExpense;
        this.engagementData.Name = "Totals";
        this.engagementData.BillingAction = 0;
        this.engagementSummaryTotal.push(this.engagementData);

        let feeSharingDataModel = new feeSharingKendoDataSourceModel();
        feeSharingDataModel.Engagement = "Total";
        feeSharingDataModel.ANSR = data.netTotalANSR;
        feeSharingDataModel.NSR = data.netTotalNSR;
        feeSharingDataModel.EAF = data.totalEAF;
        feeSharingDataModel.Expense = data.totalExpense;
        feeSharingDataModel.InvoiceAllocation = this.billingEntitySummary.totalInvoiceFee;
        this.totalFeeSharingDataSource.push(feeSharingDataModel);
        console.log(this.engagementSummaryData)
        console.log(this.engagementDataSource);
        console.log(this.engagementSummaryTotal[0])

      }, (error) => {
        // Handle Error
        console.log(error);

      });

    }, (error) => {
      // Handle Error
      console.log(error);
    });


    this.EAFCalculationChildComponent.calculateRevisedEAF();
  }


  createEngagementFeeEAFSummaryKendoDatasource(engagementSummary: engagementSummaryModel) {
    engagementSummary.engagementRevenueList.map((engagementRevenue: engagementRevenueModel) => {
      let engagementDataModel = new engagementKendoDataSourceModel();
      engagementDataModel.ANSR = engagementRevenue.totalANSR;
      engagementDataModel.NSR = engagementRevenue.totalNSR;
      engagementDataModel.Expense = engagementRevenue.totalExpense;
      engagementDataModel.Name = (engagementRevenue.engagementId) ? engagementRevenue.engagementId : "Engagement";
      engagementDataModel.BillingAction = 0;
      engagementDataModel.EAF = engagementRevenue.eaf;
      this.engagementDataSource.push(engagementDataModel);

      let itemToAdd: any = { "engagementId": engagementRevenue.engagementId, "totalInvoiceAllocation": 0, gId: null }
      this.feesharingDynamicKendoDatasource.push(itemToAdd);

      //fee sharing data source 
      let feeSharingDataModel = new feeSharingKendoDataSourceModel();
      feeSharingDataModel.Engagement = engagementRevenue.engagementId;
      feeSharingDataModel.ANSR = engagementRevenue.netTotalANSR;
      feeSharingDataModel.NSR = engagementRevenue.netTotalNSR;
      feeSharingDataModel.EAF = engagementRevenue.eaf;
      feeSharingDataModel.Expense = engagementRevenue.totalExpense;
      feeSharingDataModel.editable = true;
      this.feeSharingDataSource.push(feeSharingDataModel);

      //EAF Calculation data source

      let EAFCalculationDataModel = new EAFCalculationKendoDataSource();
      EAFCalculationDataModel.engagementId = engagementRevenue.engagementId;
      EAFCalculationDataModel.PreviousEAF = engagementRevenue.eaf;
      engagementRevenue.engagementItems.map((j: engagementItemModel) => {
        let engagementDataItemModel = new engagementKendoDataSourceModel();
        engagementDataItemModel.ANSR = j.ansr;
        engagementDataItemModel.NSR = j.nsr;
        engagementDataItemModel.Expense = j.expense;
        engagementDataItemModel.Name = engagementDataModel.Name;
        engagementDataItemModel.BillingAction = j.billingAction
        this.engagementDataSource.push(engagementDataItemModel);

        if (j.billingAction == BillingActionEnum.CarryForward) {
          EAFCalculationDataModel.CurrentinvoiceCF = j.nsr;
        }
        else if (j.billingAction == BillingActionEnum.Miscoded) {
          EAFCalculationDataModel.CurrentinvoiceMC = j.nsr;
        }
      });

      if (this.exitingEAFDetails) {
        this.overrideEAFDetails(EAFCalculationDataModel);
      }
      else {
        this.eafCalculationKendoDataSource.push(EAFCalculationDataModel);
      }

    });
    let feeSharingDataModelForTotal = new feeSharingKendoDataSourceModel();
    feeSharingDataModelForTotal.Engagement = "Total";
    feeSharingDataModelForTotal.ANSR = engagementSummary.netTotalANSR;
    feeSharingDataModelForTotal.NSR = engagementSummary.netTotalNSR;
    feeSharingDataModelForTotal.EAF = engagementSummary.totalEAF;
    feeSharingDataModelForTotal.Expense = engagementSummary.totalExpense;
    feeSharingDataModelForTotal.InvoiceAllocation = this.billingEntitySummary.totalInvoiceFee;
    this.feeSharingDataSource.push(feeSharingDataModelForTotal);
    console.log("eafSummaryDAta",this.eafCalculationKendoDataSource );
  }

  overrideEAFDetails(EAFData: EAFCalculationKendoDataSource) {

    let index: number = this.eafCalculationKendoDataSource.map(item => item.engagementId).indexOf(EAFData.engagementId);
    if (index > -1) {
      this.eafCalculationKendoDataSource[index].PreviousEAF = EAFData.PreviousEAF;
      this.eafCalculationKendoDataSource[index].CurrentinvoiceCF = EAFData.CurrentinvoiceCF;
      this.eafCalculationKendoDataSource[index].CurrentinvoiceMC = EAFData.CurrentinvoiceMC;
    }

  }



  GetBillingEntitySummary() {
    this.billingSummaryservice.getBillingEntitySummaryAPI(this.wrkspaceMasterGuid).subscribe((billingEntitySummary: billingEntitySummaryModel) => {
      this.billingEntitySummary = billingEntitySummary;
      let itemToAdd: any = { "engagementId": "Total", "totalInvoiceAllocation": billingEntitySummary.totalInvoiceFee, gId: null }
      this.totalFeeSharingDataSource[0].InvoiceAllocation = this.billingEntitySummary.totalInvoiceFee;
      this.wrkspacecommonservice.billingEntityDetails = billingEntitySummary.entityInvoiceDetails;
      billingEntitySummary.entityInvoiceDetails.forEach(item => {

        let columnconfiguration: columnConfig = new columnModel();
        columnconfiguration.field = (item.billingEntityName) ? item.billingEntityName : "NameNotInitialized"; //change to billingENtity ID
        columnconfiguration.title = (item.billingEntityName) ? item.billingEntityName : "NameNotInitialized";
        columnconfiguration.type = "text";
        columnconfiguration.width = 200;
        //columnconfiguration.value= item.invoiceFee;
        // columnconfiguration.templateDropDown = false;
        this.billingEntityColumnconfig.push(columnconfiguration);
        itemToAdd[columnconfiguration.field] = item.invoiceFee;
        itemToAdd['gId'] = (item.gId) ? item.gId : null;
      });
      this.feesharingDynamicKendoDatasource.push(itemToAdd);
      console.log(this.billingEntitySummary);


    }, (error) => {
      // Handle Error
      console.log(error);

    });
  }

  feeShaingEnumType(value: number) {

    this.feeShaingEnumtype = value;

  }


  saveDetails() {
    if (this.feeShaingEnumtype == feeSharingEnum.menu2) {
      this.FeeSharingTypeChildComponent.saveCustomFeeSharingDetails();
    }
    else if (this.feeShaingEnumtype === feeSharingEnum.menu3) {
      this.EAFCalculationChildComponent.saveEAFCustomDetails();
    }
    else{
     this.spinner.hide();
    }
  }

  GetBillingActionName(dataItem: number) {
    let billingName = EngagementBillSummary.filter(i => i.value == dataItem).map(j => j.text);
    return billingName;

  }





  backButton() {
    this._location.back();
  }
  navigatToInvoiceDetails() {
    this.route.navigate(['/invoice-details']);
  }
}
