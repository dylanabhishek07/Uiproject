import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FeeSharingTypeComponent } from './fee-sharing-type.component';

describe('FeeSharingTypeComponent', () => {
  let component: FeeSharingTypeComponent;
  let fixture: ComponentFixture<FeeSharingTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FeeSharingTypeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FeeSharingTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
