import { AfterViewInit, Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SafeStyle, DomSanitizer } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { RouterModule } from '@angular/router'
import { NgxSpinnerService } from 'ngx-spinner';
//import { NgxSpinnerService } from 'ngx-spinner/lib/ngx-spinner.service';
import { columnConfig } from 'src/app/columnConfiguration/columnInterface';
import { feeSharingType } from 'src/app/data/feeSharingType';
import { feeSharingEnum } from 'src/app/enums/feeSharingEnum';
import { feeSharingTypeEnum } from 'src/app/enums/feeSharingTypeEnum';
import { EAFCalculationKendoDataSource } from 'src/app/models/BillingSummaryModel/EAFCalculation/EAFCalculationKendoDataSource';
import { EAFCalculationResponse } from 'src/app/models/BillingSummaryModel/EAFCalculation/EAFCalculationResponse';
import { engagementRevenueModel } from 'src/app/models/BillingSummaryModel/engagementSummary/engagementRevenueModel';
import { engagementSummaryModel } from 'src/app/models/BillingSummaryModel/engagementSummary/engagementSummaryModel';
import { billingEntitySummaryModel } from 'src/app/models/BillingSummaryModel/feeSharing/billingEntitySummaryModel';
import { eitityWiseCustomInvoiceAllocationDetails } from 'src/app/models/BillingSummaryModel/feeSharing/eitityWiseCustomInvoiceAllocationDetails';
import { engagementWiseFeeSharingDetailsModel } from 'src/app/models/BillingSummaryModel/feeSharing/engagementWiseFeeSharingDetailsModel';
import { entityInvoiceDetailsData } from 'src/app/models/BillingSummaryModel/feeSharing/entityInvoiceDetailsData';
import { feeSharingModel } from 'src/app/models/BillingSummaryModel/feeSharing/feeSharingDetailModel';
import { feeSharingDetailsResponsemodel } from 'src/app/models/BillingSummaryModel/feeSharing/feeSharingDetailsResponsemodel';
import { feeSharingKendoDataSourceModel } from 'src/app/models/BillingSummaryModel/feeSharing/feeSharingKendoDataSourceModel';
import { saveCustomFeeSharingTypeDetails } from 'src/app/models/BillingSummaryModel/feeSharing/saveCustomInvoiceAllocationDetails';
import { billingSummaryService } from 'src/app/services/BillingSummary/billingSummaryService';
import { AppSettings } from 'src/app/services/CommonService/app-settings';
import { workspaceCommonService } from 'src/app/services/CommonService/workspaceCommonService';


@Component({
  selector: 'app-fee-sharing-type',
  templateUrl: './fee-sharing-type.component.html',
  styleUrls: ['./fee-sharing-type.component.scss']
})
export class FeeSharingTypeComponent implements OnInit, OnChanges {
  @Input() wrkspaceMasterGuid: string = "";
  feeSharingTypes = feeSharingType;
  eventGridFeesharing: any;
  private editedRowIndexFeeSharing: any;
  feeShaingEnumtype: number = 0;
  feesharingTypeAPIresponse = new feeSharingDetailsResponsemodel();
  //currentUser  = this.appSettings.loggedInUserName;
  enableEditablefield: boolean = false;
  formGroupFeeSharing: FormGroup | undefined
  customFeesharingData: saveCustomFeeSharingTypeDetails[] = [];
  checkInvoiceAllocation: boolean = false;
  formGroup: FormGroup | undefined;

  currentUser = this.appSettings.loggedInUserName;
  totalFeeSharingDataSource: feeSharingKendoDataSourceModel[] = [];
  feeSharingResponseModel = new feeSharingDetailsResponsemodel();

  // billingEntityColumnconfig: columnConfig[] = []
  engagementWiseFeeSharingData: engagementWiseFeeSharingDetailsModel[] = [];
  @Input() eafCalculationKendoDataSource: EAFCalculationKendoDataSource[] = [];
  @Input() engagementSummaryDetails = new engagementSummaryModel();
  @Input() billingEntitySummaryDetails = new billingEntitySummaryModel();
  @Input() feeSharingDataSource: feeSharingKendoDataSourceModel[] = [];
  @Input() feesharingDynamicKendoDatasource: any = [];
  @Input() billingEntityColumnconfig: columnConfig[] = [];
  engagementSummary = new engagementSummaryModel();
  billingEntitySummary = new billingEntitySummaryModel();
  feeSharing = new feeSharingModel();
  etcToBeProcessedValue = [true, false];
  //feesharingDynamicKendoDatasource: any = [];
  readOnly : boolean = false;
  constructor(private sanitizer: DomSanitizer, private billingSummaryservice: billingSummaryService, private wrkspacecommonservice: workspaceCommonService, private appSettings: AppSettings, private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    
    this.wrkspacecommonservice.readonly.subscribe(result=>{
      this.readOnly= result;
     })
     
   
  }
  ngOnChanges(): void {
    this.engagementSummary = this.engagementSummaryDetails;
    this.billingEntitySummary = this.billingEntitySummaryDetails;
    

  }

  public getDataItemValue(dataItem: any, item: columnConfig) {
    return dataItem[item.field];
  }
  public colorCode(dataItem: any, item: columnConfig): SafeStyle {
    let result;

    if (dataItem.engagementId == "Total" && item.templateDropDown == true) {
      result = "#FF0000";
    }
    else {
      result = "";
    }
    // console.log('dataaitem',dataItem)
    return this.sanitizer.bypassSecurityTrustStyle(result);
  }

  TotalColorChange(dataItem: any) {
    let result;
    if (dataItem.engagementId == 'Total' && this.checkInvoiceAllocation == true) {
      result = "#FF0000";
    }
    else if (dataItem.checkInvoiceAllocation == true) {
      result = "#FCED02";
    }
    else {
      result = "";
    }
    return this.sanitizer.bypassSecurityTrustStyle(result);
  }


  cellClickHandlerFeeSharing(_$event: any) {
    let readOnly = localStorage.getItem('readonly');
    let workspaceReadOnly = this.wrkspacecommonservice.WorkSpaceTracker.readonly;
    if (_$event.isEdited || (this.formGroup && !this.formGroup.valid) || workspaceReadOnly ||readOnly =='true' || this.readOnly) {
      return;
    }

    // this.saveEafCalculationData(dataItem);
    if (this.enableEditablefield) {
      //  this.saveCustomDetails(dataItem);
      let formgroup: FormGroup;
      //let 
      let dataItem = (this.eventGridFeesharing) ? this.eventGridFeesharing.dataItem : _$event.dataItem;
      this.getCustomEntityWieFeeSharing(dataItem);
      if (this.formGroupFeeSharing == undefined && this.formGroupFeeSharing == null && _$event.dataItem.engagementId !== "Total") {
        formgroup = new FormGroup({
          gId: new FormControl()
        });
        this.formGroupFeeSharing = formgroup;
      }
      this.billingEntitySummary.entityInvoiceDetails.forEach((item: entityInvoiceDetailsData) => {
        this.formGroupFeeSharing = this.createFormGroupFeeSharing(formgroup, item, _$event.dataItem);
      });
      // this.formGroupFeeSharing = this.createFormGroupFeeSharing(_$event.dataItem);
      this.editedRowIndexFeeSharing = _$event.rowIndex;
      this.eventGridFeesharing = _$event;
      _$event.sender.editRow(_$event.rowIndex, this.formGroupFeeSharing);
    }

  }
  createFormGroupFeeSharing(formGroup: FormGroup, Item: entityInvoiceDetailsData, dataItem: any) { //dataItem: feeSharingKendoDataSourceModel

    let formcolumn = (Item.billingEntityName) ? Item.billingEntityName : "NameNotInitialized";
    let value = dataItem[formcolumn]; //billingchange id
    formGroup.addControl(formcolumn, new FormControl(value));
    return formGroup;

  }
  getFeeSharingType(feeSharingType: any) {
    this.feeSharing.feeSharingType = feeSharingType.id;
    this.enableEditablefield = (feeSharingType.id == 3) ? true : false;
    if (feeSharingType.id == 3) {

      this.feeSharingDataSource.map(i => {
        i.editable = false;
      })

    }
    else {
      this.checkInvoiceAllocation = false;
      if (this.formGroupFeeSharing !== undefined && this.formGroupFeeSharing !== null) {
        this.eventGridFeesharing.sender.closeRow(this.editedRowIndexFeeSharing);
        this.editedRowIndexFeeSharing = undefined;
        this.formGroupFeeSharing = undefined;
      }
      this.feesharingDynamicKendoDatasource.forEach((i: any) => i.checkInvoiceAllocation = false);
      this.billingEntityColumnconfig.forEach(i => i.templateDropDown = false);
      this.feeSharingDataSource.map(i => {
        i.editable = true;
      })

    }
    this.GetFeeSharingDetails();
  }

  onEngagementWiseCustomChange(data: feeSharingKendoDataSourceModel, _event: any, entityIndex: number, rowIndex: number) {
    let InvoiceAllocation: number = parseFloat(_event.target.value.trim());
    this.feeSharingDataSource[rowIndex].InvoiceAllocation = InvoiceAllocation;
    let dataItem = data;
    let index: number = this.feesharingDynamicKendoDatasource.map((i: any) => i.engagementId).indexOf(dataItem.Engagement);
    this.feesharingDynamicKendoDatasource[index].totalInvoiceAllocation = InvoiceAllocation;
    let total = 0;
    this.feeSharingDataSource.forEach(i => {
      total = total + i.InvoiceAllocation
    })
    this.checkInvoiceAllocation = (total > this.billingEntitySummary.totalInvoiceFee) ? true : false;
  }
  GetFeeSharingDetails() {

    this.feeSharing.workSpaceMasterGid = this.wrkspaceMasterGuid;
    this.feeSharing.netTotalANSR = this.engagementSummary.netTotalANSR;
    this.feeSharing.netTotalNSR = this.engagementSummary.netTotalNSR;
    this.feeSharing.netTotalExpense = this.engagementSummary.totalExpense;
    this.feeSharing.totalInvoiveFee = this.billingEntitySummary.totalInvoiceFee;

    this.feeSharing.engageMentConsolidatedRevenues = this.engagementSummary.engagementRevenueList.map((i: engagementRevenueModel) => ({
      engagementId: i.engagementId,
      totalNSR: i.netTotalNSR,
      totalANSR: i.netTotalANSR,
      expense: i.totalExpense
    })
    );
    this.feeSharing.entityInvoiceDetails = this.billingEntitySummary.entityInvoiceDetails.map((i: entityInvoiceDetailsData) => ({
      billingEntityId: i.billingEntityName,
      billingEntityName: i.billingEntityName,
      invoiceFee: i.invoiceFee

    })
    );

    this.billingSummaryservice.getFeeSharingDetailsAPI(this.feeSharing).subscribe((feeSharingDetailsResponse: feeSharingDetailsResponsemodel) => {
      console.log("Fee Sharing Details ==> ", feeSharingDetailsResponse)
      let feesharingAPIresponse: feeSharingDetailsResponsemodel = feeSharingDetailsResponse;
      this.feesharingTypeAPIresponse = feeSharingDetailsResponse;
      //this.feesharingDynamicKendoDatasource = [];
      feesharingAPIresponse.engagementWiseFeeSharingDetails.forEach(element => {
        let index: number = this.feeSharingDataSource.map(i => i.Engagement).indexOf(element.engagementId);
        this.feeSharingDataSource[index].InvoiceAllocation = element.totalInvoiceAllocation;

        //Eaf calculation Engagement invoice mapping
        let indx: number = this.eafCalculationKendoDataSource.map(i => i.engagementId).indexOf(element.engagementId);
        this.eafCalculationKendoDataSource[indx].CurrentinvoiceSales = element.totalInvoiceAllocation;
        let result: number = this.feesharingDynamicKendoDatasource.map((item: any) => item.engagementId).indexOf(element.engagementId);

        this.feesharingDynamicKendoDatasource[result].totalInvoiceAllocation = element.totalInvoiceAllocation;
        this.feesharingDynamicKendoDatasource[result].customInvoiceAllocationGId = element.customInvoiceAllocationGId;

        //let itemToAdd: any = { "engagementId": element.engagementId, "totalInvoiceAllocation": element.totalInvoiceAllocation }
        element.entityInvoiceDetails.forEach(item => {
          this.feesharingDynamicKendoDatasource[result][item.billingEntityName] = item.invoiceFee;
          this.feesharingDynamicKendoDatasource[result]['gId'] = item.gId;
        });
      });
    }, (error) => {
      // Handle Error
      console.log(error);

    });
  }
  getCustomEntityWieFeeSharing(dataItem: any) {
    if (this.formGroupFeeSharing !== undefined && this.formGroupFeeSharing !== null) {
      let rowTotalInvoiceAllocation = 0;
      let index: number = this.feesharingDynamicKendoDatasource.map((i: any) => i.engagementId).indexOf(dataItem.engagementId);
      this.billingEntitySummary.entityInvoiceDetails.forEach((item: entityInvoiceDetailsData) => {
        let formcolumn = (item.billingEntityName) ? item.billingEntityName : "NameNotInitialized";
        let formValue = this.formGroupFeeSharing?.controls[formcolumn].value;
        this.feesharingDynamicKendoDatasource[index][formcolumn] = (formValue != "" || formValue != null) ? formValue : this.feesharingDynamicKendoDatasource[index][formcolumn];
        let total = 0;
        this.feesharingDynamicKendoDatasource.forEach((i: any) => {
          if (i.engagementId !== "Total") {
            total = total + i[formcolumn];
          }
        })
        //column by validation check
        let length = this.feesharingDynamicKendoDatasource.length - 1;
        let indx = this.billingEntityColumnconfig.map(i => i.field).indexOf(formcolumn);
        if (total > this.feesharingDynamicKendoDatasource[length][formcolumn]) {
          let index = this.billingEntityColumnconfig.map(i => i.field).indexOf(formcolumn);
          this.billingEntityColumnconfig[index].templateDropDown = true;
        }
        else {
          this.billingEntityColumnconfig[indx].templateDropDown = false;
        }
        //row wise validation check
        rowTotalInvoiceAllocation += dataItem[formcolumn];
      })
      dataItem['checkInvoiceAllocation'] = (rowTotalInvoiceAllocation > dataItem.totalInvoiceAllocation) ? true : false;

      this.eventGridFeesharing.sender.closeRow(this.editedRowIndexFeeSharing);
      this.editedRowIndexFeeSharing = undefined;
      this.formGroupFeeSharing = undefined;
    }

  }

  saveCustomDetails(dataItem ?: any) {

    if (this.formGroupFeeSharing != undefined && this.formGroupFeeSharing != null) {
      this.getCustomEntityWieFeeSharing(dataItem);
    }
    this.customFeesharingData = [];
    this.feeSharingDataSource.forEach(item => {
      let saveCustomFeeSharingDetail: saveCustomFeeSharingTypeDetails = new saveCustomFeeSharingTypeDetails();
      let index = this.feesharingDynamicKendoDatasource.map((i: any) => i.engagementId).indexOf(item.Engagement);
      let EngagementgId = this.feesharingDynamicKendoDatasource[index].customInvoiceAllocationGId;
      saveCustomFeeSharingDetail.gId = (EngagementgId) ? EngagementgId : null;
      saveCustomFeeSharingDetail.createdBy = this.currentUser;
      saveCustomFeeSharingDetail.modifiedBy = (EngagementgId) ? this.currentUser : null;//this.currentUser;
      saveCustomFeeSharingDetail.engagementId = item.Engagement;
      saveCustomFeeSharingDetail.invoiceAllocation = item.InvoiceAllocation;
      saveCustomFeeSharingDetail.workSpaceDetailMasterGId = this.wrkspaceMasterGuid;

      if (index > -1) {
        this.billingEntitySummary.entityInvoiceDetails.forEach((i: entityInvoiceDetailsData) => {
          let customEnitywiseInvoice = new eitityWiseCustomInvoiceAllocationDetails();
          let formcolumn = (i.billingEntityName) ? i.billingEntityName : "NameNotInitialized"; //chnage to id

          let formValue = this.feesharingDynamicKendoDatasource[index][formcolumn];
          customEnitywiseInvoice.billingEntityID = i.billingEntityId;
          customEnitywiseInvoice.billingEntityName = i.billingEntityName;
          customEnitywiseInvoice.customInvoiceAllocationId = 0; // need to ask which id
          customEnitywiseInvoice.invoiceAllocation = formValue;
          let gId = this.feesharingDynamicKendoDatasource[index]['gId'];
          customEnitywiseInvoice.modifiedBy = (gId) ? this.currentUser : null;
          customEnitywiseInvoice.createdBy = this.currentUser;
          customEnitywiseInvoice.gId = (gId) ? gId : null;
          saveCustomFeeSharingDetail.eitityWiseCustomInvoiceAllocationDetails.push(customEnitywiseInvoice);
          //this.feesharingDynamicKendoDatasource[index][formcolumn] = (formValue!="" || formValue!=null)? formValue :this.feesharingDynamicKendoDatasource[index][formcolumn];
        })
      }
      this.customFeesharingData.push(saveCustomFeeSharingDetail);
      console.log("customData", this.customFeesharingData);
    })
  }
  saveCustomFeeSharingDetails() {
    if(this.feeSharing.feeSharingType==feeSharingTypeEnum.Custom){
      this.spinner.show();
      if (this.formGroupFeeSharing != undefined && this.formGroupFeeSharing != null) 
        this.saveCustomDetails(this.eventGridFeesharing.dataItem);
        else
        this.saveCustomDetails();
     
      this.billingSummaryservice.saveCustomFeeSharingDetaislAPI(this.customFeesharingData).subscribe(result => {
        console.log(result);
        this.spinner.hide();
  
      },
        (error) => {
          // Handle Error
          console.log(error);
          this.spinner.hide();
        });
  
    }
  }
}
