import { Component, OnChanges, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { entityInvoiceDetailsData } from 'src/app/models/BillingSummaryModel/feeSharing/entityInvoiceDetailsData';
import { invoiceKendoDataSource } from 'src/app/models/InvoiceModel/invoiceKendoDataSource';
import { workspaceCommonService } from 'src/app/services/CommonService/workspaceCommonService';
import { InvoiceDetailsService } from 'src/app/services/InvoiceDetails/invoiceDetailsServices';
import { DatePipe, Location } from '@angular/common';
import { NgxSpinnerService } from 'ngx-spinner';
import { Router } from '@angular/router';
import { saveInvoiceDetailModel } from 'src/app/models/InvoiceModel/saveInvoiceDetailModel';
import { AppSettings } from 'src/app/services/CommonService/app-settings';

@Component({
  selector: 'app-invoice-details',
  templateUrl: './invoice-details.component.html',
  styleUrls: ['./invoice-details.component.scss'],
  providers: [InvoiceDetailsService, DatePipe]
})
export class InvoiceDetailsComponent implements OnInit {

  currentDate = new Date();
  todayDate: string | null = '';
  wrkspaceMasterGuid: string = "";
  invoiceDetails: any[] = []
  billingEntityDetails : entityInvoiceDetailsData[] =[]
  invoiceDetailsForm: FormGroup = new FormGroup({});
  hasChange: boolean = false;
  invoiceDetailsDataSource : saveInvoiceDetailModel[] = [];
  billingEntityData: entityInvoiceDetailsData[] = [];
  isFormCreated = false;
  readOnly: boolean=false;
  constructor(private wrkspacecommonservice: workspaceCommonService, private fb: FormBuilder, private commonservice : workspaceCommonService, private invoiceDetailsService: InvoiceDetailsService, private datePipe: DatePipe, private spinner: NgxSpinnerService, private router: Router, private location: Location, private appSettings: AppSettings) { }

  ngOnInit(): void {
    let readonly : string | null  = localStorage.getItem('readonly');
    this.wrkspacecommonservice.readonly.subscribe((result:boolean)=>{
      this.readOnly= result;
      console.log('invoice',result)
     })
    this.readOnly =( this.readOnly || readonly=='true' || this.wrkspacecommonservice.WorkSpaceTracker.readonly ) ? true : false;
    this.wrkspaceMasterGuid = this.wrkspacecommonservice.workspaceMasterGuid;
    this.todayDate = this.datePipe.transform(new Date(), 'yyyy-MM-dd');
    this.invoiceDetailsForm = this.fb.group({
      invoiceForm: this.fb.array([])
    })
    this.billingEntityDetails = this.commonservice.billingEntityDetails;
    this.billingEntityData = this.wrkspacecommonservice.billingEntityDetails;
    this.getInvoiceDetails();
  }

  getInvoiceDetails() {
      this.invoiceDetailsService.getInvoiceDetails(this.wrkspaceMasterGuid).subscribe((data) => {
      this.invoiceDetails = data;
      this.createForm();
      console.log(this.invoiceDetailsForm)
    }) 
    console.log(this.invoiceDetailsForm)
  }

  createForm() {
    if(this.invoiceDetails.length > 0) {
      for(let i = 0; i < this.invoiceDetails.length; i++) {
        console.log(this.invoiceDetails[i].preApprovalRequired)
        const formArr = <FormArray>this.invoiceDetailsForm.controls['invoiceForm'];
      formArr.push(new FormGroup({
        
        entityId: new FormControl({value: this.invoiceDetails[i].entityId, disabled: this.readOnly}),
        entityName: new FormControl({value :this.invoiceDetails[i].entityName,disabled: this.readOnly}),
        workSpaceDetailMasterGId: new FormControl(this.wrkspaceMasterGuid),
        gId: new FormControl(this.invoiceDetails[i].gId),
        invoiceType: new FormControl({value: this.invoiceDetails[i].invoiceType, disabled: this.readOnly}),
        processingDate: new FormControl({value: this.invoiceDetails[i].processingDate?.split('T')[0], disabled: this.readOnly}),
        invoiceLanguage: new FormControl({value :this.invoiceDetails[i].invoiceLanguage,disabled: this.readOnly}),
        startDate: new FormControl({value : this.invoiceDetails[i].periodStartData.split('T')[0], disabled: this.readOnly}),
        endDate: new FormControl({value : this.invoiceDetails[i].periodEndData.split('T')[0], disabled: this.readOnly}),
        clientName: new FormControl({value : this.invoiceDetails[i].clientName,disabled: this.readOnly}),
        clientAddress: new FormControl({value : this.invoiceDetails[i].clientAddress,disabled: this.readOnly}),
        clientContactName: new FormControl({value :this.invoiceDetails[i].clientContactName,disabled: this.readOnly}),
        netAmount: new FormControl({value : this.invoiceDetails[i].netAmount, disabled: this.readOnly}),
        techFeePercent: new FormControl({value : this.invoiceDetails[i].tFeesPercentage, disabled: this.readOnly}),
        coordinationFee: new FormControl({value :this.invoiceDetails[i].coordinationFee,disabled: this.readOnly}),
        totalAmount: new FormControl({value: this.invoiceDetails[i].totalAmountExVat, disabled: this.readOnly}),
        vatAmount: new FormControl({value : this.invoiceDetails[i].vatAmount, disabled: this.readOnly}),
        totalAmountWithVat: new FormControl({ value : this.invoiceDetails[i].totalAmountIncVat, disabled: this.readOnly}),
        invoiceCurrency: new FormControl({value: this.invoiceDetails[i].currency, disabled: this.readOnly}),
        invoiceDescription: new FormControl({value : this.invoiceDetails[i].description, disabled: this.readOnly}),
        costCenter: new FormControl({value : this.invoiceDetails[i].costCenter, disabled: this.readOnly}),
        preApprovalRequired: new FormControl({value :this.invoiceDetails[i].preApprovalRequired, disabled: this.readOnly}),
        mailInvoice: new FormControl({value :this.invoiceDetails[i].mailingAddress,disabled: this.readOnly}),
        allocation: new FormControl({value : this.invoiceDetails[i].totalInvoiceAllocation,disabled: this.readOnly}),
        comments: new FormControl({value :this.invoiceDetails[i].comments,disabled: this.readOnly}),
      }))
     }
    }
    else {
      for(let i = 0; i < this.billingEntityData.length; i++) {
        const formArr = <FormArray>this.invoiceDetailsForm.controls['invoiceForm'];
      formArr.push(new FormGroup({
        
        entityId: new FormControl({value: '', disabled: this.readOnly}),
        entityName: new FormControl({value: '', disabled: this.readOnly}),
        workSpaceDetailMasterGId: new FormControl(this.wrkspaceMasterGuid),
        gId: new FormControl(null),
        invoiceType: new FormControl({value: 0, disabled: this.readOnly}),
        processingDate: new FormControl({value: '', disabled: this.readOnly}),
        invoiceLanguage: new FormControl({value: 0, disabled: this.readOnly}),
        startDate: new FormControl({value: '', disabled: this.readOnly}),
        endDate: new FormControl({value: '', disabled: this.readOnly}),
        clientName: new FormControl({value: '', disabled: this.readOnly}),
        clientAddress: new FormControl({value: '', disabled: this.readOnly}),
        clientContactName: new FormControl({value: '', disabled: this.readOnly}),
        netAmount: new FormControl({value: 0, disabled: this.readOnly}),
        techFeePercent: new FormControl({value: 0, disabled: this.readOnly}),
        coordinationFee: new FormControl({value: 0, disabled: this.readOnly}),
        totalAmount: new FormControl({value: 0, disabled: this.readOnly}),
        vatAmount: new FormControl({value: 0, disabled: this.readOnly}),
        totalAmountWithVat: new FormControl({value: 0, disabled: this.readOnly}),
        invoiceCurrency: new FormControl({value: 0, disabled: this.readOnly}),
        invoiceDescription: new FormControl({value: '', disabled: this.readOnly}),
        costCenter: new FormControl({value: '', disabled: this.readOnly}),
        preApprovalRequired: new FormControl(true),
        mailInvoice: new FormControl({value: '', disabled: this.readOnly}),
        allocation: new FormControl({value: 0, disabled: this.readOnly}),
        comments: new FormControl({value: '', disabled: this.readOnly}),
      }))
  
     }
    }
    this.isFormCreated = true;
  }

  saveInvoiceDetails () {
    this.createSaveInvoiceDetailsObject();
    this.spinner.show();
     this.invoiceDetailsService.saveInvoiceDetails(this.invoiceDetailsDataSource).subscribe(data => {
      console.log(data);
      this.isFormCreated = false;
      this.getInvoiceDetails();
      this.spinner.hide();
    }, error => {
      this.spinner.hide();
    })
  }

  createSaveInvoiceDetailsObject() {
    this.invoiceDetailsDataSource = [];
    this.invoiceDetailsForm.controls['invoiceForm'].value.forEach((element: any) => {
      let invoiceDetailsDataModel  = new saveInvoiceDetailModel();
      invoiceDetailsDataModel.gId = element.gId;
      invoiceDetailsDataModel.workSpaceDetailMasterGId = element.workSpaceDetailMasterGId;
      invoiceDetailsDataModel.entityId = element.entityId;
      invoiceDetailsDataModel.entityName = element.entityName;
      invoiceDetailsDataModel.clientAddress = element.clientAddress;
      invoiceDetailsDataModel.clientName = element.clientName;
      invoiceDetailsDataModel.clientContactName = element.clientContactName;
      invoiceDetailsDataModel.comments = element.comments;
      invoiceDetailsDataModel.coordinationFee = element.coordinationFee;
      invoiceDetailsDataModel.costCenter = element.costCenter;
      invoiceDetailsDataModel.currency = Number(element.invoiceCurrency);
      invoiceDetailsDataModel.description = element.description;
      invoiceDetailsDataModel.invoiceLanguage = Number(element.invoiceLanguage);
      invoiceDetailsDataModel.invoiceType = Number(element.invoiceType);
      invoiceDetailsDataModel.mailingAddress = element.mailInvoice;
      invoiceDetailsDataModel.netAmount = element.netAmount;
      invoiceDetailsDataModel.periodEndData = new Date(element.endDate).toISOString();
      invoiceDetailsDataModel.periodStartData = new Date(element.startDate).toISOString();
      invoiceDetailsDataModel.preApprovalRequired = JSON.parse(element.preApprovalRequired);
      invoiceDetailsDataModel.processingDate = new Date(element.processingDate).toISOString();
      invoiceDetailsDataModel.tFeesPercentage = element.techFeePercent;
      invoiceDetailsDataModel.totalAmountExVat = element.totalAmount;
      invoiceDetailsDataModel.totalAmountIncVat = element.totalAmountWithVat;
      invoiceDetailsDataModel.totalInvoiceAllocation = element.allocation;
      invoiceDetailsDataModel.vatAmount = element.vatAmount;
      invoiceDetailsDataModel.modifiedDateTime = new Date().toISOString();
      invoiceDetailsDataModel.modifiedBy = this.appSettings.loggedInUserName;
      console.log(invoiceDetailsDataModel)
      this.invoiceDetailsDataSource.push(invoiceDetailsDataModel);
    });   
    
  }
  navigateToAnnexePreview() {
    this.router.navigate(['/annexe-preview'])
  }

  backButton() {
    this.location.back();
  }
}
