import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { clientService } from 'src/app/services/LandingPage/clientService';
import { wrkspaceDetail } from 'src/app/models/LandingPageModel/wrkspaceDetail';
import { FormControl, Validators } from '@angular/forms';
import { NgxSpinnerService } from "ngx-spinner";
import { ViewEncapsulation } from '@angular/core';
import { workspaceCommonService } from 'src/app/services/CommonService/workspaceCommonService';
import { workspaceTrackingModel } from 'src/app/models/WorkSpaceModel/workspaceTrackingModel';
import { sessionService } from 'src/app/services/CommonService/sessionService';
import { workSpaceUISessionDetails } from 'src/app/models/WorkSpaceModel/workSpaceUISessionDetails';
import { UIStageEnum } from 'src/app/enums/UIStageEnum';
import { existingWrkspaceColumn } from 'src/app/columnConfiguration/ExistingWrkspaceColumn';
import { columnConfig } from 'src/app/columnConfiguration/columnInterface';
import { existingWrkspaceModel } from 'src/app/models/WorkSpaceModel/existingWrkspaceModel';
import { MsalService } from '@azure/msal-angular';
import { AppSettings } from 'src/app/services/CommonService/app-settings';
import { currentUserModel } from 'src/app/models/LandingPageModel/currentUserModel';
import { workspaceStatus } from 'src/app/data/workspaceStatus';
import { workspaceStatusEnum } from 'src/app/enums/workspaceStatus';
import { engagementModel } from 'src/app/models/LandingPageModel/engagementModel';

@Component({
  selector: 'app-landing',
  templateUrl: './landing.component.html',
  styleUrls: ['./landing.component.scss'],
  encapsulation: ViewEncapsulation.None,
  providers: [clientService]
})
export class LandingComponent implements OnInit {

  existingWorkspaceColumn: columnConfig[] = existingWrkspaceColumn;
  isDisabledEngagement: boolean = true;
  clientData: any[] = [];
  showEngagementData: engagementModel[] = [];
  isWorkspaceExisted: boolean = false;
  isWorkspaceValid: boolean = true;
  engagementDetails: string = "";
  clientDetails: string = "";
  openWorkSpaceModal: boolean = false;
  isDisabledWorkSpace: boolean = true;
  clientId: string = "";
  clientEngagementMapGIds: string[] = [];
  selectedEngagementIDs: string[] = [];
  beOneWorkflowIdExisted: string = "";
  workspaceNameExisted: string = "";
  beWorkdflowId = new FormControl('', [Validators.required, Validators.maxLength(15)]);
  workspaceName = new FormControl('', [Validators.required, Validators.maxLength(15)]);
  isexistingWrkspaceFlag: boolean = false;
  existingwrkspaceDetails: existingWrkspaceModel[] = [];
  loggedInUserName: string | undefined;
  currentuser = new currentUserModel();
  constructor(private sessionservice: sessionService, private auth: MsalService, private appSettings: AppSettings, private route: Router, private clientAPI: clientService, private spinner: NgxSpinnerService, private commonservice: workspaceCommonService) { }


  ngOnInit(): void {
    this.sessionservice.clearSessionData().subscribe(() => {
      console.log("session clear");
    }, (error) => {
      // Handle Error
      console.log(error);
    });

    this.clientAPI.getAllClientListData().subscribe(element => {
      this.clientData.push(element.sort((a: any, b: any) => a.clientName.localeCompare(b.clientName)));
    }, (error) => {
      // Handle Error
      console.log(error);
    });
    this.loggedInUserName = this.appSettings.loggedInUserName;
    this.currentuser = this.commonservice.currentUser;

    //clearing data in commonservice file
    this.commonservice.AllWorkSpaceCategoryData = [];
    this.commonservice.AllWorkSpaceCategoryData = [];
  }

  GetworkspaceStatus(dataItem: number) {
    let status = workspaceStatus.filter(i => i.id == dataItem).map(j => j.value);
    return status;

  }

  handleClientChange(value: any) {
    this.showEngagementData = [];
    this.engagementDetails = '';
    this.clientId = value.clientId;
    this.clientAPI.getAllEngagementListData(value.clientId).subscribe((allEngagement: engagementModel[]) => {
      this.showEngagementData = allEngagement;
      this.isDisabledEngagement = false;
    }, (error) => {
      // Handle Error
      console.log(error);
    });
  }

  public closeWorkspace() {
    this.openWorkSpaceModal = false;
    this.isexistingWrkspaceFlag = false;

  }

  handleEngagementChange(value: engagementModel) {


    this.isDisabledWorkSpace = (value.gId && this.engagementDetails.length>0) ? false : true;
    if(!value.sameopportunityId ){
      this.showEngagementData.forEach(item => {
        item.sameopportunityId = (value.opportunityId === item.opportunityId) ? false : true;
  
      })
    }
    if(this.engagementDetails.length==0)
    {
      this.showEngagementData.forEach(item => {
        item.sameopportunityId = false 
  
      })
    }
   

  }

  createWorkspace() {
    this.spinner.show();
    let currentUser: string | undefined | null = (this.currentuser) ? this.currentuser.name : null;
    let workspaceDetail: wrkspaceDetail = new wrkspaceDetail(this.workspaceName.value, this.clientEngagementMapGIds, this.beWorkdflowId.value);
    workspaceDetail.createdBy = currentUser;
    this.clientAPI.createWorkSpaceApi(workspaceDetail).subscribe(workspaceGId => {
      this.openWorkSpaceModal = false;
      let workspacetrackerData = new workspaceTrackingModel();
      workspacetrackerData.workspaceId = workspaceGId;
      workspacetrackerData.workSpaceName =  this.workspaceName.value;
      workspacetrackerData.selectedEngagementIDS = this.engagementDetails;
      workspacetrackerData.clientName = this.clientDetails;
      workspacetrackerData.readonly = false;
  
      let interval: any;
      interval = setInterval(() => this.clientAPI.isReadyDataApi(workspaceGId).subscribe(isBillingDataReady => {
        if (isBillingDataReady) {
          if (interval) {
            clearInterval(interval);
          }
          this.wrkspaceSessionDetails(workspacetrackerData);

        }
      }, (error) => {
        console.log(error);
      }), (Math.random() * 10000));

    }, (error) => {
      // Handle Error
      console.log(error);
    });

  }


  onTextChange() { // checking mandatory fields
    if (this.beWorkdflowId.status == "VALID" && this.workspaceName.status == "VALID") {
      this.isWorkspaceValid = false;
    }
    else {
      this.isWorkspaceValid = true;
    }
  }
  startWorkSpace() {
    const that = this;
    this.clientEngagementMapGIds = [];
    for (var i = 0; i < this.engagementDetails.length; i++) {
      if (this.engagementDetails[i] != '') {
        this.showEngagementData.find(function (element: any) {
          if (element.engagementId === that.engagementDetails[i]) {
            that.clientEngagementMapGIds.push(element.gId);
            that.selectedEngagementIDs.push(element.engagementId);

          }

        })
      }
    }
    let clientEngagementMapGIds = that.clientEngagementMapGIds.join(',');

    this.clientAPI.IsWorkSpaceAlreadyExist(clientEngagementMapGIds).subscribe((existingWrkspace: existingWrkspaceModel[]) => {

      if (existingWrkspace.length > 0) {
        this.isexistingWrkspaceFlag = true;
        this.existingwrkspaceDetails = existingWrkspace;
      }
      else {
        this.openWorkSpaceModal = true;
      }
    })
  }
  navigatewrkSpacePage(dataItem: existingWrkspaceModel,) {
    let readOnly: boolean = false;
    if (dataItem.statusId == workspaceStatusEnum.InvoiceCompleted) {
      readOnly = true;
      this.commonservice.readonly.next(true);
      localStorage.setItem("readonly", 'true');
    }
    else {
      readOnly = false;
      this.commonservice.readonly.next(false);
      localStorage.setItem("readonly", 'false');
    }
    let workspacetrackerData = new workspaceTrackingModel();
    workspacetrackerData.workspaceId = dataItem.workSpaceGuid;
    workspacetrackerData.workSpaceName = dataItem.workspaceName;
    workspacetrackerData.selectedEngagementIDS = dataItem.engagementIds;
    workspacetrackerData.clientName = this.clientDetails;
    workspacetrackerData.readonly = readOnly;
    this.wrkspaceSessionDetails(workspacetrackerData);


  }

  wrkspaceSessionDetails(workspaceDetails: workspaceTrackingModel) {

    //Update Angular Service
   
    this.commonservice.WorkSpaceTracker = workspaceDetails;

    let wrkSpaceUISessionDetails: workSpaceUISessionDetails = new workSpaceUISessionDetails(UIStageEnum.Home, workspaceDetails.workspaceId, this.clientId, workspaceDetails.workSpaceName, workspaceDetails.clientName, workspaceDetails.selectedEngagementIDS.split(','),[]);

    this.sessionservice.saveSessionData(wrkSpaceUISessionDetails).subscribe(item => {
      console.log('saveDataclient session');
      this.spinner.hide();
      this.route.navigate(['./workspace']);
    }, (error) => {
      // Handle Error
      console.log(error);
    });
  }

}




