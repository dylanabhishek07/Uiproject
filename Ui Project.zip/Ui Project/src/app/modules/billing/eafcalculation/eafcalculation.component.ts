import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { billsummeryEngagmentEAFDeatils } from 'src/app/models/BillingSummaryModel/EAFCalculation/billsummeryEngagmentEAFDeatils';
import { EAFCalculationKendoDataSource } from 'src/app/models/BillingSummaryModel/EAFCalculation/EAFCalculationKendoDataSource';
import { EAFCalculationResponse } from 'src/app/models/BillingSummaryModel/EAFCalculation/EAFCalculationResponse';

import { billingSummaryService } from 'src/app/services/BillingSummary/billingSummaryService';
import { AppSettings } from 'src/app/services/CommonService/app-settings';
import { workspaceCommonService } from 'src/app/services/CommonService/workspaceCommonService';

@Component({
  selector: 'app-eafcalculation',
  templateUrl: './eafcalculation.component.html',
  styleUrls: ['./eafcalculation.component.scss']
})
export class EAFCalculationComponent implements OnInit, OnChanges {
  @Input() eafCalculationKendoDataSourceDetails: EAFCalculationKendoDataSource[] = [];
  eafCalculationKendoDataSource: EAFCalculationKendoDataSource[] = [];
  @Input() wrkspaceMasterGuid: string = "";
  @Input() eafAPIResponse = new EAFCalculationResponse();

  formGroup: FormGroup | undefined;
  eventGrid: any;
  private editedRowIndex: any;
  readOnly: boolean =false;

  constructor(private billingSummaryservice: billingSummaryService, private wrkspacecommonservice: workspaceCommonService, private appSettings: AppSettings, private spinner: NgxSpinnerService) { }

  ngOnInit(): void {
    this.wrkspacecommonservice.readonly.subscribe(result=>{
      this.readOnly= result;
      console.log("subject", result);
     })

  }

  ngOnChanges(): void {
  
    this.eafCalculationKendoDataSource = this.eafCalculationKendoDataSourceDetails;

    if (this.eafAPIResponse.workspaceMasterGid != null || this.eafAPIResponse.workspaceMasterGid != "") {
      this.BindEAFDetails(this.eafAPIResponse);
    }

  }

  calculateRevisedEAF() {
    this.eafCalculationKendoDataSource.map((i: EAFCalculationKendoDataSource) => {
      let CurrentinvoiceSales: number = (i.CurrentinvoiceSales) ? i.CurrentinvoiceSales : 0;
      let CurrentinvoiceCF: number = (i.CurrentinvoiceCF) ? i.CurrentinvoiceCF : 0;
      let CurrentinvoiceMC: number = (i.CurrentinvoiceMC) ? i.CurrentinvoiceMC : 0;

      let denominator: number = (i.etdnsr + i.etcnsr - CurrentinvoiceMC);
      if (denominator == 0) {
        i.RevisedEAF = 0;
      }
      else {
        i.RevisedEAF = (((i.etdInvoices + CurrentinvoiceSales + i.etcSales + CurrentinvoiceCF) - (i.etdExpense - i.etcExpenses)) / (i.etdnsr + i.etcnsr - CurrentinvoiceMC)) - 1;
      }

    })
  }


  BindEAFDetails(eafResponse: EAFCalculationResponse) {
    if (eafResponse.billsummeryEngagmentEAFDeatils != null) {
      eafResponse.billsummeryEngagmentEAFDeatils.map((item: billsummeryEngagmentEAFDeatils) => {
        let eafDetails = new EAFCalculationKendoDataSource();
        eafDetails.gId = item.gId;
        eafDetails.etcSales = item.etcSales;
        eafDetails.engagementId = item.engagementId;
        eafDetails.etdnsr = item.etdnsr;
        eafDetails.etdInvoices = item.etdInvoices;
        eafDetails.nui = item.nui;
        eafDetails.etcnsr = item.etcnsr;
        eafDetails.etcExpenses = item.etcExpenses;
        eafDetails.etcToBeProcessed = item.etcToBeProcessed;
        eafDetails.modifiedBy = item.modifiedBy;
        eafDetails.createdBy = item.createdBy;
        eafDetails.isDeleted = item.isDeleted;
        eafDetails.etdExpense = item.etdExpense;
        this.eafCalculationKendoDataSource.push(eafDetails);
      })
      this.calculateRevisedEAF();
    }



  }

  cellClickHandler(_$event: any) {
    let readOnly = localStorage.getItem('readonly');
    let workspaceReadOnly = this.wrkspacecommonservice.WorkSpaceTracker.readonly;
    if (_$event.isEdited || (this.formGroup && !this.formGroup.valid) || workspaceReadOnly || readOnly=='true' || this.readOnly) {
      return;
    }
    let dataItem: EAFCalculationKendoDataSource = (this.eventGrid) ? this.eventGrid.dataItem : _$event.dataItem;
    this.saveEafCalculationData(dataItem);
    this.formGroup = this.createFormGroupEAFCal(_$event.dataItem);
    this.editedRowIndex = _$event.rowIndex;
    this.eventGrid = _$event;
    _$event.sender.editRow(_$event.rowIndex, this.formGroup);
    this.calculateRevisedEAF();

  }
  saveEafCalculationData(dataItem: EAFCalculationKendoDataSource) {
    let EAFData = new billsummeryEngagmentEAFDeatils();
    if (this.formGroup != undefined && this.formGroup != null) {
      // EAFData = dataItem;
      EAFData.etdnsr = this.formGroup?.controls["etdnsr"].value;
      EAFData.etdExpense = this.formGroup?.controls["etdExpense"].value;
      EAFData.etdInvoices = this.formGroup?.controls["etdInvoices"].value;
      EAFData.nui = this.formGroup?.controls["nui"].value;
      EAFData.etcExpenses = this.formGroup?.controls["etcExpenses"].value;
      EAFData.etcSales = this.formGroup?.controls["etcSales"].value;
      EAFData.etcnsr = this.formGroup?.controls["etcnsr"].value;
      EAFData.etcToBeProcessed = this.formGroup?.controls["etcToBeProcessed"].value;
      EAFData.modifiedBy = this.wrkspacecommonservice.currentUser.name;
      EAFData.isDeleted = false;
      //EAFData.etcToBeProcessed = true;
      EAFData.engagementId = dataItem.engagementId;
      let index: number = this.eafCalculationKendoDataSource.map(i => i.engagementId).indexOf(dataItem.engagementId);
      this.eafCalculationKendoDataSource[index].etdnsr = EAFData.etdnsr;
      this.eafCalculationKendoDataSource[index].etdExpense = EAFData.etdExpense;
      this.eafCalculationKendoDataSource[index].etdInvoices = EAFData.etdInvoices;
      this.eafCalculationKendoDataSource[index].nui = EAFData.nui;
      this.eafCalculationKendoDataSource[index].etcSales = EAFData.etcSales;
      this.eafCalculationKendoDataSource[index].etcExpenses = EAFData.etcExpenses;
      this.eafCalculationKendoDataSource[index].etcnsr = EAFData.etcnsr;
      this.eafCalculationKendoDataSource[index].etcToBeProcessed = EAFData.etcToBeProcessed;

      //this.billsummeryEngagmentEAFDeatils.push(EAFData);
      this.eventGrid.sender.closeRow(this.editedRowIndex);
      this.editedRowIndex = undefined;
      this.formGroup = undefined;
    }
    console.log(this.eafCalculationKendoDataSource);
  }
  createFormGroupEAFCal(dataItem: EAFCalculationKendoDataSource) {
    let formgroup: FormGroup | undefined;

    formgroup = new FormGroup({
      etdnsr: new FormControl(dataItem.etdnsr),
      etdExpense: new FormControl(dataItem.etdExpense),
      etdInvoices: new FormControl(dataItem.etdInvoices),
      nui: new FormControl(dataItem.nui),
      etcnsr: new FormControl(dataItem.etcnsr),
      etcExpenses: new FormControl(dataItem.etcExpenses),
      etcSales: new FormControl(dataItem.etcSales),
      etcToBeProcessed: new FormControl(dataItem.etcToBeProcessed)

    });
    return formgroup;
  }

  saveEAFCustomDetails() {
    this.spinner.show();
    if (this.formGroup != undefined && this.formGroup != null) {
      this.saveEafCalculationData(this.eventGrid.dataItem);
    }
    //let billsummeryEngagmentEAFDeatils :billsummeryEngagmentEAFDeatils[] =[];
    let allEafDetails: billsummeryEngagmentEAFDeatils[] = this.eafCalculationKendoDataSource.map((item: EAFCalculationKendoDataSource) => ({
      engagementId: item.engagementId,
      etdnsr: item.etdnsr,
      etdExpense: item.etdExpense,
      etdInvoices: item.etdInvoices,
      nui: item.nui,
      etcnsr: item.etcnsr,
      etcExpenses: item.etcExpenses,
      etcSales: item.etcSales,
      etcToBeProcessed: item.etcToBeProcessed,
      isDeleted: item.isDeleted,
      createdBy: item.createdBy,
      modifiedBy: item.modifiedBy,
      gId: (item.gId) ? item.gId : null
    })
    );

    let eafDetailsResponse: EAFCalculationResponse = new EAFCalculationResponse();

    eafDetailsResponse.workspaceMasterGid = this.wrkspaceMasterGuid;
    eafDetailsResponse.billsummeryEngagmentEAFDeatils = allEafDetails;

    this.billingSummaryservice.savegetEAFCalculationAPI(eafDetailsResponse).subscribe(data => {

      if (this.eafAPIResponse.workspaceMasterGid != null || this.eafAPIResponse.workspaceMasterGid != "") {
        this.billingSummaryservice.getEAFCalculationAPI(this.wrkspaceMasterGuid).subscribe((eafResponse: EAFCalculationResponse) => {
          eafResponse.billsummeryEngagmentEAFDeatils.map((item: billsummeryEngagmentEAFDeatils) => {
            let index: number = this.eafCalculationKendoDataSource.map(i => i.engagementId).indexOf(item.engagementId);
            this.eafCalculationKendoDataSource[index].gId = item.gId;
            this.spinner.hide();
          });
        },
          (error) => {
            // Handle Error
            console.log(error);
            this.spinner.hide();
          });
      }
    },
      (error) => {
        // Handle Error
        console.log(error);
        this.spinner.hide();
      });
  }

}



