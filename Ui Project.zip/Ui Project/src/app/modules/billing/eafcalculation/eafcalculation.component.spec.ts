import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EAFCalculationComponent } from './eafcalculation.component';

describe('EAFCalculationComponent', () => {
  let component: EAFCalculationComponent;
  let fixture: ComponentFixture<EAFCalculationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EAFCalculationComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EAFCalculationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
