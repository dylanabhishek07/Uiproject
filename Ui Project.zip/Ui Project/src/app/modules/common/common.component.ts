import { Component, OnInit, Input, EventEmitter, Output, ViewEncapsulation, OnChanges, SimpleChanges, AfterViewInit, DoCheck } from '@angular/core';
import { GridDataResult, PageChangeEvent } from '@progress/kendo-angular-grid';
import { CompositeFilterDescriptor, filterBy } from '@progress/kendo-data-query';
import { AdjustedBillingAction } from 'src/app/data/adjustedBillingItem';
import { DataTypeEnum } from 'src/app/enums/DataTypeEnum';
import { workspaceDatasourceType } from 'src/app/enums/workspaceDataSource';
import { workspaceAdjustedData } from 'src/app/models/WorkSpaceModel/workspaceAdjustedData';
import { wrkspaceCommonModal } from 'src/app/models/WorkSpaceModel/wrkspaceCommonModel';


@Component({
  selector: 'app-common',
  templateUrl: './common.component.html',
  styleUrls: ['./common.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class CommonComponent implements OnInit, OnChanges {

  @Input() dataSource: any;
  @Input() coulmnDetails: any;
  @Input() adjustedBillingEntities: any;

  adjustedBillingActionDdl: any[] = [];
  adjustedBillingEntitiesDD: any[] = [];
  wrkspaceCommonData = new wrkspaceCommonModal();
  @Output()

  cellClickHandle = new EventEmitter<any>();
  @Output()

  navigateTimeDetailScreen = new EventEmitter<wrkspaceCommonModal>();
 

  copywrkSpaceAdjustedData: wrkspaceCommonModal[] = [];

  @Output()

  updateIndividualCategoryDataSource = new EventEmitter<any>();
  @Output()

  createFormGroupWorkspacescreen = new EventEmitter<any>();
  @Output()

  wrkspaceadjustedDetails = new EventEmitter<any>();

  @Output()

  copyPreviousEngagementDetailsScreen = new EventEmitter<any>();

  public gridwrkSpaceDetailsData: any[] = [];
  public gridwrkSpaceFilterData: any[] = [];
  wrkspaceadjustedData: workspaceAdjustedData[] = [];
  
  public pageSize = 5;
  public skip = 0;
  public gridView: GridDataResult = {
    data: [],
    total: 0
  }

  public filter: CompositeFilterDescriptor = { logic: 'or', filters: [] }

  constructor() { }

  ngOnInit(): void {
    this.adjustedBillingActionDdl = AdjustedBillingAction.filter((item) => item.isVisible == true);
   
    console.log('ngOnit',this.dataSource);
  }

  ngOnChanges(changes: SimpleChanges): void {
    this.adjustedBillingEntitiesDD = this.adjustedBillingEntities;

    console.log( 'onchange', this.dataSource);
  }
  public filterChange(filter: CompositeFilterDescriptor): void {
    if (filter.filters.length > 0) {
      this.filter = filter;
     
    }
   
  }
  // private loadItems(): void {
  //   this.gridView = {
  //     data: this.dataSource.slice(this.skip, this.skip + this.pageSize),
  //     total: this.gridTimeDetailsData.length,
  //   };
  // }
  // public pageChange(event: PageChangeEvent): void {
  //   this.skip = event.skip;
  //   this.loadItems();
  // }
  findAdjustedBillingArrayIndex(value: any, isAdjustedBillingEntity: boolean): number {
    let arrayindex: number = 0;
    if(!isAdjustedBillingEntity) {
      arrayindex = this.adjustedBillingActionDdl.findIndex(item => item.isVisible == true && item.value == value);
    }
    else {
      if(value == null) return 0;
      else {
        arrayindex = this.adjustedBillingEntitiesDD.findIndex((item:any) => item.id == value)
      }
    }
    return arrayindex;
  }
  cellClickHandler(_$event: any) {

    this.cellClickHandle.emit(_$event);
    
  }

  wrkSapceDuplicateDataCreation(dataItem: wrkspaceCommonModal) {

    let wrkspaceAdjusted = new workspaceAdjustedData();
    wrkspaceAdjusted.gId = dataItem.gId
    wrkspaceAdjusted.workSpaceDataType = dataItem.dataType;
    wrkspaceAdjusted.adjustedInvoiceFee = this.copywrkSpaceAdjustedData[0].adjustedInvoiceFee;
    wrkspaceAdjusted.adjustedCurrency = this.copywrkSpaceAdjustedData[0].adjustedCurrency;
    wrkspaceAdjusted.adjustedDescription = this.copywrkSpaceAdjustedData[0].adjustedDescription;
    wrkspaceAdjusted.adjustedBillingAction = this.copywrkSpaceAdjustedData[0].adjustedBillingAction;
    wrkspaceAdjusted.modifiedDateTime = null;
    wrkspaceAdjusted.productID = (dataItem.productId) ? dataItem.productId : "";
    wrkspaceAdjusted.serviceDescription = (dataItem.serviceDescription) ? dataItem.serviceDescription : "";
    wrkspaceAdjusted.costCenter = (dataItem.costCenter) ? dataItem.costCenter : "";
    wrkspaceAdjusted.GBTRef = (dataItem.gbtRef) ? dataItem.gbtRef : "";

    if (dataItem.dataType !== DataTypeEnum.Expense) {

      wrkspaceAdjusted.adjustedBillingEntityId = this.copywrkSpaceAdjustedData[0].adjustedBillingEntityId;
      //wrkspaceAdjusted.adjustedBillingEntity = this.adjustedBillingEntities.filter(item => item.id === wrkspaceAdjusted.adjustedBillingEntityId)[0].name; //aditya work here 

    }

    if (dataItem.dataType == DataTypeEnum.Adhoc || dataItem.dataType == DataTypeEnum.Uncoded) {
      wrkspaceAdjusted.adjustedCostCenter = this.copywrkSpaceAdjustedData[0].adjustedCostCenter;
      wrkspaceAdjusted.adjustedOOSNR = this.copywrkSpaceAdjustedData[0].adjustedOOSNR;
      wrkspaceAdjusted.adjustedGBTStatus = this.copywrkSpaceAdjustedData[0].adjustedGBTStatus;
      wrkspaceAdjusted.adjustedGBTRef = this.copywrkSpaceAdjustedData[0].adjustedGBTRef;
    }
    return wrkspaceAdjusted;

  }
  copyPreviousEngagementDetails(dataItem:any)
  {
    let dataitem: wrkspaceCommonModal = dataItem;
    if (this.copywrkSpaceAdjustedData.length > 0) {
      if ( dataitem.dataType == this.copywrkSpaceAdjustedData[0].dataType) {
        
        if (this.filter.filters.length>0) {
        
          this.gridwrkSpaceFilterData = filterBy(this.dataSource, this.filter);
          console.log('gridFilter', this.gridwrkSpaceFilterData);
        }
        else {
          this.gridwrkSpaceFilterData = [];
        }
        this.gridwrkSpaceFilterData.forEach(item=>{
          let createDuplicateData = this.wrkSapceDuplicateDataCreation(item);
          this.updateIndividualCategoryDataSource.emit(item);
          let gid = item.gId;
          this.createFormGroupWorkspacescreen.emit(dataitem);
          let objIndex = this.wrkspaceadjustedData.findIndex((obj: workspaceAdjustedData) => obj.gId == gid);
          if (this.wrkspaceadjustedData.length > 0 && objIndex > -1) {
            this.wrkspaceadjustedData[objIndex] = createDuplicateData;
          }
          else {
            this.wrkspaceadjustedData.push(createDuplicateData);
          }
        })
       
        this.wrkspaceadjustedDetails.emit(this.wrkspaceadjustedData);
        // this.eventGrid.sender.closeRow(this.editedRowIndex);
        // this.eventGrid.dataItem.copyTO = false;
        // this.editedRowIndex = undefined;
        // this.formGroup = undefined;
      }

      else {
        this.copywrkSpaceAdjustedData[0] = dataitem;
        
      }
      
    }
    else {
      this.copywrkSpaceAdjustedData.push(dataitem);
      this.copyPreviousEngagementDetails(dataitem);
    }
    //this.copyPreviousEngagementDetailsScreen.emit(dataItem);

  }
  
  navigetTimeDetails(dataitem: wrkspaceCommonModal) {
    this.navigateTimeDetailScreen.emit(dataitem);
  }
}


