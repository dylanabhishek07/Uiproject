import { columnConfig } from "./columnInterface"
export const workspaceBillableColumns : columnConfig[]= [
    
    {
        field : "billingItemId",
        title : "Item",
        type: "numeric",
        width: 200,
        templateButton : true,
        hidden : false,
        filterable: false
    },
    
    {
        field : "billingActionName",
        title : "Billing Action",
        type: "text",
        width: 200,
        hidden : false,
        filterable: true
    },
    {
        field : "adjustedBillingAction",
        title : "Adjusted Billing Action",
        type : "text",
        width: 200, 
        templateDropDown : true,
        hidden : false,
        filterable: true
        
       
    },
    {
        field : "clientName",
        title : "Client Name",
        type: "date",
        width: 130,
        hidden : false,
        filterable: true
    },

    {
        field : "employee",
        title : "Employee",
        type: "text",
        width: 130,
        hidden : false,
        filterable: true
    },
    {
        field : "productId",
        title : "Product ID",
        type: "text",
        width: 80,
        hidden : false,
        filterable: true
    },
    {
        field : "product",
        title : "Product",
        type: "text",
        width: 150,
        hidden : false,
        filterable: true
    },
    {
        field : "productType",
        title : "Product Type",
        type: "text",
        hidden : false,
        width : 150,
        filterable: true
    },
    {
        field : "productStatus",
        title : "Product Status",
        type: "text",
        hidden : false,
        width : 130,
        filterable: true
    },
    {
        field : "billingType",
        title : "Billing Type",
        type: "text",
        hidden : false,
        width : 130,
        filterable: true
    },
    

    {
        field : "feeType",
        title : "Fee Type",
        type: "text",
        hidden : false,
        width : 100,
        filterable: true
    },
    {
        field : "billingStatus",
        title : "Billing Status",
        type: "text",
        hidden : false,
        width : 130,
        filterable: true
    },
    {
        field : "hours",
        title : "Hours",
        type: "text",
        hidden : false,
        width : 80,
        filterable: true
    },
    {
        field : "nsr",
        title : "NSR",
        type: "text",
        hidden : false,
        width : 80,
        filterable: true
    },
    {
        field : "ansr",
        title : "ANSR",
        type: "text",
        hidden : false,
        width : 80,
        filterable: true
    },
      {
        field : "expenseAmount",
        title : "Expenses",
        type: "text",
        hidden : false,
        width : 100,
        filterable: true
    },
    {
        field : "invoiceFee",
        title : "Invoice Fee",
        type: "text",
        hidden : false,
        width : 100,
        filterable: true
    },
    {
        field : "adjustedInvoiceFee",
        title : "Invoice Fee Adj",
        type: "numeric",
        hidden : false,
        width : 130,
        editable : true,
        filterable: true
    },
    {
        field : "currency",
        title : "Currency",
        type: "text",
        hidden : false,
        width : 80,
        filterable: true
    },
    {
        field : "adjustedCurrency",
        title : "Currency Adj",
        type: "text",
        hidden : false,
        width : 130,
        editable : true,
        filterable: true
    },
    {
        field : "serviceDescription",
        title : "Service Description",
        type: "text",
        hidden : false,
        width : 180,
        filterable: true
    },
    {
        field : "adjustedDescription",
        title : "Description Adjustment",
        type: "text",
        hidden : false,
        width : 200,
        editable : true,
        filterable: true
    },
    {
        field : "billingEntity",
        title : "Billing Entity",
        type: "text",
        hidden : false,
        width : 180,
        filterable: true
    },
    {
        field : "adjustedBillingEntity",
        title : "Billing Entity Adjustment",
        type: "text",
        hidden : false,
        width : 180,
        templateDropdownEntity: true,
         editable : true,
        filterable: true
    },
    {
        field : "costCenter",
        title : "Cost Center",
        type: "text",
        hidden : false,
        width : 100,
        filterable: true
    },

    {
        field : "oosNr",
        title : "OOS nr",
        type: "text",
        hidden : false,
        width : 100,
        filterable: true
    },
    {
        field : "gbtStatus",
        title : "GBT Status",
        type: "text",
        hidden : false,
        width : 100,
        filterable: true
    },
    {
        field : "gbtRef",
        title : "GBT Ref",
        type: "text",
        hidden : false,
        width : 100,
        filterable: true
    },
    {
        field : "dataType",
        title : "dataType",
        type: "text",
        hidden : true,
        width : 100,
        filterable: true
    },
    {
        field : "gid",
        title : "gid",
        type: "text",
        hidden : true,
        width : 100,
        filterable: true
    }

]

export const workspaceAdHoc_Uncoded_Columns : columnConfig[]= [
    
    {
        field : "billingItemId",
        title : "Item",
        type: "numeric",
        width: 200,
        templateButton : true,
        hidden : false,
        filterable: false
    },
    {
        field : "adjustedBillingAction",
        title : "Billing Action",
        type: "text",
        width: 200,
        hidden : false,
        templateDropDown : true,
        filterable: true
    },
    {
        field : "activityName",
        title : "Activity",
        type: "text",
        width: 130, 
       
        hidden : false,
        filterable: true
       
    },
    {
        field : "adjustedDescription",
        title : "Service Description",
        type: "text",
        width: 200,
        hidden : false,
        filterable: true
    },
    {
        field : "adjustedInvoiceFee",
        title : "Fee",
        type: "numeric",
        hidden : false,
        width : 130,
        filterable: true
    },
    {
        field : "adjustedCurrency",
        title : "Currency",
        type: "text",
        hidden : false,
        width : 100,
        filterable: true
    },
    {
        field : "adjustedBillingEntity",
        title : "Bill To",
        type: "text",
        hidden : false,
        templateDropdownEntity: true,
        width : 130,
        filterable: true
    },
    {
        field : "adjustedCostCenter",
        title : "Cost Center",
        type: "text",
        hidden : false,
        width : 100,
        filterable: true
    },

    {
        field : "adjustedOOSNR",
        title : "OOS nr",
        type: "text",
        hidden : false,
        width : 100,
        filterable: true
    },
    {
        field : "adjustedGBTStatus",
        title : "GBT Status",
        type: "text",
        hidden : false,
        width : 100,
        filterable: true
    },
    {
        field : "adjustedGBTRef",
        title : "GBT Ref",
        type: "text",
        hidden : false,
        width : 100,
        filterable: true
    },
    
    {
        field : "hours",
        title : "Hours",
        type: "text",
        hidden : false,
        width : 80,
        filterable: true
    },
    {
        field : "nsr",
        title : "NSR",
        type: "text",
        hidden : false,
        width : 80,
        filterable: true
    },
    {
        field : "ansr",
        title : "ANSR",
        type: "text",
        hidden : false,
        width : 80,
        filterable: true
    },
      {
        field : "expenses",
        title : "Expenses",
        type: "text",
        hidden : false,
        width : 100,
        filterable: true
    },
    {
        field : "dataType",
        title : "dataType",
        type: "text",
        hidden : true,
        width : 100,
        filterable: true
    },
    {
        field : "gid",
        title : "gid",
        type: "text",
        hidden : true,
        width : 100,
        filterable: true
    }

]

export const workspaceExpenseColumn: columnConfig[]=[
    {
        field : "billingItemId",
        title : "Item",
        type: "numeric",
        width: 200,
        templateButton : true,
        hidden : false,
        filterable: false
    },
    {
        field : "adjustedBillingAction",
        title : "Billing Action",
        type: "text",
        width: 200,
        hidden : false,
        templateDropDown : true,
        filterable: true
    },
    {
        field : "invoiceRefrences",
        title : "Invoice Refrences",
        type: "text",
        width: 130, 
        hidden : false,
        filterable: true
       
    },
    
    {
        field : "invoiceVendor",
        title : "Invoice Vendor",
        type: "text",
        hidden : false,
        width : 100,
        filterable: true
    },
    {
        field : "expenseAmount",
        title : "Invoice Fee",
        type: "text",
        hidden : false,
        width : 130,
        filterable: true
    },
    {
        field : "adjustedDescription",
        title : "Service Description",
        type: "text",
        width: 200,
        hidden : false,
        filterable: true
    },
    {
        field : "adjustedInvoiceFee",
        title : "Fee",
        type: "numeric",
        hidden : false,
        width : 130,
        filterable: true
    },
    {
        field : "adjustedCurrency",
        title : "Currency",
        type: "text",
        hidden : false,
        width : 100,
        filterable: true
    },

    {
        field : "dataType",
        title : "dataType",
        type: "text",
        hidden : true,
        width : 100,
        filterable: true
    },
    {
        field : "gid",
        title : "gid",
        type: "text",
        hidden : true,
        width : 100,
        filterable: true
    }

]