import { columnConfig } from "./columnInterface";

export class columnModel implements columnConfig{
    field: string;
    title: string;
    templateDropDown?: boolean;
    templateButton? : boolean;
    type : "text" | "numeric" | "boolean" | "date" ;
    width: number;
    hidden : boolean;
    editable ?: boolean;
    filterable: boolean

    constructor()
    {
        this.field="";
        this.title="";
        this.type="text";
        this.width=150;
        this.hidden=false;
        this.filterable=false;
    }

}