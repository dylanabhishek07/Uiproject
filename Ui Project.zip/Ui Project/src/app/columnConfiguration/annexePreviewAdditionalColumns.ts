import { columnConfig } from "./columnInterface";

export const AnnexePreviewAdditionalColumns : columnConfig[] = [
    {
        field: 'employee',
        title: 'Employee Name',
        type: 'text',
        hidden: true,
        filterable: false,
        width: 200
    },
    {
        field: 'product',
        title: 'Product',
        type: 'text',
        hidden: true,
        filterable: false,
        width: 200
    },
    {
        field: 'productType',
        title: 'Product type',
        type: 'text',
        hidden: true,
        filterable: false,
        width: 200
    },
    {
        field: 'hours',
        title: 'Hours',
        type: 'numeric',
        hidden: true,
        filterable: false,
        width: 200
    },
    {
        field: 'costCenter',
        title: 'Cost Center',
        type: 'text',
        hidden: true,
        filterable: false,
        width: 200
    },
    {
        field: 'oosnr',
        title: 'OOS nr',
        type: 'text',
        hidden: true,
        filterable: false,
        width: 200
    },
    {
        field: 'gbtRef',
        title: 'GBT ref',
        type: 'text',
        hidden: true,
        filterable: false,
        width: 200
    }, 
    {
        field: 'gbtStatus',
        title: 'GBT Status',
        type: 'text',
        hidden: true,
        filterable: false,
        width: 200
    },
]