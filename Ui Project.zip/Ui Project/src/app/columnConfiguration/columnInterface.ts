export interface columnConfig  {
    field: string;
    title: string;
    templateDropDown?: boolean;
    templateButton? : boolean;
    type : "text" | "numeric" | "boolean" | "date" ;
    width: number;
    hidden : boolean;
    editable ?: boolean;
    filterable: boolean;
    templateDropdownEntity? : boolean;
    value ? : number;

     
  }