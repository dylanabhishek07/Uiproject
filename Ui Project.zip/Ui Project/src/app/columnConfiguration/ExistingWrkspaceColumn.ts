import { columnConfig } from "./columnInterface";

export const existingWrkspaceColumn : columnConfig[] = [
    {
        field : "workspaceName",
        title : "Work Space Name",
        type: "text",
        width: 150,
        templateButton : true,
        hidden : false,
        filterable: true
    },
    {
        field : "engagementIds",
        title : "Engagement ID",
        type: "text",
        width: 200,
        hidden : false,
        filterable: true
    },
    {
        field : "statusId",
        title : "Status",
        type : "text",
        width: 200, 
        hidden : false ,
        filterable: true ,
        templateDropDown : true
       
    },
]
