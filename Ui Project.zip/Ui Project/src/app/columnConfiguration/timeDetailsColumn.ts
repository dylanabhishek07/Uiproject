import { columnConfig } from "./columnInterface";

export const timeDetailsColumns : columnConfig[] = [
    {
        field : "transferTo",
        title : "Tranfer To",
        type: "text",
        width: 200,
        templateDropDown : true,
        hidden : false,
        filterable: false
    },
    {
        field : "engagementName",
        title : "Engagement Name",
        type: "text",
        width: 150,
        templateButton : true,
        hidden : false,
        filterable: true
    },
    {
        field : "transactionDate",
        title : "Transaction Date ",
        type: "date",
        width: 150,
        hidden : false,
        filterable: true
    },
    {
        field : "employeeName",
        title : "Employee Name",
        type: "text",
        width: 150, 
        hidden : false,
        filterable: true
    },
    {
        field : "rank",
        title : "Rank ",
        type: "text",
        width: 80,
        hidden : false,
        filterable: true
    },
    {
        field : "country",
        title : "Country",
        type: "text",
        hidden : false,
        width : 80,
        filterable: true
    },
    {
        field : "chargedHours",
        title : "Charged Hours/Quantity",
        type: "text",
        hidden : false,
        width : 80,
        filterable: true
    },
    {
        field : "chargedHoursDescription",
        title : "Charged Hours/Quantity Description",
        type: "text",
        hidden : false,
        width : 150,
        filterable: true
    },
    {
        field : "nsr",
        title : "NSR/Tech Revenue",
        type: "text",
        hidden : false,
        width : 100,
        filterable: true
    },

    {
        field : "nsrRate",
        title : "NSR/Tech Revenue Rate",
        type: "text",
        hidden : false,
        width : 100,
        filterable: true
    },
    {
        field : "ansr",
        title : "ANSR/Tech Revenue",
        type: "text",
        hidden : false,
        width : 100,
        filterable: true
    },
    {
        field : "eaf",
        title : "EAF Reserve Allocation",
        type: "text",
        hidden : false,
        width : 150,
        filterable: true
    },
    
    {
        field : "activityName",
        title : "Activity Code Description",
        type: "text",
        hidden : false,
        width : 150,
        filterable: true
    },
    {
        field : "accountingDate",
        title : "Accounting Date",
        type: "text",
        hidden : false,
        width : 100,
        filterable: true
    },
    {
        field : "expenseAmount",
        title : "Expense Amount",
        type: "text",
        hidden : false,
        width : 100,
        filterable: true
    },
    {
        field : "expensesDescription",
        title : "Expense Description",
        type: "text",
        hidden : false,
        width : 150,
        filterable: true
    },
    {
        field : "vendorName",
        title : "Vendor Name/ID",
        type: "text",
        hidden : false,
        width : 100,
        filterable: true
    },

    {
        field : "guid",
        title : "guid",
        type: "text",
        hidden : true,
        width : 80,
        filterable: true
    }

]