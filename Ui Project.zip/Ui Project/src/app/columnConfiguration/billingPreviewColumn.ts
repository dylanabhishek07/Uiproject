export const billingPreviewColumns = [
 "Fee",
 "Currency",
 "Description"

]


