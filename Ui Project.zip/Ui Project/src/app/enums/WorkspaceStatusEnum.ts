export enum WorkspaceStatusEnum {
    Review = 2,
    Approve = 3
}