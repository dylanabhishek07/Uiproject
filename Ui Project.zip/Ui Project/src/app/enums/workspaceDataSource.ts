export const workspaceDatasource = {
    billableItems: 'billable',
    additionalBillingData: 'additionalBilling',
    nonBillableData: 'nonBillable',
    adhocData: 'adhoc',
    uncodedData: 'uncoded',
    expensesData: 'expenses'
};

export const workspaceDatasourceType = [
    {id : 1, name : 'billable'},
    {id : 2, name :  'additionalBilling'},
    {id : 3, name : 'nonBillable'},
    {id : 4, name :  'adhoc'},
    {id : 5, name :  'uncoded'},
    {id : 6, name :  'expenses'}
];