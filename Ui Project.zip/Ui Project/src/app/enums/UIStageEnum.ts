export enum UIStageEnum {
    None=0,
    Home=1,
    Workspace=2,
    Summery=3,
    Invoice=4,
    Complete=5
  }