export enum DataTypeEnum {
    None = 0,
    Billable = 1,
    AdditionalBillingOppertunity = 2,
    NonBillable = 3,
    Adhoc = 4,
    Uncoded = 5, 
    Expense = 6
  }