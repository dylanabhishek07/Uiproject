export enum workspaceStatusEnum {
    None = 0,
    BillPreparation = 1,
    InReview = 2,
    InvoiceInProgress = 3,
    InvoiceCompleted = 4,
    ErrorProcessing = 5
}