export enum feeSharingTypeEnum {
    ProData= 1,
    EqualEAF=2,
    Custom =3 
}