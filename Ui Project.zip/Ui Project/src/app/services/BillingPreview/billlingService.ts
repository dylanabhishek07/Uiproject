import { Injectable } from '@angular/core';
import { Observable,  of  } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { workspaceCommonService } from '../CommonService/workspaceCommonService';
import { utilityService } from '../CommonService/utilityService';
import { complexData } from 'src/app/data/billingPreviewItem';


@Injectable()

export class billingService {

    constructor(private http: HttpClient, private service: workspaceCommonService, private utilityservice: utilityService) {

    }

    allBillingPreviewItemsApi(): Observable<any> {
        let allData: any[] = complexData;
        let dataFromServiceFile = this.service.AllWorkSpaceCategoryData
        let allBillingData = allData.map((i: any) => ({ Fee: (i.adjustedInvoiceFee) > -1 ? i.adjustedInvoiceFee : i.invoiceFee, Currency: i.currency, Description: i.adjustedDescription, DataType: i.dataType }))

        return of(allBillingData);
        //return  this.utilityservice.getItemWithToken("");

    }

    gridDataAdjuest(): Observable<any> {
        return of()
    }
    additionalBillingApi(): Observable<any> {

        return this.utilityservice.getItemWithToken("");

    }

    nonBillableHours(): Observable<any> {

        return this.utilityservice.getItemWithToken("");

    }

}

