import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { ModifyWorkspaceStatus } from "src/app/models/AnnexePreviewModel/modifyWorkspaceStatus";
import { SaveAnnexePreviewModel } from "src/app/models/AnnexePreviewModel/saveAnnexePreviewModel";
import { utilityService } from "../CommonService/utilityService";

@Injectable()

export class AnnexePreviewService {

    constructor(private utilityService: utilityService) {}

    getAnnexePreviewData(workSpaceGuid: string) : Observable<any> {
        let url = "AnnexePreview/GetBillingEntityWiseAnnexPreviewData?workspaceMasterGId=" + workSpaceGuid;
        return this.utilityService.getItemWithToken(url);
    }
    
    getAnnexOptionalColumns() : Observable<any> {
        let url = "AnnexePreview/GetAnnexOptionalColumns";
        return this.utilityService.getItemWithToken(url);
    }

    saveAnnexePreviewFeeData(data: SaveAnnexePreviewModel) : Observable<any> {
        let url = "AnnexePreview/SaveAnnexPreviewData";
        return this.utilityService.saveItemWithToken(url,data);
    }

    modifyWorkspaceStatus(data: ModifyWorkspaceStatus): Observable<any> {
        let url = "AnnexePreview/ModifyWorkSpaceStatus";
        return this.utilityService.saveItemWithToken(url,data);
    }
}