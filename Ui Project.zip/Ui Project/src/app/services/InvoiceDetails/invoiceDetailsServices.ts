import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { saveInvoiceDetailModel } from "src/app/models/InvoiceModel/saveInvoiceDetailModel";
import { utilityService } from "../CommonService/utilityService";

@Injectable()

export class InvoiceDetailsService {
    constructor(private utilityService: utilityService) {}

    getInvoiceDetails(workSpaceGuid: string) : Observable<any> {
        let url = "InvoiceDetail/GetInvoiceDetails?workspaceMasterGId=" + workSpaceGuid;
        return this.utilityService.getItemWithToken(url);
    }

    saveInvoiceDetails(data: saveInvoiceDetailModel[]) : Observable<any> {
        let url = "InvoiceDetail/SaveInvoiceDetails";
        return this.utilityService.saveItemWithToken(url,data);
    }
}