import { Injectable } from '@angular/core';
import { Observable, from, of, observable } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { btTimeDetailsTransferModel } from '../../models/BillingPreviewModel/btTimeDetailTransferModel';
import { calculatedWorkspaceTimeExpenseModel } from 'src/app/models/WorkSpaceModel/calculatedWorkspaceTimeExpenseModel';
import { utilityService } from '../CommonService/utilityService';

@Injectable()

export class timeDetailsService {

  constructor(private http: HttpClient  ,private utilityservice : utilityService) {
    
  }


  timeDetailsItemsApi(workSpaceGuid: String): Observable<any> {

    let url = 'WorkSpaceManagement/GetTimeDetails?workSpaceGuid=' + workSpaceGuid;
    return this.utilityservice.getItemWithToken(url);


  }

  TranferTneDataToOtherCategory(btTimeDetailsTransferModel: btTimeDetailsTransferModel[]): Observable<any> {

    //let body = JSON.stringify(btTimeDetailsTransferModel);
    let url = 'WorkSpaceManagement/TransferTNEDataToOtherCategory';
    return this.utilityservice.saveItemWithToken(url, btTimeDetailsTransferModel);

  }

  calculateWorkspaceTimeExpenseAPI(calculatedWorkspaceTimeExpenseModelData: calculatedWorkspaceTimeExpenseModel[]): Observable<any> {
    let url = 'WorkSpaceManagement/GetConsolidatedTimeDetailsForItems';
    return this.utilityservice.saveItemWithToken(url, calculatedWorkspaceTimeExpenseModelData);
  }


}