import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import * as adjustedBillingItems from '../data/adjustedBillingItem.json'
import { utilityService } from '../CommonService/utilityService';
import { workSpaceUISessionDetails } from '../../models/WorkSpaceModel/workSpaceUISessionDetails';
import { wrkspaceCommonModal } from '../../models/WorkSpaceModel/wrkspaceCommonModel';
import { map } from 'rxjs/operators';

@Injectable()

export class workspaceService {
    constructor(private utilityservice: utilityService) {

    }
    getWorkspaceData(workSpaceMasterGuid: String):Observable<wrkspaceCommonModal[]> {
        // let sampledata : wrkspaceCommonModal[] = []; 
        // sampledata.push(new wrkspaceCommonModal ());
        // console.log(sampledata);
        let url = 'WorkSpaceManagement/GetBillingDetails?workspaceMasterGId=' + workSpaceMasterGuid;
        //let url = 'WorkSpaceManagement/GetBillingDetails?workspaceGId=' + "211fd844-2154-ec11-9977-a864f19bbed1"
        return this.utilityservice.getItemWithToken(url)
        // .pipe(
        //     map(((response) =>{
        //         console.log(response);
        //         return response;
        //         // let workSpaceData = response.map(item=>{
        //         //     return new wrkspaceCommonModal(
                        
        //         //     )
        //         // })
        //         // return workSpaceData;
        //     } ))
        // )
        //return of (complexData)
    }
    saveGridDataAPI(saveGridData: workSpaceUISessionDetails): Observable<any> {
        let url = 'WorkSpaceManagement/SaveWorkSpace';
        return this.utilityservice.saveItemWithToken(url, saveGridData);
    }

    createAdhocRow(workSpaceMasterGuid:string, createdBy: string | undefined): Observable<any>{
        //return  of ("9cf34bd1-9274-ec11-8043-502f9b7d84de");
        let url = 'WorkSpaceManagement/CreateAdhocGuid?wrkSpaceGuid='+ workSpaceMasterGuid + '&createdBy=' + createdBy;
        return this.utilityservice.getItemWithToken(url);
    }
}