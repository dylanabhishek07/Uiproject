import { Injectable } from '@angular/core';
import { Observable  } from 'rxjs';

import { utilityService } from './utilityService';
import { workSpaceUISessionDetails } from '../../models/WorkSpaceModel/workSpaceUISessionDetails';
import { map } from 'rxjs/internal/operators/map';

@Injectable()
export class sessionService {

    constructor( private utilityservice : utilityService) {
      
    }

    clearSessionData() : Observable<any>{
        let url= 'SessionManagement/Clear';
        return this.utilityservice.getItemWithToken(url);
    }

    saveSessionData(saveSessionDetails :workSpaceUISessionDetails ):  Observable<any>{
        let url= 'SessionManagement/SaveWorkSpaceUIDetails';
        return this.utilityservice.saveItemWithToken(url,saveSessionDetails);
    }

    getWorkspaceUIdetails() : Observable<workSpaceUISessionDetails>{
        let url= 'SessionManagement/GetWorkSpaceUIDetails'
        return this.utilityservice.getItemWithToken(url)
        // .pipe(
        //     map(((response) =>{
        //         console.log(response);
        //         let workSpaceUISessionData: workSpaceUISessionDetails=  new workSpaceUISessionDetails(
        //                 response.stage,
        //                 response.workspaceMasterGid,
        //                 response.clientGId,
        //                 response.workspaceName,
        //                 response.clientName,
        //                 response.engagements,
        //                 response.workSpaceAdjustedDetails
        //             )

        //         return workSpaceUISessionData;
        //         //return response as workSpaceUISessionDetails;
        //     } ))
        // )
    }
}