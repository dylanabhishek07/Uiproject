import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { wrkSpaceSpecificTneData } from '../../models/WorkSpaceModel/wrkSpaceSpecificTneData';
import { calculatedWorkspaceTimeExpenseModel } from '../../models/WorkSpaceModel/calculatedWorkspaceTimeExpenseModel';
import { workspaceAdjustedData } from '../../models/WorkSpaceModel/workspaceAdjustedData';
import { workspaceTrackingModel } from '../../models/WorkSpaceModel/workspaceTrackingModel';
import { billingTimeTrackerModel } from '../../models/BillingPreviewModel/billingTimeTrackerModel';
import { wrkspaceCommonModal } from '../../models/WorkSpaceModel/wrkspaceCommonModel';
import { columnConfig } from 'src/app/columnConfiguration/columnInterface';
import { workspaceAdHoc_Uncoded_Columns, workspaceBillableColumns, workspaceExpenseColumn } from 'src/app/columnConfiguration/workspaceColumns';
import { currentUserModel } from 'src/app/models/LandingPageModel/currentUserModel';
import { billingEntitySummaryModel } from 'src/app/models/BillingSummaryModel/feeSharing/billingEntitySummaryModel';
import { entityInvoiceDetailsData } from 'src/app/models/BillingSummaryModel/feeSharing/entityInvoiceDetailsData';
import { BehaviorSubject, Subject } from 'rxjs';

@Injectable()

export class workspaceCommonService {

    timeDetailsData: wrkSpaceSpecificTneData[] = [];
    private allworkSpaceCategoryData: wrkspaceCommonModal[] = [];
    private billingtimeDetailTracker = new billingTimeTrackerModel();
    private workspaceTracker = new workspaceTrackingModel();
    private allAdjustedData: workspaceAdjustedData[] = [];
    private wrkspaceMasterId : string="";
    private wrkspaceStatusId : number = 0;
    private workspaceColumns: columnConfig[] = workspaceBillableColumns;
    private workspaceAdhoc_UncodedColumns: columnConfig[] = workspaceAdHoc_Uncoded_Columns;
    private workspaceExpenseColumns: columnConfig[] = workspaceExpenseColumn;

    private currentUserDetails = new  currentUserModel() ;

    private billingEntityName : entityInvoiceDetailsData[]= [];

    private calculatedWorkspaceTimeExpenseModelData: calculatedWorkspaceTimeExpenseModel[] = [];
     public get workspaceMasterGuid(): string{
         return this.wrkspaceMasterId;
     }

     public set workspaceMasterGuid(value : string){
         this.wrkspaceMasterId= value;
     }

     public get workspaceStatusId(): number{
        return this.wrkspaceStatusId;
    }

    public set workspaceStatusId(value : number){
        this.wrkspaceStatusId= value;
    }

    public get CalculatedWorkspaceTimeExpenseModelData(): calculatedWorkspaceTimeExpenseModel[] {
        return this.calculatedWorkspaceTimeExpenseModelData;
    }
    public set CalculatedWorkspaceTimeExpenseModelData(value: calculatedWorkspaceTimeExpenseModel[]) {
        this.calculatedWorkspaceTimeExpenseModelData = value;
    }

    public get AllWorkSpaceCategoryData(): wrkspaceCommonModal[] {
        return this.allworkSpaceCategoryData;
    }
    public set AllWorkSpaceCategoryData(value: wrkspaceCommonModal[]) {
        this.allworkSpaceCategoryData = value;
    }
    public get AllWorkSpaceAdjustedtedData(): workspaceAdjustedData[] {
        return this.allAdjustedData;
    }
    public set AllWorkSpaceAdjustedtedData(value: workspaceAdjustedData[]) {
        this.allAdjustedData = value;
    }
    public get WorkSpaceTracker(): workspaceTrackingModel {
        return this.workspaceTracker;
    }
    public set WorkSpaceTracker(value: workspaceTrackingModel) {
        this.workspaceTracker = value;
    }
    public get BillingTimeDetailsTracker(): billingTimeTrackerModel {
        return this.billingtimeDetailTracker;
    }
    public set BillingTimeDetailsTracker(value: billingTimeTrackerModel) {
        this.billingtimeDetailTracker = value;
    }
    public get WorkspaceColumns(): columnConfig[] {
        return this.workspaceColumns;
    }
    public set WorkspaceColumns(value: columnConfig[]) {
        this.workspaceColumns = value;
    }
    public get WorkspaceAdhoc_UncodedColumns(): columnConfig[] {
        return this.workspaceAdhoc_UncodedColumns;
    }
    public set WorkspaceAdhoc_UncodedColumns(value: columnConfig[]) {
        this.workspaceAdhoc_UncodedColumns = value;
    }
    public get WorkspaceExpenseColumns(): columnConfig[] {
        return this.workspaceExpenseColumns;
    }
    public set WorkspaceExpenseColumns(value: columnConfig[]) {
        this.workspaceExpenseColumns = value;
    }

    public get currentUser(): currentUserModel {
        return this.currentUserDetails;
    }
    public set currentUser(value: currentUserModel) {
        this.currentUserDetails = value;
    }

    public get billingEntityDetails(): entityInvoiceDetailsData[] {
        return this.billingEntityName;
    }
    public set billingEntityDetails(value: entityInvoiceDetailsData[]){
        this.billingEntityName = value;
    }

    readonly = new BehaviorSubject<boolean>(false);
   
    
    constructor(private http: HttpClient) {

    }

}