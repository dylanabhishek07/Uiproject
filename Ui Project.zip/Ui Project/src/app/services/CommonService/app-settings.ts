import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { MsalService } from '@azure/msal-angular';

@Injectable({
    providedIn: 'root'
})
export class AppSettings {
    isUserLoggedIn: BehaviorSubject<boolean> = new BehaviorSubject<boolean>(this.msal.instance.getActiveAccount() == null ? false : true);
    userName = this.msal.instance.getActiveAccount()?.name;
    loggedInUserName: string | undefined = this.userName != undefined ? this.userName.replace(/\./g,' ').replace(/\d+/g, '') : undefined;

    feeSharingType = [
        { id: 1, value: 'Pro-rata' },
        { id: 2, value: 'Equal EAF' },
        { id: 3, value: 'Custom' }
    ];
    constructor(private msal: MsalService) { }
}