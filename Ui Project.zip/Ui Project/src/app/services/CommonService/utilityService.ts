import { Injectable } from '@angular/core';
import { Observable, from, of, observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable()

export class utilityService {

    apiURL = environment.apiURL;
    headers = { 'content-type': 'application/json' };
    constructor(private http: HttpClient) {

    }

    getItemWithToken(url: string): Observable<any> {
        let finalUrl = this.apiURL + url
        // return this.http.get<T>(finalUrl).pipe(map(response => {
             
        //     return response as T
        // }));
        return this.http.get(finalUrl,{withCredentials: true});
    }

    saveItemWithToken(url: string, data: any): Observable<any> {
        let body = JSON.stringify(data);
        let finalUrl = this.apiURL + url;
        return this.http.post(finalUrl, body, { 'headers': this.headers,withCredentials:true });
    }

}