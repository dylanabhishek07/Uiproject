import { Injectable } from '@angular/core';
import { Observable, from, of } from 'rxjs';
import { EAFCalculationResponse } from 'src/app/models/BillingSummaryModel/EAFCalculation/EAFCalculationResponse';
import { feeSharingModel } from 'src/app/models/BillingSummaryModel/feeSharing/feeSharingDetailModel';
import { saveCustomFeeSharingTypeDetails } from 'src/app/models/BillingSummaryModel/feeSharing/saveCustomInvoiceAllocationDetails';
import { utilityService } from '../CommonService/utilityService';


@Injectable()

export class billingSummaryService{

    constructor ( private utilityservice : utilityService)
    {
    }
    getEngagementSummaryAPI(workSpaceGuid: string) : Observable<any>{
        let url = 'BillSummery/GetEngagementSummery?workspaceMasterGId=' + workSpaceGuid;
        return this.utilityservice.getItemWithToken(url);
    }

    getBillingEntitySummaryAPI(workSpaceGuid: string) : Observable<any>{
        let url = 'BillSummery/GetBillingEntitySummery?workspaceMasterGId=' + workSpaceGuid;
        return this.utilityservice.getItemWithToken(url);
    }

    getFeeSharingDetailsAPI(data: feeSharingModel) : Observable<any>{
        let url = 'BillSummery/GetFeeSharingDetails';
        return this.utilityservice.saveItemWithToken(url, data);
    }
    getEAFCalculationAPI(workSpaceGuid: string) : Observable<any>{
        let url = 'BillSummery/GetEAFDetails?workspaceMasterGId=' + workSpaceGuid;
        return this.utilityservice.getItemWithToken(url);
    }
    savegetEAFCalculationAPI(data: EAFCalculationResponse) : Observable<any>{
        let url = 'BillSummery/SaveEAFDetails';
        return this.utilityservice.saveItemWithToken(url, data);
    }

    saveCustomFeeSharingDetaislAPI( data : saveCustomFeeSharingTypeDetails[]) : Observable<any>{
        let url= 'BillSummery/SaveCustomInvoiceAllocationDetails';
        return this.utilityservice.saveItemWithToken(url, data);
    }
}