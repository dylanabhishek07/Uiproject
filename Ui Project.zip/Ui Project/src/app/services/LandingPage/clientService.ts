
import { Injectable } from '@angular/core';
import { Observable, from, of } from 'rxjs';
import { environment } from 'src/environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { workspaceCommonService } from '../CommonService/workspaceCommonService';
import { wrkspaceDetail } from '../../models/LandingPageModel/wrkspaceDetail';
import { utilityService } from '../CommonService/utilityService';
import { existingWrkspaceModel } from '../../models/WorkSpaceModel/existingWrkspaceModel';


// import {client_model} from 'src/app/models/client'
@Injectable()

export class clientService {

    constructor(private httpClient: HttpClient, private service: workspaceCommonService, private utilityservice:utilityService) { }
    

    getAllClientListData(): Observable<any> {
       
        let url= 'ClientManagement/GetClientsByIndex?startIndex=0&count=20'
        return this.utilityservice.getItemWithToken(url);
    }

    getAllEngagementListData(id: string): Observable<any> {

        
        let url ='ClientManagement/GetClientSpecificEngagementsByIndex?clientId='+id+'&startIndex=0&count=20'
        return this.utilityservice.getItemWithToken(url);
        
    }


    createWorkSpaceApi(workSpaceDetail: wrkspaceDetail): Observable<any> {
        const headers = { 'content-type': 'application/json' };
        let apiURL = environment.apiURL;
        let body = JSON.stringify(workSpaceDetail);
        apiURL = apiURL + 'WorkSpaceManagement/CreateWorkSpace'
        return this.httpClient.post(apiURL, body, { 'headers': headers });

    }

    isReadyDataApi(id:string) : Observable<any>
    {
        let apiURL= environment.apiURL;
        apiURL = apiURL + 'WorkSpaceManagement/IsBillingDataReady?workspaceId='+id;
        return this.httpClient.get(apiURL);
    }

    IsWorkSpaceAlreadyExist( clientEngagementMapGIds : string) : Observable<any>
    {
        let apiURL= environment.apiURL;
        apiURL = apiURL + 'WorkSpaceManagement/IsWorkSpaceAlreadyExisting?clientEngagementMapGIds='+clientEngagementMapGIds;
       // return of (existingWorkspacedata);
       return this.httpClient.get(apiURL);
    }

    getClientDetailsWithBillingEntity(mercuryGId: string) {
        let url ='ClientManagement/GetClientDetailsWithBillingEntity?mercuryGId='+mercuryGId;
        return this.utilityservice.getItemWithToken(url);
    }
}


