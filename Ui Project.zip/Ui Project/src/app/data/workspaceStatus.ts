export const workspaceStatus=
 [
    { id: 0, value: 'None' },
    { id: 1, value: 'BillPreparation' },
    { id: 2, value: 'InReview' },
    { id: 3, value: 'InvoiceInProgress' },
    { id: 4, value: 'InvoiceCompleted' },
    { id: 5, value: 'ErrorProcessing' },

];