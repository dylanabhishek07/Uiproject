export const feeSharingType=
 [
    { id: 1, value: 'Pro-rata' },
    { id: 2, value: 'Equal EAF' },
    { id: 3, value: 'Custom' }
];