export const AdjustedBillingAction = 
[
    {
        "text":"Select",
        "value":0,
        "isVisible":true,
    },
    {
        "text":"Invoice Now",
        "value":1,
        "isVisible":true,
    },
    {
        "text":"Carry Forward(CF)",
        "value":2,
        "isVisible":true,
    },
    {
        "text":"Not Billable(WO)",
        "value":3,
        "isVisible":true,
    },
    {
        "text":"Already Billed(AB)",
        "value": 4,
        "isVisible":true,
    },
    {
        "text":"Miscoded(MC)",
        "value":5,
        "isVisible":true,
    }

]