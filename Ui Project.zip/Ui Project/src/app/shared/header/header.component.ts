import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MsalService } from '@azure/msal-angular';
import { AppSettings } from 'src/app/services/CommonService/app-settings';
// import '../../app.component.scss'

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  isUserLoggedIn: boolean = false;
  loggedInUserName: string|undefined;
  constructor(private msalService: MsalService, private appSettings: AppSettings , private router : Router) { 
  }

  ngOnInit(): void {
    this.appSettings.isUserLoggedIn.subscribe((data: boolean) => {
      this.isUserLoggedIn = data;
      this.loggedInUserName = this.isUserLoggedIn? this.appSettings.loggedInUserName: '';
    });
  }

  logout() {
    this.appSettings.isUserLoggedIn.next(false);
    this.loggedInUserName='';
    this.msalService.logout();
    setTimeout(() => {
      this.router.navigate(['/login']);
    }, 9000);
    
    
  }
}
