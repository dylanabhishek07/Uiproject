import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LandingComponent } from './modules/billing/landing/landing/landing.component';
import { CommonModule, DatePipe } from '@angular/common';
// import { LaunchComponent } from './launch/launch.component';
// import { HomeComponent } from './home/home.component';
// import { LoginComponent } from './modules/login/login/login.component';
import { LoginPageComponent } from './modules/login/loginPage/login-page/login-page.component';
import { SharedModule } from './shared/shared.module';
import { InputsModule } from '@progress/kendo-angular-inputs';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DropDownsModule } from '@progress/kendo-angular-dropdowns';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { DialogModule } from '@progress/kendo-angular-dialog';
// import { HomeModule } from './modules/billing/home.module';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ReactiveFormsModule } from '@angular/forms';

import { MatSelectModule } from '@angular/material/select';
import { PreviewComponent } from './modules/billing/preview/preview/preview.component';
import { workspaceCommonService } from './services/CommonService/workspaceCommonService';
import { TimeDetailsComponent } from './modules/billing/timeDetails/time-details/time-details.component';
import { GridModule } from '@progress/kendo-angular-grid';
import { WorkspaceComponent } from './modules/billing/workspace/workspace/workspace.component';
import { NgxSpinnerModule } from "ngx-spinner";
import { utilityService } from './services/CommonService/utilityService';
import { InvoicesComponent } from './modules/billing/invoices/invoices/invoices.component';
import { sessionService } from './services/CommonService/sessionService';
import { CommonComponent } from './modules/common/common.component';
import { SummaryComponent } from './modules/billing/summary/summary/summary.component';
import { MsalBroadcastService, MsalGuard, MsalGuardConfiguration, MsalInterceptor, MsalInterceptorConfiguration, MsalService, MSAL_GUARD_CONFIG, MSAL_INSTANCE, MSAL_INTERCEPTOR_CONFIG } from '@azure/msal-angular';
import { BrowserCacheLocation, InteractionType, IPublicClientApplication, LogLevel, PublicClientApplication } from '@azure/msal-browser';
import { environment } from 'src/environments/environment';
import { MSALGuardConfigFactory, MSALInstanceFactory, MSALInterceptorConfigFactory } from './services/CommonService/MsalAuthenticationService';
import { AnnexePreviewComponent } from './modules/billing/annexe-preview/annexe-preview.component';
import { InvoiceDetailsComponent } from './modules/billing/invoice-details/invoice-details/invoice-details.component';
import { FeeSharingTypeComponent } from './modules/billing/fee-sharing-type/fee-sharing-type.component';
import { EAFCalculationComponent } from './modules/billing/eafcalculation/eafcalculation.component';
/*
const isIE = window.navigator.userAgent.indexOf("MSIE ") > -1 || window.navigator.userAgent.indexOf("Trident/") > -1;

export function loggerCallback(logLevel: LogLevel, message: string) {
  console.log(message);
}

export function MSALInstanceFactory(): IPublicClientApplication {
  return new PublicClientApplication({
    auth: {
      clientId: environment.clientId,
      authority: environment.authority,
      redirectUri:environment.redirectUri
    },
    cache: {
      cacheLocation: BrowserCacheLocation.LocalStorage,
      storeAuthStateInCookie: isIE, // set to true for IE 11
    },
    system: {
      loggerOptions: {
        loggerCallback,
        logLevel: LogLevel.Info,
        piiLoggingEnabled: false
      }
    }
  });
}

export function MSALInterceptorConfigFactory(): MsalInterceptorConfiguration {
  const protectedResourceMap = new Map<string, Array<string>>();
  protectedResourceMap.set('/api/', [environment.scope]);

  return {
    interactionType: InteractionType.Redirect,
    protectedResourceMap
  };
}

export function MSALGuardConfigFactory(): MsalGuardConfiguration {
  return { 
    interactionType: InteractionType.Redirect,
    authRequest: {
      scopes: [environment.scope]
    }
  };
}
*/
@NgModule({
  declarations: [
    AppComponent,
    // LaunchComponent,
    // HomeComponent,
    // LoginComponent,
    //LoginPageComponent,
    LandingComponent,
    PreviewComponent,
    TimeDetailsComponent,
    InvoicesComponent,
    WorkspaceComponent,
    CommonComponent,
    SummaryComponent,
    AnnexePreviewComponent,
    InvoiceDetailsComponent,
    FeeSharingTypeComponent,
    EAFCalculationComponent
  ],
  imports: [
    BrowserModule,
    InputsModule,
    AppRoutingModule,
    DropDownsModule,
    SharedModule,
    FormsModule,
    HttpClientModule,
    CommonModule,
    DialogModule,
    MatInputModule,
    BrowserAnimationsModule,
    MatSelectModule,
    MatFormFieldModule,
    ReactiveFormsModule,
    GridModule,
    NgxSpinnerModule
    // HomeModule
  ],
 
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: MsalInterceptor,
      multi: true
    },
    {
      provide: MSAL_INSTANCE,
      useFactory: MSALInstanceFactory
    },
    {
      provide: MSAL_GUARD_CONFIG,
      useFactory: MSALGuardConfigFactory
    },
    {
      provide: MSAL_INTERCEPTOR_CONFIG,
      useFactory: MSALInterceptorConfigFactory
    },
    MsalService,
    MsalGuard,
    MsalBroadcastService,
    workspaceCommonService, utilityService, sessionService
  ],
  bootstrap: [AppComponent],
  schemas: [
    NO_ERRORS_SCHEMA
  ]
})
export class AppModule { }
