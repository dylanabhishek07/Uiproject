export class timeDataModel {
    GUID : string;
    Hrs : string;
    ANSR : string;
    Expenses : string;
   constructor ( GUID : string, Hrs:string,   ANSR : string, Expenses : string)
   {
    this.GUID = GUID;
    this.Hrs = Hrs;
    this.ANSR= ANSR;
    this.Expenses = Expenses;
   }
    

}
