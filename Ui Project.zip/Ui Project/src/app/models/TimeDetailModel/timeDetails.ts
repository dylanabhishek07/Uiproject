import { timeDataModel } from "./timeData";

export class timeDetails { 
    engagementName: string;
    transactionDate: string;
    employeeName: string;
    rank: string;
    country: string;
    chargedHours: number;
    chargedHoursDescription : string;
    nsr : number;
    nsrRate : number;
    ansr : number;
    eaf : number;
    activityName : string;
    accountingDate : string;
    expenseAmount : number;
    expensesDescription : string;
    vendorName : string;
    guid : string;
    checked: boolean;

    constructor() {
        this.engagementName = "";
        this.transactionDate ="";
        this.employeeName = "";
        this.rank = "";
        this.country = "";
        this.chargedHours = 0;
        this.chargedHoursDescription = "";
        this.nsr = 0;
        this.nsrRate = 0;
        this.ansr = 0;
        this.eaf = 0;
        this.activityName = "";
        this.accountingDate = "";
        this.expenseAmount = 0;
        this.expensesDescription="";
        this.vendorName="";
        this.guid="";
        this.checked=false;
      
    }

}