export class engagementItemModel {

    billingAction: number;
    nsr: number;
    ansr: number;
    expense: number;

    constructor() {
        this.billingAction = 0;
        this.nsr = 0;
        this.ansr = 0;
        this.expense = 0;

    }

}
