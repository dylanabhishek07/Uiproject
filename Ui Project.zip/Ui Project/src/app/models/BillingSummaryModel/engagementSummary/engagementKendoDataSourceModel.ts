export class engagementKendoDataSourceModel {
    BillingAction: number;
    NSR: number;
    ANSR: number;
    Expense: number;
    Name : string;
    EAF : number;

    constructor() {
        this.BillingAction = 0;
        this.NSR = 0;
        this.ANSR = 0;
        this.Expense = 0;
        this.Name='';
        this.EAF= 0;
    }
}