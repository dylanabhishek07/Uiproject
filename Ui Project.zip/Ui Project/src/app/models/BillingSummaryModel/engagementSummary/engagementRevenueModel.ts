import { engagementItemModel } from "./engagementItemModel";

export class engagementRevenueModel {

    engagementId: string;
    totalNSR: number;
    totalANSR: number;
    eaf: number;
    totalExpense: number;
    netTotalNSR: number;
    netTotalANSR: number;
    engagementItems: engagementItemModel[];

    constructor() {
        this.engagementId = '';
        this.totalExpense = 0;
        this.totalANSR = 0;
        this.netTotalNSR = 0;
        this.netTotalANSR = 0;
        this.totalNSR = 0;
        this.eaf = 0;
        this.engagementItems = [];
    }
}