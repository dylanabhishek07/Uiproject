import { engagementRevenueModel } from "./engagementRevenueModel";

export class engagementSummaryModel {

    workSpaceMasterGid: string;
    totalNSR: number;
    totalANSR: number;
    totalEAF: number;
    netTotalNSR: number;
    netTotalANSR: number;
    totalExpense: number;
    engagementRevenueList: engagementRevenueModel[];

    constructor() {
        this.workSpaceMasterGid = '';
        this.totalExpense = 0;
        this.totalANSR = 0;
        this.netTotalNSR = 0;
        this.netTotalANSR = 0;
        this.totalNSR = 0;
        this.totalEAF = 0;
        this.engagementRevenueList = [];
    }


}