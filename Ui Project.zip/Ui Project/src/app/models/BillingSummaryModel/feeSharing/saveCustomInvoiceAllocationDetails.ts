import { eitityWiseCustomInvoiceAllocationDetails } from "./eitityWiseCustomInvoiceAllocationDetails";

export class saveCustomFeeSharingTypeDetails {
    
        gId: string | null;
        workSpaceDetailMasterGId: string;
        engagementId: string;
        invoiceAllocation: number | null;
        createdBy: string | null | undefined;
        modifiedBy: string | null | undefined;
        eitityWiseCustomInvoiceAllocationDetails : eitityWiseCustomInvoiceAllocationDetails[];

        constructor(){
            this.gId="";
            this.workSpaceDetailMasterGId="";
            this.engagementId="";
            this.invoiceAllocation=null;
            this.createdBy="";
            this.modifiedBy="";
            this.eitityWiseCustomInvoiceAllocationDetails=[];
        }
      }

