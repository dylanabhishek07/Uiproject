export class eitityWiseCustomInvoiceAllocationDetails {
    gId: string | null;
    customInvoiceAllocationId: number;
    billingEntityID: string;
    billingEntityName: string;
    invoiceAllocation: number;
    createdBy: string | null | undefined;
    modifiedBy: string | null | undefined;

    constructor() {
        this.gId = ""; 
        this.customInvoiceAllocationId = 0; this.billingEntityID = ""; 
        this.billingEntityName = ""; this.invoiceAllocation = 0; this.createdBy = "";
         this.modifiedBy = "";
    }
}

