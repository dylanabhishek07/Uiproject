export class entityInvoiceDetailsData {
    
    billingEntityId : string;
    billingEntityName : string;
    invoiceFee : number;
    gId? : string;

    constructor()
    {
        this.billingEntityId="";
        this.billingEntityName="";
        this.invoiceFee=0;
    }
}