import { entityInvoiceDetailsData } from "./entityInvoiceDetailsData";


export class billingEntitySummaryModel {
    entityInvoiceDetails :  entityInvoiceDetailsData[];
    workSpaceMasterGid : string;
    totalInvoiceFee : number;

    constructor()
    {
        this.entityInvoiceDetails= [];
        this.workSpaceMasterGid='';
        this.totalInvoiceFee=0;
    }

}