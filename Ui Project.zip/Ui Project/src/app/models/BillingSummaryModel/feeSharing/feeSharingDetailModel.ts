import { engageMentConsolidatedRevenuesModel } from "./engageMentConsolidatedRevenuesModel";
import { entityInvoiceDetailsData } from "./entityInvoiceDetailsData";


export class feeSharingModel {
    workSpaceMasterGid: string;
    feeSharingType: number;
    netTotalNSR: number;
    netTotalANSR: number;
    netTotalExpense: number;
    totalInvoiveFee: number;
    engageMentConsolidatedRevenues: engageMentConsolidatedRevenuesModel[];
    entityInvoiceDetails: entityInvoiceDetailsData[];
    constructor() {
        this.workSpaceMasterGid = '';
        this.feeSharingType = 0;
        this.netTotalNSR = 0;
        this.netTotalANSR = 0;
        this.netTotalExpense = 0;
        this.totalInvoiveFee = 0;
        this.engageMentConsolidatedRevenues = [];
        this.entityInvoiceDetails = [];
    }

}