export class engageMentConsolidatedRevenuesModel {
    engagementId: string;
    totalNSR: number;
    totalANSR: number;
    expense: number;
    constructor() {
        this.engagementId = '';
        this.expense = 0;
        this.totalANSR = 0;
        this.totalNSR = 0;
    }
}