import { engagementWiseFeeSharingDetailsModel } from "./engagementWiseFeeSharingDetailsModel";

export class feeSharingDetailsResponsemodel {
    workspaceGid: string;
    engagementWiseFeeSharingDetails: engagementWiseFeeSharingDetailsModel[];

    constructor() {
        this.workspaceGid = "";
        this.engagementWiseFeeSharingDetails = [];
    }
}