import { entityInvoiceDetailsData } from "./entityInvoiceDetailsData";


export class engagementWiseFeeSharingDetailsModel {
    engagementId: string;
    totalInvoiceAllocation: number;
    entityInvoiceDetails: entityInvoiceDetailsData [];
    customInvoiceAllocationGId? : string;
    constructor() {
        this.engagementId = "";
        this.totalInvoiceAllocation = 0;
        this.entityInvoiceDetails = [];
    }
}