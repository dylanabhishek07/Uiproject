

export class feeSharingKendoDataSourceModel {
    Engagement: string;
    NSR: number;
    ANSR: number;
    Expense: number;
    EAF: number;
    InvoiceAllocation : number;
    EAFCurrentInvoice : number;
    gId: string;
    editable :boolean;
    constructor()
    {
        this.Engagement ="";
        this.NSR=0;
        this.ANSR=0;
        this.Expense=0;
        this.EAF=0;
        this.InvoiceAllocation=0;
        this.EAFCurrentInvoice=0;
        this.gId="";
        this.editable=true;
    }


}