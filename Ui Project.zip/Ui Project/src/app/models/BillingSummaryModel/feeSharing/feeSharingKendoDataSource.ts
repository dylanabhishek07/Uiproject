
// export class feeSharingKendoDataSource {
//     engagementId : string;
//     totalInvoiceAllocation : number;


// }