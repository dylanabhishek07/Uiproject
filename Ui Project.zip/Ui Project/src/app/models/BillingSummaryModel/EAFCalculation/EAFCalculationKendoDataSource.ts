export class EAFCalculationKendoDataSource{
    engagementId : string;
    etdnsr: number;
    etdExpense: number;
    etdInvoices: number;
    nui: number;
    etcnsr: number;
    etcExpenses: number;
    etcSales: number;
    etcToBeProcessed : boolean;
    isDeleted: boolean;
    createdBy?: string;
    modifiedBy?: string;
    CurrentinvoiceCF? : number;
    CurrentinvoiceMC ?: number;
    CurrentinvoiceSales? : number;
    PreviousEAF ?: number;
    gId : string | null;
    RevisedEAF ?: number;
    

    constructor()
    {
        this.engagementId = "";
        this.etcnsr = 0;
        this.etdExpense = 0;
        this.etdnsr = 0;
        this.etdInvoices = 0;
        this.nui = 0;

        this.etcExpenses = 0;
        this.etcSales = 0;
        this.CurrentinvoiceCF=0;
        this.CurrentinvoiceMC =0;
        this.CurrentinvoiceSales =0;
        this.PreviousEAF=0;
        this.etcToBeProcessed = true;
        this.isDeleted = true;
        this.createdBy = "";
        this.modifiedBy = "";
        this.gId = "";
        

    }

}