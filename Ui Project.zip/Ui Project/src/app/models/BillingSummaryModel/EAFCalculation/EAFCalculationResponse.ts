import { billsummeryEngagmentEAFDeatils } from "./billsummeryEngagmentEAFDeatils";

export class EAFCalculationResponse {
    workspaceMasterGid: string;
    billsummeryEngagmentEAFDeatils: billsummeryEngagmentEAFDeatils [];
    constructor()
    {
        this.workspaceMasterGid="";
        this.billsummeryEngagmentEAFDeatils=[];
    }
}