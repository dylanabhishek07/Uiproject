export class billsummeryEngagmentEAFDeatils {
    engagementId: string;
    etdnsr: number;
    etdExpense : number;
    etdInvoices: number;
    nui: number;
    etcnsr: number;
    etcExpenses: number;
    etcSales: number;
    etcToBeProcessed: boolean;
    isDeleted: boolean;
    createdBy?: string|undefined;
    modifiedBy?: string | undefined;
    gId : string| null;

    constructor() {
        this.engagementId = "";
        this.etcnsr = 0;
        this.etdExpense = 0;
        this.etdnsr = 0;
        this.etdInvoices = 0;
        this.nui = 0;

        this.etcExpenses = 0;
        this.etcSales = 0;
        this.etcToBeProcessed = true;
        this.isDeleted = true;
        this.createdBy = "";
        this.modifiedBy = "";
        this.gId =null;
    }

}
