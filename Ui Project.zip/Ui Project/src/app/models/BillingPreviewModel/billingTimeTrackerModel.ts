export class billingTimeTrackerModel {
    gid: string;
    itemID: string | undefined;
    datatype: number;
    constructor() {
        this.gid = "";
        this.itemID = "";
        this.datatype = 0;
    }
}