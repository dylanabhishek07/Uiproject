export class billingPreviewModel {

    Fee: number | undefined;
    Currency: string | undefined;
    Description: string | undefined;
    DataType: number;

    constructor(Fee: number, Currency: string, Description: string, DataType: number) {

        this.Fee = 0;
        this.Currency = "";
        this.Description = "";
        this.DataType = -1;
    }


}



