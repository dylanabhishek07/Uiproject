export class btTimeDetailsTransferModel {
    
    transferToWorkspaceGId: string;
    isSourceCategory: boolean;
    transferToDataCategory: number;
    finalProcessedTnEList: string[];
  

    constructor() {
        this.transferToWorkspaceGId = "";
        this.isSourceCategory = false;
        this.transferToDataCategory = 0;
        this.finalProcessedTnEList = [];   
    }

}