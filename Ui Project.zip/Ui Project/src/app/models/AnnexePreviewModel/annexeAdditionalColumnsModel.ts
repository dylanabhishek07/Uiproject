export class AnnexeAdditionalColumnsModel {
    columnGId: string;
    columnName: string;

    constructor() {
        this.columnGId = "";
        this.columnName = "";
    }
}