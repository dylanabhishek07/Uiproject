export class AnnexePreviewDistributionItemsModel {
    workSpaceRowGID: string;
    productID: string;
    serviceDescription: string;
    invoiceFee: number;
    oosnr: string;
    costCenter: string;
    gbtRef: string;
    feeText: string | null;
    currency: string;
    employee: string;
    product: string;
    productType: string;
    hours: number;
    gbtStatus: string;
    rowSequenceID: number;
    createdBy: string | undefined;
    modifiedBy: string | undefined;
    gId: string;
    
    constructor() {
        this.workSpaceRowGID = "";
        this.productID = "";
        this.serviceDescription = "";
        this.invoiceFee = 0;
        this.oosnr = "";
        this.costCenter = "";
        this.gbtRef = "";
        this.feeText = "";
        this.currency = "";
        this.employee = "";
        this.product = "";
        this.productType = "";
        this.hours = 0;
        this.gbtStatus = "";
        this.rowSequenceID = 0;
        this.createdBy = "";
        this.modifiedBy = "";
        this.gId = "";
    }
}