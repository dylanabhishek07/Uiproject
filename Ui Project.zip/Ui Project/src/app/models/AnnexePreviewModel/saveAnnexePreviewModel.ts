import { SaveAnnexePreviewDistributionModel } from "./saveAnnexePreviewDistributionModel";

export class SaveAnnexePreviewModel {
    workSpaceMasterGid: string;
    selectedColumnGIds: string[];
    annexPreviewDistribution: SaveAnnexePreviewDistributionModel[];

    constructor() {
        this.workSpaceMasterGid = "";
        this.selectedColumnGIds = [];
        this.annexPreviewDistribution = [];
    }
  }