import { AnnexePreviewDistributionItemsModel } from "./annexePreviewDistributionItemsModel";

export class AnnexePreviewDistributionModel {
    billingEntityId: string;
    billingEntityName: string;
    totalFee: number;
    annexPreviewDistributionItems: AnnexePreviewDistributionItemsModel[];

    constructor() {
        this.billingEntityId = "";
        this.billingEntityName = "";
        this.totalFee = 0;
        this.annexPreviewDistributionItems = [];
    }
}