export class SaveAnnexePreviewDataModel {
    workSpaceRowGId: string;
    feeText: string | null;
    createdBy: string | undefined | null;
    createdDateTime: string | null;
    modifiedBy: string | undefined |null;
    modifiedDateTime: string | null;

    constructor() {
        this.workSpaceRowGId = "";
        this.feeText = "";
        this.createdBy = "";
        this.createdDateTime = "";
        this.modifiedBy = "";
        this.modifiedDateTime = "";
    }
}