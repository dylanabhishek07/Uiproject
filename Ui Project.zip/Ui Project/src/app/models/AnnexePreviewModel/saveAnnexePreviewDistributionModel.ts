import { SaveAnnexePreviewDistributionItemsModel } from "./saveAnnexePreviewDistributionItemsModel";

export class SaveAnnexePreviewDistributionModel {
    billingEntityId: string;
    billingEntityName: string;
    totalFee: number;
    annexPreviewDistributionItems: SaveAnnexePreviewDistributionItemsModel[];

    constructor() {
        this.billingEntityId = "";
        this.billingEntityName = "";
        this.totalFee = 0;
        this.annexPreviewDistributionItems = [];
    }
}