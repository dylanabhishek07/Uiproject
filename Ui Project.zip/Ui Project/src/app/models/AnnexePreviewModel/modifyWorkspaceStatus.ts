export class ModifyWorkspaceStatus {
    workSpaceMasterGId: string;
    workSpaceStatus: number;
    modifiedBy: string | undefined;
    approvedBy: string | undefined | null;

    constructor() {
        this.workSpaceMasterGId = "";
        this.workSpaceStatus = 0;
        this.modifiedBy = "";
        this.approvedBy = "";
    }
}