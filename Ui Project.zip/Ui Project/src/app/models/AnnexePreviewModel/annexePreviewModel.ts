import { AnnexePreviewDistributionModel } from "./annexePreviewDistributionModel";

export class AnnexePreviewModel {
    workSpaceMasterGid: string;
    selectedOptionalColumnGIds: string[];
    annexPreviewDistribution: AnnexePreviewDistributionModel[];

    constructor() {
        this.workSpaceMasterGid = "";
        this.selectedOptionalColumnGIds = [];
        this.annexPreviewDistribution = [];
    }
}