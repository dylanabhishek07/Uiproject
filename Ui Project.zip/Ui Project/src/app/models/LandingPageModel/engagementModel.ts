export class engagementModel {
    
        gId: string;
        engagementId: string;
        engagementName: string;
        opportunityId: string;
        oppertunityDesc: string;
        sameopportunityId  : boolean;
      
    constructor() {
        this.gId = "";
        this.engagementId = "";
        this.engagementName = "";
        this.opportunityId = "";
        this.oppertunityDesc = "";
       this.sameopportunityId= false;
    }
}
