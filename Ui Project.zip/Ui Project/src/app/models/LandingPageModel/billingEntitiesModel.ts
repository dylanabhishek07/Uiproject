export class billingEntitiesModel {
    id: string;
    name: string;

    constructor() {
        this.id = "";
        this.name = "";
    }
}