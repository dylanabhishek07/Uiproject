export class currentUserModel {
    environment: string;
    homeAccountId: string;
    idTokenClaims ?: any;
    localAccountId: string
    name?: string | undefined;
    tenantId: string;
    username: string;
    constructor() {
        this.environment = '';
        this.homeAccountId = '';
        
        this.localAccountId = '';
        this.name = '';
        this.tenantId = '';
        this.username = '';

    }

}