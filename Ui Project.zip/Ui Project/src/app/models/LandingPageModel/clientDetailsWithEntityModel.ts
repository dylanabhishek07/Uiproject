import { billingEntitiesModel } from "./billingEntitiesModel";

export class clientDetailsWithEntityModel {
    clientId: string;
    clientName: string;
    billingEntities: billingEntitiesModel[];

    constructor() {
        this.clientId = "";
        this.clientName = "";
        this.billingEntities = [];
    }
}