export class wrkspaceDetail {

  
    workspaceName : string;
    clientEngagementMapGIds : string[];
    beOneWorkFlowId : string;
    createdBy : string | undefined | null;
    
   constructor ( workspaceName : string, clientEngagementMapGIds:string [],   beOneWorkFlowId : string)
   {

    this.workspaceName = workspaceName;
    this.clientEngagementMapGIds = clientEngagementMapGIds;
    this.beOneWorkFlowId= beOneWorkFlowId;
   
   }
    

}



