export class invoiceKendoDataSource {
    gId: string;
    entityId: string;
    entityName: string | null;
    workSpaceDetailMasterGId: string;
    invoiceType: number;
    processingDate: string | null;
    invoiceLanguage: number;
    periodStartData: string;
    periodEndData: string;
    clientName: string;
    clientAddress: string;
    clientContactName: string;
    netAmount: number;
    tFeesPercentage: number;
    coordinationFee: number;
    totalAmountExVat: number;
    vatAmount: number;
    totalAmountIncVat: number;
    currency: number;
    description: string;
    costCenter: string;
    preApprovalRequired: true;
    mailingAddress: string;
    totalInvoiceAllocation: number;
    comments: string;
    isDeleted: boolean;
    modifiedDateTime: string | null;
    modifiedBy: string | null

    constructor() {
    this.gId = "";
    this.entityId = "";
    this.entityName = "";
    this.workSpaceDetailMasterGId = "";
    this.invoiceType = 0;
    this.processingDate = "";
    this.invoiceLanguage = 0;
    this.periodStartData = "";
    this.periodEndData = "";
    this.clientName = "";
    this.clientAddress = "";
    this.clientContactName = "";
    this.netAmount = 0;
    this.tFeesPercentage = 0;
    this.coordinationFee = 0;
    this.totalAmountExVat = 0;
    this.vatAmount = 0;
    this.totalAmountIncVat = 0;
    this.currency = 0;
    this.description = "";
    this.costCenter = "";
    this.preApprovalRequired = true;
    this.mailingAddress = "";
    this.totalInvoiceAllocation = 0;
    this.comments = "";
    this.isDeleted = false;
    this.modifiedDateTime = "";
    this.modifiedBy = ""
    }
}