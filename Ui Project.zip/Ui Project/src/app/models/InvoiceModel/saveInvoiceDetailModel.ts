export class saveInvoiceDetailModel {

    gId: string;
    entityId: string;
    entityName: string;
    workSpaceDetailMasterGId: string;
    invoiceType: number;
    processingDate: string | null;
    invoiceLanguage: number;
    periodStartData: string | null;
    periodEndData: string | null;
    clientName: string;
    clientAddress: string;
    clientContactName: string;
    netAmount: number;
    tFeesPercentage: number;
    coordinationFee: number;
    totalAmountExVat: number;
    vatAmount: number;
    totalAmountIncVat: number;
    currency: number;
    description: string;
    costCenter: string;
    preApprovalRequired: boolean;
    mailingAddress: string;
    totalInvoiceAllocation: number;
    comments: string;
    isDeleted: boolean;
    modifiedDateTime: string | null;
    modifiedBy: string | undefined;

    constructor() {
        this.gId = "";
        this.entityId = "";
        this.clientAddress = "";
        this.clientContactName = "";
        this.clientName = "";
        this.comments = "";
        this.coordinationFee = 0;
        this.costCenter = "";
        this.currency = 0;
        this.description = "";
        this.entityId = "";
        this.entityName = "";
        this.invoiceLanguage = 0;
        this.invoiceType = 0;
        this.isDeleted = true;
        this.mailingAddress = "";
        this.modifiedBy = "";
        this.modifiedDateTime = '';
        this.netAmount = 0;
        this.periodEndData = '';
        this.periodStartData = '';
        this.preApprovalRequired = true;
        this.processingDate = '';
        this.totalInvoiceAllocation = 0;
        this.tFeesPercentage = 0;
        this.totalAmountExVat = 0;
        this.totalAmountIncVat = 0;

        this.vatAmount = 0;
        this.workSpaceDetailMasterGId = "";

    }

}