export class existingWrkspaceModel {
    
    workSpaceGuid: string;
    workspaceName: string;
    engagementIds: string;
    clientEngagementMapGIds: string[];
    beOneWorkFlowId: string;
    createdBy: string;
    authorizedFor : string;
    accessWrkspace : boolean;
    //isWrkspaceReady : boolean;
    statusId : number;

    constructor() {
        this.workSpaceGuid = "";
        this.workspaceName = "";
        this.engagementIds = "";
        this.clientEngagementMapGIds = [];  
        this.beOneWorkFlowId = "";
        this.createdBy = "" ;
        this.accessWrkspace=true;
        //this.isWrkspaceReady= false;
        this.authorizedFor ="";
        this.statusId= 0;
    }

}