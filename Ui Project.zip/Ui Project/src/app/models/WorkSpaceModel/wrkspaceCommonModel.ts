export class wrkspaceCommonModal {
        billingItemId?: string;
        billingAction: number;
        billingActionName? : string ;
        dataType: number;
        productId?: string;
        product?: string;
        activityId: number;
        activityDescription?: string;
        expenseReferenceId: string;
        clientName?: string;
        clientId?: string;
        billingStatus: string;
        productType?: string;
        employee?: string;
        employeeId?: string;
        productStatus?: string;
        billingType?: string;
        feeType?: string;
        hours: number;
        ansr: number;
        expenseAmount: number;
        invoiceFee?: number;
        currency?: string;
        serviceDescription?: string;
        billingEntity?: string;
        costCenter?: string;
        oosNr?: string;
        gbtRef?: string;
        gbtStatus?: string;
        invoiceVendor?: string;
        invoiceReference?: string;
    
        adjustedBillingAction?: number;
        adjustedInvoiceFee?: number;
        adjustedCurrency?: string;
        adjustedDescription?: string;
        adjustedBillingEntity?: string;
        adjustedBillingEntityId?: string;
        adjustedCostCenter?: string;
        adjustedOOSNR?: string;
        adjustedGBTStatus?: string;
        adjustedGBTRef?: string;
        modifiedBy: string;
        modifiedDateTime: string;
        gId: string;
        copyTo? : boolean;
    
        constructor() {
            this.billingAction = 0;
            this.dataType = 0;
            this.activityId = 0;
            this.expenseReferenceId = "";
            this.billingStatus = "";
            this.hours = 0;
            this.ansr = 0;
            this.expenseAmount = 0;
            this.modifiedBy = "";
            this.modifiedDateTime = "";
            this.gId = "";    
         
        }
    
    }



