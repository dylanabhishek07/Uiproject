export class wrkSpaceSpecificTneData {
timeDetailsHeader : string;
workSpaceGuid: string;
workSpaceDataType: number;

constructor() {
    this.timeDetailsHeader = "";
    this.workSpaceGuid = "";
    this.workSpaceDataType = 0;
}

}