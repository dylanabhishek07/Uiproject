export class calculatedWorkspaceTimeExpenseModel {
   GId: string;
   TotalHours: number;
   TotalANSR: number;
   TotalExpenseAmount: number;

   constructor() {
      this.GId = '';
      this.TotalHours = 0;
      this.TotalANSR = 0;
      this.TotalExpenseAmount = 0;

   }
}