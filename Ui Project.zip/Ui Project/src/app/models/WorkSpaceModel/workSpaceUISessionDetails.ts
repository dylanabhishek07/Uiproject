import { UIStageEnum } from "src/app/enums/UIStageEnum";
import { workspaceAdjustedData } from "../WorkSpaceModel/workspaceAdjustedData";

export class workSpaceUISessionDetails {
    

    stage: UIStageEnum;
    workspaceMasterGid: string;
    clientGId: string;
    workspaceName: string;
    clientName: string;
    engagements: string[];
    modifiedWorkSpaceDetails : workspaceAdjustedData[];
    constructor(
        stage:UIStageEnum,
        workspaceMasterGid:string,
        ClientGId: string,
        WorkspaceName: string,
        ClientName: string,
        Engagements: string[],
        WorkSpaceAdjustedDetails: workspaceAdjustedData[]
        ) {
       
        this.clientGId = ClientGId;
        this.stage = stage;
        this.workspaceMasterGid = workspaceMasterGid;
        this.engagements = Engagements;
        this.modifiedWorkSpaceDetails = WorkSpaceAdjustedDetails;
        this.clientName=ClientName;
        this.workspaceName=WorkspaceName;
    }
}