export class workspaceAdjustedData {
    gId: string;
    workSpaceDataType: number;
    adjustedBillingAction?: number;
    adjustedInvoiceFee?: number;
    adjustedCurrency?: string;
    adjustedDescription?: string;
    adjustedBillingEntity?: string;
    adjustedBillingEntityId?: string;
    adjustedCostCenter?: string;
    adjustedOOSNR?: string;
    adjustedGBTStatus?: string;
    adjustedGBTRef?: string
    modifiedBy: string;
    modifiedDateTime: string | null;
    invoiceFee?: number;
    billingEntityName?: string;
    billingEntityId?: string;
    billingActionId: number;
    productID: string | undefined;
    serviceDescription: string | undefined;
    OOSNR: string | undefined;
    costCenter : string | undefined;
    GBTRef : string | undefined;
    currency: string | undefined;
    employee: string | undefined;
    product: string | undefined;
    productType: string | undefined;
    hours: number;
    gbtStatus: string | undefined;

    constructor() {
        this.gId = "";
        this.workSpaceDataType = 0;
        this.adjustedBillingAction = 0;
        this.adjustedInvoiceFee = 0;
        this.adjustedCurrency = "";
        this.adjustedDescription = "";
        this.adjustedBillingEntity = "";
        this.adjustedCostCenter = "";
        this.adjustedOOSNR = "";
        this.adjustedGBTStatus = "";
        this.adjustedGBTRef = "";
        this.modifiedBy = "";
        this.invoiceFee = 0;
        this.billingEntityId = "";
        this.billingEntityName = "";
        this.billingActionId = 0;
        this.modifiedDateTime = null;
        this.productID = "";
        this.serviceDescription = "";
        this.OOSNR = "";
        this.costCenter ="";
        this.GBTRef= "";
        this.currency = "";
        this.employee = "";
        this.product = "";
        this.productType = "";
        this.hours = 0;
        this.gbtStatus = "";
    }

}