export class workspaceTrackingModel {

  
    workspaceId : string;
    workSpaceName : string;
    selectedEngagementIDS : string;
    clientName : string;
    readonly : boolean;
   constructor ( )
   {

    this.workspaceId = "";
    this.workSpaceName ="" ;
    this.selectedEngagementIDS= "";
    this.clientName = "";
    this.readonly = false;
   }
    

}