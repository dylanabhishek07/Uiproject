import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MsalGuard, MsalRedirectComponent } from '@azure/msal-angular';
import { AuthGuard } from './auth.guard';
import { AnnexePreviewComponent } from './modules/billing/annexe-preview/annexe-preview.component';
import { InvoiceDetailsComponent } from './modules/billing/invoice-details/invoice-details/invoice-details.component';
import { InvoicesComponent } from './modules/billing/invoices/invoices/invoices.component';
import { LandingComponent } from './modules/billing/landing/landing/landing.component';
import { PreviewComponent } from './modules/billing/preview/preview/preview.component';
import { SummaryComponent } from './modules/billing/summary/summary/summary.component';
import { TimeDetailsComponent } from './modules/billing/timeDetails/time-details/time-details.component';
import { WorkspaceComponent } from './modules/billing/workspace/workspace/workspace.component';
import { LoginPageComponent } from './modules/login/loginPage/login-page/login-page.component';

const routes: Routes = [
  { path: '', component: LoginPageComponent },
  {
    path: 'invoice', component: InvoicesComponent, canActivate: [
      MsalGuard, AuthGuard]
  },
  {
    path: 'workspace', component: WorkspaceComponent, canActivate: [
      MsalGuard, AuthGuard]
  },
  {
    path: 'preview', component: PreviewComponent, canActivate: [
      MsalGuard, AuthGuard]
  },
  {
    path: 'summary', component: SummaryComponent, canActivate: [
      MsalGuard, AuthGuard]
  },
  {
    path: 'timeDetails', component: TimeDetailsComponent, canActivate: [
      MsalGuard, AuthGuard]
  },
  { path: 'login', component: LoginPageComponent},
  {
    path: 'landing', component: LandingComponent, canActivate: [
      MsalGuard, AuthGuard]
  },
  {
    path: 'annexe-preview', component: AnnexePreviewComponent, canActivate: [
      MsalGuard, AuthGuard]
  },
  {
    path: 'invoice-details', component: InvoiceDetailsComponent, canActivate: [
      MsalGuard, AuthGuard]
  },
  { path: 'auth', component: MsalRedirectComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
