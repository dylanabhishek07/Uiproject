import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import { AppSettings } from './services/CommonService/app-settings';

@Injectable({
  providedIn: 'root'
})
export class CustomGuard implements CanActivate {
  constructor(private appSettings: AppSettings, private router: Router) { }
  canActivate(
    route: ActivatedRouteSnapshot,
    state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
      if(this.appSettings.isUserLoggedIn) {
        this.router.navigate(['/landing']);
        return false;
      }
      else {
        return true;
      }
  }  
}
