// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  apiURL: "https://bbactpapi01.azurewebsites.net/api/v1.0/",
  clientId: '5b3a7398-e718-4b74-b3e3-a378e96b20ae',
  authority: 'https://login.microsoftonline.com/adb53b4f-b05f-4dcb-a2e1-9111380568c3',
  redirectUri: 'http://localhost:4200/',//https://bbactpui01.azurewebsites.net/',
  scope : 'api://7ef50ef1-d7d8-43bf-bab1-68dff195b791/.default'
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
